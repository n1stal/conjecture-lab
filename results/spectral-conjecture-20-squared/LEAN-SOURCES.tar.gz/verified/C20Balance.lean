import C20Triangle
import C20Bench
namespace Conjecture20Squared
open Matrix Finset SpectralConjecture20 PawUnbounded TriangleSpectralFence
open scoped BigOperators Matrix
noncomputable def balanced (n : Nat) :=
  withIsolates TriangleSpectralFence.triangleSeed (TriangleSpectralFence.triangleWeights n n n) 0
theorem balanced_quotient_spectrum (n : Nat) (hn : 3 ≤ n) :
    let w := triangleWeights n n n
    let hQ := weightedQuotient_isHermitian triangleSeed triangleSeedHermitian w
    sorted3 hQ 0=2*(n:ℝ) ∧ sorted3 hQ 1= -(n:ℝ) ∧ sorted3 hQ 2= -(n:ℝ) := by
  let w := triangleWeights n n n
  let hQ := weightedQuotient_isHermitian triangleSeed triangleSeedHermitian w
  let q := sorted3 hQ
  let U := triangleQ (Real.sqrt (n:ℝ)) (Real.sqrt (n:ℝ)) (Real.sqrt (n:ℝ))
  have hE : weightedQuotient triangleSeed w=U := triangleQ_quotient n n n
  let hU : U.IsHermitian := hE ▸ hQ
  have hf (x : ℝ) : generalTriPoly n n n x=(x-q 0)*(x-q 1)*(x-q 2) := by
    have hs := sorted3_congr hQ hU hE
    dsimp only [q]
    rw [hs]
    have hp := tri_factor_sorted (Real.sqrt (n:ℝ)) (Real.sqrt (n:ℝ)) (Real.sqrt (n:ℝ)) x hU
    simpa only [Real.sq_sqrt (Nat.cast_nonneg _)] using hp
  have hP (x : ℝ) : generalTriPoly n n n x=(x-2*(n:ℝ))*(x+(n:ℝ))^2 := by
    unfold generalTriPoly; ring
  have hc (i : Fin 3) : q i=2*(n:ℝ) ∨ q i= -(n:ℝ) := by
    have h := hf (q i)
    rw [hP] at h
    have hz : (q i-2*(n:ℝ))*(q i+(n:ℝ))^2=0 := by fin_cases i <;> simpa using h
    rcases mul_eq_zero.mp hz with h | h
    · exact Or.inl (by linarith)
    · exact Or.inr (by have := eq_zero_of_pow_eq_zero h; linarith)
  have htr := (tri_moments n n n (q 0) (q 1) (q 2) hf).1
  have hAnti := sorted3_antitone hQ
  have ha : q 1 ≤ q 0 := hAnti (by decide)
  have hb : q 2 ≤ q 1 := hAnti (by decide)
  have hnR : (3:ℝ) ≤ n := by exact_mod_cast hn
  rcases hc 0 with h0|h0 <;> rcases hc 1 with h1|h1 <;> rcases hc 2 with h2|h2 <;>
    first | exact ⟨h0,h1,h2⟩ | exfalso; linarith

theorem balanced_card (n : Nat) :
    Fintype.card (Vertices (triangleWeights n n n) ⊕ Fin 0)=3*n := by
  rw [card_blowup_vertices]
  simp [triangleWeights,Fin.sum_univ_succ]
  omega

theorem balanced_matches_target (n : Nat) (hn : 3 ≤ n)
    (hF : (balanced n).IsHermitian) :
    hF.eigenvalues₀=target n _ := by
  let w := triangleWeights n n n
  let N := Fintype.card (Vertices w ⊕ Fin 0)
  let f : Fin N → ℝ := hF.eigenvalues₀
  let hQ := weightedQuotient_isHermitian triangleSeed triangleSeedHermitian w
  let q := sorted3 hQ
  have hN : N=3*n := balanced_card n
  have wh (j : Fin N) : 3*n ≤ j.val+2 ↔ j.rev.val < 2 := by
    rw [Fin.val_rev]; have := j.isLt; omega
  have hw (i : Fin 3) : 0 < w i := by fin_cases i <;> exact (show 0 < n by omega)
  have hf : Antitone f := hF.eigenvalues₀_antitone
  have hq : Antitone q := sorted3_antitone hQ
  have hSort (s u : ℝ) (hu : 0 ≤ u) :
      Fintype.card {i // u < s*f i} = Fintype.card {j // u < s*q j} := by
    have hh := withIsolates_quotient_sorted_cut triangleSeed triangleSeedHermitian w hw 0 hF s u hu
    exact hh.trans (Fintype.card_congr (Equiv.subtypeEquiv (finCongr (Fintype.card_fin 3)) (fun _=>Iff.rfl)))
  have hPos (u : ℝ) (hu : 0 ≤ u) :
      Fintype.card {i // u < f i}=Fintype.card {j // u < q j} := by simpa only [one_mul] using hSort 1 u hu
  have hNeg (u : ℝ) (hu : 0 ≤ u) :
      Fintype.card {i : Fin N // u < -f i.rev}=Fintype.card {j : Fin 3 // u < -q j.rev} := by
    rw [←signed_reversed_cuts f,←signed_reversed_cuts q]
    simpa only [neg_one_mul] using hSort (-1) u hu
  obtain ⟨hq0,hq1,hq2⟩ := balanced_quotient_spectrum n hn
  change q 0=2*(n:ℝ) at hq0
  change q 1= -(n:ℝ) at hq1
  change q 2= -(n:ℝ) at hq2
  have hnR : (3:ℝ) ≤ n := by exact_mod_cast hn
  have hqP : 0 < q 0 := by linarith
  have countP : Fintype.card {i // 0 < f i}=1 := by
    rw [hPos 0 (by norm_num),Fintype.card_subtype,Finset.card_eq_sum_ones,Finset.sum_filter]
    change (∑ i : Fin 3, if 0 < q i then (1:Nat) else 0)=1
    rw [Fin.sum_univ_three,hq0,hq1,hq2]
    simp only [ite_eq_left (show (0:ℝ)<2*n by positivity),ite_eq_right (show ¬(0:ℝ)< -(n:ℝ) by linarith)]
  have countN : Fintype.card {i : Fin N // 0 < -f i.rev}=2 := by 
    rw [hNeg 0 (by norm_num),←signed_reversed_cuts q,Fintype.card_subtype,Finset.card_eq_sum_ones,Finset.sum_filter]
    change (∑ i : Fin 3, if 0 < -q i then (1:Nat) else 0)=2
    rw [Fin.sum_univ_three,hq0,hq1,hq2]
    simp only [neg_neg,ite_eq_left (show (0:ℝ)<n by linarith),ite_eq_right (show ¬(0:ℝ)< -(2*(n:ℝ)) by linarith)]
  have hfR := antitone_neg_rev f hf
  have hqR := antitone_neg_rev q hq
  ext i
  change f i=target n N i
  by_cases hi : i.val=0
  · have h : 0 < f i := (cut_count_rank_iff f hf 0 i).mpr (by omega)
    have eq := equal_coord_of_nonnegative_cut_counts f q hf hq i 0 hi h.le hqP.le hPos
    rw [eq,hq0]; simp [target,hi]
  by_cases hr : i.rev.val < 2
  · let j : Fin 3 := ⟨i.rev.val,by omega⟩
    have h : 0 < -f i.rev.rev := (cut_count_rank_iff _ hfR 0 i.rev).mpr (by omega)
    have hp : 0 < -q j.rev := by
      have hnJ : j=0 ∨ j=1 := by
        have ej : j.val=0 ∨ j.val=1 := by change i.rev.val=0 ∨ i.rev.val=1; omega
        exact ej.imp (fun h => Fin.ext h) (fun h => Fin.ext h)
      rcases hnJ with ej|ej
      · rw [ej]; change 0 < -q 2; linarith
      · rw [ej]; change 0 < -q 1; linarith
    have eq := equal_coord_of_nonnegative_cut_counts _ _ hfR hqR i.rev j rfl h.le hp.le hNeg
    change -f i.rev.rev = -q j.rev at eq
    rw [Fin.rev_rev] at eq
    have hj : q j.rev= -(n:ℝ) := by
      have ej : j.val=0 ∨ j.val=1 := by change i.rev.val=0 ∨ i.rev.val=1; omega
      rcases ej with he|he
      · have hh : j=0 := Fin.ext he
        rw [hh]; exact hq2
      · have hh : j=1 := Fin.ext he
        rw [hh]; exact hq1
    have ht : 3*n ≤ i.val+2 := (wh i).mpr hr
    simp [target,hi,ht]
    linarith only [eq,hj]
  · have h₀ : ¬0 < f i := by
      intro h
      have hh := (cut_count_rank_iff f hf 0 i).mp h
      omega
    have h₁ : ¬f i < 0 := by
      intro h
      have h' : 0 < -f i.rev.rev := by simpa using neg_pos.mpr h
      have hh := (cut_count_rank_iff _ hfR 0 i.rev).mp h'
      omega
    have hZ : f i=0 := by linarith
    have ht : ¬3*n ≤ i.val+2 := fun h => hr ((wh i).mp h)
    simp [target,hi,ht,hZ]


#print axioms balanced_matches_target
end Conjecture20Squared
