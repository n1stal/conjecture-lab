import C20Weighted
import C20ProfileProbe

namespace PawUnbounded
open Matrix Finset SpectralConjecture20
open scoped BigOperators Matrix

theorem card_blowup_vertices {m : Type*} [Fintype m] (w : m → Nat) (z : Nat) :
    Fintype.card (Vertices w ⊕ Fin z)=(∑ i,w i)+z := by
  simp [Vertices,Fintype.card_sum,Fintype.card_sigma]

theorem ordered_eigenvalue_sum {m : Type*} [Fintype m] [DecidableEq m]
    (A : Matrix m m ℝ) (hA : A.IsHermitian) : (∑ i,hA.eigenvalues₀ i)=A.trace := by
  rw [hA.trace_eq_sum_eigenvalues]
  exact (Equiv.sum_comp (Fintype.equivOfCardEq (Fintype.card_fin _)).symm hA.eigenvalues₀).symm

theorem ordered_eigenvalue_sum_zero_of_diag {m : Type*} [Fintype m] [DecidableEq m]
    (A : Matrix m m ℝ) (hA : A.IsHermitian) (hd : ∀ i,A i i=0) :
    (∑ i,hA.eigenvalues₀ i)=0 := by
  rw [ordered_eigenvalue_sum A hA]
  simp [Matrix.trace,Matrix.diag_apply,hd]

theorem withIsolates_diagonal_zero {m : Type*} (B : Matrix m m ℝ) (hD : ∀ i,B i i=0)
    (w : m → Nat) (z : Nat) (i : Vertices w ⊕ Fin z) :
    withIsolates B w z i i=0 := by
  cases i with
  | inl i => exact hD i.1
  | inr i => rfl

#print axioms ordered_eigenvalue_sum_zero_of_diag
end PawUnbounded


namespace Conjecture20Squared
open Matrix Finset SpectralConjecture20 UnitPruning PawUnbounded
open scoped BigOperators Matrix
noncomputable def score {m : Type*} [Fintype m] [DecidableEq m]
    (n : Nat) (B : Matrix m m ℝ) (h : B.IsHermitian) : ℝ :=
  ∑ i, (h.eigenvalues₀ i-target n (Fintype.card m) i)^2
def RelabelAs {m k : Type*} (A : Matrix m m ℝ) (B : Matrix k k ℝ) : Prop :=
  ∃ e : k ≃ m, A.submatrix e e = B
noncomputable def hub (n : Nat) :=
  withIsolates PawUnbounded.seedPaw (singletonWeights (n-1) n n) 0
theorem padded_herm {m : Type*} (B : Matrix m m ℝ) (hB : B.IsHermitian)
    (w : m → Nat) (z : Nat) : (withIsolates B w z).IsHermitian := by
  rw [Matrix.IsHermitian.ext_iff]
  intro i j
  cases i <;> cases j
  · exact Matrix.IsHermitian.ext_iff.mp hB _ _
  all_goals simp [withIsolates]
theorem score_relabel {m k : Type*} [Fintype m] [Fintype k] [DecidableEq m] [DecidableEq k]
    (n : Nat) (A : Matrix m m ℝ) (hA : A.IsHermitian) (B : Matrix k k ℝ)
    (hB : B.IsHermitian) (e : k ≃ m) (he : B=A.submatrix e e) :
    score n B hB=score n A hA :=
  squared_distance_submatrix_equiv A hA B hB e he (target n _)
theorem hub_card (n : Nat) (hn : 1 ≤ n) :
    Fintype.card (Vertices (singletonWeights (n-1) n n) ⊕ Fin 0)=3*n := by
  rw [card_blowup_vertices]
  simp [singletonWeights,Fin.sum_univ_four]; omega

theorem hub_herm (n : Nat) : (hub n).IsHermitian :=
  padded_herm seedPaw seedHerm (singletonWeights (n-1) n n) 0

theorem hub_score_bounds (n : Nat) (hn : 3 ≤ n) : 
    0 < score n _ (hub_herm n) ∧ score n _ (hub_herm n) < (16/27:ℝ) := by
  have hsz := hub_card n (by omega)
  have hN : 4 ≤ Fintype.card (Vertices (singletonWeights (n-1) n n) ⊕ Fin 0) := by omega
  obtain ⟨hy0,hy1,hy2,hy3,_,_,_,_,_,_,hyR⟩ := profile n _ hn hsz
  refine ⟨?_,(actual_hub_benchmark_scores n 0 hn (hub_herm n) hN (target n _) hy0 hy1 hy2 hy3 hyR).1⟩
  unfold score
  have he := singleton_ordered_quartet_score_eq n (n-1) n n 0 (by omega) (by omega) (by omega)
    (hub_herm n) hN (target n _) hy0 hy1 hy2 hy3 hyR (fun x=>x^2) (by norm_num)
  refine lt_of_lt_of_eq ?_ he.symm
  have h := singleton_second_pos (n-1) n n (by omega) (by omega) (by omega)
  positivity

theorem positive_score_iff (n : Nat) {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (hB : B.IsHermitian) :
    0 < score n B hB ↔ hB.eigenvalues₀≠target n (Fintype.card m) := by
  classical
  unfold score
  constructor
  · intro h he
    simp [he] at h
  · intro h
    by_contra! hc
    have h0 : ∑ i,(hB.eigenvalues₀ i-target n (Fintype.card m) i)^2=0 :=
      le_antisymm hc (Finset.sum_nonneg (fun i _ => sq_nonneg _))
    apply h
    funext i
    have hh := (Finset.sum_eq_zero_iff_of_nonneg (fun i _ => sq_nonneg
      (hB.eigenvalues₀ i-target n (Fintype.card m) i))).mp h0 i (Finset.mem_univ i)
    exact sub_eq_zero.mp (eq_zero_of_pow_eq_zero hh)


end Conjecture20Squared

#print axioms Conjecture20Squared.hub_score_bounds

#print axioms Conjecture20Squared.positive_score_iff
