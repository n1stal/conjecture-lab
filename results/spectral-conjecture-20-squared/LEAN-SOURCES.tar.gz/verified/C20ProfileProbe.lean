import Mathlib.Analysis.Matrix.Spectrum
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
namespace Conjecture20Squared
open Matrix Finset
open scoped BigOperators Matrix
noncomputable def target (n N : Nat) (i : Fin N) : ℝ :=
  if i.val=0 then 2*(n:ℝ) else if 3*n ≤ i.val+2 then -(n:ℝ) else 0

theorem profile (n N : Nat) (hn : 3 ≤ n) (hN : N=3*n) :
    let y := target n N
    y ⟨0,by omega⟩=2*(n:ℝ) ∧ y ⟨1,by omega⟩=0 ∧
    y (Fin.rev ⟨1,by omega⟩)= -(n:ℝ) ∧ y (Fin.rev ⟨0,by omega⟩)= -(n:ℝ) ∧
    (∀ i, -(n:ℝ) ≤ y i) ∧ (∀ i, y i≠0 → 1 ≤ |y i|) ∧
    Fintype.card {i // 0 < y i}=1 ∧ Fintype.card {i // y i < 0}=2 ∧
    Fintype.card {i // y i= -(n:ℝ)}=2 ∧ (∀ i, y i < 0 → y i≤ -3) ∧
    (∀ i : Fin N, 2 ≤ i.val → 2 ≤ i.rev.val → y i=0) := by
  classical
  have hnR : (3:ℝ) ≤ n := by exact_mod_cast hn
  have wh (i : Fin N) : 3*n ≤ i.val+2 ↔ i.rev.val < 2 := by rw [Fin.val_rev]; have := i.isLt; omega
  have hP (i : Fin N) : 0 < target n N i ↔ i.val=0 := by
    unfold target
    split
    · simp_all; linarith
    · split <;> simp_all
  have hM (i : Fin N) : target n N i < 0 ↔ i.rev.val < 2 := by
    rw [←wh i]
    unfold target
    split_ifs with hz ht
    · exact ⟨fun h => by exfalso; linarith, fun h => by exfalso; omega⟩
    · exact ⟨fun _ => ht, fun _ => by linarith⟩
    · exact ⟨fun h => by exfalso; linarith, fun h => (ht h).elim⟩
  have hLast (i : Fin N) : target n N i = -(n:ℝ) ↔ i.rev.val < 2 := by
    rw [←wh i]
    unfold target
    split_ifs with hz ht
    · exact ⟨fun h => by exfalso; linarith, fun h => by exfalso; omega⟩
    · exact ⟨fun _ => ht, fun _ => rfl⟩
    · exact ⟨fun h => by exfalso; linarith, fun h => (ht h).elim⟩
  let eP : {i : Fin N // i.val=0} ≃ Fin 1 :=
    { toFun := fun _ => 0
      invFun := fun _ => ⟨⟨0,by omega⟩,rfl⟩
      left_inv := fun i => Subtype.ext (Fin.ext i.property.symm)
      right_inv := fun i => Subsingleton.elim _ _ }
  let eM : {i : Fin N // i.rev.val < 2} ≃ Fin 2 :=
    { toFun := fun i => ⟨i.val.rev.val,i.property⟩
      invFun := fun j => ⟨(⟨j.val,by have := j.isLt; omega⟩ : Fin N).rev,by simp [j.isLt]⟩
      left_inv := by
        intro i
        apply Subtype.ext
        exact Fin.rev_rev i.1
      right_inv := by
        intro j
        apply Fin.ext
        change ((⟨j.val,by have := j.isLt; omega⟩ : Fin N).rev.rev).val = j.val
        rw [Fin.rev_rev] }
  refine ⟨?_,?_,?_,?_,?_,?_,?_,?_,?_,?_,?_⟩
  · simp [target]
  · simp [target,show ¬3*n ≤ 1+2 by omega]
  · exact (hLast _).mpr (by simp)
  · exact (hLast _).mpr (by simp)
  · intro i; unfold target; split_ifs <;> linarith
  · intro i hi
    by_cases h0 : i.val = 0
    · have he : target n N i = 2*(n:ℝ) := ite_eq_left h0
      rw [he,abs_of_nonneg (by positivity)]
      linarith
    · by_cases ht : 3*n ≤ i.val+2
      · have he := (hLast i).mpr ((wh i).mp ht)
        rw [he,abs_neg,abs_of_nonneg (by positivity)]
        linarith
      · exact (hi (by simp only [target,ite_eq_right h0,ite_eq_right ht])).elim
  · rw [Fintype.card_congr (Equiv.subtypeEquivRight hP),Fintype.card_congr eP,Fintype.card_fin]
  · rw [Fintype.card_congr (Equiv.subtypeEquivRight hM),Fintype.card_congr eM,Fintype.card_fin]
  · rw [Fintype.card_congr (Equiv.subtypeEquivRight hLast),Fintype.card_congr eM,Fintype.card_fin]
  · intro i hi; rw [(hLast i).mpr ((hM i).mp hi)]; linarith
  · intro i hi hr; simp [target,show i.val≠0 by omega,show ¬3*n ≤ i.val+2 by rw [wh]; omega]

#print axioms profile
end Conjecture20Squared
