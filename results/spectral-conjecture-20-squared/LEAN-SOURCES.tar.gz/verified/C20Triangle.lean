import C20Weighted
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import Mathlib.Tactic.FieldSimp
import Mathlib.Analysis.Real.Sqrt
import Mathlib.Analysis.Matrix.Spectrum
import Mathlib.LinearAlgebra.Matrix.Charpoly.Basic









namespace TriangleSpectralFence
open Matrix
open scoped Matrix
def triPoly (n k x : ℝ) : ℝ :=
  x^3-(3*n^2-k^2)*x-2*n*(n^2-k^2)

theorem tripartite_fence (n k : ℝ) (hn : 3 ≤ n) (hk : 1 ≤ k) (hkn : k ≤ n-1) :
    let d := (k^2+1/3)/(3*n)
    0 < 2*n-d ∧ 0 < triPoly n k (2*n-d) := by
  dsimp only
  let d : ℝ := (k^2+1/3)/(3*n)
  change 0 < 2*n-d ∧ 0 < triPoly n k (2*n-d)
  have hn0 : 0 < n := by linarith
  have h1 : 0 ≤ k-1 := by linarith
  have h2 : 0 ≤ k+1 := by linarith
  have hl : 0 ≤ n-k-1 := by linarith
  have hr : 0 ≤ n+k := by linarith
  have hksq : 1 ≤ k^2 := by nlinarith [mul_nonneg h1 h2]
  have hk2 : k^2 + 1/3 < n^2 := by nlinarith [mul_nonneg hl hr]
  have hdn : 3*n*d = k^2+1/3 := by
    dsimp [d]
    field_simp
  have hd : 0 < d := by dsimp [d]; positivity
  have hsmall : d < n/3 := by
    by_contra! hh
    have hh' : 0 ≤ 3*d-n := by linarith
    nlinarith [mul_nonneg hh' hn0.le]
  have hp : 0 < (6*n-d)*d-k^2 := by
    have hm := mul_nonneg (show 0 ≤ n/3-d by linarith) hd.le
    nlinarith
  have heq : triPoly n k (2*n-d) = n*(k^2-1)+d*((6*n-d)*d-k^2) := by
    unfold triPoly
    have h := congrArg (fun y : ℝ => (-3*n)*y) hdn
    nlinarith only [h]
  refine ⟨by linarith, ?_⟩
  rw [heq]
  exact add_pos_of_nonneg_of_pos (mul_nonneg hn0.le (by linarith)) (mul_pos hd hp)

theorem exclude_unbalanced_tripartite (n k r b c : ℝ)
    (hn : 3 ≤ n) (hk : 1 ≤ k) (hkn : k ≤ n-1)
    (hb : b ≤ 0) (hc : c ≤ 0) (htrace : r+b+c = 0)
    (hsecond : r^2+b^2+c^2 = 6*n^2-2*k^2)
    (hfactor : ∀ x : ℝ, triPoly n k x = (x-r)*(x-b)*(x-c)) :
    (2/3 : ℝ) < (r-2*n)^2+(b+n)^2+(c+n)^2 := by
  let d : ℝ := (k^2+1/3)/(3*n)
  let x : ℝ := 2*n-d
  have hx : 0 < x ∧ 0 < triPoly n k x := tripartite_fence n k hn hk hkn
  have hxr : 0 < x-r := by
    by_contra! h
    have he := mul_nonpos_of_nonpos_of_nonneg
      (mul_nonpos_of_nonpos_of_nonneg h (show 0 ≤ x-b by linarith [hx.1]))
      (show 0 ≤ x-c by linarith [hx.1])
    rw [← hfactor] at he
    exact (not_lt_of_ge he) hx.2
  have hn0 : 0 < n := by linarith
  have hdn : 3*n*d = k^2+1/3 := by
    dsimp [d]
    field_simp
  have hh : 2*n-r>d := by dsimp [x] at hxr; linarith
  have hg := mul_lt_mul_of_pos_left hh hn0
  have ht := congrArg (fun x : ℝ => 2*n*x) htrace
  nlinarith [ht, hg, hdn, hsecond]

def generalTriPoly (a t c x : ℝ) : ℝ :=
  x^3 - (a*t+a*c+t*c)*x - 2*a*t*c

/-- The middle part weight lies between the magnitudes of the two negative roots.
The sign of the cubic at its negative avoids separate rank-one interlacing. -/
theorem median_weight_fence
    (a t c r b g : ℝ) (ht : 0 < t) (hat : a ≤ t) (htc : t ≤ c) (hr : 0 < r) (hbg : g ≤ b)
    (hf : ∀ x : ℝ, generalTriPoly a t c x = (x-r)*(x-b)*(x-g)) :
    g ≤ -t ∧ -t ≤ b := by
  have hsign : 0 ≤ generalTriPoly a t c (-t) := by
    have he : generalTriPoly a t c (-t) = t*(t-a)*(c-t) := by
      unfold generalTriPoly
      ring
    rw [he]
    exact mul_nonneg (mul_nonneg ht.le (by linarith)) (by linarith)
  have hx : -t-r < 0 := by linarith
  have hp : (-t-b)*(-t-g) ≤ 0 := by
    by_contra! hn
    have h := mul_neg_of_neg_of_pos hx hn
    rw [←mul_assoc, ←hf] at h
    exact (not_lt_of_ge hsign) h
  constructor
  · by_contra! hh
    exact (not_lt_of_ge hp) (mul_pos_of_neg_of_neg (by linarith) (by linarith))
  · by_contra! hh
    exact (not_lt_of_ge hp) (mul_pos (by linarith) (by linarith))

/-- If both negative eigenvalues are in the radius-1 target band, their
intermediate positive integer part weight is exactly the target n. -/
theorem median_int_exact (t n : ℤ) (b g : ℝ)
    (hg : g ≤ -(t : ℝ)) (hb : -(t : ℝ) ≤ b)
    (h₁ : -(n : ℝ)-1 < g) (h₂ : b < -(n : ℝ)+1) : t = n := by
  have hh₁ : (t : ℝ) < (n : ℝ)+1 := by linarith
  have hh₂ : (n : ℝ)-1 < (t : ℝ) := by linarith
  have h₃ : t < n+1 := by exact_mod_cast hh₁
  have h₄ : n-1 < t := by exact_mod_cast hh₂
  omega

def triangleQ (u v w : ℝ) : Matrix (Fin 3) (Fin 3) ℝ :=
  !![0,u*v,u*w;u*v,0,v*w;u*w,v*w,0]

theorem det_triangle (u v w x : ℝ) :
    (Matrix.scalar (Fin 3) x - triangleQ u v w).det =
      generalTriPoly (u^2) (v^2) (w^2) x := by
  unfold triangleQ generalTriPoly
  simp [Matrix.det_fin_three, Matrix.sub_apply, Matrix.scalar_apply]
  ring

theorem tri_factor (u v w x : ℝ) (h : (triangleQ u v w).IsHermitian) :
    generalTriPoly (u^2) (v^2) (w^2) x =
      (x-h.eigenvalues 0)*(x-h.eigenvalues 1)*(x-h.eigenvalues 2) := by
  rw [←det_triangle, ←Matrix.eval_charpoly, h.charpoly_eq, Polynomial.eval_prod]
  simp [Fin.prod_univ_succ, Fin.succ_zero_eq_one, Fin.succ_one_eq_two, mul_assoc]

/-- Both spectral moments follow from the cubic factorization without any
    additional hypothesis on the vectors used to obtain the eigenvalues. -/
theorem tri_moments (a t c r b g : ℝ)
    (hf : ∀ x : ℝ, generalTriPoly a t c x = (x-r)*(x-b)*(x-g)) :
    r+b+g=0 ∧ r^2+b^2+g^2=2*(a*t+a*c+t*c) := by
  have h0 := hf 0
  have h1 := hf 1
  have hm := hf (-1)
  unfold generalTriPoly at h0 h1 hm
  have htr : r+b+g=0 := by nlinarith only [h0,h1,hm]
  have hp : r*b+r*g+b*g = -(a*t+a*c+t*c) := by nlinarith only [h0,h1,hm]
  exact ⟨htr, by nlinarith only [hp, congrArg (fun x : ℝ => x*x) htr]⟩

noncomputable def sorted3 {A : Matrix (Fin 3) (Fin 3) ℝ} (h : A.IsHermitian) (i : Fin 3) :=
  h.eigenvalues₀ (Fin.cast (Fintype.card_fin 3).symm i)

theorem sorted3_antitone {A : Matrix (Fin 3) (Fin 3) ℝ} (h : A.IsHermitian) :
    Antitone (sorted3 h) := by
  intro i j hij
  apply h.eigenvalues₀_antitone
  exact hij

theorem tri_factor_sorted (u v w x : ℝ) (h : (triangleQ u v w).IsHermitian) :
    generalTriPoly (u^2) (v^2) (w^2) x =
      (x-sorted3 h 0)*(x-sorted3 h 1)*(x-sorted3 h 2) := by
  rw [←det_triangle, ←Matrix.eval_charpoly, h.charpoly_eq, Polynomial.eval_prod]
  simp only [Polynomial.eval_sub, Polynomial.eval_X, Polynomial.eval_C]
  classical
  let e : Fin 3 ≃ Fin 3 := (Fin.castOrderIso (Fintype.card_fin 3).symm).toEquiv.trans
    (Fintype.equivOfCardEq (Fintype.card_fin _))
  change (∏ j : Fin 3, (x-h.eigenvalues j)) = _
  rw [←Equiv.prod_comp e (fun j : Fin 3 => x-h.eigenvalues j)]
  have he (j : Fin 3) : h.eigenvalues (e j) = sorted3 h j := by
    unfold Matrix.IsHermitian.eigenvalues sorted3 e
    simp
  simp_rw [he]
  simp [Fin.prod_univ_succ, Fin.succ_zero_eq_one, Fin.succ_one_eq_two, mul_assoc]

/-- A length-three ordered spectrum with the tripartite cubic cannot beat the
balanced profile except when all three positive integer part sizes agree. -/
theorem close_sorted_cubic_is_balanced (a t c n : ℕ) (ha : 0<a) (hat : a≤t) (htc : t≤c)
    (hn : 3≤n) (hsum : a+t+c=3*n) (r b g : ℝ) (hbg : g≤b)
    (hf : ∀ x : ℝ, generalTriPoly a t c x = (x-r)*(x-b)*(x-g))
    (hclose : (r-2*(n:ℝ))^2+(b+(n:ℝ))^2+(g+(n:ℝ))^2 < (2/3 : ℝ)) :
    a=n ∧ t=n ∧ c=n := by
  have hnR : (3:ℝ)≤n := by exact_mod_cast hn
  have htR : (0:ℝ)<t := by exact_mod_cast (show 0<t by omega)
  have hatR : (a:ℝ)≤t := by exact_mod_cast hat
  have htcR : (t:ℝ)≤c := by exact_mod_cast htc
  have hrSq : (r-2*(n:ℝ))^2 < (1:ℝ)^2 := by
    nlinarith only [hclose, sq_nonneg (b+(n:ℝ)), sq_nonneg (g+(n:ℝ))]
  have hbSq : (b+(n:ℝ))^2 < (1:ℝ)^2 := by
    nlinarith only [hclose, sq_nonneg (r-2*(n:ℝ)), sq_nonneg (g+(n:ℝ))]
  have hgSq : (g+(n:ℝ))^2 < (1:ℝ)^2 := by
    nlinarith only [hclose, sq_nonneg (r-2*(n:ℝ)), sq_nonneg (b+(n:ℝ))]
  have hbandr := abs_lt.mp (by simpa using sq_lt_sq.mp hrSq)
  have hbandb := abs_lt.mp (by simpa using sq_lt_sq.mp hbSq)
  have hbandg := abs_lt.mp (by simpa using sq_lt_sq.mp hgSq)
  have hr : 0<r := by linarith [hbandr.1]
  have hb0 : b≤0 := by linarith [hbandb.2]
  have hg0 : g≤0 := hbg.trans hb0
  have hmed := median_weight_fence _ _ _ _ _ _ htR hatR htcR hr hbg hf
  have htZ : (t:ℤ)=(n:ℤ) := median_int_exact (t:ℤ) (n:ℤ) b g
    (by simpa using hmed.1) (by simpa using hmed.2)
    (by push_cast; linarith [hbandg.1]) (by push_cast; linarith [hbandb.2])
  have ht : t=n := by exact_mod_cast htZ
  have htr : (t:ℝ)=n := by exact_mod_cast ht
  by_cases hEq : a=n
  · exact ⟨hEq, ht, by omega⟩
  let k : ℝ := (n:ℝ)-a
  have hk : 1≤k := by
    have q : a+1≤n := by omega
    have q' : (a:ℝ)+1≤n := by exact_mod_cast q
    dsimp [k]; linarith
  have hkn : k≤(n:ℝ)-1 := by
    have q : (1:ℝ)≤a := by exact_mod_cast ha
    dsimp [k]; linarith
  have haR : (a:ℝ)=(n:ℝ)-k := by dsimp [k]; ring
  have hcR : (c:ℝ)=(n:ℝ)+k := by
    have q : (a:ℝ)+t+c=3*(n:ℝ) := by exact_mod_cast hsum
    linarith
  have hm := tri_moments _ _ _ _ _ _ hf
  have hsecond : r^2+b^2+g^2=6*(n:ℝ)^2-2*k^2 := by
    rw [haR,htr,hcR] at hm
    nlinarith [hm.2]
  have hf' (x : ℝ) : triPoly (n:ℝ) k x = (x-r)*(x-b)*(x-g) := by
    rw [←hf x, haR,htr,hcR]
    unfold triPoly generalTriPoly
    ring
  have hcontra := exclude_unbalanced_tripartite _ _ _ _ _ hnR hk hkn hb0 hg0 hm.1 hsecond hf'
  linarith


/-- The spectrum statement is insensitive to the labelling of the three parts. -/
theorem close_cubic_is_balanced (a t c n : ℕ) (ha : 0<a) (ht : 0<t) (hc : 0<c)
    (hn : 3≤n) (hsum : a+t+c=3*n) (r b g : ℝ) (hbg : g≤b)
    (hf : ∀ x : ℝ, generalTriPoly a t c x = (x-r)*(x-b)*(x-g))
    (hclose : (r-2*(n:ℝ))^2+(b+(n:ℝ))^2+(g+(n:ℝ))^2 < (2/3 : ℝ)) :
    a=n ∧ t=n ∧ c=n := by
  have lower (a' t' c' : ℕ) (hp : 0<a') (h₁ : a'≤t') (h₂ : t'≤c')
      (htot : a'+t'+c'=3*n)
      (hperm : ∀ x : ℝ, generalTriPoly a' t' c' x = generalTriPoly a t c x) :
      a'=n ∧ t'=n ∧ c'=n :=
    close_sorted_cubic_is_balanced _ _ _ _ hp h₁ h₂ hn htot _ _ _ hbg
      (fun x => (hperm x).trans (hf x)) hclose
  rcases le_total a t with h₁|h₁
  · rcases le_total t c with h₂|h₂
    · exact lower a t c ha h₁ h₂ hsum (by intros; rfl)
    · rcases le_total a c with h₃|h₃
      · have hq := lower a c t ha h₃ h₂ (by omega) (by intro; unfold generalTriPoly; ring)
        omega
      · have hq := lower c a t hc h₃ h₁ (by omega) (by intro; unfold generalTriPoly; ring)
        omega
  · rcases le_total a c with h₂|h₂
    · have hq := lower t a c ht h₁ h₂ (by omega) (by intro; unfold generalTriPoly; ring)
      omega
    · rcases le_total t c with h₃|h₃
      · have hq := lower t c a ht h₃ h₂ (by omega) (by intro; unfold generalTriPoly; ring)
        omega
      · have hq := lower c t a hc h₃ h₁ (by omega) (by intro; unfold generalTriPoly; ring)
        omega

#print axioms TriangleSpectralFence.close_cubic_is_balanced
/-- Any no-isolate complete tripartite quotient with ordered positive integer weights
within squared distance <2/3 is the balanced tripartite graph. -/
theorem close_triangle_is_balanced (a t c n : ℕ) (ha : 0<a) (hat : a≤t) (htc : t≤c)
    (hn : 3≤n) (hsum : a+t+c=3*n)
    (h : (triangleQ (√(a:ℝ)) (√(t:ℝ)) (√(c:ℝ))).IsHermitian)
    (hclose : (sorted3 h 0-2*(n:ℝ))^2+
      (sorted3 h 1+(n:ℝ))^2+(sorted3 h 2+(n:ℝ))^2 < (2/3 : ℝ)) :
    a=n ∧ t=n ∧ c=n := by
  let r := sorted3 h 0
  let b := sorted3 h 1
  let g := sorted3 h 2
  change (r-2*(n:ℝ))^2+(b+(n:ℝ))^2+(g+(n:ℝ))^2 < (2/3 : ℝ) at hclose
  have hnR : (3:ℝ)≤n := by exact_mod_cast hn
  have htR : (0:ℝ)<t := by exact_mod_cast (show 0<t by omega)
  have hatR : (a:ℝ)≤t := by exact_mod_cast hat
  have htcR : (t:ℝ)≤c := by exact_mod_cast htc
  have hf (x : ℝ) : generalTriPoly a t c x = (x-r)*(x-b)*(x-g) := by
    have eq := tri_factor_sorted _ _ _ x h
    rw [Real.sq_sqrt (by positivity : 0 ≤ (a:ℝ)),
      Real.sq_sqrt (by positivity : 0 ≤ (t:ℝ)), Real.sq_sqrt (by positivity : 0 ≤ (c:ℝ))] at eq
    exact eq
  have hrSq : (r-2*(n:ℝ))^2 < (1:ℝ)^2 := by
    nlinarith only [hclose, sq_nonneg (b+(n:ℝ)), sq_nonneg (g+(n:ℝ))]
  have hbSq : (b+(n:ℝ))^2 < (1:ℝ)^2 := by
    nlinarith only [hclose, sq_nonneg (r-2*(n:ℝ)), sq_nonneg (g+(n:ℝ))]
  have hgSq : (g+(n:ℝ))^2 < (1:ℝ)^2 := by
    nlinarith only [hclose, sq_nonneg (r-2*(n:ℝ)), sq_nonneg (b+(n:ℝ))]
  have hbandr := abs_lt.mp (by simpa using sq_lt_sq.mp hrSq)
  have hbandb := abs_lt.mp (by simpa using sq_lt_sq.mp hbSq)
  have hbandg := abs_lt.mp (by simpa using sq_lt_sq.mp hgSq)
  have hr : 0<r := by linarith [hbandr.1]
  have hbg : g≤b := sorted3_antitone h (by decide : (1 :Fin 3) ≤ 2)
  have hb0 : b≤0 := by linarith [hbandb.2]
  have hg0 : g≤0 := hbg.trans hb0
  have hmed := median_weight_fence _ _ _ _ _ _ htR hatR htcR hr hbg hf
  have htZ : (t:ℤ)=(n:ℤ) := median_int_exact (t:ℤ) (n:ℤ) b g
    (by simpa using hmed.1) (by simpa using hmed.2)
    (by push_cast; linarith [hbandg.1]) (by push_cast; linarith [hbandb.2])
  have ht : t=n := by exact_mod_cast htZ
  have htr : (t:ℝ)=n := by exact_mod_cast ht
  by_cases hEq : a=n
  · exact ⟨hEq, ht, by omega⟩
  let k : ℝ := (n:ℝ)-a
  have hk : 1≤k := by
    have q : a+1≤n := by omega
    have q' : (a:ℝ)+1≤n := by exact_mod_cast q
    dsimp [k]; linarith
  have hkn : k≤(n:ℝ)-1 := by
    have q : (1:ℝ)≤a := by exact_mod_cast ha
    dsimp [k]; linarith
  have haR : (a:ℝ)=(n:ℝ)-k := by dsimp [k]; ring
  have hcR : (c:ℝ)=(n:ℝ)+k := by
    have q : (a:ℝ)+t+c=3*(n:ℝ) := by exact_mod_cast hsum
    linarith
  have hm := tri_moments _ _ _ _ _ _ hf
  have hsecond : r^2+b^2+g^2=6*(n:ℝ)^2-2*k^2 := by
    rw [haR,htr,hcR] at hm
    nlinarith [hm.2]
  have hf' (x : ℝ) : triPoly (n:ℝ) k x = (x-r)*(x-b)*(x-g) := by
    rw [←hf x, haR,htr,hcR]
    unfold triPoly generalTriPoly
    ring
  have hcontra := exclude_unbalanced_tripartite _ _ _ _ _ hnR hk hkn hb0 hg0 hm.1 hsecond hf'
  linarith

/-- An isolate imposes a spectral penalty of at least 2/3 for any tripartite quotient
in the required sign regime. This does not use a graph enumeration. -/
theorem triangle_isolate_penalty (a t c n r b g : ℝ)
    (ha : 0<a) (ht : 0<t) (hc : 0<c)
    (hsmall : a+t+c ≤ 3*n-1) (hb : b≤0) (hg : g≤0)
    (hf : ∀ x : ℝ, generalTriPoly a t c x = (x-r)*(x-b)*(x-g)) :
    (2/3 : ℝ) ≤ (r-2*n)^2+(b+n)^2+(g+n)^2 := by
  let m := a+t+c
  let S := a*t+a*c+t*c
  let P := a*t*c
  have hm : 0<m := by dsimp [m]; linarith
  have hS0 : 0≤S := by dsimp [S]; positivity
  have hS : 3*S≤m^2 := by
    dsimp [S,m]
    nlinarith only [sq_nonneg (a-t),sq_nonneg (a-c),sq_nonneg (t-c)]
  have hSP : 3*m*P≤S^2 := by
    dsimp [m,P,S]
    nlinarith only [sq_nonneg (a*t-a*c),sq_nonneg (a*t-t*c),sq_nonneg (a*c-t*c)]
  have hS2 := (sq_le_sq₀ (show 0≤3*S by positivity) (sq_nonneg m)).mpr hS
  have hP : 27*P≤m^3 := by
    apply le_of_mul_le_mul_left (a:=m) _ hm
    nlinarith only [hS2,hSP]
  let x := 2*m/3
  have hx : 0<x := by dsimp [x]; linarith
  have hq : 0≤generalTriPoly a t c x := by
    have hh := mul_le_mul_of_nonneg_right hS hx.le
    have he : generalTriPoly a t c x = x^3-S*x-2*P := by
      dsimp [generalTriPoly,S,P]
      ring
    rw [he]
    dsimp only [x] at hh ⊢
    nlinarith only [hh,hP]
  have hr : r≤x := by
    by_contra! h
    have h1 : x-r<0 := sub_neg.mpr h
    have h2 : 0<x-b := by linarith
    have h3 : 0<x-g := by linarith
    have bad := mul_neg_of_neg_of_pos (mul_neg_of_neg_of_pos h1 h2) h3
    rw [←hf] at bad
    exact (not_lt_of_ge hq) bad
  have hdelta : (2/3 : ℝ)≤2*n-r := by dsimp [x,m] at hr; linarith
  have htrace := (tri_moments _ _ _ _ _ _ hf).1
  have hsum : (b+n)+(g+n)=2*n-r := by linarith
  have hcauchy : (2*n-r)^2≤2*((b+n)^2+(g+n)^2) := by
    rw [←hsum]
    nlinarith only [sq_nonneg (b-g)]
  have hd2 := (sq_le_sq₀ (show (0:ℝ)≤2/3 by norm_num) (by linarith : 0≤2*n-r)).mpr hdelta
  nlinarith only [hcauchy,hd2]

theorem close_weighted_triangle_fills_and_balances (a t c n : ℕ)
    (ha : 0<a) (ht : 0<t) (hc : 0<c) (hn : 3≤n) (htotal : a+t+c≤3*n)
    (h : (triangleQ (√(a:ℝ)) (√(t:ℝ)) (√(c:ℝ))).IsHermitian)
    (hclose : (sorted3 h 0-2*(n:ℝ))^2+
      (sorted3 h 1+(n:ℝ))^2+(sorted3 h 2+(n:ℝ))^2 < (2/3 : ℝ)) :
    a=n ∧ t=n ∧ c=n := by
  let r := sorted3 h 0
  let b := sorted3 h 1
  let g := sorted3 h 2
  change (r-2*(n:ℝ))^2+(b+(n:ℝ))^2+(g+(n:ℝ))^2 < (2/3 : ℝ) at hclose
  have hf (x : ℝ) : generalTriPoly a t c x = (x-r)*(x-b)*(x-g) := by
    have he := tri_factor_sorted _ _ _ x h
    rw [Real.sq_sqrt (by positivity : 0 ≤ (a:ℝ)),
      Real.sq_sqrt (by positivity : 0 ≤ (t:ℝ)), Real.sq_sqrt (by positivity : 0 ≤ (c:ℝ))] at he
    exact he
  have hbg : g≤b := sorted3_antitone h (by decide : (1:Fin 3)≤2)
  by_cases hall : a+t+c=3*n
  · exact close_cubic_is_balanced _ _ _ _ ha ht hc hn hall _ _ _ hbg hf hclose
  · have hs : a+t+c+1≤3*n := by omega
    have hsR : (a:ℝ)+t+c+1≤3*(n:ℝ) := by exact_mod_cast hs
    have hnR : (3:ℝ)≤n := by exact_mod_cast hn
    have hbSq : (b+(n:ℝ))^2 < (1:ℝ)^2 := by
      nlinarith only [hclose,sq_nonneg (r-2*(n:ℝ)),sq_nonneg (g+(n:ℝ))]
    have hband := abs_lt.mp (by simpa using sq_lt_sq.mp hbSq)
    have hb0 : b≤0 := by linarith [hband.2]
    have hg0 : g≤0 := hbg.trans hb0
    have hpen := triangle_isolate_penalty (a:ℝ) (t:ℝ) (c:ℝ) (n:ℝ) r b g
      (by exact_mod_cast ha) (by exact_mod_cast ht) (by exact_mod_cast hc)
      (by linarith) hb0 hg0 hf
    exfalso
    linarith

#print axioms TriangleSpectralFence.close_weighted_triangle_fills_and_balances
#print axioms TriangleSpectralFence.triangle_isolate_penalty
#print axioms TriangleSpectralFence.close_triangle_is_balanced
#print axioms TriangleSpectralFence.tri_factor_sorted
#print axioms TriangleSpectralFence.tri_factor
#print axioms TriangleSpectralFence.tri_moments
#print axioms TriangleSpectralFence.median_weight_fence
#print axioms TriangleSpectralFence.median_int_exact
#print axioms TriangleSpectralFence.exclude_unbalanced_tripartite
end TriangleSpectralFence


namespace TriangleSpectralFence
open Matrix SpectralConjecture20 PawUnbounded
open scoped Matrix BigOperators

def triangleSeed : Matrix (Fin 3) (Fin 3) ℝ := !![0,1,1;1,0,1;1,1,0]
def triangleWeights (a b c : Nat) : Fin 3 → Nat := ![a,b,c]

theorem triangleSeedHermitian : triangleSeed.IsHermitian := by
  ext i j
  fin_cases i <;> fin_cases j <;> simp [triangleSeed,Matrix.conjTranspose_apply]

theorem triangleQ_quotient (a b c : Nat) :
    weightedQuotient triangleSeed (triangleWeights a b c) =
    triangleQ (√(a:ℝ)) (√(b:ℝ)) (√(c:ℝ)) := by
  ext i j
  simp [weightedQuotient,sqrtWeights,Matrix.diagonal_mul,Matrix.mul_diagonal]
  fin_cases i <;> fin_cases j <;> simp [triangleSeed,triangleWeights,triangleQ,mul_comm]

theorem sorted3_congr {A B : Matrix (Fin 3) (Fin 3) ℝ} (hA : A.IsHermitian)
    (hB : B.IsHermitian) (h : A=B) : sorted3 hA = sorted3 hB := by
  subst B
  rfl

theorem triangle_padded_close_is_balanced (n a b c z : Nat) (hn : 3≤n)
    (ha : 0<a) (hb : 0<b) (hc : 0<c)
    (hF : (withIsolates triangleSeed (triangleWeights a b c) z).IsHermitian)
    (hN : Fintype.card (Vertices (triangleWeights a b c) ⊕ Fin z) = 3*n)
    (y : Fin (Fintype.card (Vertices (triangleWeights a b c) ⊕ Fin z)) → ℝ)
    (hy0 : y ⟨0,by omega⟩=2*(n:ℝ))
    (hy2 : y (Fin.rev ⟨1,by omega⟩)= -(n:ℝ))
    (hy3 : y (Fin.rev ⟨0,by omega⟩)= -(n:ℝ))
    (hClose : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(2/3:ℝ)) :
    a=n ∧ b=n ∧ c=n ∧ z=0 := by
  classical
  let w := triangleWeights a b c
  let N := Fintype.card (Vertices (triangleWeights a b c) ⊕ Fin z)
  let f : Fin N → ℝ := hF.eigenvalues₀
  let Q := weightedQuotient triangleSeed w
  let hQ : Q.IsHermitian := weightedQuotient_isHermitian triangleSeed triangleSeedHermitian w
  let q : Fin 3 → ℝ := sorted3 hQ
  let i0 : Fin N := ⟨0,by dsimp [N]; omega⟩
  let i1 : Fin N := ⟨1,by dsimp [N]; omega⟩
  have hw (i : Fin 3) : 0<w i := by
    fin_cases i <;> first | exact ha | exact hb | exact hc
  have hf : Antitone f := hF.eigenvalues₀_antitone
  have hq : Antitone q := sorted3_antitone hQ
  have hcAll (s u : ℝ) (hu : 0≤u) :
      Fintype.card {i // u < s*f i} = Fintype.card {j // u < s*q j} := by
    have hh := withIsolates_quotient_sorted_cut triangleSeed triangleSeedHermitian w hw z hF s u hu
    refine hh.trans ?_
    exact Fintype.card_congr (Equiv.subtypeEquiv (finCongr (Fintype.card_fin 3)) (fun _ => Iff.rfl))
  have hcPos (u : ℝ) (hu : 0≤u) :
      Fintype.card {i // u < f i} = Fintype.card {j // u < q j} := by
    simpa only [one_mul] using hcAll 1 u hu
  have hcNeg (u : ℝ) (hu : 0≤u) :
      Fintype.card {i : Fin N // u < -f i.rev} = Fintype.card {j : Fin 3 // u < -q j.rev} := by
    rw [←signed_reversed_cuts f,←signed_reversed_cuts q]
    simpa only [neg_one_mul] using hcAll (-1) u hu
  have hNear (i : Fin N) : |f i-y i| < 1 := by
    have hh := Finset.single_le_sum (s := Finset.univ) (f := fun i => (f i-y i)^2)
      (fun j _ => sq_nonneg (f j-y j)) (Finset.mem_univ i)
    have hs : (f i-y i)^2 < (1:ℝ)^2 := by
      have hh' := hh.trans_lt hClose
      linarith
    simpa using sq_lt_sq.mp hs
  change y i0=2*(n:ℝ) at hy0
  change y i1.rev= -(n:ℝ) at hy2
  change y i0.rev= -(n:ℝ) at hy3
  have hnR : (3:ℝ)≤n := by exact_mod_cast hn
  have hPosF : 0<f i0 := by
    have hband := abs_lt.mp (hNear i0)
    rw [hy0] at hband
    linarith
  have hPosQ : 0<q 0 := by
    apply (cut_count_rank_iff _ hq 0 0).mpr
    rw [← hcPos 0 le_rfl]
    exact (cut_count_rank_iff _ hf 0 i0).mp hPosF
  have he0 : f i0=q 0 :=
    equal_coord_of_nonnegative_cut_counts _ _ hf hq i0 0 rfl hPosF.le hPosQ.le hcPos
  have hNegAt (i : Fin N) (hY : y i= -(n:ℝ)) : 0< -f i := by
    have hband := abs_lt.mp (hNear i)
    rw [hY] at hband
    linarith
  have hfr := antitone_neg_rev f hf
  have hqr := antitone_neg_rev q hq
  have sortNeg (i : Fin N) (j : Fin 3) (hij : i.val=j.val) (hNeg : 0< -f i.rev) :
      f i.rev = q j.rev := by
    have hqN : 0< -q j.rev := by
      apply (cut_count_rank_iff _ hqr 0 j).mpr
      rw [←hij,←hcNeg 0 le_rfl]
      exact (cut_count_rank_iff _ hfr 0 i).mp hNeg
    have he := equal_coord_of_nonnegative_cut_counts _ _ hfr hqr i j hij hNeg.le hqN.le hcNeg
    linarith only [he]
  have he2 : f i1.rev=q 1 := sortNeg i1 1 rfl (hNegAt i1.rev hy2)
  have he3 : f i0.rev=q 2 := sortNeg i0 0 rfl (hNegAt i0.rev hy3)
  let eFun : Fin 3 → Fin N := ![i0,i1.rev,i0.rev]
  have hinj : Function.Injective eFun := by
    intro i j hi
    have hval := congrArg Fin.val hi
    fin_cases i <;> fin_cases j <;>
      simp [eFun,i0,i1,Fin.val_rev] at hval ⊢ <;> omega
  let e : Fin 3 ↪ Fin N := ⟨eFun,hinj⟩
  have hs : ∑ j, (f (e j)-y (e j))^2≤∑ i,(f i-y i)^2 := by
    let F : Fin N → ℝ := fun i => (f i-y i)^2
    have hh : (∑ i ∈ (Finset.univ : Finset (Fin 3)).map e, F i) ≤ ∑ i, F i :=
      Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _) (fun i _ _ => sq_nonneg _)
    simpa only [Finset.sum_map,F] using hh
  rw [Fin.sum_univ_three] at hs
  change (f i0-y i0)^2+(f i1.rev-y i1.rev)^2+(f i0.rev-y i0.rev)^2≤_ at hs
  rw [he0,he2,he3,hy0,hy2,hy3,sub_neg_eq_add,sub_neg_eq_add] at hs
  have hcloseQ : (q 0-2*(n:ℝ))^2+(q 1+(n:ℝ))^2+(q 2+(n:ℝ))^2<(2/3:ℝ) :=
    hs.trans_lt hClose
  have hwcard : Fintype.card (Vertices w ⊕ Fin z) = a+b+c+z := by
    rw [Fintype.card_sum,Fintype.card_sigma,Fintype.card_fin]
    simp [w,Fin.sum_univ_three,triangleWeights]
  have hsum : a+b+c+z=3*n := hwcard.symm.trans hN
  have hMat := triangleQ_quotient a b c
  let hT : (triangleQ (√(a:ℝ)) (√(b:ℝ)) (√(c:ℝ))).IsHermitian := hMat ▸ hQ
  have hEq : q=sorted3 hT := sorted3_congr hQ hT hMat
  rw [hEq] at hcloseQ
  obtain ⟨ea,eb,ec⟩ := close_weighted_triangle_fills_and_balances a b c n ha hb hc hn (by omega) hT hcloseQ
  exact ⟨ea,eb,ec,by omega⟩

#print axioms TriangleSpectralFence.triangle_padded_close_is_balanced
end TriangleSpectralFence
