import C20TriBranch
import C20Catalogue
namespace Conjecture20Squared
open Matrix Finset SpectralConjecture20 Conj20StarCert UnitPruning PawUnbounded
open scoped BigOperators Matrix
theorem classify_catalogue {m : Type*} [Fintype m] [DecidableEq m]
    (A : Matrix m m ℝ) (n : Nat) (hn : 3 ≤ n) (q r : Nat) (hl : 2 ≤ q) (hh : q ≤ 5)
    (hr : r < (templatesOfRank q).size)
    (w : Fin (templatesOfRank q)[r]!.size→Nat) (z : Nat)
    (g : (Vertices w ⊕ Fin z) ≃ m) (hw : ∀ i,0 < w i)
    (hB : A.submatrix g g=withIsolates (catalogueMatrix (templatesOfRank q)[r]!) w z)
    (hG : (withIsolates (catalogueMatrix (templatesOfRank q)[r]!) w z).IsHermitian)
    (hsz : Fintype.card (Vertices w ⊕ Fin z)=3*n)
    (hCloseG : score n _ hG < (16/27:ℝ)) :
    RelabelAs A (balanced n) ∨ RelabelAs A (hub n) := by
  let y := target n (Fintype.card (Vertices w ⊕ Fin z))
  obtain ⟨hy0,hy1,hy2,hy3,hyLo,hyAbs,hyP,hyM,hyN,hyDeep,_⟩ := profile n _ hn hsz
  have hyTop : ∃ i, 2*(n:ℝ) ≤ y i := ⟨⟨0,by omega⟩,hy0.ge⟩
  have hMass : (∑ i,w i)+z=3*n := (card_blowup_vertices w z).symm.trans hsz
  have hFour : 4 ≤ Fintype.card (Vertices w ⊕ Fin z) := by omega
  have hTotal : (∑ i,w i) ≤ 3*n := by omega
  have hRank : q=2 ∨ q=3 ∨ q=4 ∨ q=5 := by omega
  rcases hRank with rfl|rfl|rfl|rfl
  · change r < 1 at hr
    have e : r=0 := by omega
    subst r
    exact ((hCloseG.trans (by norm_num : (16/27:ℝ) < 2/3)).not_ge
      (bipartite_catalogue_2_0_excluded w hw z hG y hyM hyP hyDeep)).elim
  · change r < 1 at hr
    have e : r=0 := by omega
    subst r
    obtain ⟨hz,hW⟩ := triangle_branch n hn w z hw hsz hG hCloseG
    have pack (v : Fin 3 → Nat) (t : Nat) (hv : v=TriangleSpectralFence.triangleWeights n n n)
        (ht : t=0) (e : (Vertices v ⊕ Fin t) ≃ m)
        (hEq : A.submatrix e e=withIsolates (catalogueMatrix T3[0]!) v t) : RelabelAs A (balanced n) := by
      subst v; subst t
      exact ⟨e,hEq.trans (congrArg (fun M => withIsolates M _ 0) canonical_triangle_row)⟩
    exact Or.inl (pack w z hW hz g hB)
  · let j : Fin 9 := ⟨r,hr⟩
    by_cases h1 : r=1
    · subst r
      exact ((hCloseG.trans (by norm_num : (16/27:ℝ) < 2/3)).not_ge
        (bipartite_catalogue_4_1_excluded w hw z hG y hyM hyP hyDeep)).elim
    by_cases h2 : r=2
    · subst r
      have eq := congrArg (fun M => withIsolates M w z) catalogue_paw_exact.symm
      have hP : (withIsolates PawLargestFence.paw w z).IsHermitian := eq ▸ hG
      have he := score_congr (m:=Vertices w ⊕ Fin z) n _ _ eq hG hP
      have hCloseP : score (m:=Vertices w ⊕ Fin z) n _ hP < (16/27:ℝ) := he.symm.trans_lt hCloseG
      obtain ⟨hz,hl,hA,hB',hC⟩ := PawIsolate.paw_below_isolate_gap n hn w hw z hMass hP
        hFour y hy0 hy1 hy2 hy3 hyLo hyP hyN hCloseP
      have hW : w=singletonWeights (n-1) n n := by
        funext i
        fin_cases i
        · change w (0:Fin 4)=n-1; omega
        · exact hB'
        · exact hC
        · exact hl
      have pack (v : Fin 4 → Nat) (t : Nat) (hv : v=singletonWeights (n-1) n n)
          (ht : t=0) (e : (Vertices v ⊕ Fin t) ≃ m)
          (hEq : A.submatrix e e=withIsolates PawLargestFence.paw v t) : RelabelAs A (hub n) := by
        subst v; subst t
        exact ⟨e,hEq.trans (congrArg (fun M => withIsolates M _ 0) seed_paw_exact.symm)⟩
      exact Or.inr (pack w z hW hz g (hB.trans eq))
    by_cases h5 : r=5
    · subst r
      exact ((hCloseG.trans (by norm_num : (16/27:ℝ) < 2/3)).not_ge
        (catalogue_house_excluded n hn w hw hTotal z hG y hyP hyN hyTop)).elim
    by_cases h6 : r=6
    · subst r
      exact ((hCloseG.trans (by norm_num : (16/27:ℝ) < 2/3)).not_ge
        (catalogue_bull_excluded n hn w hw hTotal z hG y hyP hyN hyTop)).elim
    exact ((hCloseG.trans (by norm_num : (16/27:ℝ) < 2/3)).not_ge
      (catalogue_rank_four_excluded j h1 h2 h5 h6 w hw z hG y hyAbs hyP hyM)).elim
  · let j : Fin 25 := ⟨r,hr⟩
    exact ((hCloseG.trans (by norm_num : (16/27:ℝ) < 2/3)).not_ge
      (catalogue_all_rank_five_excluded j w hw z hG y hyAbs hyP hyM hyDeep)).elim

theorem close_graph_is_balanced_or_hub (n : Nat) (hn : 3 ≤ n)
    (A : Fin (3*n) → Fin (3*n) → Bool) (hS : ∀ i j,A i j=A j i) (hD : ∀ i,A i i=false)
    (hF : (SpectralRank.boolAdj A).IsHermitian) (hClose : score n _ hF < (16/27:ℝ)) :
    RelabelAs (SpectralRank.boolAdj A) (balanced n) ∨ RelabelAs (SpectralRank.boolAdj A) (hub n) := by
  let B := binaryAdj A
  let q := B.rank
  have hl : 2 ≤ q := rank_two_min_of_near n hn A hS hD hF hClose
  have hh : q ≤ 5 := by
    apply SpectralRank.problem_21 n hn A hD hS
    exact hClose.trans (by norm_num)
  obtain ⟨r,hr,w,z,g,hw,hB⟩ :=
    binary_graph_rank_two_to_five_is_catalogue_blowup A hS hD q rfl hl hh
  let C := catalogueMatrix (templatesOfRank q)[r]!
  change (binaryAdj A).submatrix g g=withIsolates C w z at hB
  let hG : (withIsolates C w z).IsHermitian := hB ▸ hF.submatrix g
  have hsz : Fintype.card (Vertices w ⊕ Fin z)=3*n := (Fintype.card_congr g).trans (Fintype.card_fin _)
  have hCloseG : score n _ hG < (16/27:ℝ) :=
    (score_relabel n (binaryAdj A) hF _ hG g hB.symm).trans_lt hClose
  exact classify_catalogue _ n hn q r hl hh hr w z g hw hB hG hsz hCloseG

#print axioms close_graph_is_balanced_or_hub

/-- Source-faithful p=2 nearest-graph assertion, using the paper's squared distance. -/
theorem squared_unique_nearest (n : Nat) (hn : 3 ≤ n)
    (A : Fin (3*n) → Fin (3*n) → Bool) (hS : ∀ i j,A i j=A j i) (hD : ∀ i,A i i=false) :
    ((¬ RelabelAs (realAdj A) (balanced n)) ∧
      (∀ (B : Fin (3*n) → Fin (3*n) → Bool) (hT : ∀ i j, B i j = B j i),
        (∀ i, B i i=false) → (¬ RelabelAs (realAdj B) (balanced n)) →
        score n _ (realAdjHerm A hS) ≤ score n _ (realAdjHerm B hT))) ↔
      RelabelAs (realAdj A) (hub n) := by
  refine squared_minimizer_of_classification n hn ?_ A hS hD
  intro D hDS hDD hc
  exact close_graph_is_balanced_or_hub n hn D hDS hDD (realAdjHerm D hDS) hc
#print axioms squared_unique_nearest
end Conjecture20Squared
