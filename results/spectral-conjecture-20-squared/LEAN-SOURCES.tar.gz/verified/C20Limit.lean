import C20Classify
import C20NumericalCore

namespace C20Rate
open Conjecture20Squared PawUnbounded SpectralConjecture20 Filter
open scoped BigOperators Topology

/-- The source's objective for actual H_n, with an explicit error bound. -/
theorem actual_hub_rate (n : Nat) (hn : 5 ≤ n) :
    |(n:ℝ)*(score n _ (hub_herm n)-1/2)| ≤ 7 := by
  let q := singletonQEigen (n-1) n n
  have hA := benchmark_spectral_antitone n
  have hab : q 1 ≤ q 0 := hA (by decide)
  have hbc : q 2 ≤ q 1 := hA (by decide)
  have hcd : q 3 ≤ q 2 := hA (by decide)
  have hnR : (5:ℝ) ≤ n := by exact_mod_cast hn
  obtain ⟨hd,hf⟩ := HubBenchmark.reduce_quartic n (q 0) (q 1) (q 2) (q 3)
    (by linarith) (hcd.trans (hbc.trans hab)) (hcd.trans hbc) hcd
    (benchmark_actual_quartic n (by omega))
  have hsz := hub_card n (by omega)
  have hN : 4 ≤ Fintype.card (Vertices (singletonWeights (n-1) n n) ⊕ Fin 0) := by omega
  obtain ⟨hy0,hy1,hy2,hy3,_,_,_,_,_,_,hyR⟩ := profile n _ (by omega) hsz
  have eq := singleton_ordered_quartet_score_eq n (n-1) n n 0 (by omega) (by omega) (by omega)
    (hub_herm n) hN (target n _) hy0 hy1 hy2 hy3 hyR (fun x => x^2) (by norm_num)
  change score n _ (hub_herm n) = (q 0-2*n)^2+(q 1)^2+(q 2+n)^2+(q 3+n)^2 at eq
  rw [hd] at eq
  have he : score n _ (hub_herm n) = HubBenchmark.score n (q 0) (q 1) (q 2) := by
    simpa [HubBenchmark.score] using eq
  rw [he]
  exact C20NumericalCore.scaled_score_rate hnR (HubBenchmark.brackets_large n _ _ _ hnR hab hbc hf) hf

/-- Every realized score from a graph of order 3n NOT isomorphic to the target. -/
def competitors (n : Nat) : Set ℝ := {s | ∃ (A : Fin (3*n) → Fin (3*n) → Bool)
    (hs : ∀ i j, A i j=A j i), (∀ i, A i i=false) ∧
    (¬ RelabelAs (realAdj A) (balanced n)) ∧ score n _ (realAdjHerm A hs)=s}

noncomputable def cospectralitySquared (n : Nat) : ℝ := sInf (competitors n)

theorem cospectrality_eq (n : Nat) (hn : 3≤n) :
    cospectralitySquared n=score n _ (hub_herm n) := by
  obtain ⟨A,hs,hd,hr⟩ := hub_has_bool_representative n (by omega)
  obtain ⟨hNot,hMin⟩ := (squared_unique_nearest n hn A hs hd).mpr hr
  obtain ⟨e,he⟩ := hr
  have eq := score_relabel n _ (realAdjHerm A hs) _ (hub_herm n) e he.symm
  apply IsLeast.csInf_eq
  constructor
  · exact ⟨A,hs,hd,hNot,eq.symm⟩
  · rintro s ⟨B,ht,hD,hnB,heq⟩
    exact eq.le.trans ((hMin B ht hD hnB).trans heq.le)

theorem conjecture_20_squared_limit :
    Tendsto cospectralitySquared atTop (𝓝 (1/2 : ℝ)) := by
  apply Metric.tendsto_atTop.mpr
  intro ε hε
  obtain ⟨K,hK⟩ := exists_nat_gt (7/ε)
  refine ⟨max K 5,?_⟩
  intro n hn
  have h5 : 5≤n := (le_max_right K 5).trans hn
  have hk : K≤n := (le_max_left K 5).trans hn
  have hnR : (0:ℝ)<n := by exact_mod_cast (show 0<n by omega)
  have he : 7 < (n:ℝ)*ε := (div_lt_iff₀ hε).mp (hK.trans_le (by exact_mod_cast hk))
  rw [Real.dist_eq,cospectrality_eq n (by omega)]
  have hb := actual_hub_rate n h5
  rw [abs_mul,abs_of_pos hnR] at hb
  exact lt_of_mul_lt_mul_left (hb.trans_lt he) hnR.le

#print axioms conjecture_20_squared_limit
end C20Rate
