import C20Weighted
import SpectralRank.SpectralTop
import Lean
import SpectralRank.PrincipalMinor
import Mathlib.LinearAlgebra.Matrix.SchurComplement
import Mathlib.LinearAlgebra.Matrix.Rank
import Mathlib.Basic.Real.Basic





open scoped Bool
namespace Conj20StarCert
abbrev IMat := Array (Array Int)
abbrev Tmpl := Array (Array Nat)
abbrev Witness := Nat × Array Nat
structure Family where
  mask : Nat
  det : Int
  adj : IMat
  base : List Nat
  choices : List Nat
  rows : Array (Option Witness)
def mget (A : IMat) (i j : Nat) : Int := ((A[i]?.getD #[])[j]?).getD 0
def tget (A : Tmpl) (i j : Nat) : Nat := ((A[i]?.getD #[])[j]?).getD 0
def edge (mask i j : Nat) : Bool :=
  if i == j then false else mask.testBit ((max i j)*(max i j-1)/2+min i j)
def zedge (mask i j : Nat) : Int := if edge mask i j then 1 else 0
def bil (n : Nat) (J : IMat) (x y : Nat) : Int :=
  ((List.range n).map (fun i =>
    ((List.range n).map (fun j => if x.testBit i && y.testBit j then mget J i j else 0)).sum)).sum
def binary (det q : Int) : Bool := (q == 0) || (q == det)
def rowCode (n mask i : Nat) : Nat :=
  ((List.range n).map (fun j => if edge mask i j then 2^j else 0)).sum
def eligible (n : Nat) (f : Family) (x : Nat) : Bool :=
  x != 0 && !(f.base.contains x) && (bil n f.adj x x == 0) &&
  f.base.all (fun y => binary f.det (bil n f.adj x y))
def selected (f : Family) (sel : Nat) : List Nat :=
  f.base ++ (f.choices.zipIdx.filter fun x => sel.testBit x.2).map Prod.fst
def compatible (n : Nat) (f : Family) (s : List Nat) : Bool :=
  s.all (fun x => s.all (fun y => binary f.det (bil n f.adj x y)))
def permValid (n : Nat) (p : Array Nat) : Bool :=
  (p.size == n) &&
   (List.range n).all (fun i => (p[i]! < n) &&
    (List.range i).all (fun j => p[j]! != p[i]!))
def rowValid (n : Nat) (f : Family) (templates : Array Tmpl) (i : Nat) : Bool :=
  let list := selected f i
  let ok := compatible n f list
  match f.rows[i]?.getD none with
  | none => !ok
  | some (r,p) =>
    ok && decide (r < templates.size) && (templates[r]!.size == list.length) &&
    permValid list.length p &&
    (List.range list.length).all (fun j => (List.range list.length).all (fun k =>
      (if bil n f.adj list[j]! list[k]! == f.det then 1 else 0) ==
          tget templates[r]! p[j]! p[k]!))
def familyValid (n : Nat) (f : Family) (templates : Array Tmpl) : Bool :=
  f.det != 0 &&
  (f.base == (List.range n).map (rowCode n f.mask)) &&
  (f.choices == (List.range (2^n)).filter (eligible n f)) &&
  (f.rows.size == 2^f.choices.length) &&
  (List.range n).all (fun i => (List.range n).all (fun j =>
    ((List.range n).map (fun k => mget f.adj i k * zedge f.mask k j)).sum ==
      if i == j then f.det else 0)) &&
  (List.range (2^f.choices.length)).all (rowValid n f templates)
end Conj20StarCert

namespace Conj20StarCert

theorem bit_vector (n : Nat) (u : Fin n → Bool) :
    ∃ b < 2^n, ∀ i : Fin n, b.testBit i = u i := by
  induction n with
  | zero =>
    refine ⟨0,by decide,fun i => Fin.elim0 i⟩
  | succ n ih =>
    obtain ⟨b,hb,hu⟩ := ih (fun i => u i.castSucc)
    let a : Nat := if u (Fin.last n) then 1 else 0
    refine ⟨2^n*a+b,?_ ,?_⟩
    · rw [Nat.pow_succ]
      cases ha : u (Fin.last n) <;> simp [a,ha] <;> omega
    · intro i
      rw [Nat.testBit_two_pow_mul_add a hb]
      refine Fin.lastCases ?_ (fun j => ?_) i
      · simp only [Fin.val_last,Nat.lt_irrefl,ite_false,Nat.sub_self]
        cases ha : u (Fin.last n) <;> simp [a,ha]
      · simpa [j.isLt] using hu j

theorem bit_vector_unique {n a b : Nat} (ha : a<2^n) (hb : b<2^n)
    (he : ∀ i : Fin n, a.testBit i=b.testBit i) : a=b := by
  apply Nat.eq_of_testBit_eq
  intro i
  by_cases h : i<n
  · exact he ⟨i,h⟩
  · have hp : 2^n≤2^i := Nat.pow_le_pow_right (by decide : 0<2) (Nat.le_of_not_gt h)
    rw [Nat.testBit_lt_two_pow (Nat.lt_of_lt_of_le ha hp),Nat.testBit_lt_two_pow (Nat.lt_of_lt_of_le hb hp)]
#print axioms bit_vector_unique

theorem selections_cover (f : Family) (want : Nat → Bool) :
    ∃ k < 2^f.choices.length, ∀ x, x ∈ selected f k ↔
      x∈f.base ∨ (x∈f.choices ∧ want x = true) := by
  obtain ⟨k,hk,hbits⟩ := bit_vector f.choices.length (fun i => want f.choices[i])
  refine ⟨k,hk,fun x => ?_⟩
  unfold selected
  rw [List.mem_append]
  apply or_congr_right
  constructor
  · intro hx
    obtain ⟨⟨y,i⟩,hy,hx⟩ := List.mem_map.mp hx
    change y=x at hx
    subst y
    obtain ⟨hy',hp⟩ := List.mem_filter.mp hy
    have hget := List.mk_mem_zipIdx_iff_getElem?.mp hy'
    obtain ⟨hi,ha⟩ := List.getElem?_eq_some_iff.mp hget
    have w := hbits ⟨i,hi⟩
    change k.testBit i = want f.choices[i] at w
    rw [ha] at w
    exact ⟨List.mem_iff_getElem.mpr ⟨i,hi,ha⟩, w.symm.trans hp⟩
  · intro hx
    obtain ⟨i,hi,ha⟩ := List.mem_iff_getElem.mp hx.1
    have hget : f.choices[i]? = some x := List.getElem?_eq_some_iff.mpr ⟨hi,ha⟩
    have hy := List.mk_mem_zipIdx_iff_getElem?.mpr hget
    have w := hbits ⟨i,hi⟩
    change k.testBit i = want f.choices[i] at w
    rw [ha] at w
    exact List.mem_map.mpr ⟨(x,i),List.mem_filter.mpr ⟨hy,w.trans hx.2⟩,rfl⟩

#print axioms selections_cover

theorem eligible_mem_choices (n : Nat) (f : Family) (templates : Array Tmpl)
    (h : familyValid n f templates = true) {x : Nat} (hx : x<2^n) (he : eligible n f x = true) :
    x∈f.choices := by
  have h0 := (Bool.and_eq_true_iff.mp h).1
  have h1 := (Bool.and_eq_true_iff.mp h0).1
  have h2 := (Bool.and_eq_true_iff.mp h1).1
  have h3 := (Bool.and_eq_true_iff.mp h2).2
  have hchoices : f.choices = (List.range (2^n)).filter (eligible n f) := beq_iff_eq.mp h3
  rw [hchoices]
  exact List.mem_filter.mpr ⟨List.mem_range.mpr hx,he⟩

theorem compatible_subset_has_row (n : Nat) (f : Family) (templates : Array Tmpl)
    (h : familyValid n f templates = true) (i : Nat) (hi : i<2^f.choices.length)
    (hOk : compatible n f (selected f i) = true) :
    ∃ (r : Nat) (p : Array Nat), r<templates.size ∧ templates[r]!.size=(selected f i).length ∧
      permValid (selected f i).length p = true ∧
      ∀ j<(selected f i).length, ∀ k<(selected f i).length,
        (if bil n f.adj (selected f i)[j]! (selected f i)[k]! == f.det then 1 else 0)
          = tget templates[r]! p[j]! p[k]! := by
  have hall := (Bool.and_eq_true_iff.mp h).2
  have hrow := List.all_eq_true.mp hall i (List.mem_range.mpr hi)
  cases hr : f.rows[i]?.getD none with
  | none => simp [rowValid,hr,hOk] at hrow
  | some a =>
    obtain ⟨r,p⟩ := a
    simp only [rowValid,hr,hOk,Bool.true_and,Bool.and_eq_true,decide_eq_true_eq] at hrow
    obtain ⟨⟨⟨hR,hSize⟩,hP⟩,hEdges⟩ := hrow
    refine ⟨r,p,hR,beq_iff_eq.mp hSize,hP,fun j hj k hk => ?_⟩
    exact beq_iff_eq.mp (List.all_eq_true.mp
      (List.all_eq_true.mp hEdges j (List.mem_range.mpr hj)) k (List.mem_range.mpr hk))
#print axioms compatible_subset_has_row

theorem checked_permutation_injective (n : Nat) (p : Array Nat) (h : permValid n p=true) :
    ∃ f : Fin n → Fin n, Function.Injective f ∧ ∀ i : Fin n, (f i).val=p[i.val]! := by
  simp only [permValid,Bool.and_eq_true, List.all_eq_true,decide_eq_true_eq] at h
  have hb (i : Fin n) : p[i.val]!<n := (h.2 i (List.mem_range.mpr i.isLt)).1
  let f (i : Fin n) : Fin n := ⟨p[i.val]!,hb i⟩
  refine ⟨f,?_,fun _ => rfl⟩
  intro i j he
  have hf : p[i.val]! = p[j.val]! := congrArg Fin.val he
  apply Fin.ext
  rcases Nat.lt_trichotomy i.val j.val with hi | hi | hi
  · have hne := (h.2 j (List.mem_range.mpr j.isLt)).2 i (List.mem_range.mpr hi)
    have hh : p[i.val]! ≠ p[j.val]! := by simpa using hne
    exact (hh hf).elim
  · exact hi
  · have hne := (h.2 i (List.mem_range.mpr i.isLt)).2 j (List.mem_range.mpr hi)
    have hh : p[j.val]! ≠ p[i.val]! := by simpa using hne
    exact (hh hf.symm).elim
#print axioms checked_permutation_injective

/-- From any realized predicate of legal compatible codes, the finite checker
supplies a selected list and a genuine injective relabeling into a catalogued
template. The only remaining graph input is proving that its star codes are legal. -/
theorem star_catalogue_covers_mask_pred (n : Nat) (f : Family) (T : Array Tmpl)
    (h : familyValid n f T=true) (S : Nat → Bool)
    (hbase : ∀ x∈f.base, S x = true)
    (hlegal : ∀ x, S x=true → x<2^n ∧ (x∈f.base ∨ eligible n f x=true))
    (hpairs : ∀ x y, S x=true → S y=true → binary f.det (bil n f.adj x y)=true) :
    ∃ (k : Nat) (r : Nat) (p : Array Nat),
      k<2^f.choices.length ∧ r<T.size ∧ T[r]!.size=(selected f k).length ∧
      (∀ x, x∈selected f k ↔ S x=true) ∧
      permValid (selected f k).length p=true ∧
      (∀ j<(selected f k).length, ∀ l<(selected f k).length,
        (if bil n f.adj (selected f k)[j]! (selected f k)[l]! == f.det then 1 else 0) =
          tget T[r]! p[j]! p[l]!) := by
  obtain ⟨k,hk,hm⟩ := selections_cover f S
  have hb (x : Nat) : x ∈ selected f k ↔ S x=true := by
    rw [hm x]
    constructor
    · rintro (hb|⟨_,hh⟩)
      · exact hbase x hb
      · exact hh
    · intro hx
      obtain ⟨hl,hb|he⟩ := hlegal x hx
      · exact Or.inl hb
      · exact Or.inr ⟨eligible_mem_choices n f T h hl he,hx⟩
  have hcompat : compatible n f (selected f k)=true := by
    unfold compatible
    exact List.all_eq_true.mpr (fun x hx =>
      List.all_eq_true.mpr (fun y hy => hpairs x y ((hb x).mp hx) ((hb y).mp hy)))
  obtain ⟨r,p,hr,hs,hp,hE⟩ := compatible_subset_has_row n f T h k hk hcompat
  exact ⟨k,r,p,hk,hr,hs,hb,hp,hE⟩
#print axioms star_catalogue_covers_mask_pred

theorem checked_selected_nodup (n : Nat) (f : Family) (T : Array Tmpl)
    (h : familyValid n f T=true) (hBase : f.base.Nodup) (k : Nat) :
    (selected f k).Nodup := by
  have h0 := (Bool.and_eq_true_iff.mp h).1
  have h1 := (Bool.and_eq_true_iff.mp h0).1
  have h2 := (Bool.and_eq_true_iff.mp h1).1
  have h3 := (Bool.and_eq_true_iff.mp h2).2
  have hchoices : f.choices = (List.range (2^n)).filter (eligible n f) := beq_iff_eq.mp h3
  let rest := (f.choices.zipIdx.filter fun x => k.testBit x.2).map Prod.fst
  have hsub : List.Sublist rest f.choices := by
    have hs : List.Sublist (f.choices.zipIdx.filter (fun x => k.testBit x.2)) f.choices.zipIdx := List.filter_sublist
    simpa [rest,List.zipIdx_map_fst] using hs.map Prod.fst
  have hc : f.choices.Nodup := by
    rw [hchoices]
    exact List.Nodup.sublist List.filter_sublist List.nodup_range
  change (f.base ++ rest).Nodup
  apply List.nodup_append.mpr
  refine ⟨hBase,hsub.nodup hc,?_⟩
  intro a ha b hb hEq
  subst b
  have hh : a ∈ f.choices := hsub.subset hb
  rw [hchoices] at hh
  have he := (List.mem_filter.mp hh).2
  unfold eligible at he
  simp [ha] at he
#print axioms checked_selected_nodup

-- Extra digest: base row codes must express the actual binary bits and be nonzero.
def basisBitsValid (n : Nat) (f : Family) : Bool :=
  f.base.length == n &&
  (List.range n).all (fun i =>
    (f.base[i]! != 0) && decide (f.base[i]! < 2^n) &&
    (List.range n).all (fun j => (f.base[i]!).testBit j == edge f.mask i j))

theorem basisBitsValid_sound (n : Nat) (f : Family) (h : basisBitsValid n f = true) :
    f.base.length = n ∧ ∀ i<n, f.base[i]! ≠ 0 ∧ f.base[i]!<2^n ∧
        ∀ j<n, (f.base[i]!).testBit j = edge f.mask i j := by
  simp only [basisBitsValid,Bool.and_eq_true,List.all_eq_true,decide_eq_true_eq] at h
  refine ⟨beq_iff_eq.mp h.1,fun i hi => ?_⟩
  have hh := h.2 i (List.mem_range.mpr hi)
  refine ⟨by simpa using hh.1.1,hh.1.2,fun j hj => ?_⟩
  exact beq_iff_eq.mp (hh.2 j (List.mem_range.mpr hj))
#print axioms basisBitsValid_sound
end Conj20StarCert
open Matrix
namespace SpectralConjecture20

/-- If an invertible top-left block already has the full matrix rank, its
Schur complement is zero. No symmetry is necessary. -/
theorem schur_zero_of_rank_le {m n : Type*} [Fintype m] [Fintype n] [DecidableEq m] [DecidableEq n]
    (A : Matrix m m ℝ) (B : Matrix m n ℝ) (C : Matrix n m ℝ) (D : Matrix n n ℝ)
    (hA : A.det ≠ 0) (hr : (fromBlocks A B C D).rank ≤ Fintype.card m) :
    D = C * A⁻¹ * B := by
  let : Invertible A := invertibleOfIsUnitDet A (isUnit_iff_ne_zero.mpr hA)
  let E : Matrix n n ℝ := D-C*⅟A*B
  have h0 : E = 0 := by
    by_contra! hne
    obtain ⟨i,j,hij⟩ : ∃ i j, E i j ≠ 0 := by
      by_contra! h
      exact hne (by ext i j; exact h i j)
    let r : Unit → n := fun _ => i
    let c : Unit → n := fun _ => j
    let B' := B.submatrix id c
    let C' := C.submatrix r id
    let D' := D.submatrix r c
    have hSchur : D'-C'*⅟A*B' = E.submatrix r c := by
      ext a b
      change D (r a) (c b) - (C'*⅟A*B') a b =
        D (r a) (c b) - (C*⅟A*B) (r a) (c b)
      congr 1
    have hd : (fromBlocks A B' C' D').det ≠ 0 := by
      rw [det_fromBlocks₁₁,hSchur,det_unique (E.submatrix r c)]
      exact mul_ne_zero hA hij
    have hsub : fromBlocks A B' C' D' =
        (fromBlocks A B C D).submatrix (Sum.map id r) (Sum.map id c) := by
      ext (a|a) (b|b) <;> rfl
    have hr' := rank_submatrix_le (fromBlocks A B C D) (Sum.map id r) (Sum.map id c)
    rw [← hsub,rank_of_det_ne_zero hd, Fintype.card_sum, Fintype.card_unit] at hr'
    omega
  have res : D = C * ⅟A * B := sub_eq_zero.mp h0
  rwa [invOf_eq_nonsing_inv] at res

#print axioms schur_zero_of_rank_le

/-- Every entry is recovered from the row, column and inverse basis block. -/
theorem rank_exact_block_factorization {m n : Type*} [Fintype m] [Fintype n]
    [DecidableEq m] [DecidableEq n]
    (A : Matrix m m ℝ) (B : Matrix m n ℝ) (C : Matrix n m ℝ) (D : Matrix n n ℝ)
    (hA : A.det ≠ 0) (hr : (fromBlocks A B C D).rank ≤ Fintype.card m) :
    fromBlocks A B C D =
      (Matrix.of (fun (i : m ⊕ n) j => i.elim (fun a => A a j) (fun a => C a j))) * A⁻¹ *
      (Matrix.of (fun i (j : m ⊕ n) => j.elim (A i) (B i))) := by
  have hu := isUnit_iff_ne_zero.mpr hA
  ext (i|i) (j|j)
  · change A i j = (A*A⁻¹*A) i j
    rw [mul_nonsing_inv A hu,Matrix.one_mul]
  · change B i j = (A*A⁻¹*B) i j
    rw [mul_nonsing_inv A hu,Matrix.one_mul]
  · change C i j = (C*A⁻¹*A) i j
    rw [Matrix.mul_assoc, nonsing_inv_mul A hu, Matrix.mul_one]
  · change D i j = (C*A⁻¹*B) i j
    rw [schur_zero_of_rank_le A B C D hA hr]

#print axioms rank_exact_block_factorization

/-- Rank-exact entry reconstruction from a principal block, indexed by the
original ambient index type. This is the algebraic star-complement identity. -/
theorem rank_exact_entry_reconstruction {m n : Type*} [Fintype m] [Fintype n]
    [DecidableEq n]
    (H : Matrix m m ℝ) (e : n ↪ m)
    (hInv : (H.submatrix e e).det ≠ 0) (hr : H.rank ≤ Fintype.card n) :
    ∀ i j, H i j = (fun k => H i (e k)) ⬝ᵥ
      ((H.submatrix e e)⁻¹ *ᵥ (fun k => H (e k) j)) := by
  classical
  let Cmp := {a : m // a ∉ Set.range e}
  let ex : n ≃ {a : m // a ∈ Set.range e} := Equiv.ofInjective e e.injective
  let g : n ⊕ Cmp ≃ m :=
    (Equiv.sumCongr ex (Equiv.refl Cmp)).trans (Equiv.sumCompl (· ∈ Set.range e))
  have gi (k : n) : g (Sum.inl k) = e k := rfl
  let c : Cmp → m := g ∘ Sum.inr
  let A := H.submatrix e e
  let B := H.submatrix e c
  let C := H.submatrix c e
  let D := H.submatrix c c
  have hBlock : fromBlocks A B C D = H.submatrix g g := by
    ext (i|i) (j|j) <;> rfl
  have hR : (fromBlocks A B C D).rank ≤ Fintype.card n := by
    rwa [hBlock,rank_submatrix]
  have he := rank_exact_block_factorization A B C D hInv hR
  rw [hBlock, Matrix.mul_assoc] at he
  intro i j
  obtain ⟨i,rfl⟩ := g.surjective i
  obtain ⟨j,rfl⟩ := g.surjective j
  have h := congrFun₂ he i j
  let X : Matrix (n ⊕ Cmp) n ℝ :=
    fun i j => i.elim (fun a => A a j) (fun a => C a j)
  let Y : Matrix n (n ⊕ Cmp) ℝ :=
    fun i j => j.elim (A i) (B i)
  have hX (k : n) : X i k = H (g i) (e k) := by cases i <;> rfl
  have hY (k : n) : Y k j = H (e k) (g j) := by cases j <;> rfl
  change H (g i) (g j) = (X * (A⁻¹ * Y)) i j at h
  rw [h, Matrix.mul_apply]
  unfold dotProduct
  apply Finset.sum_congr rfl
  intro k _
  rw [hX,Matrix.mul_apply,Matrix.mulVec, dotProduct]
  simp_rw [hY]
  rfl

#print axioms rank_exact_entry_reconstruction

noncomputable def realCode {n : Type*} (x : n → Bool) : n → ℝ :=
  fun k => if x k then 1 else 0

noncomputable def binaryAdj {m : Type*} (A : m → m → Bool) : Matrix m m ℝ :=
  fun i j => if A i j then 1 else 0

noncomputable def bilinearCode {n : Type*} [Fintype n] [DecidableEq n]
    (B : Matrix n n ℝ) (x y : n → Bool) : ℝ :=
  realCode x ⬝ᵥ (B⁻¹ *ᵥ realCode y)

def codeAt {m n : Type*} (A : m → m → Bool) (e : n ↪ m) (i : m) : n → Bool :=
  fun k => A i (e k)

theorem binary_entry_type_of_rank_exact {m n : Type*} [Fintype m] [Fintype n] [DecidableEq n]
    (A : m → m → Bool) (hs : ∀ i j, A i j=A j i) (e : n ↪ m)
    (hInv : ((binaryAdj A).submatrix e e).det ≠ 0)
    (hr : (binaryAdj A).rank ≤ Fintype.card n) :
    ∀ i j, binaryAdj A i j =
      bilinearCode ((binaryAdj A).submatrix e e) (codeAt A e i) (codeAt A e j) := by
  intro i j
  rw [rank_exact_entry_reconstruction (binaryAdj A) e hInv hr i j]
  have h : (fun k => binaryAdj A (e k) j) = realCode (codeAt A e j) := by
    funext k
    change (if A (e k) j then (1:ℝ) else 0) = if A j (e k) then 1 else 0
    rw [hs (e k) j]
  rw [h]
  rfl

theorem binary_code_eq_iff_row_eq {m n : Type*} [Fintype m] [Fintype n] [DecidableEq n]
    (A : m → m → Bool) (hs : ∀ i j, A i j=A j i) (e : n ↪ m)
    (hInv : ((binaryAdj A).submatrix e e).det ≠ 0)
    (hr : (binaryAdj A).rank ≤ Fintype.card n) (i j : m) :
    codeAt A e i = codeAt A e j ↔ (∀ k, A i k=A j k) := by
  constructor
  · intro he k
    have r₁ := binary_entry_type_of_rank_exact A hs e hInv hr i k
    have r₂ := binary_entry_type_of_rank_exact A hs e hInv hr j k
    rw [he,←r₂] at r₁
    by_cases hi : A i k <;> by_cases hj : A j k <;> simp_all [binaryAdj]
  · intro h
    funext k
    exact h (e k)


theorem exact_principal_basis {m : Type*} [Fintype m]
    (H : Matrix m m ℝ) (hs : Hᵀ=H) :
    ∃ e : Fin H.rank ↪ m, (H.submatrix e e).det ≠ 0 := by
  have h := SpectralRank.exists_nonsingular_principal_near_rank H hs H.rank (le_refl _)
  obtain ⟨r,e,hr,hn⟩ := h
  rcases hr with hr|hr
  · subst r
    exact ⟨e,hn⟩
  · have hin := Matrix.rank_submatrix_le H e e
    rw [Matrix.rank_of_det_ne_zero hn,Fintype.card_fin,hr] at hin
    omega

theorem binary_star_complement {m : Type*} [Fintype m]
    (A : m → m → Bool) (hs : ∀ i j, A i j=A j i) (hd : ∀ i, A i i=false) :
    ∃ e : Fin (binaryAdj A).rank ↪ m,
      ((binaryAdj A).submatrix e e).det ≠ 0 ∧
      (∀ i j, binaryAdj A i j =
        bilinearCode ((binaryAdj A).submatrix e e) (codeAt A e i) (codeAt A e j)) ∧
      (∀ i, bilinearCode ((binaryAdj A).submatrix e e) (codeAt A e i) (codeAt A e i)=0) ∧
      (∀ i j, codeAt A e i=codeAt A e j ↔ ∀ k, A i k=A j k) := by
  have ht : (binaryAdj A)ᵀ = binaryAdj A := by
    ext i j
    change (if A j i then (1:ℝ) else 0) = if A i j then 1 else 0
    rw [hs]
  obtain ⟨e,hInv⟩ := exact_principal_basis (binaryAdj A) ht
  have hr : (binaryAdj A).rank ≤ Fintype.card (Fin (binaryAdj A).rank) := by simp
  have h := binary_entry_type_of_rank_exact A hs e hInv hr
  refine ⟨e,hInv,h,?_,binary_code_eq_iff_row_eq A hs e hInv hr⟩
  intro i
  rw [← h i i]
  simp [binaryAdj,hd i]

#print axioms binary_star_complement
end SpectralConjecture20
open Matrix Finset
open scoped BigOperators
namespace Conj20StarCert
open SpectralConjecture20

theorem list_range_sum {α : Type*} [AddCommMonoid α] (n : Nat) (f : Nat → α) :
    ((List.range n).map f).sum = ∑ i : Fin n, f i.val := by
  have he : (List.ofFn (fun i : Fin n => i.val)) = List.range n := by
    apply List.ext_getElem
    · simp
    · intro i hi hj
      simp
  rw [←he, List.map_ofFn, List.sum_ofFn]
  rfl

def realBasis (n : Nat) (f : Family) : Matrix (Fin n) (Fin n) ℝ :=
  fun i j => if edge f.mask i j then 1 else 0

def adjInt (n : Nat) (f : Family) : Matrix (Fin n) (Fin n) ℤ :=
  fun i j => mget f.adj i j

def adjReal (n : Nat) (f : Family) : Matrix (Fin n) (Fin n) ℝ :=
  (adjInt n f).map (Int.castRingHom ℝ)

theorem adj_scaled_of_valid (n : Nat) (f : Family) (T : Array Tmpl)
    (h : familyValid n f T = true) :
    adjReal n f * realBasis n f = (f.det : ℝ) • (1 : Matrix (Fin n) (Fin n) ℝ) := by
  have h0 := (Bool.and_eq_true_iff.mp h).1
  have hh := (Bool.and_eq_true_iff.mp h0).2
  ext i j
  have he := beq_iff_eq.mp (List.all_eq_true.mp
      (List.all_eq_true.mp hh i (List.mem_range.mpr i.isLt)) j (List.mem_range.mpr j.isLt))
  rw [list_range_sum] at he
  rw [Matrix.mul_apply,Matrix.smul_apply]
  have hl : ∀ k : Fin n,
    adjReal n f i k * realBasis n f k j =
      (((mget f.adj i k * zedge f.mask k j : ℤ)) : ℝ) := by
    intro k
    simp only [adjReal,adjInt,realBasis,zedge,Matrix.map_apply,Int.coe_castRingHom,Int.cast_mul]
    split <;> simp
  simp_rw [hl]
  rw [←Int.cast_sum,he]
  by_cases hh : i=j
  · subst j
    simp
  · have hh' : i.val ≠ j.val := fun w => hh (Fin.ext w)
    simp [hh,hh']

theorem adj_real_eq_scale_inv (n : Nat) (f : Family) (T : Array Tmpl)
    (h : familyValid n f T = true) (hi : (realBasis n f).det ≠ 0) :
    adjReal n f = (f.det : ℝ) • (realBasis n f)⁻¹ := by
  have ht := Matrix.mul_nonsing_inv (realBasis n f) (isUnit_iff_ne_zero.mpr hi)
  calc
    _ = adjReal n f * (realBasis n f * (realBasis n f)⁻¹) := by rw [ht,Matrix.mul_one]
    _ = _ := by
      rw [← Matrix.mul_assoc,adj_scaled_of_valid n f T h,Matrix.smul_mul,Matrix.one_mul]

theorem bil_cast_real (n : Nat) (f : Family) (x y : Nat) :
    (bil n f.adj x y : ℝ) =
    realCode (fun i : Fin n => x.testBit i) ⬝ᵥ
      (adjReal n f *ᵥ realCode (fun i : Fin n => y.testBit i)) := by
  unfold bil
  rw [list_range_sum]
  simp_rw [list_range_sum,Int.cast_sum]
  unfold dotProduct
  apply Finset.sum_congr rfl
  intro i _
  rw [Matrix.mulVec, dotProduct,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro j _
  cases hx : x.testBit i.val <;> cases hy : y.testBit j.val <;>
    simp [realCode,hx,hy,adjReal,adjInt]

theorem encoded_integer_adjacency (n : Nat) (f : Family) (T : Array Tmpl)
    (h : familyValid n f T = true)
    {m : Type*} [Fintype m] (A : m → m → Bool) (hS : ∀ i j,A i j=A j i)
    (e : Fin n ↪ m) (hInv : ((binaryAdj A).submatrix e e).det ≠ 0)
    (hr : (binaryAdj A).rank ≤ n)
    (basis : ∀ i j : Fin n, A (e i) (e j)=edge f.mask i j)
    (q : m → Nat) (hq : ∀ i (k : Fin n), (q i).testBit k = A i (e k)) :
    ∀ i j, bil n f.adj (q i) (q j) = if A i j then f.det else 0 := by
  have hb : realBasis n f = (binaryAdj A).submatrix e e := by
    ext i j
    change (if edge f.mask i j then (1:ℝ) else 0) = if A (e i) (e j) then 1 else 0
    rw [basis]
  have hInv' : (realBasis n f).det ≠ 0 := by rwa [hb]
  have hc (i : m) : (fun k : Fin n => (q i).testBit k) = codeAt A e i := by
    funext k
    exact hq i k
  intro i j
  have hF := binary_entry_type_of_rank_exact A hS e hInv (by simpa using hr) i j
  have he : (bil n f.adj (q i) (q j) : ℝ) = (f.det : ℝ) * binaryAdj A i j := by
    rw [bil_cast_real, hc, hc, adj_real_eq_scale_inv n f T h hInv', hb,
        smul_mulVec, dotProduct_smul, smul_eq_mul]
    change (f.det : ℝ) * bilinearCode ((binaryAdj A).submatrix e e) (codeAt A e i) (codeAt A e j) = _
    rw [← hF]
  cases hh : A i j with
  | false =>
      have hp : (bil n f.adj (q i) (q j) : ℝ)=0 := by simpa [binaryAdj,hh] using he
      exact_mod_cast hp
  | true =>
      have hp : (bil n f.adj (q i) (q j) : ℝ)=(f.det : ℝ) := by simpa [binaryAdj,hh] using he
      simpa using (Int.cast_inj.mp hp)
#print axioms encoded_integer_adjacency

theorem valid_family_det_ne_zero (n : Nat) (f : Family) (T : Array Tmpl)
    (h : familyValid n f T = true) : f.det ≠ 0 := by
  simp only [familyValid,Bool.and_eq_true] at h
  have h0 : (f.det != 0) = true := h.1.1.1.1.1
  simpa using h0

/-- Interface to the graph blowup: when the exact-rank principal basis is
recognized, all actual nonisolated vertex types have a verified reduced
catalogue template, with integer adjacency and injective relabeling data. -/
theorem graph_codes_enter_catalogue (n : Nat) (f : Family) (T : Array Tmpl)
    (h : familyValid n f T = true) (hBits : basisBitsValid n f=true) (hDistinct : f.base.Nodup)
    {m : Type*} [Fintype m] (A : m → m → Bool)
    (hS : ∀ i j,A i j=A j i) (hDiag : ∀ i,A i i=false)
    (e : Fin n ↪ m) (hInv : ((binaryAdj A).submatrix e e).det ≠ 0)
    (hr : (binaryAdj A).rank ≤ n)
    (basis : ∀ i j : Fin n, A (e i) (e j)=edge f.mask i j) :
    ∃ (q : m → Nat) (k r : Nat) (p : Array Nat),
      k<2^f.choices.length ∧ r<T.size ∧ T[r]!.size=(selected f k).length ∧
      (selected f k).Nodup ∧
      (∀ x, x∈selected f k ↔ x≠0 ∧ ∃ i, q i=x) ∧
      (∀ i, q i=0 ↔ ∀ j, A i j=false) ∧
      (∀ i j, bil n f.adj (q i) (q j)=if A i j then f.det else 0) ∧
      permValid (selected f k).length p = true ∧
      (∀ j<(selected f k).length, ∀ l<(selected f k).length,
        (if bil n f.adj (selected f k)[j]! (selected f k)[l]! == f.det then 1 else 0) =
          tget T[r]! p[j]! p[l]!) := by
  classical
  have ex (i : m) := bit_vector n (fun k => A i (e k))
  let q (i : m) := Classical.choose (ex i)
  have qLim (i : m) : q i<2^n := (Classical.choose_spec (ex i)).1
  have qBits (i : m) (k : Fin n) : (q i).testBit k=A i (e k) :=
    (Classical.choose_spec (ex i)).2 k
  have hAdj := encoded_integer_adjacency n f T h A hS e hInv hr basis q qBits
  let S (x : Nat) : Bool := decide (x≠0 ∧ ∃ i, q i=x)
  have hSreal (x : Nat) : S x=true ↔ x≠0 ∧ ∃ i, q i=x := by
    simp [S]
  have hDet := valid_family_det_ne_zero n f T h
  have hLen := (basisBitsValid_sound n f hBits).1
  have hBase : ∀ x∈f.base, S x=true := by
    intro x hx
    obtain ⟨i,hi,hix⟩ := List.mem_iff_getElem.mp hx
    have hiN : i<n := hLen ▸ hi
    obtain ⟨h0,hL,hB⟩ := (basisBitsValid_sound n f hBits).2 i hiN
    rw [getElem!_pos f.base i hi,hix] at h0 hL hB
    let j : Fin n := ⟨i,hiN⟩
    have eq : q (e j)=x := by
      apply bit_vector_unique (qLim (e j)) hL
      intro v
      rw [qBits (e j) v,basis j v,hB v v.isLt]
    exact (hSreal x).2 ⟨h0,e j,eq⟩
  have hIso (i : m) : q i=0 ↔ ∀ j,A i j=false := by
    constructor
    · intro hi j
      have res := hAdj i j
      rw [hi] at res
      have hz : bil n f.adj 0 (q j) = 0 := by simp [bil]
      rw [hz] at res
      cases hh : A i j with
      | false => rfl
      | true => exact (hDet (by simpa [hh] using res.symm)).elim
    · intro hh
      apply bit_vector_unique (qLim i) (Nat.two_pow_pos _)
      intro k
      rw [qBits,hh]
      simp
  have hpair (x y : Nat) (hx : S x=true) (hy : S y=true) :
      binary f.det (bil n f.adj x y)=true := by
    obtain ⟨_,i,rfl⟩ := (hSreal x).1 hx
    obtain ⟨_,j,rfl⟩ := (hSreal y).1 hy
    rw [hAdj]
    cases A i j <;> simp [binary]
  have hLegal (x : Nat) (hx : S x=true) : x<2^n ∧ (x∈f.base ∨ eligible n f x=true) := by
    obtain ⟨h0,i,rfl⟩ := (hSreal x).1 hx
    refine ⟨qLim i,?_⟩
    by_cases hb : q i∈f.base
    · exact Or.inl hb
    · right
      have hD : bil n f.adj (q i) (q i)=0 := by rw [hAdj,hDiag]; rfl
      unfold eligible
      simp only [Bool.and_eq_true]
      exact ⟨⟨⟨by simpa using h0,by simpa using hb⟩,beq_iff_eq.mpr hD⟩,
        List.all_eq_true.mpr (fun y hy => hpair _ _ hx (hBase y hy))⟩
  obtain ⟨k,r,p,hk,hR,hSz,hSel,hP,hEdges⟩ := star_catalogue_covers_mask_pred n f T h S hBase hLegal hpair
  exact ⟨q,k,r,p,hk,hR,hSz,checked_selected_nodup n f T h hDistinct k,
    fun x => (hSel x).trans (hSreal x),hIso,hAdj,hP,hEdges⟩
#print axioms graph_codes_enter_catalogue
end Conj20StarCert
open Matrix

namespace SpectralConjecture20

/-- A partition into nonempty live classes, together with isolated vertices,
    gives a genuine weighted blowup up to simultaneous vertex reindexing. -/
theorem matrix_is_blowup_of_partition {m c : Type*} [Fintype m] [Fintype c]
    (H : Matrix m m ℝ) (B : Matrix c c ℝ) (live : m → Prop)
    (cls : {i // live i} → c)
    (hSurj : Function.Surjective cls)
    (hLive : ∀ i j : {i // live i}, H i.val j.val = B (cls i) (cls j))
    (hZero : ∀ i j, ¬live i ∨ ¬live j → H i j=0) :
    ∃ (w : c → Nat) (z : Nat)
      (e : (Σ j, Fin (w j)) ⊕ Fin z ≃ m), (∀ i, 0<w i) ∧
        H.submatrix e e = fromBlocks (B.submatrix Sigma.fst Sigma.fst) 0 0 0 := by
  classical
  let w (j : c) := Fintype.card {i : {i // live i} // cls i=j}
  let z := Fintype.card {i : m // ¬live i}
  let ph (j : c) : Fin (w j) ≃ {i : {i // live i} // cls i=j} :=
    (Fintype.equivFin _).symm
  let g : (Σ j, Fin (w j)) ≃ {i // live i} :=
    (Equiv.sigmaCongrRight ph).trans (Equiv.sigmaFiberEquiv cls)
  let e : (Σ j, Fin (w j)) ⊕ Fin z ≃ m :=
    (Equiv.sumCongr g (Fintype.equivFin {i : m // ¬live i}).symm).trans (Equiv.sumCompl live)
  have hW (j : c) : 0<w j := by
    obtain ⟨x,hx⟩ := hSurj j
    exact Fintype.card_pos_iff.mpr ⟨⟨x,hx⟩⟩
  have hLeft (v : Σ j, Fin (w j)) : e (Sum.inl v)=(g v).val := rfl
  have hCls (v : Σ j, Fin (w j)) : cls (g v) = v.1 := (ph v.1 v.2).property
  have hI (i : Fin z) : ¬live (e (Sum.inr i)) :=
    ((Fintype.equivFin {i : m // ¬live i}).symm i).property
  refine ⟨w,z,e,hW,?_⟩
  ext (i|i) (j|j)
  · change H (e (Sum.inl i)) (e (Sum.inl j)) = B i.1 j.1
    rw [hLeft,hLeft,hLive,hCls,hCls]
  · exact hZero _ _ (Or.inr (hI j))
  · exact hZero _ _ (Or.inl (hI i))
  · exact hZero _ _ (Or.inl (hI i))
#print axioms matrix_is_blowup_of_partition
end SpectralConjecture20


namespace Conj20StarCert
open SpectralConjecture20

def catalogueMatrix (T : Tmpl) : Matrix (Fin T.size) (Fin T.size) ℝ :=
  fun i j => (tget T i j : ℝ)

theorem graph_is_catalogue_blowup {m : Type*} [Fintype m]
    (A : m → m → Bool) (hS : ∀ i j,A i j=A j i) (hD : ∀ i,A i i=false)
    (n : Nat) (T : Array Tmpl) (f : Family)
    (h : familyValid n f T=true) (hB : basisBitsValid n f=true) (hN : f.base.Nodup)
    (e : Fin n ↪ m) (hInv : ((binaryAdj A).submatrix e e).det ≠ 0)
    (hr : (binaryAdj A).rank ≤ n)
    (hBasis : ∀ i j : Fin n,A (e i) (e j)=edge f.mask i j) :
    ∃ (r : Nat) (_ : r<T.size) (w : Fin T[r]!.size → Nat) (z : Nat)
        (g : ((Σ i, Fin (w i)) ⊕ Fin z) ≃ m), (∀ i, 0<w i) ∧
      (binaryAdj A).submatrix g g =
        fromBlocks ((catalogueMatrix T[r]!).submatrix Sigma.fst Sigma.fst) 0 0 0 := by
  classical
  obtain ⟨q,k,r,p,_,hR,hSz,hNoDup,hMem,hIso,hAdj,hPerm,hEdge⟩ :=
    graph_codes_enter_catalogue n f T h hB hN A hS hD e hInv hr hBasis
  let inside (i : m) : Prop := q i≠0
  let L := selected f k
  let I := Fin L.length
  have hx (x : {i // inside i}) : ∃ j : I, L[j.val]=q x.val := by
    have hm := (hMem (q x.val)).2 ⟨x.property,x.val,rfl⟩
    obtain ⟨j,hj,hg⟩ := List.mem_iff_getElem.mp hm
    exact ⟨⟨j,hj⟩,hg⟩
  let pos (x : {i // inside i}) : I := Classical.choose (hx x)
  have atPos (x : {i // inside i}) : L[(pos x).val]=q x.val :=
    Classical.choose_spec (hx x)
  have hSurj : Function.Surjective pos := by
    intro a
    have hm := List.getElem_mem a.isLt
    obtain ⟨h0,v,hv⟩ := (hMem L[a.val]).1 hm
    let vv : {i // inside i} := ⟨v,by simpa [inside,hv] using h0⟩
    refine ⟨vv,?_⟩
    apply (List.nodup_iff_injective_get.mp hNoDup)
    exact (atPos vv).trans hv
  obtain ⟨t,htInj,ht⟩ := checked_permutation_injective L.length p hPerm
  let pE : I ≃ Fin T[r]!.size :=
    (Equiv.ofBijective t ⟨htInj,Finite.surjective_of_injective htInj⟩).trans (finCongr hSz.symm)
  let cls : {i // inside i} → Fin T[r]!.size := pE ∘ pos
  have clsSurj : Function.Surjective cls := pE.surjective.comp hSurj
  have hDet := valid_family_det_ne_zero n f T h
  have hLive (u v : {i // inside i}) : binaryAdj A u.val v.val = catalogueMatrix T[r]! (cls u) (cls v) := by
    have he := hEdge (pos u).val (pos u).isLt (pos v).val (pos v).isLt
    rw [getElem!_pos L (pos u).val (pos u).isLt, getElem!_pos L (pos v).val (pos v).isLt] at he
    rw [atPos u,atPos v,hAdj] at he
    have hu : (cls u).val = p[(pos u).val]! := ht (pos u)
    have hv : (cls v).val = p[(pos v).val]! := ht (pos v)
    change (if A u.val v.val then (1:ℝ) else 0) =
      (tget T[r]! (cls u).val (cls v).val : ℝ)
    rw [hu,hv]
    cases hA : A u.val v.val with
    | false =>
        simp [hA,hDet.symm] at he
        simp [←he]
    | true =>
        simp [hA] at he
        simp [←he]
  have hZ (i j : m) (hz : ¬inside i ∨ ¬inside j) : binaryAdj A i j=0 := by
    have he : A i j=false := by
      rcases hz with hz|hz
      · exact (hIso i).mp (by simpa [inside] using hz) j
      · rw [hS i j]
        exact (hIso j).mp (by simpa [inside] using hz) i
    simp [binaryAdj,he]
  obtain ⟨w,z,g,hW,hEq⟩ := matrix_is_blowup_of_partition (binaryAdj A)
    (catalogueMatrix T[r]!) inside cls clsSurj hLive hZ
  exact ⟨r,hR,w,z,g,hW,hEq⟩
#print axioms graph_is_catalogue_blowup
end Conj20StarCert

namespace Conj20StarCert
open SpectralConjecture20

def maskMatrix (n mask : Nat) : Matrix (Fin n) (Fin n) ℝ :=
  fun i j => if edge mask i j then 1 else 0

def CertifiedFamily (n : Nat) (T : Array Tmpl) (f : Family) : Prop :=
  familyValid n f T=true ∧ basisBitsValid n f=true ∧ f.base.Nodup

def BasisClassifies (n : Nat) (R : Array Nat) (T : Array Tmpl) : Prop :=
  ∀ i : Fin R.size, (maskMatrix n R[i]).det=0 ∨
    ∃ f : Family, f.mask=R[i] ∧ CertifiedFamily n T f

theorem covered_basis_blowup {m : Type*} [Fintype m]
    (A : m → m → Bool) (hS : ∀ i j,A i j=A j i) (hD : ∀ i,A i i=false)
    (n : Nat) (R : Array Nat) (T : Array Tmpl)
    (hCovers : SpectralRank.CoverageData.Covers n R) (hClass : BasisClassifies n R T)
    (e : Fin n ↪ m) (hInv : ((binaryAdj A).submatrix e e).det ≠ 0)
    (hr : (binaryAdj A).rank ≤ n) :
    ∃ (r : Nat) (_ : r<T.size) (w : Fin T[r]!.size → Nat) (z : Nat)
        (g : ((Σ i, Fin (w i)) ⊕ Fin z) ≃ m), (∀ i, 0<w i) ∧
      (binaryAdj A).submatrix g g =
        fromBlocks ((catalogueMatrix T[r]!).submatrix Sigma.fst Sigma.fst) 0 0 0 := by
  classical
  obtain ⟨i,p,hIso⟩ := hCovers (fun u v => A (e u) (e v)) (fun u => hD (e u))
    (fun u v => hS (e u) (e v))
  have he : (binaryAdj A).submatrix e e = (maskMatrix n R[i]).submatrix p p := by
    ext u v
    change (if A (e u) (e v) then (1:ℝ) else 0) = if edge R[i] (p u) (p v) then 1 else 0
    exact congrArg (fun b : Bool => if b then (1:ℝ) else 0) (hIso u v)
  have hMat : (maskMatrix n R[i]).det≠0 := by rwa [he,det_submatrix_equiv_self] at hInv
  obtain hs|⟨f,hf,hab,hbit,hN⟩ := hClass i
  · exact (hMat hs).elim
  let en : Fin n ↪ m := p.symm.toEmbedding.trans e
  have hBasis (u v : Fin n) : A (en u) (en v)=edge f.mask u v := by
    have heq := hIso (p.symm u) (p.symm v)
    have hx := heq
    rw [p.apply_symm_apply,p.apply_symm_apply,←hf] at hx
    exact hx
  have hn : (binaryAdj A).submatrix en en = maskMatrix n f.mask := by
    ext u v
    exact congrArg (fun b : Bool => if b then (1:ℝ) else 0) (hBasis u v)
  have hNew : ((binaryAdj A).submatrix en en).det≠0 := by rwa [hn,hf]
  exact graph_is_catalogue_blowup A hS hD n T f hab hbit hN en hNew hr hBasis

#print axioms covered_basis_blowup
end Conj20StarCert


namespace Conj20StarCert
open SpectralConjecture20

def nullOfMask (n mask : Nat) (z : Array Int) : Bool :=
  (List.range n).any (fun i => (z[i]?.getD 0) != 0) &&
  (List.range n).all (fun i =>
    ((List.range n).map (fun j => zedge mask i j * (z[j]?.getD 0))).sum == 0)

theorem nullOfMask_sound (n mask : Nat) (z : Array Int)
    (h : nullOfMask n mask z=true) : (maskMatrix n mask).det=0 := by
  simp only [nullOfMask,Bool.and_eq_true] at h
  obtain ⟨i,hi,hq⟩ := List.any_eq_true.mp h.1
  let v : Fin n → ℝ := fun i => ((z[i.val]?.getD 0 : ℤ) : ℝ)
  have hNz : v≠0 := by
    intro hZ
    let j : Fin n := ⟨i,List.mem_range.mp hi⟩
    have he : ((z[i]?.getD 0 : ℤ):ℝ)=0 := congrFun hZ j
    have hc : z[i]?.getD 0=0 := by exact_mod_cast he
    simp [hc] at hq
  have hMv : maskMatrix n mask *ᵥ v = 0 := by
    funext j
    have he := beq_iff_eq.mp (List.all_eq_true.mp h.2 j (List.mem_range.mpr j.isLt))
    rw [list_range_sum] at he
    change (∑ k : Fin n, (maskMatrix n mask) j k * v k)=0
    have coeff (k : Fin n) : (maskMatrix n mask) j k =
        ((zedge mask j k : ℤ) : ℝ) := by
      cases hEdge : edge mask j k <;> simp [maskMatrix,zedge,hEdge]
    simp_rw [coeff]
    change (∑ k : Fin n, ((zedge mask j k:ℤ):ℝ)*((z[k.val]?.getD 0:ℤ):ℝ))=0
    exact_mod_cast he
  by_contra! hd
  exact hNz (mulVec_injective_of_det_ne_zero hd (by simpa using hMv))
#print axioms nullOfMask_sound
end Conj20StarCert

namespace Conj20StarCert
open SpectralRank.CoverageData
set_option maxRecDepth 100000
set_option maxHeartbeats 50000000
def T2 : Array Tmpl := #[#[#[0,1],#[1,0]]]
def f2_0 : Family := ⟨1,-1,#[#[0,-1],#[-1,0]],[2, 1],[],#[some (0,#[0,1])]⟩
theorem f2_0_certified : CertifiedFamily 2 T2 f2_0 := by unfold CertifiedFamily; decide +kernel
theorem classifies2 : BasisClassifies 2 R2 T2 := by
  intro i
  fin_cases i
  · exact Or.inl (nullOfMask_sound 2 0 #[1,0] (by decide +kernel))
  · exact Or.inr ⟨f2_0,rfl,f2_0_certified⟩
#print axioms classifies2
def T3 : Array Tmpl := #[#[#[0,1,1],#[1,0,1],#[1,1,0]]]
def f3_0 : Family := ⟨7,2,#[#[-1,1,1],#[1,-1,1],#[1,1,-1]],[6, 5, 3],[],#[some (0,#[0,1,2])]⟩
theorem f3_0_certified : CertifiedFamily 3 T3 f3_0 := by unfold CertifiedFamily; decide +kernel
theorem classifies3 : BasisClassifies 3 R3 T3 := by
  intro i
  fin_cases i
  · exact Or.inl (nullOfMask_sound 3 0 #[1,0,0] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 3 1 #[0,0,-1] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 3 3 #[0,1,-1] (by decide +kernel))
  · exact Or.inr ⟨f3_0,rfl,f3_0_certified⟩
#print axioms classifies3
def T4 : Array Tmpl := #[#[#[0,0,0,1],#[0,0,1,0],#[0,1,0,0],#[1,0,0,0]],#[#[0,1,0,1],#[1,0,1,0],#[0,1,0,0],#[1,0,0,0]],#[#[0,1,1,1],#[1,0,1,0],#[1,1,0,0],#[1,0,0,0]],#[#[0,1,1,1],#[1,0,1,1],#[1,1,0,1],#[1,1,1,0]],#[#[0,1,0,1,0],#[1,0,1,0,0],#[0,1,0,0,0],#[1,0,0,0,1],#[0,0,0,1,0]],#[#[0,1,1,1,0],#[1,0,1,0,0],#[1,1,0,0,1],#[1,0,0,0,1],#[0,0,1,1,0]],#[#[0,1,1,1,0],#[1,0,1,0,0],#[1,1,0,0,1],#[1,0,0,0,0],#[0,0,1,0,0]],#[#[0,1,1,1,0,0],#[1,0,1,0,1,0],#[1,1,0,0,0,1],#[1,0,0,0,1,1],#[0,1,0,1,0,1],#[0,0,1,1,1,0]],#[#[0,1,1,1,0,0],#[1,0,1,0,0,1],#[1,1,0,0,1,0],#[1,0,0,0,0,1],#[0,0,1,0,0,0],#[0,1,0,1,0,0]]]
def f4_0 : Family := ⟨12,1,#[#[0,0,0,1],#[0,0,1,0],#[0,1,0,0],#[1,0,0,0]],[8, 4, 2, 1],[3, 5, 10, 12],#[some (0,#[0,1,2,3]),some (4,#[1,3,4,2,0]),some (4,#[1,4,3,2,0]),some (8,#[2,3,5,4,0,1]),some (4,#[2,3,4,1,0]),some (8,#[3,2,4,5,0,1]),none,none,some (4,#[2,4,3,1,0]),none,some (8,#[3,4,2,5,0,1]),none,some (8,#[4,3,5,2,0,1]),none,none,none]⟩
theorem f4_0_certified : CertifiedFamily 4 T4 f4_0 := by unfold CertifiedFamily; decide +kernel
def f4_1 : Family := ⟨13,1,#[#[0,0,0,1],#[0,0,1,0],#[0,1,0,-1],#[1,0,-1,0]],[10, 5, 2, 1],[3, 4, 8, 13, 14],#[some (1,#[0,1,2,3]),some (6,#[0,2,4,3,1]),some (4,#[1,0,3,2,4]),some (8,#[2,0,3,4,1,5]),some (4,#[0,1,2,3,4]),some (8,#[0,2,4,3,1,5]),none,none,some (5,#[0,3,4,1,2]),none,none,none,some (8,#[0,3,5,2,4,1]),none,none,none,some (5,#[3,0,1,4,2]),none,some (8,#[3,0,2,5,4,1]),none,none,none,none,none,some (7,#[0,3,4,2,1,5]),none,none,none,none,none,none,none]⟩
theorem f4_1_certified : CertifiedFamily 4 T4 f4_1 := by unfold CertifiedFamily; decide +kernel
def f4_2 : Family := ⟨15,1,#[#[0,0,0,1],#[0,0,1,-1],#[0,1,0,-1],#[1,-1,-1,2]],[14, 5, 3, 1],[2, 4, 10, 12],#[some (2,#[0,1,2,3]),some (6,#[0,2,1,3,4]),some (6,#[0,1,2,3,4]),some (8,#[2,0,1,4,3,5]),some (5,#[0,2,1,3,4]),none,some (8,#[0,1,2,3,4,5]),none,some (5,#[0,1,2,3,4]),some (8,#[0,2,1,3,4,5]),none,none,some (7,#[0,1,2,3,4,5]),none,none,none]⟩
theorem f4_2_certified : CertifiedFamily 4 T4 f4_2 := by unfold CertifiedFamily; decide +kernel
def f4_3 : Family := ⟨63,-3,#[#[2,-1,-1,-1],#[-1,2,-1,-1],#[-1,-1,2,-1],#[-1,-1,-1,2]],[14, 13, 11, 7],[],#[some (3,#[0,1,2,3])]⟩
theorem f4_3_certified : CertifiedFamily 4 T4 f4_3 := by unfold CertifiedFamily; decide +kernel
theorem classifies4 : BasisClassifies 4 R4 T4 := by
  intro i
  fin_cases i
  · exact Or.inl (nullOfMask_sound 4 0 #[1,0,0,0] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 4 1 #[0,0,-1,0] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 4 3 #[0,1,-1,0] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 4 7 #[0,0,0,1] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 4 11 #[0,1,-1,0] (by decide +kernel))
  · exact Or.inr ⟨f4_0,rfl,f4_0_certified⟩
  · exact Or.inr ⟨f4_1,rfl,f4_1_certified⟩
  · exact Or.inr ⟨f4_2,rfl,f4_2_certified⟩
  · exact Or.inl (nullOfMask_sound 4 30 #[1,-1,0,0] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 4 31 #[0,0,-1,1] (by decide +kernel))
  · exact Or.inr ⟨f4_3,rfl,f4_3_certified⟩
#print axioms classifies4
def T5 : Array Tmpl := #[#[#[0,0,0,1,1],#[0,0,1,0,1],#[0,1,0,1,0],#[1,0,1,0,0],#[1,1,0,0,0]],#[#[0,0,0,0,1],#[0,0,1,1,0],#[0,1,0,1,0],#[0,1,1,0,0],#[1,0,0,0,0]],#[#[0,1,1,0,1],#[1,0,1,1,0],#[1,1,0,1,0],#[0,1,1,0,0],#[1,0,0,0,0]],#[#[0,1,0,0,1],#[1,0,1,1,0],#[0,1,0,1,0],#[0,1,1,0,0],#[1,0,0,0,0]],#[#[0,1,1,1,1],#[1,0,0,0,1],#[1,0,0,1,0],#[1,0,1,0,0],#[1,1,0,0,0]],#[#[0,1,1,1,1],#[1,0,1,0,1],#[1,1,0,1,0],#[1,0,1,0,0],#[1,1,0,0,0]],#[#[0,1,1,1,1],#[1,0,1,1,0],#[1,1,0,1,0],#[1,1,1,0,0],#[1,0,0,0,0]],#[#[0,1,1,1,1],#[1,0,1,1,1],#[1,1,0,1,0],#[1,1,1,0,0],#[1,1,0,0,0]],#[#[0,1,1,1,1],#[1,0,1,1,1],#[1,1,0,1,1],#[1,1,1,0,1],#[1,1,1,1,0]],#[#[0,1,0,0,1,1],#[1,0,1,1,0,0],#[0,1,0,1,0,0],#[0,1,1,0,0,1],#[1,0,0,0,0,1],#[1,0,0,1,1,0]],#[#[0,1,1,0,1,0],#[1,0,1,1,0,0],#[1,1,0,1,0,0],#[0,1,1,0,0,0],#[1,0,0,0,0,1],#[0,0,0,0,1,0]],#[#[0,1,1,1,1,0],#[1,0,1,0,1,1],#[1,1,0,1,0,1],#[1,0,1,0,0,0],#[1,1,0,0,0,1],#[0,1,1,0,1,0]],#[#[0,1,1,1,1,0],#[1,0,1,1,0,0],#[1,1,0,1,0,0],#[1,1,1,0,0,1],#[1,0,0,0,0,1],#[0,0,0,1,1,0]],#[#[0,1,1,1,1,0],#[1,0,1,1,1,0],#[1,1,0,1,0,0],#[1,1,1,0,0,1],#[1,1,0,0,0,0],#[0,0,0,1,0,0]],#[#[0,1,1,1,1,0],#[1,0,1,0,1,0],#[1,1,0,1,0,0],#[1,0,1,0,0,0],#[1,1,0,0,0,1],#[0,0,0,0,1,0]],#[#[0,1,1,1,1,0],#[1,0,1,1,1,1],#[1,1,0,1,0,0],#[1,1,1,0,0,1],#[1,1,0,0,0,1],#[0,1,0,1,1,0]],#[#[0,1,1,1,1,0,0],#[1,0,1,0,1,0,1],#[1,1,0,1,0,0,1],#[1,0,1,0,0,0,0],#[1,1,0,0,0,1,1],#[0,0,0,0,1,0,1],#[0,1,1,0,1,1,0]],#[#[0,1,1,1,1,0,0],#[1,0,1,1,0,0,0],#[1,1,0,1,0,1,0],#[1,1,1,0,0,0,1],#[1,0,0,0,0,1,1],#[0,0,1,0,1,0,1],#[0,0,0,1,1,1,0]],#[#[0,1,1,1,1,0,0],#[1,0,1,0,1,1,0],#[1,1,0,1,0,1,0],#[1,0,1,0,0,1,0],#[1,1,0,0,0,0,1],#[0,1,1,1,0,0,0],#[0,0,0,0,1,0,0]],#[#[0,1,1,1,1,1,0],#[1,0,1,1,1,0,1],#[1,1,0,1,0,0,0],#[1,1,1,0,0,1,1],#[1,1,0,0,0,1,1],#[1,0,0,1,1,0,1],#[0,1,0,1,1,1,0]],#[#[0,1,1,1,1,0,0],#[1,0,1,1,1,0,0],#[1,1,0,1,0,1,0],#[1,1,1,0,0,0,1],#[1,1,0,0,0,0,0],#[0,0,1,0,0,0,1],#[0,0,0,1,0,1,0]],#[#[0,1,1,1,1,0,0],#[1,0,1,1,1,0,1],#[1,1,0,1,0,0,1],#[1,1,1,0,0,1,0],#[1,1,0,0,0,0,1],#[0,0,0,1,0,0,0],#[0,1,1,0,1,0,0]],#[#[0,1,1,1,1,0,0],#[1,0,1,1,1,1,1],#[1,1,0,1,0,1,0],#[1,1,1,0,0,0,1],#[1,1,0,0,0,1,1],#[0,1,1,0,1,0,1],#[0,1,0,1,1,1,0]],#[#[0,1,1,1,1,0,0,0],#[1,0,1,1,0,1,0,0],#[1,1,0,1,0,0,1,0],#[1,1,1,0,0,0,0,1],#[1,0,0,0,0,1,1,1],#[0,1,0,0,1,0,1,1],#[0,0,1,0,1,1,0,1],#[0,0,0,1,1,1,1,0]],#[#[0,1,1,1,1,0,1,0],#[1,0,1,1,1,0,0,1],#[1,1,0,1,0,0,1,1],#[1,1,1,0,0,1,0,0],#[1,1,0,0,0,0,1,1],#[0,0,0,1,0,0,0,0],#[1,0,1,0,1,0,0,1],#[0,1,1,0,1,0,1,0]]]
def f5_0 : Family := ⟨116,-2,#[#[0,0,0,0,-2],#[0,1,-1,-1,0],#[0,-1,1,-1,0],#[0,-1,-1,1,0],#[-2,0,0,0,0]],[16, 12, 10, 6, 1],[7, 11, 13, 22, 26, 28],#[some (1,#[0,1,2,3,4]),some (10,#[4,1,2,3,5,0]),some (10,#[4,1,3,2,5,0]),some (18,#[4,2,3,5,6,0,1]),some (10,#[4,3,1,2,5,0]),some (18,#[4,3,2,5,6,0,1]),some (18,#[4,3,5,2,6,0,1]),some (24,#[3,4,6,7,5,0,1,2]),some (10,#[5,1,2,3,4,0]),some (20,#[5,0,1,4,6,2,3]),none,none,none,none,none,none,some (10,#[5,1,3,2,4,0]),none,some (20,#[5,0,4,1,6,2,3]),none,none,none,none,none,some (18,#[6,2,3,5,4,0,1]),none,none,none,none,none,none,none,some (10,#[5,3,1,2,4,0]),none,none,none,some (20,#[5,4,0,1,6,2,3]),none,none,none,some (18,#[6,3,2,5,4,0,1]),none,none,none,none,none,none,none,some (18,#[6,3,5,2,4,0,1]),none,none,none,none,none,none,none,some (24,#[5,4,6,7,3,0,1,2]),none,none,none,none,none,none,none]⟩
theorem f5_0_certified : CertifiedFamily 5 T5 f5_0 := by unfold CertifiedFamily; decide +kernel
def f5_1 : Family := ⟨117,-2,#[#[0,0,0,0,-2],#[0,1,-1,-1,-1],#[0,-1,1,-1,1],#[0,-1,-1,1,1],#[-2,-1,1,1,1]],[18, 13, 10, 6, 1],[7, 11, 12, 21, 25, 30],#[some (3,#[0,1,2,3,4]),some (14,#[4,0,2,3,5,1]),some (14,#[4,0,3,2,5,1]),some (21,#[3,1,4,6,5,0,2]),some (10,#[4,0,1,2,5,3]),some (18,#[4,0,2,3,6,1,5]),some (18,#[4,0,3,2,6,1,5]),some (24,#[3,0,4,6,5,1,2,7]),some (9,#[0,1,3,2,4,5]),some (16,#[0,4,6,5,3,1,2]),none,none,none,none,none,none,some (9,#[0,1,2,3,4,5]),none,some (16,#[0,4,5,6,3,1,2]),none,none,none,none,none,some (17,#[0,4,5,6,1,2,3]),none,none,none,none,none,none,none,some (12,#[4,0,1,2,5,3]),none,none,none,some (20,#[5,2,0,1,6,4,3]),none,none,none,some (17,#[4,0,2,1,6,5,3]),none,none,none,none,none,none,none,some (17,#[4,0,1,2,6,5,3]),none,none,none,none,none,none,none,some (23,#[0,4,5,6,3,1,2,7]),none,none,none,none,none,none,none]⟩
theorem f5_1_certified : CertifiedFamily 5 T5 f5_1 := by unfold CertifiedFamily; decide +kernel
def f5_2 : Family := ⟨119,-2,#[#[0,0,0,0,-2],#[0,1,-1,-1,0],#[0,-1,1,-1,0],#[0,-1,-1,1,2],#[-2,0,0,2,0]],[22, 13, 11, 6, 1],[7, 10, 12, 16, 27, 29],#[some (2,#[0,1,2,3,4]),some (13,#[3,0,1,4,5,2]),some (14,#[4,0,1,2,5,3]),some (21,#[3,1,0,4,5,2,6]),some (14,#[4,1,0,2,5,3]),some (21,#[3,0,1,4,5,2,6]),some (18,#[4,0,1,2,6,3,5]),some (24,#[3,0,1,4,5,2,6,7]),some (10,#[0,1,2,3,4,5]),some (20,#[2,0,1,4,5,3,6]),none,none,none,none,none,none,some (11,#[0,1,4,5,3,2]),none,none,none,some (16,#[0,1,4,6,3,5,2]),none,none,none,some (18,#[0,2,3,5,4,6,1]),none,none,none,none,none,none,none,some (11,#[0,4,1,5,3,2]),none,some (16,#[0,4,1,6,3,5,2]),none,none,none,none,none,some (18,#[0,3,2,5,4,6,1]),none,none,none,none,none,none,none,some (19,#[0,4,5,6,2,1,3]),none,none,none,none,none,none,none,some (24,#[0,4,6,7,3,5,1,2]),none,none,none,none,none,none,none]⟩
theorem f5_2_certified : CertifiedFamily 5 T5 f5_2 := by unfold CertifiedFamily; decide +kernel
def f5_3 : Family := ⟨127,-2,#[#[0,0,0,0,-2],#[0,1,-1,-1,1],#[0,-1,1,-1,1],#[0,-1,-1,1,1],#[-2,1,1,1,-3]],[30, 13, 11, 7, 1],[6, 10, 12, 18, 20, 24],#[some (6,#[0,1,2,3,4]),some (13,#[3,0,1,2,5,4]),some (13,#[3,0,2,1,5,4]),some (21,#[3,1,0,2,5,4,6]),some (13,#[3,2,0,1,5,4]),some (21,#[3,0,1,2,5,4,6]),some (21,#[3,0,2,1,5,4,6]),some (24,#[3,0,1,2,5,4,6,7]),some (12,#[0,3,1,2,4,5]),none,none,none,some (20,#[2,3,0,1,5,4,6]),none,none,none,some (12,#[0,1,3,2,4,5]),none,some (20,#[2,0,3,1,5,4,6]),none,none,none,none,none,some (17,#[0,2,3,1,4,5,6]),none,none,none,none,none,none,none,some (12,#[0,1,2,3,4,5]),some (20,#[2,0,1,3,5,4,6]),none,none,none,none,none,none,some (17,#[0,2,1,3,4,5,6]),none,none,none,none,none,none,none,some (17,#[0,1,2,3,4,5,6]),none,none,none,none,none,none,none,some (23,#[0,1,2,3,4,5,6,7]),none,none,none,none,none,none,none]⟩
theorem f5_3_certified : CertifiedFamily 5 T5 f5_3 := by unfold CertifiedFamily; decide +kernel
def f5_4 : Family := ⟨235,-4,#[#[1,-1,-1,-1,-1],#[-1,1,1,1,-3],#[-1,1,1,-3,1],#[-1,1,-3,1,1],#[-1,-3,1,1,1]],[30, 17, 9, 5, 3],[],#[some (4,#[0,1,2,3,4])]⟩
theorem f5_4_certified : CertifiedFamily 5 T5 f5_4 := by unfold CertifiedFamily; decide +kernel
def f5_5 : Family := ⟨236,2,#[#[1,-1,-1,1,1],#[-1,1,1,-1,1],#[-1,1,1,1,-1],#[1,-1,1,1,-1],#[1,1,-1,-1,1]],[24, 20, 10, 5, 3],[],#[some (0,#[0,1,2,3,4])]⟩
theorem f5_5_certified : CertifiedFamily 5 T5 f5_5 := by unfold CertifiedFamily; decide +kernel
def f5_6 : Family := ⟨239,-2,#[#[1,-1,-1,0,0],#[-1,1,1,0,-2],#[-1,1,1,-2,0],#[0,0,-2,0,2],#[0,-2,0,2,0]],[30, 21, 11, 5, 3],[8, 14, 16, 22, 27, 29],#[some (5,#[0,1,2,3,4]),some (14,#[0,2,1,4,3,5]),some (11,#[0,2,1,4,3,5]),some (16,#[0,2,1,4,3,5,6]),some (14,#[0,1,2,3,4,5]),none,some (18,#[0,1,2,3,4,5,6]),none,some (11,#[0,1,2,3,4,5]),some (18,#[0,2,1,4,3,6,5]),none,none,some (16,#[0,1,2,3,4,5,6]),none,none,none,some (15,#[1,0,4,5,2,3]),none,some (19,#[0,1,4,5,2,6,3]),none,some (21,#[1,0,4,6,3,5,2]),none,some (24,#[0,1,4,6,3,7,5,2]),none,none,none,none,none,none,none,none,none,some (15,#[1,4,0,2,5,3]),some (21,#[1,4,0,3,6,5,2]),none,none,none,none,none,none,some (19,#[0,4,1,2,5,6,3]),some (24,#[0,4,1,3,6,5,7,2]),none,none,none,none,none,none,some (22,#[1,0,4,5,3,2,6]),none,none,none,none,none,none,none,none,none,none,none,none,none,none,none]⟩
theorem f5_6_certified : CertifiedFamily 5 T5 f5_6 := by unfold CertifiedFamily; decide +kernel
def f5_7 : Family := ⟨255,-2,#[#[1,-1,0,0,-1],#[-1,1,0,0,-1],#[0,0,0,-2,2],#[0,0,-2,0,2],#[-1,-1,2,2,-3]],[30, 29, 11, 7, 3],[4, 8, 21, 22, 25, 26],#[some (7,#[0,1,2,3,4]),some (13,#[0,1,3,2,4,5]),some (13,#[0,1,2,3,4,5]),some (20,#[0,1,2,3,4,5,6]),some (15,#[1,0,3,2,4,5]),none,some (21,#[1,0,2,3,4,5,6]),none,some (15,#[0,1,3,2,4,5]),none,some (21,#[0,1,2,3,4,5,6]),none,some (19,#[0,1,3,2,4,5,6]),none,some (24,#[0,1,2,3,4,5,6,7]),none,some (15,#[1,0,2,3,4,5]),some (21,#[1,0,3,2,4,5,6]),none,none,some (22,#[1,0,2,3,4,5,6]),none,none,none,none,none,none,none,none,none,none,none,some (15,#[0,1,2,3,4,5]),some (21,#[0,1,3,2,4,5,6]),none,none,none,none,none,none,some (22,#[0,1,2,3,4,5,6]),none,none,none,none,none,none,none,some (19,#[0,1,2,3,4,5,6]),some (24,#[0,1,3,2,4,5,6,7]),none,none,none,none,none,none,none,none,none,none,none,none,none,none]⟩
theorem f5_7_certified : CertifiedFamily 5 T5 f5_7 := by unfold CertifiedFamily; decide +kernel
def f5_8 : Family := ⟨1023,4,#[#[-3,1,1,1,1],#[1,-3,1,1,1],#[1,1,-3,1,1],#[1,1,1,-3,1],#[1,1,1,1,-3]],[30, 29, 27, 23, 15],[],#[some (8,#[0,1,2,3,4])]⟩
theorem f5_8_certified : CertifiedFamily 5 T5 f5_8 := by unfold CertifiedFamily; decide +kernel
theorem classifies5 : BasisClassifies 5 R5 T5 := by
  intro i
  fin_cases i
  · exact Or.inl (nullOfMask_sound 5 0 #[1,0,0,0,0] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 5 1 #[0,0,-1,0,0] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 5 3 #[0,1,-1,0,0] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 5 7 #[0,0,0,1,0] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 5 11 #[0,1,-1,0,0] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 5 12 #[0,0,0,0,1] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 5 13 #[0,0,0,0,1] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 5 15 #[0,0,0,0,1] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 5 30 #[1,-1,0,0,0] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 5 31 #[0,0,-1,1,0] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 5 63 #[0,0,0,0,-1] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 5 75 #[0,1,-1,0,0] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 5 76 #[0,0,0,-1,1] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 5 77 #[0,0,0,-1,1] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 5 79 #[0,0,0,-1,1] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 5 86 #[0,0,-1,1,1] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 5 87 #[0,0,-1,1,1] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 5 94 #[0,0,-1,1,0] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 5 95 #[0,0,-1,1,0] (by decide +kernel))
  · exact Or.inr ⟨f5_0,rfl,f5_0_certified⟩
  · exact Or.inr ⟨f5_1,rfl,f5_1_certified⟩
  · exact Or.inr ⟨f5_2,rfl,f5_2_certified⟩
  · exact Or.inr ⟨f5_3,rfl,f5_3_certified⟩
  · exact Or.inl (nullOfMask_sound 5 222 #[1,-1,0,0,0] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 5 223 #[0,0,-1,1,0] (by decide +kernel))
  · exact Or.inr ⟨f5_4,rfl,f5_4_certified⟩
  · exact Or.inr ⟨f5_5,rfl,f5_5_certified⟩
  · exact Or.inl (nullOfMask_sound 5 237 #[1,-1,-1,1,0] (by decide +kernel))
  · exact Or.inr ⟨f5_6,rfl,f5_6_certified⟩
  · exact Or.inl (nullOfMask_sound 5 254 #[-1,1,0,0,0] (by decide +kernel))
  · exact Or.inr ⟨f5_7,rfl,f5_7_certified⟩
  · exact Or.inl (nullOfMask_sound 5 507 #[0,-1,1,0,0] (by decide +kernel))
  · exact Or.inl (nullOfMask_sound 5 511 #[0,0,0,1,-1] (by decide +kernel))
  · exact Or.inr ⟨f5_8,rfl,f5_8_certified⟩
#print axioms classifies5
end Conj20StarCert


namespace Conj20StarCert
open SpectralConjecture20 SpectralRank.CoverageData

def basisRepsOfRank : Nat → Array Nat
  | 2 => R2
  | 3 => R3
  | 4 => R4
  | 5 => R5
  | _ => #[]

def templatesOfRank : Nat → Array Tmpl
  | 2 => T2
  | 3 => T3
  | 4 => T4
  | 5 => T5
  | _ => #[]

theorem covers_rank_two_to_five (n : Nat) (hLo : 2≤n) (hHi : n≤5) :
    Covers n (basisRepsOfRank n) ∧ BasisClassifies n (basisRepsOfRank n) (templatesOfRank n) := by
  have hn : n=2 ∨ n=3 ∨ n=4 ∨ n=5 := by omega
  rcases hn with rfl|rfl|rfl|rfl
  · exact ⟨covers2,classifies2⟩
  · exact ⟨covers3,classifies3⟩
  · exact ⟨covers4,classifies4⟩
  · exact ⟨covers5,classifies5⟩

/-- Full source-to-verified-catalogue reduction for loopless binary symmetric
matrices of rank 2, 3, 4, or 5. Isolates are retained as a zero block. -/
theorem binary_graph_rank_two_to_five_is_catalogue_blowup {m : Type*} [Fintype m]
    (A : m → m → Bool) (hS : ∀ i j,A i j=A j i) (hD : ∀ i,A i i=false)
    (n : Nat) (hn : (binaryAdj A).rank=n) (hLo : 2≤n) (hHi : n≤5) :
    let T := templatesOfRank n
    ∃ (r : Nat) (_ : r<T.size) (w : Fin T[r]!.size → Nat) (z : Nat)
      (g : ((Σ i, Fin (w i)) ⊕ Fin z) ≃ m), (∀ i, 0<w i) ∧
      (binaryAdj A).submatrix g g =
        fromBlocks ((catalogueMatrix T[r]!).submatrix Sigma.fst Sigma.fst) 0 0 0 := by
  have ht : (binaryAdj A)ᵀ = binaryAdj A := by
    ext i j
    change (if A j i then (1:ℝ) else 0) = if A i j then 1 else 0
    rw [hS]
  have hBasis : ∃ e : Fin n ↪ m, ((binaryAdj A).submatrix e e).det ≠ 0 := by
    rw [←hn]
    exact exact_principal_basis (binaryAdj A) ht
  obtain ⟨e,hInv⟩ := hBasis
  obtain ⟨cov,clas⟩ := covers_rank_two_to_five n hLo hHi
  exact covered_basis_blowup A hS hD n (basisRepsOfRank n) (templatesOfRank n)
    cov clas e hInv hn.le
#print axioms binary_graph_rank_two_to_five_is_catalogue_blowup
end Conj20StarCert
