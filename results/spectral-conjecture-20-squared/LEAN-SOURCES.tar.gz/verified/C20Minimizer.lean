import C20Balance
import C20HubRepEarly
import C20Scope

namespace Conjecture20Squared
open Matrix Finset SpectralConjecture20 PawUnbounded
open scoped BigOperators Matrix

theorem realAdjHerm {V : Type*} (A : V → V → Bool) (hS : ∀ i j, A i j=A j i) :
    (realAdj A).IsHermitian := by
  rw [Matrix.IsHermitian.ext_iff]
  intro i j
  simp [realAdj,hS j i]

/-- A single explicitly displayed unverified input: the universal near-graph
classification. All other steps in the actual graph minimization are proved below. -/
theorem squared_minimizer_of_classification (n : Nat) (hn : 3 ≤ n)
    (near : ∀ (D : Fin (3*n) → Fin (3*n) → Bool) (hDS : ∀ i j, D i j=D j i),
      (∀ i, D i i=false) → score n _ (realAdjHerm D hDS) < (16/27:ℝ) →
      RelabelAs (realAdj D) (balanced n) ∨ RelabelAs (realAdj D) (hub n))
    (A : Fin (3*n) → Fin (3*n) → Bool) (hS : ∀ i j,A i j=A j i) (hD : ∀ i,A i i=false) :
    ((¬ RelabelAs (realAdj A) (balanced n)) ∧
      (∀ (B : Fin (3*n) → Fin (3*n) → Bool) (hT : ∀ i j, B i j = B j i),
        (∀ i, B i i=false) → (¬ RelabelAs (realAdj B) (balanced n)) →
        score n _ (realAdjHerm A hS) ≤ score n _ (realAdjHerm B hT))) ↔
      RelabelAs (realAdj A) (hub n) := by
  have hK : (balanced n).IsHermitian :=
    padded_herm TriangleSpectralFence.triangleSeed TriangleSpectralFence.triangleSeedHermitian
      (TriangleSpectralFence.triangleWeights n n n) 0
  have hKzero : score n _ hK=0 := by unfold score; simp [balanced_matches_target n hn hK]
  have hHub := hub_score_bounds n hn
  have zeroOf {B : Fin (3*n) → Fin (3*n) → Bool} (hB : ∀ i j, B i j=B j i)
      (rel : RelabelAs (realAdj B) (balanced n)) : score n _ (realAdjHerm B hB)=0 := by
    obtain ⟨e,he⟩ := rel
    exact (score_relabel n _ (realAdjHerm B hB) _ hK e he.symm).symm.trans hKzero
  have hubOf {B : Fin (3*n) → Fin (3*n) → Bool} (hB : ∀ i j, B i j=B j i)
      (rel : RelabelAs (realAdj B) (hub n)) : score n _ (realAdjHerm B hB)=score n _ (hub_herm n) := by
    obtain ⟨e,he⟩ := rel
    exact (score_relabel n _ (realAdjHerm B hB) _ (hub_herm n) e he.symm).symm
  have excl {B : Fin (3*n) → Fin (3*n) → Bool} (hB : ∀ i j, B i j=B j i)
      (hr : RelabelAs (realAdj B) (hub n)) : ¬ RelabelAs (realAdj B) (balanced n) := by
    intro hb
    exact hHub.1.ne' ((hubOf hB hr).symm.trans (zeroOf hB hb))
  constructor
  · rintro ⟨hNot,hMin⟩
    obtain ⟨B,hBS,hBD,hr⟩ := hub_has_bool_representative n (by omega)
    have hc := (hMin B hBS hBD (excl hBS hr)).trans_lt ((hubOf hBS hr).trans_lt hHub.2)
    exact (near A hS hD hc).resolve_left hNot
  · intro hr
    refine ⟨excl hS hr,?_⟩
    intro B hT hDiag hNot
    by_contra! hc
    have hB := (near B hT hDiag (hc.trans ((hubOf hS hr).trans_lt hHub.2))).resolve_left hNot
    exact hc.ne ((hubOf hT hB).trans (hubOf hS hr).symm)

#print axioms squared_minimizer_of_classification
end Conjecture20Squared
