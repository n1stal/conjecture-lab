import C20RankMin
import C20Structure
namespace Conjecture20Squared
open Matrix Finset SpectralConjecture20 Conj20StarCert UnitPruning PawUnbounded
open scoped BigOperators Matrix
theorem score_congr {m : Type*} [Fintype m] [DecidableEq m] (n : Nat)
    (A B : Matrix m m ℝ) (e : A=B) (hA : A.IsHermitian) (hB : B.IsHermitian) :
    score n A hA=score n B hB := by subst B; rfl

theorem canonical_triangle_row :
    catalogueMatrix T3[0]! = TriangleSpectralFence.triangleSeed := by
  apply Matrix.ext
  change ∀ i j : Fin 3, catalogueMatrix T3[0]! i j=TriangleSpectralFence.triangleSeed i j
  intro i j
  fin_cases i <;> fin_cases j <;> norm_num [catalogueMatrix,tget,T3,TriangleSpectralFence.triangleSeed]

theorem triangle_branch (n : Nat) (hn : 3 ≤ n) (w : Fin 3 → Nat) (z : Nat) (hw : ∀ i, 0 < w i)
    (hSize : Fintype.card (Vertices w ⊕ Fin z)=3*n)
    (hF : (withIsolates (catalogueMatrix T3[0]!) w z).IsHermitian)
    (hClose : score (m:=Vertices w ⊕ Fin z) n _ hF < (16/27:ℝ)) :
    z=0 ∧ w = TriangleSpectralFence.triangleWeights n n n := by
  let a := w 0
  let b := w 1
  let c := w 2
  have hW : w = TriangleSpectralFence.triangleWeights a b c := by
    funext i; fin_cases i <;> rfl
  have normal (v : Fin 3 → Nat) (hV : v=TriangleSpectralFence.triangleWeights a b c)
      (hS : Fintype.card (Vertices v ⊕ Fin z)=3*n)
      (hG : (withIsolates (catalogueMatrix T3[0]!) v z).IsHermitian)
      (hC : score (m:=Vertices v ⊕ Fin z) n _ hG < (16/27:ℝ)) : a=n ∧ b=n ∧ c=n ∧ z=0 := by
    subst v
    let v := TriangleSpectralFence.triangleWeights a b c
    have eq := congrArg (fun M => withIsolates M v z) canonical_triangle_row
    have hB : (withIsolates TriangleSpectralFence.triangleSeed v z).IsHermitian := eq ▸ hG
    have ee := score_congr (m:=Vertices v ⊕ Fin z) n _ _ eq hG hB
    have ht := ee.symm.trans_lt hC
    obtain ⟨h0,_,h2,h3,_⟩ := profile n _ hn hS
    exact TriangleSpectralFence.triangle_padded_close_is_balanced n a b c z hn
      (hw 0) (hw 1) (hw 2) hB hS (target n _) h0 h2 h3 (ht.trans (by norm_num))
  obtain ⟨ha,hb,hc,hz⟩ := normal w hW hSize hF hClose
  exact ⟨hz, hW.trans (by rw [ha,hb,hc])⟩

#print axioms triangle_branch
end Conjecture20Squared
