import C20Bench

namespace Conjecture20Squared
open Matrix
open scoped BigOperators Matrix

/-- Conditional only on the near-graph classification and a known copy
of the balanced spectrum. It is unnecessary to assume a separate DS theorem.
The positive distance of the hub is the actual kernel-checked benchmark. -/
theorem eq_target_iff_iso_of_close_classification
    {V K : Type*} [Fintype V] [DecidableEq V] [Fintype K] [DecidableEq K]
    (n : Nat) (hn : 3 ≤ n)
    (A : Matrix V V ℝ) (hA : A.IsHermitian)
    (B : Matrix K K ℝ) (hB : B.IsHermitian)
    (base : hB.eigenvalues₀ = target n (Fintype.card K))
    (near : score n _ hA < (16/27:ℝ) → RelabelAs A B ∨ RelabelAs A (hub n)) :
    hA.eigenvalues₀ = target n (Fintype.card V) ↔ RelabelAs A B := by
  have hZ : score n _ hB = 0 := by unfold score; simp [base]
  constructor
  · intro equal
    have hz : score n _ hA = 0 := by unfold score; simp [equal]
    have hs : score n _ hA < (16/27:ℝ) := by rw [hz]; norm_num
    rcases near hs with hb | ⟨e,he⟩
    · exact hb
    · have eq := score_relabel n A hA _ (hub_herm n) e he.symm
      exact False.elim ((hub_score_bounds n hn).1.ne' (eq.trans hz))
  · rintro ⟨e,he⟩
    by_contra h
    have hp := (positive_score_iff n A hA).2 h
    exact hp.ne' ((score_relabel n A hA B hB e he.symm).symm.trans hZ)

#print axioms eq_target_iff_iso_of_close_classification
end Conjecture20Squared
