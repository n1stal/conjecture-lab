import Lean
import Mathlib.Analysis.Matrix.Spectrum
import Mathlib.Algebra.Order.BigOperators.Ring.Finset
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import Mathlib.Analysis.Real.Sqrt
import Mathlib.LinearAlgebra.Matrix.Charpoly.Basic
import Mathlib.Data.Fin.Embedding
import Mathlib.LinearAlgebra.Matrix.Rank
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity












open Matrix Finset Module
open scoped BigOperators
namespace SpectralConjecture20

/-- A diagonal form cannot be positive on a subspace of dimension larger than
    the number of its positive coefficients. -/
theorem positive_diagonal_dimension_bound {m : Type*} [Fintype m]
    (d : m → ℝ) (V : Submodule ℝ (m → ℝ))
    (hp : ∀ x ∈ V, x ≠ 0 → 0 < ∑ i, d i * (x i)^2) :
    finrank ℝ V ≤ Fintype.card {i // 0 < d i} := by
  classical
  let f : V →ₗ[ℝ] ({i // 0 < d i} → ℝ) :=
    { toFun := fun x i => x.val i
      map_add' := by intro x y; rfl
      map_smul' := by intro s x; rfl }
  have hinj : Function.Injective f := by
    apply LinearMap.ker_eq_bot.mp
    rw [Submodule.eq_bot_iff]
    intro x hx
    have hz : ∀ i, 0 < d i → x.val i = 0 := fun i hi =>
      congrFun (LinearMap.mem_ker.mp hx) ⟨i,hi⟩
    by_contra! hne
    have hn : x.val ≠ (0 : m → ℝ) := fun h => hne (Subtype.ext h)
    have H := hp x.val x.property hn
    have S : (∑ i, d i * (x.val i)^2) ≤ 0 := sum_nonpos fun i _ => by
      by_cases hi : 0 < d i
      · simp [hz i hi]
      · exact mul_nonpos_of_nonpos_of_nonneg (le_of_not_gt hi) (sq_nonneg _)
    exact (not_lt_of_ge S) H
  simpa using (LinearMap.finrank_le_finrank_of_injective hinj :
    finrank ℝ V ≤ finrank ℝ ({i // 0 < d i} → ℝ))
#print axioms positive_diagonal_dimension_bound

theorem quadratic_form_of_diagonalization {m : Type*} [Fintype m] [DecidableEq m]
    (U : Matrix m m ℝ) (d : m → ℝ) (x : m → ℝ) :
    x ⬝ᵥ ((U * diagonal d * Uᵀ) *ᵥ x) =
      ∑ i, d i * ((Uᵀ *ᵥ x) i)^2 := by
  rw [← mulVec_mulVec, ← mulVec_mulVec]
  have e : x ⬝ᵥ (U *ᵥ (diagonal d *ᵥ (Uᵀ *ᵥ x))) =
       (diagonal d *ᵥ (Uᵀ *ᵥ x)) ⬝ᵥ (Uᵀ *ᵥ x) := by
    simpa only [transpose_transpose] using
      (dotProduct_transpose_mulVec Uᵀ x (diagonal d *ᵥ (Uᵀ *ᵥ x)))
  rw [e,dotProduct]
  apply Finset.sum_congr rfl
  intro i _
  rw [mulVec_diagonal]
  ring

theorem positive_index_upper_bound {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (hB : B.IsHermitian) (V : Submodule ℝ (m → ℝ))
    (hp : ∀ x ∈ V, x ≠ 0 → 0 < x ⬝ᵥ (B *ᵥ x)) :
    finrank ℝ V ≤ Fintype.card {i // 0 < hB.eigenvalues i} := by
  classical
  let U : Matrix m m ℝ := hB.eigenvectorUnitary
  have hstar : star U = Uᵀ := by
    rw [star_eq_conjTranspose,conjTranspose_eq_transpose_of_trivial]
  have hLeft : Uᵀ * U=1 := by
    rw [← hstar]
    exact Unitary.coe_star_mul_self hB.eigenvectorUnitary
  have hRight : U * Uᵀ=1 := by
    rw [← hstar]
    exact Unitary.coe_mul_star_self hB.eigenvectorUnitary
  have he : B = U * diagonal hB.eigenvalues * Uᵀ := by
    have h := hB.spectral_theorem
    rw [Unitary.conjStarAlgAut_apply, ← Unitary.coe_star] at h
    change B = U * diagonal (RCLike.ofReal ∘ hB.eigenvalues) * star U at h
    rw [hstar] at h
    simpa using h
  let e : (m → ℝ) ≃ₗ[ℝ] (m → ℝ) :=
    LinearEquiv.ofLinearMap Uᵀ.mulVecLin U.mulVecLin
      (by rw [← mulVecLin_mul,hLeft]; ext z i; simp)
      (by rw [← mulVecLin_mul,hRight]; ext z i; simp)
  rw [← LinearEquiv.finrank_map_eq e V]
  refine positive_diagonal_dimension_bound hB.eigenvalues (V.map e.toLinearMap) ?_
  intro y hy hy0
  obtain ⟨x,hx,rfl⟩ := Submodule.mem_map.mp hy
  have hx0 : x ≠ 0 := by
    intro hxz
    exact hy0 (by simp [hxz])
  have eq : x ⬝ᵥ (B *ᵥ x) = ∑ i, hB.eigenvalues i * ((Uᵀ *ᵥ x) i)^2 := by
    exact (congrArg (fun A : Matrix m m ℝ => x ⬝ᵥ (A *ᵥ x)) he).trans
      (quadratic_form_of_diagonalization U hB.eigenvalues x)
  change 0 < ∑ i, hB.eigenvalues i * ((Uᵀ *ᵥ x) i)^2
  exact eq ▸ hp x hx hx0
#print axioms positive_index_upper_bound

theorem positive_diagonal_subspace_exists {m : Type*} [Fintype m]
    (d : m → ℝ) :
    ∃ V : Submodule ℝ (m → ℝ), finrank ℝ V = Fintype.card {i // 0 < d i} ∧
      ∀ x ∈ V, x ≠ 0 → 0 < ∑ i, d i * (x i)^2 := by
  classical
  let f : ({i // 0<d i} → ℝ) →ₗ[ℝ] (m → ℝ) :=
    { toFun := fun v i => if h : 0<d i then v ⟨i,h⟩ else 0
      map_add' := by
        intro x y
        funext i
        by_cases h : 0<d i <;> simp [h]
      map_smul' := by
        intro a x
        funext i
        by_cases h : 0<d i <;> simp [h] }
  have hf : Function.Injective f := by
    intro x y eq
    funext i
    have h := congrFun eq i.val
    change (if p : 0<d i.val then x ⟨i.val,p⟩ else 0) =
      (if p : 0<d i.val then y ⟨i.val,p⟩ else 0) at h
    simpa only [dite_eq_left i.property] using h
  refine ⟨LinearMap.range f,?_,?_⟩
  · rw [LinearMap.finrank_range_of_inj hf]
    simp
  · intro x hx h0
    obtain ⟨v,rfl⟩ := hx
    have hv : v ≠ 0 := by
      intro hz
      exact h0 (by simp [hz])
    obtain ⟨i,hi⟩ : ∃ i : {i // 0<d i}, v i ≠ 0 := by
      by_contra! h
      apply hv
      funext i
      exact h i
    have hAt : 0< d i.val * (f v i.val)^2 := by
      have eq : f v i.val = v i := by
        change (if p : 0<d i.val then v ⟨i.val,p⟩ else 0) = v i
        simp only [dite_eq_left i.property]
      exact mul_pos i.property (sq_pos_of_ne_zero (eq ▸ hi))
    have nonneg (j : m) : 0 ≤ d j * (f v j)^2 := by
      by_cases h : 0<d j
      · exact mul_nonneg h.le (sq_nonneg _)
      · have eq : f v j = 0 := by
          change (if p : 0<d j then v ⟨j,p⟩ else 0) = 0
          simp only [dite_eq_right h]
        simp [eq]
    exact hAt.trans_le (single_le_sum (fun j _ => nonneg j) (mem_univ i.val))

theorem positive_index_subspace {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (hB : B.IsHermitian) :
    ∃ V : Submodule ℝ (m → ℝ), finrank ℝ V = Fintype.card {i // 0<hB.eigenvalues i} ∧
      ∀ x ∈ V, x ≠ 0 → 0 < x ⬝ᵥ (B *ᵥ x) := by
  classical
  let U : Matrix m m ℝ := hB.eigenvectorUnitary
  have hstar : star U = Uᵀ := by
    rw [star_eq_conjTranspose,conjTranspose_eq_transpose_of_trivial]
  have hLeft : Uᵀ * U=1 := by
    rw [← hstar]
    exact Unitary.coe_star_mul_self hB.eigenvectorUnitary
  have hRight : U * Uᵀ=1 := by
    rw [← hstar]
    exact Unitary.coe_mul_star_self hB.eigenvectorUnitary
  have he : B = U * diagonal hB.eigenvalues * Uᵀ := by
    have h := hB.spectral_theorem
    rw [Unitary.conjStarAlgAut_apply, ← Unitary.coe_star] at h
    change B = U * diagonal (RCLike.ofReal ∘ hB.eigenvalues) * star U at h
    rw [hstar] at h
    simpa using h
  let e : (m → ℝ) ≃ₗ[ℝ] (m → ℝ) :=
    LinearEquiv.ofLinearMap U.mulVecLin Uᵀ.mulVecLin
      (by rw [← mulVecLin_mul,hRight]; ext z i; simp)
      (by rw [← mulVecLin_mul,hLeft]; ext z i; simp)
  obtain ⟨V,hV,hp⟩ := positive_diagonal_subspace_exists hB.eigenvalues
  refine ⟨V.map e.toLinearMap, (LinearEquiv.finrank_map_eq e V).trans hV, ?_⟩
  intro y hy hy0
  obtain ⟨x,hx,rfl⟩ := Submodule.mem_map.mp hy
  have h0 : x ≠ 0 := by
    intro hz
    exact hy0 (by simp [hz])
  change 0 < (U *ᵥ x) ⬝ᵥ (B *ᵥ (U *ᵥ x))
  have eq : (U *ᵥ x) ⬝ᵥ (B *ᵥ (U *ᵥ x)) =
      ∑ i, hB.eigenvalues i * ((Uᵀ *ᵥ (U *ᵥ x)) i)^2 := by
    exact (congrArg (fun A : Matrix m m ℝ => (U *ᵥ x) ⬝ᵥ (A *ᵥ (U *ᵥ x))) he).trans
      (quadratic_form_of_diagonalization U hB.eigenvalues (U *ᵥ x))
  rw [eq,mulVec_mulVec,hLeft,one_mulVec]
  exact hp x hx h0
#print axioms positive_index_subspace

theorem compression_form {m n : Type*} [Fintype m] [Fintype n]
    (A : Matrix m m ℝ) (E : Matrix m n ℝ) (x : n → ℝ) :
    x ⬝ᵥ ((Eᵀ * A * E) *ᵥ x) = (E *ᵥ x) ⬝ᵥ (A *ᵥ (E *ᵥ x)) := by
  rw [← mulVec_mulVec, ← mulVec_mulVec, dotProduct_transpose_mulVec, dotProduct_comm]

theorem positive_index_compression_mono {m n : Type*} [Fintype m] [Fintype n]
    [DecidableEq m] [DecidableEq n]
    (A : Matrix m m ℝ) (hA : A.IsHermitian) (E : Matrix m n ℝ)
    (hC : (Eᵀ * A * E).IsHermitian) (hf : Function.Injective E.mulVecLin) :
    Fintype.card {i // 0 < hC.eigenvalues i} ≤ Fintype.card {i // 0 < hA.eigenvalues i} := by
  obtain ⟨V,hV,hp⟩ := positive_index_subspace (Eᵀ*A*E) hC
  let f := E.mulVecLin
  have hdim : finrank ℝ (V.map f) = finrank ℝ V := by
    have em : V.map f = LinearMap.range (f.comp V.subtype) := by
      rw [LinearMap.range_comp,Submodule.range_subtype]
    rw [em]
    exact LinearMap.finrank_range_of_inj (hf.comp V.injective_subtype)
  rw [← hV, ← hdim]
  apply positive_index_upper_bound A hA
  intro y hy hy0
  obtain ⟨x,hx,rfl⟩ := Submodule.mem_map.mp hy
  have hx0 : x ≠ 0 := by
    intro hz
    exact hy0 (by simp [hz])
  change 0 < (E *ᵥ x) ⬝ᵥ (A *ᵥ (E *ᵥ x))
  rw [← compression_form]
  exact hp x hx hx0

theorem compress_coordinate_form {m n : Type*} [Fintype m] [Fintype n]
    [DecidableEq m] (A : Matrix m m ℝ) (e : n ↪ m) :
    let E : Matrix m n ℝ := fun i j => if i=e j then 1 else 0
    Eᵀ * A * E = A.submatrix e e := by
  let E : Matrix m n ℝ := fun i j => if i=e j then 1 else 0
  change Eᵀ * A * E = A.submatrix e e
  have hAE : A*E = A.submatrix id e := by
    ext i j
    rw [Matrix.mul_apply]
    change (∑ k, A i k * (if k=e j then 1 else 0)) = A i (e j)
    simp [mul_ite]
  rw [Matrix.mul_assoc,hAE]
  ext i j
  rw [Matrix.mul_apply]
  change (∑ k, (if k=e i then 1 else 0) * A k (e j)) = A (e i) (e j)
  simp [ite_mul]

theorem coordinate_mulVec_injective {m n : Type*} [Fintype n] [DecidableEq m]
    (e : n ↪ m) :
    let E : Matrix m n ℝ := fun i j => if i=e j then 1 else 0
    Function.Injective E.mulVecLin := by
  classical
  let E : Matrix m n ℝ := fun i j => if i=e j then 1 else 0
  change Function.Injective E.mulVecLin
  intro x y h
  funext i
  have hz := congrFun h (e i)
  change (E *ᵥ x) (e i) = (E *ᵥ y) (e i) at hz
  simpa [E,mulVec,dotProduct,ite_mul,e.injective.eq_iff] using hz

theorem positive_index_principal_mono {m n : Type*} [Fintype m] [Fintype n]
    [DecidableEq m] [DecidableEq n]
    (A : Matrix m m ℝ) (hA : A.IsHermitian) (e : n ↪ m)
    (hB : (A.submatrix e e).IsHermitian) :
    Fintype.card {i // 0<hB.eigenvalues i} ≤ Fintype.card {i // 0<hA.eigenvalues i} := by
  let E : Matrix m n ℝ := fun i j => if i=e j then 1 else 0
  have hE : Eᵀ*A*E = A.submatrix e e := compress_coordinate_form A e
  have hC : (Eᵀ*A*E).IsHermitian := hE ▸ hB
  have h := positive_index_compression_mono A hA E hC (coordinate_mulVec_injective e)
  revert hC h
  rw [hE]
  exact fun _ h => h
#print axioms positive_index_principal_mono

theorem positive_index_compression_codim {m n : Type*} [Fintype m] [Fintype n]
    [DecidableEq m] [DecidableEq n]
    (A : Matrix m m ℝ) (hA : A.IsHermitian) (E : Matrix m n ℝ)
    (hC : (Eᵀ * A * E).IsHermitian) (hf : Function.Injective E.mulVecLin) :
    Fintype.card {i // 0 < hA.eigenvalues i} + Fintype.card n ≤
      Fintype.card {i // 0 < hC.eigenvalues i} + Fintype.card m := by
  obtain ⟨V,hV,hp⟩ := positive_index_subspace A hA
  let f := E.mulVecLin
  let R := LinearMap.range f
  let W := V.comap f
  have hR : finrank ℝ R = Fintype.card n := by
    change finrank ℝ (LinearMap.range f) = Fintype.card n
    rw [LinearMap.finrank_range_of_inj hf]
    simp
  have em : W.map f = LinearMap.range (f.comp W.subtype) := by
    rw [LinearMap.range_comp,Submodule.range_subtype]
  have hdim : finrank ℝ ↥(R ⊓ V) = finrank ℝ W := by
    rw [← Submodule.map_comap_eq f V]
    change finrank ℝ (W.map f) = finrank ℝ W
    rw [em]
    exact LinearMap.finrank_range_of_inj (hf.comp W.injective_subtype)
  have hSup : finrank ℝ ↥(R ⊔ V) ≤ Fintype.card m := by
    simpa using (Submodule.finrank_le (R ⊔ V) : finrank ℝ ↥(R ⊔ V) ≤ finrank ℝ (m → ℝ))
  have hd := Submodule.finrank_sup_add_finrank_inf_eq R V
  have hcount : finrank ℝ W ≤ Fintype.card {i // 0 < hC.eigenvalues i} := by
    apply positive_index_upper_bound (Eᵀ*A*E) hC W
    intro x hx hx0
    have hxV : (E *ᵥ x) ∈ V := hx
    have hy0 : E *ᵥ x ≠ 0 := by
      intro hy
      apply hx0
      apply hf
      simpa using hy
    rw [compression_form]
    exact hp (E *ᵥ x) hxV hy0
  omega

theorem positive_index_principal_codim {m n : Type*} [Fintype m] [Fintype n]
    [DecidableEq m] [DecidableEq n]
    (A : Matrix m m ℝ) (hA : A.IsHermitian) (e : n ↪ m)
    (hB : (A.submatrix e e).IsHermitian) :
    Fintype.card {i // 0<hA.eigenvalues i} + Fintype.card n ≤
      Fintype.card {i // 0<hB.eigenvalues i} + Fintype.card m := by
  let E : Matrix m n ℝ := fun i j => if i=e j then 1 else 0
  have hE : Eᵀ*A*E = A.submatrix e e := compress_coordinate_form A e
  have hC : (Eᵀ*A*E).IsHermitian := hE ▸ hB
  have h := positive_index_compression_codim A hA E hC (coordinate_mulVec_injective e)
  revert hC h
  rw [hE]
  exact fun _ h => h
#print axioms positive_index_principal_codim

theorem diagonal_quadratic_form {m : Type*} [Fintype m] [DecidableEq m]
    (d x : m → ℝ) : x ⬝ᵥ (diagonal d *ᵥ x) = ∑ i, d i*(x i)^2 := by
  rw [dotProduct]
  apply Finset.sum_congr rfl
  intro i _
  rw [mulVec_diagonal]
  ring

theorem diagonal_index_congr {m : Type*} [Fintype m] [DecidableEq m]
    (d : m → ℝ) (hD : (diagonal d).IsHermitian) :
    Fintype.card {i // 0<hD.eigenvalues i} = Fintype.card {i // 0<d i} := by
  apply Nat.le_antisymm
  · obtain ⟨V,hV,hp⟩ := positive_index_subspace (diagonal d) hD
    rw [← hV]
    apply positive_diagonal_dimension_bound d V
    intro x hx hn
    rw [← diagonal_quadratic_form]
    exact hp x hx hn
  · obtain ⟨V,hV,hp⟩ := positive_diagonal_subspace_exists d
    rw [←hV]
    apply positive_index_upper_bound (diagonal d) hD V
    intro x hx hn
    rw [diagonal_quadratic_form]
    exact hp x hx hn

theorem shifted_isHermitian {m : Type*} [DecidableEq m] (B : Matrix m m ℝ)
    (hB : B.IsHermitian) (s t : ℝ) : (s • B - t • (1 : Matrix m m ℝ)).IsHermitian := by
  change Bᴴ = B at hB
  change (s • B - t • (1 : Matrix m m ℝ))ᴴ = _
  rw [conjTranspose_eq_transpose_of_trivial] at hB ⊢
  simp [hB]

theorem shifted_positive_index {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (hB : B.IsHermitian) (s t : ℝ) :
    Fintype.card {i // 0<(shifted_isHermitian B hB s t).eigenvalues i} =
      Fintype.card {i // t<s*hB.eigenvalues i} := by
  classical
  let U : Matrix m m ℝ := hB.eigenvectorUnitary
  have hstar : star U = Uᵀ := by
    rw [star_eq_conjTranspose,conjTranspose_eq_transpose_of_trivial]
  have hL : Uᵀ * U = 1 := by
    rw [←hstar]
    exact Unitary.coe_star_mul_self hB.eigenvectorUnitary
  have hR : U * Uᵀ = 1 := by
    rw [←hstar]
    exact Unitary.coe_mul_star_self hB.eigenvectorUnitary
  have he : B = U * diagonal hB.eigenvalues * Uᵀ := by
    have h := hB.spectral_theorem
    rw [Unitary.conjStarAlgAut_apply, ← Unitary.coe_star] at h
    change B = U * diagonal (RCLike.ofReal ∘ hB.eigenvalues) * star U at h
    rw [hstar] at h
    simpa using h
  let d : m → ℝ := fun i => s*hB.eigenvalues i-t
  have hD : (diagonal d).IsHermitian := by
    change (diagonal d)ᴴ = diagonal d
    simp
  let C : Matrix m m ℝ := s • B-t • (1 : Matrix m m ℝ)
  have hC : C.IsHermitian := shifted_isHermitian B hB s t
  have hRep : C = U*diagonal d*Uᵀ := by
    change s • B-t • (1 : Matrix m m ℝ) = _
    have hDiag : diagonal d = s • diagonal hB.eigenvalues - t • (1 : Matrix m m ℝ) := by
      ext i j
      by_cases hij : i=j
      · subst j; simp [d]
      · simp [hij]
    rw [hDiag,mul_sub,sub_mul,Matrix.mul_smul,Matrix.smul_mul,Matrix.mul_smul,
      Matrix.smul_mul, Matrix.mul_one, hR, ← he]
  have hComp : Uᵀ * C * U = diagonal d := by
    rw [hRep]
    calc
      _ = (Uᵀ*U)*diagonal d*(Uᵀ*U) := by simp only [Matrix.mul_assoc]
      _ = _ := by rw [hL,Matrix.one_mul,Matrix.mul_one]
  have hInj : Function.Injective U.mulVecLin := by
    intro x y h
    have q := congrArg (fun z => Uᵀ *ᵥ z) h
    change Uᵀ *ᵥ (U *ᵥ x) = Uᵀ *ᵥ (U *ᵥ y) at q
    simpa [mulVec_mulVec,hL] using q
  have hCH : (Uᵀ*C*U).IsHermitian := hComp ▸ hD
  have hMono := positive_index_compression_mono C hC U hCH hInj
  have hCodim := positive_index_compression_codim C hC U hCH hInj
  have hEq : Fintype.card {i // 0<hC.eigenvalues i} = Fintype.card {i // 0<hCH.eigenvalues i} := by omega
  have hToD : Fintype.card {i // 0<hCH.eigenvalues i} = Fintype.card {i // 0<hD.eigenvalues i} := by
    revert hCH
    rw [hComp]
    intros
    rfl
  exact hEq.trans (hToD.trans ((diagonal_index_congr d hD).trans
    (by simp only [d, sub_pos])))

#print axioms shifted_positive_index

theorem positive_index_of_matrix_eq {n : Type*} [Fintype n] [DecidableEq n]
    {X Y : Matrix n n ℝ} (he : X=Y) (hX : X.IsHermitian) (hY : Y.IsHermitian) :
    Fintype.card {i // 0<hX.eigenvalues i} = Fintype.card {i // 0<hY.eigenvalues i} := by
  subst Y
  rfl

theorem shifted_principal_interlacing {m n : Type*} [Fintype m] [Fintype n] [DecidableEq m] [DecidableEq n]
    (B : Matrix m m ℝ) (hB : B.IsHermitian) (e : n ↪ m) (s t : ℝ) :
    let hS := hB.submatrix e
    let q := Fintype.card {i // t < s * hB.eigenvalues i}
    let r := Fintype.card {i // t < s * hS.eigenvalues i}
    r ≤ q ∧ q + Fintype.card n ≤ r + Fintype.card m := by
  let C : Matrix m m ℝ := s • B - t • (1 : Matrix m m ℝ)
  let hC : C.IsHermitian := shifted_isHermitian B hB s t
  let hS := hB.submatrix e
  let D : Matrix n n ℝ := s • B.submatrix e e - t • (1 : Matrix n n ℝ)
  let hD : D.IsHermitian := shifted_isHermitian (B.submatrix e e) hS s t
  have re : C.submatrix e e = D := by
    ext i j
    change s*B (e i) (e j) - t*(1 : Matrix m m ℝ) (e i) (e j) =
      s*B (e i) (e j) - t*(1 : Matrix n n ℝ) i j
    simp [Matrix.one_apply,e.injective.eq_iff]
  have hem : Fintype.card {i // 0 < (hC.submatrix e).eigenvalues i} =
      Fintype.card {i // 0 < hD.eigenvalues i} :=
    positive_index_of_matrix_eq re (hC.submatrix e) hD
  have hm := positive_index_principal_mono C hC e (hC.submatrix e)
  have hc := positive_index_principal_codim C hC e (hC.submatrix e)
  have ha := shifted_positive_index B hB s t
  have hb := shifted_positive_index (B.submatrix e e) hS s t
  change Fintype.card {i // 0<hC.eigenvalues i} = _ at ha
  change Fintype.card {i // 0<hD.eigenvalues i} = _ at hb
  rw [hem, ha, hb] at hm hc
  exact ⟨hm,hc⟩
#print axioms shifted_principal_interlacing
end SpectralConjecture20

open Matrix Polynomial Finset
open scoped BigOperators
namespace SpectralConjecture20

abbrev Vertices {m : Type*} (w : m → Nat) := Σ i, Fin (w i)

def blowup {m : Type*} (B : Matrix m m ℝ) (w : m → Nat) :
    Matrix (Vertices w) (Vertices w) ℝ :=
  B.submatrix Sigma.fst Sigma.fst

def incidence {m : Type*} [DecidableEq m] (w : m → Nat) :
    Matrix (Vertices w) m ℝ := fun a i => if a.1=i then 1 else 0

theorem incidence_blowup {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (w : m → Nat) :
    incidence w * B * (incidence w)ᵀ = blowup B w := by
  have h : incidence w * B = B.submatrix Sigma.fst id := by
    ext a i
    rw [Matrix.mul_apply]
    change (∑ j, (if a.1=j then (1:ℝ) else 0)*B j i) = B a.1 i
    simp [ite_mul]
  rw [h]
  ext a b
  rw [Matrix.mul_apply]
  change (∑ j, B a.1 j * (if b.1=j then (1:ℝ) else 0)) = B a.1 b.1
  simp [mul_ite]

theorem incidence_gram {m : Type*} [Fintype m] [DecidableEq m] (w : m → Nat) :
    (incidence w)ᵀ * incidence w = diagonal (fun i => (w i : ℝ)) := by
  ext i j
  rw [Matrix.mul_apply]
  change (∑ a : Vertices w, (if a.1=i then (1:ℝ) else 0)*(if a.1=j then 1 else 0)) = _
  rw [Fintype.sum_sigma]
  by_cases h : i=j
  · subst j
    simp [mul_ite]
  · simp [mul_ite,h,Ne.symm h]

noncomputable def sqrtWeights {m : Type*} [DecidableEq m] (w : m → Nat) : Matrix m m ℝ :=
  diagonal (fun i => Real.sqrt (w i))

noncomputable def weightedQuotient {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (w : m → Nat) : Matrix m m ℝ :=
  sqrtWeights w * B * sqrtWeights w

theorem sqrtWeights_sq {m : Type*} [Fintype m] [DecidableEq m]
    (w : m → Nat) : sqrtWeights w * sqrtWeights w = diagonal (fun i => (w i : ℝ)) := by
  rw [sqrtWeights, diagonal_mul_diagonal]
  congr 1
  funext i
  exact Real.mul_self_sqrt (Nat.cast_nonneg _)

theorem weightedQuotient_charpoly {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (w : m → Nat) :
    (weightedQuotient B w).charpoly = (B * diagonal (fun i => (w i : ℝ))).charpoly := by
  rw [weightedQuotient, Matrix.mul_assoc, Matrix.charpoly_mul_comm, Matrix.mul_assoc, sqrtWeights_sq]

theorem blowup_charpoly {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (w : m → Nat) (hw : ∀ i, 0<w i) :
    (blowup B w).charpoly =
      X^(Fintype.card (Vertices w)-Fintype.card m) * (weightedQuotient B w).charpoly := by
  have hc : Fintype.card m ≤ Fintype.card (Vertices w) :=
    Fintype.card_le_of_injective (fun i => Sigma.mk i (⟨0,hw i⟩ : Fin (w i)))
      (fun _ _ hh => congrArg Sigma.fst hh)
  rw [← incidence_blowup, Matrix.charpoly_mul_comm_of_le _ _ hc, ← Matrix.mul_assoc, incidence_gram]
  rw [weightedQuotient_charpoly, Matrix.charpoly_mul_comm (diagonal _) B]

theorem blowup_roots {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (w : m → Nat) (hw : ∀ i, 0<w i) :
    (blowup B w).charpoly.roots =
      (Fintype.card (Vertices w)-Fintype.card m) • ({0} : Multiset ℝ) +
        (weightedQuotient B w).charpoly.roots := by
  rw [blowup_charpoly B w hw, roots_mul, roots_X_pow]
  exact mul_ne_zero (pow_ne_zero _ X_ne_zero) (charpoly_monic _).ne_zero

#print axioms blowup_roots

theorem blowup_isHermitian {m : Type*} (B : Matrix m m ℝ) (hB : B.IsHermitian) (w : m → Nat) :
    (blowup B w).IsHermitian :=
  hB.submatrix Sigma.fst

theorem weightedQuotient_isHermitian {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (hB : B.IsHermitian) (w : m → Nat) :
    (weightedQuotient B w).IsHermitian := by
  have hs : (sqrtWeights w).IsHermitian := by
    simp [sqrtWeights]
  have h := isHermitian_mul_mul_conjTranspose (sqrtWeights w) hB
  rw [hs.eq] at h
  exact h

theorem blowup_spectrum {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (hB : B.IsHermitian) (w : m → Nat) (hw : ∀ i, 0<w i) :
    (Finset.univ : Finset (Vertices w)).val.map (blowup_isHermitian B hB w).eigenvalues =
      (Fintype.card (Vertices w)-Fintype.card m) • ({0} : Multiset ℝ) +
        (Finset.univ : Finset m).val.map (weightedQuotient_isHermitian B hB w).eigenvalues := by
  simpa only [(blowup_isHermitian B hB w).roots_charpoly_eq_eigenvalues,
    (weightedQuotient_isHermitian B hB w).roots_charpoly_eq_eigenvalues,
    RCLike.ofReal_real_eq_id,Function.id_comp] using blowup_roots B w hw

#print axioms blowup_spectrum

theorem weighted_reciprocal_gram {m : Type*} [Fintype m] [DecidableEq m]
    (w : m → Nat) (hw : ∀ i, 0 < w i) :
    sqrtWeights w * diagonal (fun i => (w i : ℝ)⁻¹) * sqrtWeights w = 1 := by
  rw [sqrtWeights, diagonal_mul_diagonal, diagonal_mul_diagonal, ← diagonal_one]
  congr 1
  funext i
  have hW : (w i : ℝ) ≠ 0 := by exact_mod_cast (hw i).ne'
  change Real.sqrt (w i) * (w i : ℝ)⁻¹ * Real.sqrt (w i) = 1
  rw [mul_right_comm, Real.mul_self_sqrt (Nat.cast_nonneg _), mul_inv_cancel₀ hW]

theorem reciprocalShift_isHermitian {m : Type*} [DecidableEq m]
    (B : Matrix m m ℝ) (hB : B.IsHermitian) (w : m → Nat) (s t : ℝ) :
    (s • B - t • diagonal (fun i => (w i : ℝ)⁻¹)).IsHermitian := by
  change Bᴴ = B at hB
  change (s • B - t • diagonal (fun i => (w i : ℝ)⁻¹))ᴴ = _
  rw [conjTranspose_eq_transpose_of_trivial] at hB ⊢
  simp [hB]

theorem weighted_spectral_cut {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (hB : B.IsHermitian) (w : m → Nat) (hw : ∀ i, 0<w i)
    (s t : ℝ) :
    Fintype.card {i // t < s*(weightedQuotient_isHermitian B hB w).eigenvalues i} =
      Fintype.card {i // 0<(reciprocalShift_isHermitian B hB w s t).eigenvalues i} := by
  let S := sqrtWeights w
  let Q := weightedQuotient B w
  let hQ := weightedQuotient_isHermitian B hB w
  let A : Matrix m m ℝ := s • B - t • diagonal (fun i => (w i : ℝ)⁻¹)
  let hA : A.IsHermitian := reciprocalShift_isHermitian B hB w s t
  let hShift := shifted_isHermitian Q hQ s t
  have hSt : Sᵀ = S := by simp [S,sqrtWeights]
  have hemp : Sᵀ * A * S = s • Q - t • (1 : Matrix m m ℝ) := by
    change Sᵀ * (s • B - t • diagonal (fun i => (w i : ℝ)⁻¹)) * S = _
    rw [hSt,mul_sub,sub_mul,Matrix.mul_smul,Matrix.smul_mul,Matrix.mul_smul,Matrix.smul_mul]
    rw [weighted_reciprocal_gram w hw]
    rfl
  have hC : (Sᵀ*A*S).IsHermitian := hemp ▸ hShift
  have hf : Function.Injective S.mulVecLin := by
    intro x y h
    funext i
    have q := congrFun h i
    change (sqrtWeights w *ᵥ x) i = (sqrtWeights w *ᵥ y) i at q
    rw [sqrtWeights,mulVec_diagonal,mulVec_diagonal] at q
    have hs : Real.sqrt (w i) ≠ 0 := (Real.sqrt_pos.2 (by exact_mod_cast hw i)).ne'
    exact mul_left_cancel₀ hs q
  have hMono := positive_index_compression_mono A hA S hC hf
  have hCodim := positive_index_compression_codim A hA S hC hf
  have hEq : Fintype.card {i // 0<hC.eigenvalues i} = Fintype.card {i // 0<hA.eigenvalues i} := by omega
  exact (shifted_positive_index Q hQ s t).symm.trans
    ((positive_index_of_matrix_eq hemp hC hShift).symm.trans hEq)

#print axioms weighted_spectral_cut

def intWeightedCut {m : Type*} [DecidableEq m] (A : Matrix m m ℤ) (w : m → Nat)
    (L v : Nat) (s u : Int) : Matrix m m ℤ :=
  ((v : ℤ)*(L : ℤ)*s) • A - u • diagonal (fun i => ((L / w i : Nat) : ℤ))

def intMatrixToReal {n m : Type*} (A : Matrix n m ℤ) : Matrix n m ℝ := A.map (Int.castRingHom ℝ)

theorem intWeightedCut_cast {m : Type*} [DecidableEq m]
    (A : Matrix m m ℤ) (w : m → Nat) (hw : ∀ i, 0<w i)
    (L v : Nat) (hv : 0<v) (hd : ∀ i, w i ∣ L) (s u : Int) :
    intMatrixToReal (intWeightedCut A w L v s u) =
      ((v : ℝ)*(L : ℝ)) • ((s : ℝ) • intMatrixToReal A -
        ((u : ℝ)/(v : ℝ)) • diagonal (fun i => (w i : ℝ)⁻¹)) := by
  have hV : (v : ℝ) ≠ 0 := by exact_mod_cast hv.ne'
  ext i j
  have hW : (w i : ℝ) ≠ 0 := by exact_mod_cast (hw i).ne'
  have hquot : ((L / w i : Nat) : ℝ) = (L : ℝ) / (w i : ℝ) := by
    apply (eq_div_iff hW).2
    exact_mod_cast (Nat.div_mul_cancel (hd i))
  by_cases hh : i=j
  · subst j
    simp only [intMatrixToReal,intWeightedCut, Matrix.map_apply, Matrix.sub_apply,
      Matrix.smul_apply, smul_eq_mul, Matrix.diagonal_apply_eq, Int.coe_castRingHom,
      Int.cast_sub, Int.cast_mul, Int.cast_natCast,hquot]
    field_simp
  · simp [intMatrixToReal,intWeightedCut,smul_eq_mul,diagonal_apply_ne _ hh]
    ring

theorem intWeightedCut_isHermitian {m : Type*} [DecidableEq m]
    (A : Matrix m m ℤ) (hA : (intMatrixToReal A).IsHermitian)
    (w : m → Nat) (hw : ∀ i, 0<w i)
    (L v : Nat) (hv : 0<v) (hd : ∀ i, w i ∣ L) (s u : Int) :
    (intMatrixToReal (intWeightedCut A w L v s u)).IsHermitian := by
  rw [intWeightedCut_cast A w hw L v hv hd s u]
  exact (reciprocalShift_isHermitian (intMatrixToReal A) hA w (s : ℝ)
    ((u : ℝ)/(v : ℝ))).smul (by simp [IsSelfAdjoint])

theorem weighted_spectral_cut_integer {m : Type*} [Fintype m] [DecidableEq m]
    (A : Matrix m m ℤ) (hA : (intMatrixToReal A).IsHermitian)
    (w : m → Nat) (hw : ∀ i, 0<w i) (L v : Nat) (hL : 0<L) (hv : 0<v)
    (hd : ∀ i, w i ∣ L) (s u : Int) :
    Fintype.card {i // (u : ℝ)/(v : ℝ) <
        (s : ℝ)*(weightedQuotient_isHermitian (intMatrixToReal A) hA w).eigenvalues i} =
      Fintype.card {i // 0<(intWeightedCut_isHermitian A hA w hw L v hv hd s u).eigenvalues i} := by
  let D := (s : ℝ) • intMatrixToReal A - ((u : ℝ)/(v : ℝ)) • diagonal (fun i => (w i : ℝ)⁻¹)
  let hD := reciprocalShift_isHermitian (intMatrixToReal A) hA w (s : ℝ) ((u : ℝ)/(v : ℝ))
  let τ : ℝ := (v : ℝ)*(L : ℝ)
  have hτ : 0<τ := mul_pos (by exact_mod_cast hv) (by exact_mod_cast hL)
  have hEq : intMatrixToReal (intWeightedCut A w L v s u) =
      τ • D - (0 : ℝ) • (1 : Matrix m m ℝ) := by
    rw [zero_smul,sub_zero]
    exact intWeightedCut_cast A w hw L v hv hd s u
  have hOne := weighted_spectral_cut (intMatrixToReal A) hA w hw (s : ℝ) ((u : ℝ)/(v : ℝ))
  have hTwo := shifted_positive_index D hD τ 0
  have hThree := positive_index_of_matrix_eq hEq
    (intWeightedCut_isHermitian A hA w hw L v hv hd s u) (shifted_isHermitian D hD τ 0)
  rw [hOne,hThree,hTwo]
  simp only [mul_pos_iff_of_pos_left hτ]
#print axioms weighted_spectral_cut_integer

theorem card_filter_spectrum {n : Type*} [Fintype n] (u : n → ℝ) (p : ℝ → Prop)
    [DecidablePred p] :
    ((Finset.univ : Finset n).val.map u |>.filter p).card = Fintype.card {i // p (u i)} := by
  rw [Fintype.card_subtype, Multiset.filter_map, Multiset.card_map]
  rfl

theorem blowup_count_cut {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (hB : B.IsHermitian) (w : m → Nat) (hw : ∀ i, 0<w i)
    (s t : ℝ) (ht : 0≤t) :
    Fintype.card {i // t < s*(blowup_isHermitian B hB w).eigenvalues i} =
      Fintype.card {i // t < s*(weightedQuotient_isHermitian B hB w).eigenvalues i} := by
  classical
  let p : ℝ → Prop := fun x => t<s*x
  have hz (d : Nat) : (d • ({0} : Multiset ℝ)).filter p = 0 := by
    induction d with
    | zero => simp
    | succ d hd =>
      rw [succ_nsmul,Multiset.filter_add,hd,Multiset.filter_singleton]
      simp [p,ht.not_gt]
  have h := congrArg (fun z : Multiset ℝ => (z.filter p).card) (blowup_spectrum B hB w hw)
  simp only [Multiset.filter_add,hz,zero_add,card_filter_spectrum] at h
  exact h

theorem cut_index_of_matrix_eq {n : Type*} [Fintype n] [DecidableEq n]
    {X Y : Matrix n n ℝ} (he : X=Y) (hX : X.IsHermitian) (hY : Y.IsHermitian) (s t : ℝ) :
    Fintype.card {i // t < s*hX.eigenvalues i} = Fintype.card {i // t < s*hY.eigenvalues i} := by
  subst Y
  rfl

theorem weighted_spectral_cut_mono {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (hB : B.IsHermitian) (w z : m → Nat)
    (hw : ∀ i, 0<w i) (hm : ∀ i, w i ≤ z i) (s t : ℝ) (ht : 0≤t) :
    Fintype.card {i // t < s*(weightedQuotient_isHermitian B hB w).eigenvalues i} ≤
      Fintype.card {i // t < s*(weightedQuotient_isHermitian B hB z).eigenvalues i} := by
  let e : Vertices w ↪ Vertices z :=
    (Function.Embedding.refl m).sigmaMap (fun i => Fin.castLEEmb (hm i))
  have he : (blowup B z).submatrix e e = blowup B w := rfl
  have h := (shifted_principal_interlacing (blowup B z) (blowup_isHermitian B hB z) e s t).1
  change Fintype.card {i // t < s*((blowup_isHermitian B hB z).submatrix e).eigenvalues i} ≤
    Fintype.card {i // t < s*(blowup_isHermitian B hB z).eigenvalues i} at h
  rw [cut_index_of_matrix_eq he ((blowup_isHermitian B hB z).submatrix e)
        (blowup_isHermitian B hB w) s t,
      blowup_count_cut B hB w hw s t ht,
      blowup_count_cut B hB z (fun i => (hw i).trans_le (hm i)) s t ht] at h
  exact h

#print axioms weighted_spectral_cut_mono
/-- Adjoin a block of t isolated vertices to the template's blowup. -/
def withIsolates {m : Type*} (B : Matrix m m ℝ) (w : m → Nat) (t : Nat) :
    Matrix (Vertices w ⊕ Fin t) (Vertices w ⊕ Fin t) ℝ :=
  fromBlocks (blowup B w) 0 0 0

theorem withIsolates_charpoly {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (w : m → Nat) (hw : ∀ i, 0<w i) (t : Nat) :
    (withIsolates B w t).charpoly =
      X ^ ((Fintype.card (Vertices w)-Fintype.card m)+t) * (weightedQuotient B w).charpoly := by
  rw [withIsolates,charpoly_fromBlocks_zero₂₁,blowup_charpoly B w hw,charpoly_zero,Fintype.card_fin,pow_add]
  ring

theorem withIsolates_roots {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (w : m → Nat) (hw : ∀ i, 0<w i) (t : Nat) :
    (withIsolates B w t).charpoly.roots =
      ((Fintype.card (Vertices w)-Fintype.card m)+t) • ({0} : Multiset ℝ) +
        (weightedQuotient B w).charpoly.roots := by
  rw [withIsolates_charpoly B w hw t, roots_mul, roots_X_pow]
  exact mul_ne_zero (pow_ne_zero _ X_ne_zero) (charpoly_monic _).ne_zero
#print axioms withIsolates_roots
end SpectralConjecture20
namespace SpectralConjecture20

/-- A nonpositive subspace of dimension d rules out more than n-d positive
eigenvalues. This includes null directions. -/
theorem positive_index_nonpositive_sandwich {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (hB : B.IsHermitian) (V W : Submodule ℝ (m → ℝ))
    (hp : ∀ x ∈ V, x ≠ 0 → 0 < x ⬝ᵥ (B *ᵥ x))
    (hn : ∀ x ∈ W, x ⬝ᵥ (B *ᵥ x) ≤ 0) :
    finrank ℝ V ≤ Fintype.card {i // 0<hB.eigenvalues i} ∧
      Fintype.card {i // 0<hB.eigenvalues i}+finrank ℝ W ≤ Fintype.card m := by
  refine ⟨positive_index_upper_bound B hB V hp,?_⟩
  obtain ⟨E,hE,hpos⟩ := positive_index_subspace B hB
  have dis : E ⊓ W = ⊥ := by
    rw [Submodule.eq_bot_iff]
    intro x hx
    by_contra! hx0
    exact (not_lt_of_ge (hn x hx.2)) (hpos x hx.1 hx0)
  have hDimensions := Submodule.finrank_sup_add_finrank_inf_eq E W
  rw [dis,finrank_bot,add_zero,hE] at hDimensions
  rw [← hDimensions]
  simpa using (Submodule.finrank_le (E ⊔ W) : finrank ℝ ↥(E ⊔ W) ≤ finrank ℝ (m → ℝ))

/-- A full-rank exact integral Gram certificate verifies both inertia signs, including
the case of a zero eigenvalue: the positive diagonal entries count the positive index. -/
theorem int_gram_exact_positive_index {m : Type*} [Fintype m] [DecidableEq m]
    (B P : Matrix m m ℤ) (hB : (intMatrixToReal B).IsHermitian)
    (d : m → ℤ) (hp : P.det ≠ 0) (hGram : Pᵀ * B * P = diagonal d) :
    Fintype.card {i // 0<hB.eigenvalues i} = Fintype.card {i // 0<d i} := by
  let E := intMatrixToReal P
  have hj : E.det ≠ 0 := by
    change (P.map (fun x : ℤ => (x : ℝ))).det ≠ 0
    rw [←Int.cast_det]
    exact_mod_cast hp
  have hInj : Function.Injective E.mulVecLin := mulVec_injective_of_det_ne_zero hj
  have he : Eᵀ * intMatrixToReal B * E = diagonal (fun i => (d i : ℝ)) := by
    have h := congrArg (fun C : Matrix m m ℤ => C.map (Int.castRingHom ℝ)) hGram
    rw [Matrix.map_mul, Matrix.map_mul] at h
    have et : Pᵀ.map (Int.castRingHom ℝ) = Eᵀ := by rfl
    rw [et] at h
    simpa [intMatrixToReal,E] using h
  have hD : (diagonal (fun i => (d i : ℝ))).IsHermitian := by simp
  have hC : (Eᵀ * intMatrixToReal B * E).IsHermitian := he ▸ hD
  have hMono := positive_index_compression_mono (intMatrixToReal B) hB E hC hInj
  have hCodim := positive_index_compression_codim (intMatrixToReal B) hB E hC hInj
  have hCount : Fintype.card {i // 0<hB.eigenvalues i} = Fintype.card {i // 0<hC.eigenvalues i} := by omega
  have hd := positive_index_of_matrix_eq he hC hD
  have heq := diagonal_index_congr (fun i => (d i : ℝ)) hD
  rw [hCount,hd,heq]
  simp only [Int.cast_pos]

theorem weighted_spectral_cut_verified_gram {m : Type*} [Fintype m] [DecidableEq m]
    (A : Matrix m m ℤ) (hA : (intMatrixToReal A).IsHermitian)
    (w : m → Nat) (hw : ∀ i, 0<w i) (L v : Nat) (hL : 0<L) (hv : 0<v)
    (hd : ∀ i, w i ∣ L) (s u : Int)
    (P : Matrix m m ℤ) (d : m → ℤ) (hp : P.det ≠ 0)
    (hg : Pᵀ * intWeightedCut A w L v s u * P = diagonal d) :
    Fintype.card {i // (u : ℝ)/(v : ℝ) <
      (s : ℝ)*(weightedQuotient_isHermitian (intMatrixToReal A) hA w).eigenvalues i} =
      Fintype.card {i // 0<d i} := by
  rw [weighted_spectral_cut_integer A hA w hw L v hL hv hd s u]
  exact int_gram_exact_positive_index (intWeightedCut A w L v s u) P
    (intWeightedCut_isHermitian A hA w hw L v hv hd s u) d hp hg

#print axioms positive_index_nonpositive_sandwich
#print axioms int_gram_exact_positive_index
#print axioms weighted_spectral_cut_verified_gram

end SpectralConjecture20
namespace SpectralConjecture20

theorem det_ne_zero_of_scaled_left_inverse {m : Type*} [Fintype m] [DecidableEq m]
    (P K : Matrix m m ℤ) (d : ℤ) (hd : d ≠ 0) (h : K*P=d•(1:Matrix m m ℤ)) : P.det ≠ 0 := by
  have hdets := congrArg Matrix.det h
  rw [det_mul,det_smul,det_one,mul_one] at hdets
  intro hp
  rw [hp,mul_zero] at hdets
  exact pow_ne_zero _ hd hdets.symm

namespace PawCutExample

def A : Matrix (Fin 4) (Fin 4) ℤ := !![0,1,1,1;1,0,1,0;1,1,0,0;1,0,0,0]
def w : Fin 4 → Nat := ![17,17,17,1]
def P : Matrix (Fin 4) (Fin 4) ℤ := !![1,-85,85,7055;0,-2,85,-7225;0,0,-83,-7225;0,0,0,14616]
def K : Matrix (Fin 4) (Fin 4) ℤ := !![2426256,-103115880,-103115880,-103115880;0,-1213128,-1242360,-1213800;0,0,-29232,-14450;0,0,0,166]
def d : Fin 4 → Int := ![-578,4173738,-350593992,433938209544]

theorem checked_inverse : K*P=(2426256 : ℤ)•(1:Matrix (Fin 4) (Fin 4) ℤ) := by
  ext i j
  fin_cases i <;> fin_cases j <;> norm_num [K,P,Matrix.mul_apply,Matrix.one_apply,Fin.sum_univ_succ]

def cut : Matrix (Fin 4) (Fin 4) ℤ := !![-578,24565,24565,24565;24565,-578,24565,0;24565,24565,-578,0;24565,0,0,-9826]

theorem checked_matrix : intWeightedCut A w 4913 5 1 2 = cut := by
  ext i j
  fin_cases i <;> fin_cases j <;> decide +kernel

theorem checked_Gram : Pᵀ * intWeightedCut A w 4913 5 1 2 * P = diagonal d := by
  rw [checked_matrix]
  ext i j
  fin_cases i <;> fin_cases j <;>
    norm_num [P,d,cut,Matrix.mul_apply,diagonal_apply,Fin.sum_univ_succ]

theorem verified_paw_cut :
    let h : (intMatrixToReal A).IsHermitian := by
      ext i j; fin_cases i <;> fin_cases j <;> rfl
    Fintype.card {i // (2:ℝ)/5 < (weightedQuotient_isHermitian (intMatrixToReal A) h w).eigenvalues i} = 2 := by
  intro h
  have hv (i : Fin 4) : 0 < w i := by fin_cases i <;> decide
  have hd (i : Fin 4) : w i ∣ 4913 := by fin_cases i <;> decide
  have he := weighted_spectral_cut_verified_gram A h w hv 4913 5 (by decide) (by decide) hd
    1 2 P d (det_ne_zero_of_scaled_left_inverse P K _ (by decide) checked_inverse) checked_Gram
  rw [show (Fintype.card {i // (2:ℝ)/5 <
          (weightedQuotient_isHermitian (intMatrixToReal A) h w).eigenvalues i}) =
        Fintype.card {i // ((2:ℤ):ℝ)/(5:ℕ) <
          ((1:ℤ):ℝ)*(weightedQuotient_isHermitian (intMatrixToReal A) h w).eigenvalues i} by simp]
  rw [he]
  decide +kernel

#print axioms verified_paw_cut
end PawCutExample

end SpectralConjecture20
namespace SpectralConjecture20

theorem withIsolates_ordered_cut_count {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (hB : B.IsHermitian) (w : m → Nat) (hw : ∀ i, 0<w i) (z : Nat)
    (hFull : (withIsolates B w z).IsHermitian) (s t : ℝ) (ht : 0≤t) :
    Fintype.card {i // t < s*hFull.eigenvalues₀ i} =
      Fintype.card {i // t < s*(weightedQuotient_isHermitian B hB w).eigenvalues i} := by
  classical
  let p : ℝ → Prop := fun x => t<s*x
  have hz (d : Nat) : (d • ({0} : Multiset ℝ)).filter p = 0 := by
    induction d with
    | zero => simp
    | succ d hd =>
      rw [succ_nsmul,Multiset.filter_add,hd,Multiset.filter_singleton]
      simp [p,ht.not_gt]
  have he := withIsolates_roots B w hw z
  rw [hFull.roots_charpoly_eq_eigenvalues₀,
      (weightedQuotient_isHermitian B hB w).roots_charpoly_eq_eigenvalues,
      RCLike.ofReal_real_eq_id,Function.id_comp,Function.id_comp] at he
  have h := congrArg (fun u : Multiset ℝ => (u.filter p).card) he
  simp only [Multiset.filter_add,hz,zero_add,card_filter_spectrum] at h
  exact h
#print axioms withIsolates_ordered_cut_count

end SpectralConjecture20
open scoped BigOperators
open Finset
namespace SpectralConjecture20

noncomputable def gridMass (x : ℝ) (d : Nat) : ℝ :=
  ∑ j ∈ Finset.range d, if (j : ℝ)+1 < x then 2*(j : ℝ)+1 else 0

theorem gridMass_le_size (x : ℝ) (d : Nat) : gridMass x d ≤ (d : ℝ)^2 := by
  induction d with
  | zero => simp [gridMass]
  | succ d ih =>
    rw [gridMass,Finset.sum_range_succ,← gridMass]
    have h : (if (d : ℝ)+1 < x then 2*(d : ℝ)+1 else 0) ≤ 2*(d : ℝ)+1 := by
      split
      · exact le_rfl
      · positivity
    push_cast
    nlinarith

theorem gridMass_le_sq (x : ℝ) (d : Nat) (hx : 0≤x) : gridMass x d ≤ x^2 := by
  induction d with
  | zero => simpa [gridMass] using sq_nonneg x
  | succ d ih =>
    by_cases h : (d : ℝ)+1 < x
    · have ee := gridMass_le_size x (d+1)
      exact ee.trans (by push_cast; nlinarith)
    · rw [gridMass,Finset.sum_range_succ,← gridMass,ite_eq_right h,add_zero]
      exact ih

theorem signed_grid_coord_le {D : Nat} (hD : 0<D) (x : ℝ) :
    (∑ j ∈ Finset.range D,
      ((if ((j : ℝ)+1)/(D:ℝ) < x then 2*(j : ℝ)+1 else 0) +
      (if ((j : ℝ)+1)/(D:ℝ) < -x then 2*(j : ℝ)+1 else 0))) ≤
        (D : ℝ)^2 * x^2 := by
  have hDR : (0:ℝ) < (D:ℝ) := by exact_mod_cast hD
  have eq (y : ℝ) :
      (∑ j ∈ Finset.range D, if ((j : ℝ)+1)/(D:ℝ) < y then 2*(j : ℝ)+1 else 0) =
        gridMass ((D:ℝ)*y) D := by
    unfold gridMass
    apply sum_congr rfl
    intro j _
    simp only [div_lt_iff₀ hDR, mul_comm y (D:ℝ)]
  rw [sum_add_distrib,eq,eq]
  rcases le_total 0 x with h|h
  · have h0 : gridMass ((D:ℝ)*(-x)) D = 0 := by
      unfold gridMass
      apply sum_eq_zero
      intro j _
      rw [ite_eq_right]
      have h1 : (0:ℝ) ≤ (j:ℝ) := Nat.cast_nonneg _
      have h2 := mul_nonpos_of_nonneg_of_nonpos hDR.le (neg_nonpos.mpr h)
      linarith
    rw [h0,add_zero,←mul_pow]
    exact gridMass_le_sq _ _ (mul_nonneg hDR.le h)
  · have h0 : gridMass ((D:ℝ)*x) D = 0 := by
      unfold gridMass
      apply sum_eq_zero
      intro j _
      rw [ite_eq_right]
      have h1 : (0:ℝ) ≤ (j:ℝ) := Nat.cast_nonneg _
      have h2 := mul_nonpos_of_nonneg_of_nonpos hDR.le h
      linarith
    rw [h0,zero_add]
    simpa only [mul_pow, neg_sq] using gridMass_le_sq _ D (mul_nonneg hDR.le (neg_nonneg.mpr h))

#print axioms signed_grid_coord_le

theorem count_after_exceptions {ι : Type*} [Fintype ι] [DecidableEq ι]
    (p : ι → Prop) [DecidablePred p] (I E : Finset ι)
    (h : ∀ i, p i → i∉I → i∈E) :
    (Finset.univ.filter p).card - E.card ≤ (I.filter p).card := by
  have hsub : Finset.univ.filter p ⊆ I.filter p ∪ E := by
    intro i hi
    have hp := (Finset.mem_filter.mp hi).2
    by_cases hI : i∈I
    · exact mem_union_left _ (Finset.mem_filter.mpr ⟨hI,hp⟩)
    · exact mem_union_right _ (h i hp hI)
  have hh := (card_le_card hsub).trans (card_union_le _ _)
  omega

theorem sum_constant_ite {ι : Type*} (I : Finset ι) (p : ι → Prop) [DecidablePred p] (r : ℝ) :
    (∑ i ∈ I, if p i then r else 0) = ((I.filter p).card : ℝ) * r := by
  rw [← Finset.sum_filter]
  simp [nsmul_eq_mul]

noncomputable def signedTailGrid {ι : Type*} [Fintype ι] (x : ι → ℝ) (D a b : Nat) : ℝ :=
  ∑ j ∈ Finset.range D, (2*(j : ℝ)+1) *
    ((((Finset.univ.filter (fun i => ((j:ℝ)+1)/(D:ℝ) < x i)).card-a : Nat) : ℝ)+
      (((Finset.univ.filter (fun i => ((j:ℝ)+1)/(D:ℝ) < -x i)).card-b : Nat) : ℝ))

theorem signed_tail_grid_le {ι : Type*} [Fintype ι] [DecidableEq ι]
    (x : ι → ℝ) (I P N : Finset ι) (D : Nat) (hD : 0<D)
    (hP : ∀ i, 0<x i → i∉I → i∈P) (hN : ∀ i, x i<0 → i∉I → i∈N) :
    signedTailGrid x D P.card N.card ≤ (D:ℝ)^2 * ∑ i ∈ I, (x i)^2 := by
  have hDR : (0:ℝ)<(D:ℝ) := by exact_mod_cast hD
  let c (j : Nat) : ℝ := ((j:ℝ)+1)/(D:ℝ)
  let g (j : Nat) : ℝ := 2*(j:ℝ)+1
  have hcut (j : Nat) : 0 ≤ c j := by dsimp [c]; positivity
  have hw (j : Nat) : 0 ≤ g j := by dsimp [g]; positivity
  have hp (j : Nat) :
      (Finset.univ.filter (fun i => c j < x i)).card-P.card ≤ (I.filter (fun i => c j < x i)).card :=
    count_after_exceptions _ I P (fun i hi => hP i ((hcut j).trans_lt hi))
  have hn (j : Nat) :
      (Finset.univ.filter (fun i => c j < -x i)).card-N.card ≤ (I.filter (fun i => c j < -x i)).card :=
    count_after_exceptions _ I N (fun i hi => hN i (neg_pos.mp ((hcut j).trans_lt hi)))
  calc
    signedTailGrid x D P.card N.card ≤ ∑ j ∈ Finset.range D,
      g j * (((I.filter (fun i => c j < x i)).card : ℝ) + ((I.filter (fun i => c j < -x i)).card : ℝ)) := by
      unfold signedTailGrid
      apply sum_le_sum
      intro j _
      exact mul_le_mul_of_nonneg_left (add_le_add (Nat.cast_le.mpr (hp j)) (Nat.cast_le.mpr (hn j))) (hw j)
    _ = ∑ i ∈ I, ∑ j ∈ Finset.range D,
        ((if c j < x i then g j else 0)+(if c j < -x i then g j else 0)) := by
      rw [Finset.sum_comm]
      apply sum_congr rfl
      intro j _
      rw [sum_add_distrib, sum_constant_ite, sum_constant_ite]
      ring
    _ ≤ (D:ℝ)^2 * ∑ i ∈ I, (x i)^2 := by
      rw [Finset.mul_sum]
      exact sum_le_sum (fun i _ => signed_grid_coord_le hD (x i))

/-- The discarded coordinates may be nonzero, but the score agrees with x²
on all of I; this converts the grid bound to the actual distance there. -/
theorem signed_tail_grid_le_discrepancy {ι : Type*} [Fintype ι] [DecidableEq ι]
    (x y : ι → ℝ) (I P N : Finset ι) (D : Nat) (hD : 0<D)
    (hP : ∀ i, 0<x i → i∉I → i∈P) (hN : ∀ i, x i<0 → i∉I → i∈N)
    (hy : ∀ i∈I, y i=0) :
    signedTailGrid x D P.card N.card ≤ (D:ℝ)^2 * ∑ i, (x i-y i)^2 := by
  have hpart : (∑ i ∈ I, (x i)^2) ≤ ∑ i, (x i-y i)^2 := by
    calc
      (∑ i ∈ I, (x i)^2) = ∑ i ∈ I, (x i-y i)^2 :=
        sum_congr rfl (fun i hi => by rw [hy i hi,sub_zero])
      _ ≤ _ := sum_le_sum_of_subset_of_nonneg (subset_univ I) (fun i _ _ => sq_nonneg _)
  exact (signed_tail_grid_le x I P N D hD hP hN).trans (mul_le_mul_of_nonneg_left hpart (sq_nonneg _))

#print axioms signed_tail_grid_le_discrepancy

/-- If the total squared error is below one, any target coordinate whose
absolute value is at least one retains its sign. Thus only the signs in the
target support need to be subtracted from the grid counts. -/
theorem signed_grid_of_small_discrepancy {ι : Type*} [Fintype ι] [DecidableEq ι]
    (x y : ι → ℝ) (hLarge : ∀ i, y i≠0 → 1≤|y i|)
    (hClose : (∑ i, (x i-y i)^2) < 1) (D : Nat) (hD : 0<D) :
    signedTailGrid x D
        (Fintype.card {i // 0<y i}) (Fintype.card {i // y i<0}) ≤
      (D:ℝ)^2 * ∑ i, (x i-y i)^2 := by
  let I : Finset ι := Finset.univ.filter (fun i => y i=0)
  let P : Finset ι := Finset.univ.filter (fun i => 0<y i)
  let N : Finset ι := Finset.univ.filter (fun i => y i<0)
  have each (i : ι) : (x i-y i)^2 < 1 :=
    (single_le_sum (fun j _ => sq_nonneg (x j-y j)) (mem_univ i)).trans_lt hClose
  have hnzero (i : ι) (hi : i∉I) : y i≠0 := by
    simpa [I] using hi
  have hp (i : ι) (hx : 0<x i) (hi : i∉I) : i∈P := by
    simp only [P,mem_filter,mem_univ,true_and]
    by_contra! h
    have h0 : y i < 0 := lt_of_le_of_ne h (hnzero i hi)
    have h1 := hLarge i (hnzero i hi)
    rw [abs_of_neg h0] at h1
    have he : 1 ≤ x i-y i := by linarith
    nlinarith [mul_nonneg (sub_nonneg.mpr he) (by linarith : 0 ≤ x i-y i+1), each i]
  have hn (i : ι) (hx : x i<0) (hi : i∉I) : i∈N := by
    simp only [N,mem_filter,mem_univ,true_and]
    by_contra! h
    have h0 : 0 < y i := lt_of_le_of_ne h (hnzero i hi).symm
    have h1 := hLarge i (hnzero i hi)
    rw [abs_of_pos h0] at h1
    have he : 1 ≤ y i-x i := by linarith
    nlinarith [mul_nonneg (sub_nonneg.mpr he) (by linarith : 0 ≤ y i-x i+1), each i]
  have hZ : ∀ i∈I, y i=0 := fun i hi => (mem_filter.mp hi).2
  rw [Fintype.card_subtype,Fintype.card_subtype]
  exact signed_tail_grid_le_discrepancy x y I P N D hD hp hn hZ

#print axioms signed_grid_of_small_discrepancy
end SpectralConjecture20
namespace SpectralConjecture20

theorem signed_grid_mono_thresholds {ι κ : Type*} [Fintype ι] [Fintype κ]
    (x : ι → ℝ) (y : κ → ℝ) (D a b : Nat)
    (hcount : ∀ s t : ℝ, 0≤t →
      Fintype.card {i // t<s*x i} ≤ Fintype.card {i // t<s*y i}) :
    signedTailGrid x D a b ≤ signedTailGrid y D a b := by
  unfold signedTailGrid
  apply sum_le_sum
  intro j _
  let c : ℝ := ((j : ℝ)+1)/(D:ℝ)
  have hc : 0≤c := by dsimp [c]; positivity
  have hp := hcount 1 c hc
  have hn := hcount (-1) c hc
  simp only [one_mul,Fintype.card_subtype] at hp
  simp only [neg_one_mul,Fintype.card_subtype] at hn
  exact mul_le_mul_of_nonneg_left
    (add_le_add
      (Nat.cast_le.mpr (Nat.sub_le_sub_right hp a))
      (Nat.cast_le.mpr (Nat.sub_le_sub_right hn b))) (by positivity)

theorem weighted_template_grid_le_distance {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (hB : B.IsHermitian)
    (w z : m → Nat) (hw : ∀ i, 0<w i) (hm : ∀ i, w i≤z i) (u : Nat)
    (hFull : (withIsolates B z u).IsHermitian)
    (y : Fin (Fintype.card (Vertices z ⊕ Fin u)) → ℝ)
    (hy : ∀ i, y i≠0 → 1≤|y i|)
    (hClose : (∑ i, (hFull.eigenvalues₀ i-y i)^2)<1)
    (D : Nat) (hD : 0<D) :
    signedTailGrid (weightedQuotient_isHermitian B hB w).eigenvalues D
      (Fintype.card {i // 0<y i}) (Fintype.card {i // y i<0}) ≤
        (D:ℝ)^2 * ∑ i, (hFull.eigenvalues₀ i-y i)^2 := by
  apply le_trans ?_ (signed_grid_of_small_discrepancy hFull.eigenvalues₀ y hy hClose D hD)
  apply signed_grid_mono_thresholds
  intro s t ht
  exact (weighted_spectral_cut_mono B hB w z hw hm s t ht).trans
    (withIsolates_ordered_cut_count B hB z (fun i => (hw i).trans_le (hm i)) u hFull s t ht).symm.le

#print axioms weighted_template_grid_le_distance

end SpectralConjecture20

-- Pure data and executable checks, before Mathlib imports in the generated module.
namespace Conj20CutCert

abbrev Rows := Array (Array Int)
abbrev Values := Array Int
abbrev Weights := Array Nat
structure Cert where
  P : Rows
  d : Values
  K : Rows
  c : Int

def entry (A : Rows) (i j : Nat) : Int :=
  ((A[i]?.getD #[])[j]?).getD 0

def getWeight (w : Weights) (i : Nat) : Nat := (w[i]?).getD 0

def sumFn (n : Nat) (f : Fin n → Int) : Int := (List.ofFn f).sum

def mulEntry (n : Nat) (A B : Fin n → Fin n → Int) (i j : Fin n) : Int :=
  sumFn n fun k => A i k * B k j

def around (n : Nat) (f : Fin n → Bool) : Bool := (List.ofFn f).all id

def gramCutEntry (A : Rows) (w : Weights) (L v : Nat) (s u : Int)
    (i j : Nat) : Int :=
  (v : Int)*(L : Int)*s*entry A i j - if i == j then u*((L/getWeight w i : Nat) : Int) else 0

def valid (n : Nat) (A : Rows) (w : Weights) (L v : Nat) (s u : Int) (cert : Cert) : Bool :=
  let p (i j : Fin n) := entry cert.P i j
  let pt (i j : Fin n) := entry cert.P j i
  let k (i j : Fin n) := entry cert.K i j
  let M (i j : Fin n) := gramCutEntry A w L v s u i j
  let X (i j : Fin n) := mulEntry n pt M i j
  cert.c != 0 &&
  around n (fun i => around n (fun j =>
    (mulEntry n X p i j == (if i == j then (cert.d[i.val]?).getD 0 else 0)) &&
    (mulEntry n k p i j == if i == j then cert.c else 0)))

def countPos (n : Nat) (d : Values) : Nat :=
  (List.ofFn (fun i : Fin n => if 0 < (d[i.val]?).getD 0 then 1 else 0)).sum

def validCached (n : Nat) (A : Rows) (w : Weights) (L v : Nat) (s u : Int)
    (cert : Cert) (cache : Rows) : Bool :=
  let p (i j : Fin n) := entry cert.P i j
  let pt (i j : Fin n) := entry cert.P j i
  let k (i j : Fin n) := entry cert.K i j
  let M (i j : Fin n) := gramCutEntry A w L v s u i j
  let X (i j : Fin n) := entry cache i j
  cert.c != 0 &&
  around n (fun i => around n (fun j =>
    (mulEntry n pt M i j == X i j) &&
    (mulEntry n X p i j == (if i == j then (cert.d[i.val]?).getD 0 else 0)) &&
    (mulEntry n k p i j == if i == j then cert.c else 0)))

end Conj20CutCert
open Matrix Finset
open scoped BigOperators
namespace Conj20CutCert
open SpectralConjecture20

def ofRows (n : Nat) (A : Rows) : Matrix (Fin n) (Fin n) ℤ :=
  fun i j => entry A i j

def diagValues (n : Nat) (d : Values) : Fin n → ℤ :=
  fun i => (d[i.val]?).getD 0

def weightFn (n : Nat) (w : Weights) : Fin n → Nat :=
  fun i => getWeight w i

theorem eval_mul_entry (n : Nat) (A B : Matrix (Fin n) (Fin n) ℤ) (i j : Fin n) :
    mulEntry n A B i j = (A*B) i j := by
  simp [mulEntry,sumFn,Matrix.mul_apply,List.sum_ofFn]

theorem around_true {n : Nat} {f : Fin n → Bool} (h : around n f = true) (i : Fin n) :
    f i = true :=
  List.all_eq_true.mp h _ (List.mem_ofFn.mpr ⟨i,rfl⟩)

theorem countPos_sound (n : Nat) (d : Values) :
    countPos n d = Fintype.card {i // 0<diagValues n d i} := by
  rw [countPos,List.sum_ofFn,Fintype.card_subtype,Finset.card_eq_sum_ones,Finset.sum_filter]
  rfl

theorem gramCutEntry_eq (n : Nat) (A : Rows) (w : Weights) (L v : Nat) (s u : ℤ)
    (i j : Fin n) :
    gramCutEntry A w L v s u i j = intWeightedCut (ofRows n A) (weightFn n w) L v s u i j := by
  unfold intWeightedCut
  rw [Matrix.sub_apply, Matrix.smul_apply, Matrix.smul_apply]
  change _ = (v : ℤ)*(L:ℤ)*s*entry A i j - u * (diagonal (fun x : Fin n => ((L/getWeight w x : Nat):ℤ))) i j
  by_cases h : i=j
  · subst j
    simp [gramCutEntry]
  · have hh : i.val ≠ j.val := fun hg => h (Fin.ext hg)
    simp [gramCutEntry, Matrix.diagonal_apply_ne _ h, hh]

theorem valid_sound (n : Nat) (A : Rows) (w : Weights) (L v : Nat) (s u : ℤ) (C : Cert)
    (h : valid n A w L v s u C = true) :
    let P := ofRows n C.P
    let K := ofRows n C.K
    let M := intWeightedCut (ofRows n A) (weightFn n w) L v s u
    C.c ≠ 0 ∧ Pᵀ*M*P = diagonal (diagValues n C.d) ∧ K*P=C.c•(1:Matrix (Fin n) (Fin n) ℤ) := by
  simp only [valid,Bool.and_eq_true] at h
  let P := ofRows n C.P
  let K := ofRows n C.K
  let M := intWeightedCut (ofRows n A) (weightFn n w) L v s u
  exact ⟨by simpa using h.1, by
    ext i j
    have hpair := around_true (around_true h.2 i) j
    have h1 := beq_iff_eq.mp (Bool.and_eq_true_iff.mp hpair).1
    have hX : (fun a b : Fin n => mulEntry n (fun i j => entry C.P j i)
         (fun i j => gramCutEntry A w L v s u i j) a b) = Pᵀ*M := by
      ext a b
      rw [← eval_mul_entry]
      congr 1
      funext x y
      exact gramCutEntry_eq n A w L v s u x y
    rw [hX] at h1
    have hE := eval_mul_entry n (Pᵀ*M) P i j
    rw [←hE]
    change mulEntry n (Pᵀ*M) P i j =
        (if i == j then (C.d[i.val]?).getD 0 else 0) at h1
    simpa [diagValues,Matrix.diagonal_apply] using h1, by
    ext i j
    have hpair := around_true (around_true h.2 i) j
    have h2 := beq_iff_eq.mp (Bool.and_eq_true_iff.mp hpair).2
    rw [←eval_mul_entry]
    change mulEntry n K P i j = (if i == j then C.c else 0) at h2
    simpa [Matrix.smul_apply,Matrix.one_apply] using h2⟩
#print axioms valid_sound

theorem around_intro {n : Nat} {f : Fin n → Bool} (h : ∀ i, f i = true) :
    around n f = true := by
  apply List.all_eq_true.mpr
  intro y hy
  obtain ⟨i,rfl⟩ := List.mem_ofFn.mp hy
  exact h i

theorem valid_cached_implies_valid (n : Nat) (A : Rows) (w : Weights) (L v : Nat) (s u : ℤ)
    (C : Cert) (X : Rows) (h : validCached n A w L v s u C X = true) :
    valid n A w L v s u C = true := by
  simp only [validCached,Bool.and_eq_true] at h
  unfold valid
  apply Bool.and_eq_true_iff.mpr
  refine ⟨h.1,?_⟩
  apply around_intro
  intro i
  apply around_intro
  intro j
  have row := around_true (around_true h.2 i) j
  obtain ⟨⟨_,hg⟩,hk⟩ := Bool.and_eq_true_iff.mp row |>.imp_left Bool.and_eq_true_iff.mp
  have he :
      (fun a b : Fin n => mulEntry n (fun i j => entry C.P j i)
        (fun i j => gramCutEntry A w L v s u i j) a b) =
      (fun a b : Fin n => entry X a b) := by
    funext a b
    have row := around_true (around_true h.2 a) b
    exact beq_iff_eq.mp (Bool.and_eq_true_iff.mp (Bool.and_eq_true_iff.mp row).1).1
  rw [he]
  exact Bool.and_eq_true_iff.mpr ⟨hg,hk⟩

theorem cached_cut_count_sound (n : Nat) (A : Rows) (w : Weights) (L v : Nat) (s u : ℤ)
    (C : Cert) (X : Rows) (h : validCached n A w L v s u C X=true)
    (hA : (intMatrixToReal (ofRows n A)).IsHermitian)
    (hw : ∀ i, 0<weightFn n w i) (hL : 0<L) (hv : 0<v)
    (hd : ∀ i, weightFn n w i ∣ L) :
    Fintype.card {i // (u:ℝ)/(v:ℝ) <
      (s:ℝ)*(weightedQuotient_isHermitian (intMatrixToReal (ofRows n A)) hA (weightFn n w)).eigenvalues i} =
      countPos n C.d := by
  obtain ⟨hc,hGram,hKP⟩ := valid_sound n A w L v s u C
    (valid_cached_implies_valid n A w L v s u C X h)
  have hp := det_ne_zero_of_scaled_left_inverse (ofRows n C.P) (ofRows n C.K) C.c hc hKP
  rw [countPos_sound]
  exact weighted_spectral_cut_verified_gram (ofRows n A) hA (weightFn n w) hw L v hL hv hd s u
    (ofRows n C.P) (diagValues n C.d) hp hGram
#print axioms cached_cut_count_sound
end Conj20CutCert

namespace SpectralConjecture20
open Finset
open scoped BigOperators

def knownGridMass (D a b : Nat) (P N : Nat → Nat) : Nat :=
  ∑ j ∈ Finset.range D, (2*j+1) * ((P j-a)+(N j-b))

theorem known_grid_mass_le {m : Type*} [Fintype m] (x : m → ℝ) (D a b : Nat)
    (P N : Nat → Nat)
    (hp : ∀ j<D, P j ≤ Fintype.card {i // ((j:ℝ)+1)/(D:ℝ)<x i})
    (hn : ∀ j<D, N j ≤ Fintype.card {i // ((j:ℝ)+1)/(D:ℝ)< -x i}) :
    ((knownGridMass D a b P N : Nat):ℝ) ≤ signedTailGrid x D a b := by
  unfold knownGridMass signedTailGrid
  push_cast
  apply Finset.sum_le_sum
  intro j hj
  have hp' := hp j (Finset.mem_range.mp hj)
  have hn' := hn j (Finset.mem_range.mp hj)
  rw [Fintype.card_subtype] at hp' hn'
  exact mul_le_mul_of_nonneg_left
    (add_le_add (Nat.cast_le.mpr (Nat.sub_le_sub_right hp' a))
      (Nat.cast_le.mpr (Nat.sub_le_sub_right hn' b))) (by positivity)

/-- A finite ledger may omit some thresholds (use count zero there); its
known positive contributions already suffice for a rejection. -/
theorem known_grid_rejects_close {m n : Type*} [Fintype m] [Fintype n]
    (D a b : Nat) (hD : 0<D) (P N : Nat → Nat) (x : m → ℝ) (u v : n → ℝ)
    (hp : ∀ j<D, P j ≤ Fintype.card {i // ((j:ℝ)+1)/(D:ℝ)<x i})
    (hn : ∀ j<D, N j ≤ Fintype.card {i // ((j:ℝ)+1)/(D:ℝ)< -x i})
    (hMass : 2*D^2 ≤ 3*knownGridMass D a b P N)
    (hGrid : signedTailGrid x D a b ≤ (D:ℝ)^2*∑ i, (u i-v i)^2) :
    (2/3:ℝ) ≤ ∑ i, (u i-v i)^2 := by
  have hLedger := (known_grid_mass_le x D a b P N hp hn).trans hGrid
  have hR : 2*(D:ℝ)^2 ≤ 3*(knownGridMass D a b P N:ℝ) := by exact_mod_cast hMass
  by_contra! hc
  have hPos : (0:ℝ) < (D:ℝ)^2 := sq_pos_of_pos (by exact_mod_cast hD)
  have hs := mul_lt_mul_of_pos_left hc hPos
  linarith
#print axioms known_grid_rejects_close
end SpectralConjecture20

namespace SpectralConjecture20
open Finset
open scoped BigOperators

def prefixCount (threshold count : Nat) (j : Nat) : Nat :=
  if j+1 ≤ threshold then count else 0

theorem prefix_count_sound {m : Type*} [Fintype m] (x : m → ℝ) (D a c : Nat)
    (hD : 0<D) (hP : c≤Fintype.card {i // (a:ℝ)/(D:ℝ)<x i}) (j : Nat) :
    prefixCount a c j ≤ Fintype.card {i // ((j:ℝ)+1)/(D:ℝ)<x i} := by
  unfold prefixCount
  by_cases h : j+1≤a
  · rw [ite_eq_left h]
    refine hP.trans (Fintype.card_subtype_mono _ _ ?_)
    intro i hi
    have hR : (j:ℝ)+1 ≤ (a:ℝ) := by exact_mod_cast h
    have hN : (0:ℝ)<(D:ℝ) := by exact_mod_cast hD
    exact (div_le_div_of_nonneg_right hR hN.le).trans_lt hi
  · simp [h]

theorem two_prefix_grid_rejects {m n : Type*} [Fintype m] [Fintype n]
    (D : Nat) (hD : 0<D) (a b : Nat) (x : m → ℝ) (u v : n → ℝ)
    (hp : 2≤Fintype.card {i // (a:ℝ)/(D:ℝ)<x i})
    (hn : 3≤Fintype.card {i // (b:ℝ)/(D:ℝ)< -x i})
    (hMass : 2*D^2 ≤ 3*knownGridMass D 1 2 (prefixCount a 2) (prefixCount b 3))
    (hGrid : signedTailGrid x D 1 2 ≤ (D:ℝ)^2*∑ i, (u i-v i)^2) :
    (2/3:ℝ) ≤ ∑ i, (u i-v i)^2 := by
  apply known_grid_rejects_close D 1 2 hD _ _ x u v _ _ hMass hGrid
  · intro j _
    exact prefix_count_sound x D a 2 hD hp j
  · intro j _
    exact prefix_count_sound (fun i=> -x i) D b 3 hD hn j

theorem below_one_preserves_strict_negative_cut {m : Type*} [Fintype m]
    (x y : m → ℝ) (h : (∑ i, (x i-y i)^2)<1)
    (hy : ∀ i, y i<0 → y i≤ -3) :
    Fintype.card {i // y i<0} ≤ Fintype.card {i // (2:ℝ) < -x i} := by
  apply Fintype.card_subtype_mono
  intro i hi
  classical
  have he : (x i-y i)^2<1 :=
    (single_le_sum (fun j _ => sq_nonneg (x j-y j)) (mem_univ i)).trans_lt h
  have hn := hy i hi
  by_contra! hc
  have hdiff : 1≤x i-y i := by linarith
  nlinarith [mul_nonneg (sub_nonneg.mpr hdiff) (by linarith : 0 ≤ x i-y i+1)]

#print axioms two_prefix_grid_rejects
#print axioms below_one_preserves_strict_negative_cut
end SpectralConjecture20

namespace WeightedSeedPruning
open Matrix Finset SpectralConjecture20 Conj20CutCert
open scoped BigOperators Matrix

theorem coord_fence {m : Type*} [Fintype m] (x y : m → ℝ) (h : (∑ i,(x i-y i)^2)<(2/3:ℝ))
    (i : m) : |x i-y i| < (41/50:ℝ) := by
  classical
  have hs := (single_le_sum (s := Finset.univ) (f := fun j => (x j-y j)^2)
    (fun j _ => sq_nonneg (x j-y j)) (mem_univ i)).trans_lt h
  by_contra! hc
  have ht := mul_nonneg (show 0≤|x i-y i|-41/50 by linarith)
    (show 0≤|x i-y i|+41/50 by linarith [abs_nonneg (x i-y i)])
  nlinarith only [ht,hs,sq_abs (x i-y i)]

theorem close_positive_cut_at_most_one {m : Type*} [Fintype m]
    (x y : m → ℝ) (h : (∑ i,(x i-y i)^2)<(2/3:ℝ))
    (hPos : Fintype.card {i // 0<y i}=1) :
    Fintype.card {i // (41/50:ℝ)<x i}≤1 := by
  rw [←hPos]
  apply Fintype.card_subtype_mono
  intro i hi
  have hB := (abs_lt.mp (coord_fence x y h i)).2
  change (41/50:ℝ)<x i at hi
  linarith

theorem close_negative_cut_at_least_two {m : Type*} [Fintype m]
    (x y : m → ℝ) (n : ℝ) (h : (∑ i,(x i-y i)^2)<(2/3:ℝ))
    (hNeg : Fintype.card {i // y i= -n}=2) :
    2≤Fintype.card {i // n-41/50 < -x i} := by
  rw [←hNeg]
  apply Fintype.card_subtype_mono
  intro i hi
  have hB := (abs_lt.mp (coord_fence x y h i)).2
  change y i= -n at hi
  change n-41/50 < -x i
  linarith

theorem close_forbids_seed {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (hB : B.IsHermitian)
    (v w : m → Nat) (hv : ∀ i, 0<v i) (hw : ∀ i, 0<w i)
    (z : Nat) (hF : (withIsolates B w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hPos : Fintype.card {i // 0<y i}=1)
    (hClose : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(2/3:ℝ))
    (hCut : 2≤Fintype.card {i // (41/50:ℝ)<(weightedQuotient_isHermitian B hB v).eigenvalues i}) :
    ¬(∀ i, v i≤w i) := by
  intro hMono
  have hM := weighted_spectral_cut_mono B hB v w hv hMono 1 (41/50) (by norm_num)
  have hFQ := withIsolates_ordered_cut_count B hB w hw z hF 1 (41/50) (by norm_num)
  simp only [one_mul] at hM hFQ
  have hP := close_positive_cut_at_most_one hF.eigenvalues₀ y hClose hPos
  rw [hFQ] at hP
  omega

#print axioms close_forbids_seed
end WeightedSeedPruning

namespace WeightedSeedPruning
open Matrix SpectralConjecture20 Conj20CutCert
def HRows : Rows := #[#[0,1,0,1,1],#[1,0,1,0,0],#[0,1,0,0,1],#[1,0,0,0,1],#[1,0,1,1,0]]
def HMat : Matrix (Fin 5) (Fin 5) ℝ := intMatrixToReal (ofRows 5 HRows)
theorem HHerm : HMat.IsHermitian := by ext i j; fin_cases i <;> fin_cases j <;> rfl
def BRows : Rows := #[#[0,1,0,1,1],#[1,0,1,0,1],#[0,1,0,0,0],#[1,0,0,0,0],#[1,1,0,0,0]]
def BMat : Matrix (Fin 5) (Fin 5) ℝ := intMatrixToReal (ofRows 5 BRows)
theorem BHerm : BMat.IsHermitian := by ext i j; fin_cases i <;> fin_cases j <;> rfl
def PRows : Rows := #[#[0,1,1,1],#[1,0,1,0],#[1,1,0,0],#[1,0,0,0]]
def PMat : Matrix (Fin 4) (Fin 4) ℝ := intMatrixToReal (ofRows 4 PRows)
theorem PHerm : PMat.IsHermitian := by ext i j; fin_cases i <;> fin_cases j <;> rfl

def h1Rows : Weights := #[1,2,1,1,1]
def h1Weight : Fin 5 → Nat := weightFn 5 h1Rows
def h1C : Cert := ⟨#[#[1,-50,5000,165950,-4851450],#[0,-41,4100,-205000,14560000],#[0,0,-3319,-250000,10821050],#[0,0,0,341079,-12851450],#[0,0,0,0,-5686739]],#[-82,136079,-2264082402,-3879254502762,1261730441477078],#[#[-263942536740675099,321881142366676950,0,321881142366676950,321881142366676950],#[0,6437622847333539,7952471730662100,9698136256905000,9698136256905000],#[0,0,79524717306621,58289074750000,19596786930950],#[0,0,0,-773845756381,1748812464550],#[0,0,0,0,46413689241]],-263942536740675099⟩
def h1X : Rows := #[#[-82,100,0,100,100],#[0,-3319,-4100,-5000,-5000],#[0,0,682158,500000,168100],#[0,0,0,-11373478,25702900],#[0,0,0,0,-221872402]]
theorem h1_check : validCached 5 HRows h1Rows 2 50 1 41 h1C h1X=true := by decide +kernel
theorem h1_positive (i : Fin 5) : 0<h1Weight i := by fin_cases i <;> decide
theorem h1_count :
    Fintype.card {i // (41/50:ℝ)<(weightedQuotient_isHermitian HMat HHerm h1Weight).eigenvalues i}=2 := by
  have hd (i : Fin 5) : h1Weight i ∣ 2 := by fin_cases i <;> decide
  have he := cached_cut_count_sound 5 HRows h1Rows 2 50 1 41 h1C h1X
    h1_check HHerm h1_positive (by decide) (by decide) hd
  have hh : countPos 5 h1C.d=2 := by decide +kernel
  rw [hh] at he
  norm_num [h1Weight] at he ⊢
  exact he


theorem h1_forbidden (w : Fin 5 → Nat) (hw : ∀ i, 0<w i)
    (z : Nat) (hF : (withIsolates HMat w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hPos : Fintype.card {i // 0<y i}=1)
    (hClose : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(2/3:ℝ)) :
    ¬(∀ i, h1Weight i≤w i) :=
  close_forbids_seed HMat HHerm h1Weight w h1_positive hw z hF y hPos hClose h1_count.ge


def h2Rows : Weights := #[1,1,2,1,1]
def h2Weight : Fin 5 → Nat := weightFn 5 h2Rows
def h2C : Cert := ⟨#[#[1,-50,2500,165950,-4851450],#[0,-41,2050,-102500,5232500],#[0,0,-819,-250000,9142100],#[0,0,0,238579,-7726450],#[0,0,0,0,-1484239]],#[-82,67158,-195396201,-708216512762,329311672072078],#[#[-11890601141017599,14500733098801950,0,14500733098801950,14500733098801950],#[0,290014661976039,725921925581050,885270640952500,885270640952500],#[0,0,14518438511621,15213449750000,10229523611900],#[0,0,0,-49839261381,259446464550],#[0,0,0,0,8011244241]],-11890601141017599⟩
def h2X : Rows := #[#[-82,100,0,100,100],#[0,-1638,-4100,-5000,-5000],#[0,0,238579,250000,168100],#[0,0,0,-2968478,15452900],#[0,0,0,0,-221872402]]
theorem h2_check : validCached 5 HRows h2Rows 2 50 1 41 h2C h2X=true := by decide +kernel
theorem h2_positive (i : Fin 5) : 0<h2Weight i := by fin_cases i <;> decide
theorem h2_count :
    Fintype.card {i // (41/50:ℝ)<(weightedQuotient_isHermitian HMat HHerm h2Weight).eigenvalues i}=2 := by
  have hd (i : Fin 5) : h2Weight i ∣ 2 := by fin_cases i <;> decide
  have he := cached_cut_count_sound 5 HRows h2Rows 2 50 1 41 h2C h2X
    h2_check HHerm h2_positive (by decide) (by decide) hd
  have hh : countPos 5 h2C.d=2 := by decide +kernel
  rw [hh] at he
  norm_num [h2Weight] at he ⊢
  exact he


theorem h2_forbidden (w : Fin 5 → Nat) (hw : ∀ i, 0<w i)
    (z : Nat) (hF : (withIsolates HMat w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hPos : Fintype.card {i // 0<y i}=1)
    (hClose : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(2/3:ℝ)) :
    ¬(∀ i, h2Weight i≤w i) :=
  close_forbids_seed HMat HHerm h2Weight w h2_positive hw z hF y hPos hClose h2_count.ge


def h3Rows : Weights := #[1,1,1,3,1]
def h3Weight : Fin 5 → Nat := weightFn 5 h3Rows
def h3C : Cert := ⟨#[#[1,-50,2500,40950,-2696450],#[0,-41,2050,-102500,5030000],#[0,0,-819,-125000,6821050],#[0,0,0,136079,-7804350],#[0,0,0,0,563261]],#[-123,100737,-334346103,76647993619,-349922293069383],#[#[2573762977732401,-3138735338698050,0,-3138735338698050,-3138735338698050],#[0,-62774706773961,-157128386918950,-191619984047500,-191619984047500],#[0,0,-3142567738379,-2886712625000,-1941025569050],#[0,0,0,18913741119,262062268650],#[0,0,0,0,4569396741]],2573762977732401⟩
def h3X : Rows := #[#[-123,150,0,150,150],#[0,-2457,-6150,-7500,-7500],#[0,0,408237,375000,252150],#[0,0,0,563261,7804350],#[0,0,0,0,-621243603]]
theorem h3_check : validCached 5 HRows h3Rows 3 50 1 41 h3C h3X=true := by decide +kernel
theorem h3_positive (i : Fin 5) : 0<h3Weight i := by fin_cases i <;> decide
theorem h3_count :
    Fintype.card {i // (41/50:ℝ)<(weightedQuotient_isHermitian HMat HHerm h3Weight).eigenvalues i}=2 := by
  have hd (i : Fin 5) : h3Weight i ∣ 3 := by fin_cases i <;> decide
  have he := cached_cut_count_sound 5 HRows h3Rows 3 50 1 41 h3C h3X
    h3_check HHerm h3_positive (by decide) (by decide) hd
  have hh : countPos 5 h3C.d=2 := by decide +kernel
  rw [hh] at he
  norm_num [h3Weight] at he ⊢
  exact he


theorem h3_forbidden (w : Fin 5 → Nat) (hw : ∀ i, 0<w i)
    (z : Nat) (hF : (withIsolates HMat w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hPos : Fintype.card {i // 0<y i}=1)
    (hClose : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(2/3:ℝ)) :
    ¬(∀ i, h3Weight i≤w i) :=
  close_forbids_seed HMat HHerm h3Weight w h3_positive hw z hF y hPos hClose h3_count.ge


def b2tripleRows : Weights := #[1,1,3,1,1]
def b2tripleWeight : Fin 5 → Nat := weightFn 5 b2tripleRows
def b2tripleC : Cert := ⟨#[#[1,-50,2500,290950,-7726450],#[0,-41,2050,-102500,2523550],#[0,0,-819,-375000,9232500],#[0,0,0,341079,-9422500],#[0,0,0,0,563261]],#[-123,100737,-279343701,576349495857,-478611941891883],#[#[6451079907127401,-7867170618448050,0,-7867170618448050,-7867170618448050],#[0,-157343412368961,-393838822168950,-480291246547500,-874130068716450],#[0,0,-7876776443379,-8660137875000,-15761450932500],#[0,0,0,18913741119,316398127500],#[0,0,0,0,11453091741]],6451079907127401⟩
def b2tripleX : Rows := #[#[-123,150,0,150,150],#[0,-2457,-6150,-7500,-13650],#[0,0,341079,375000,682500],#[0,0,0,1689783,28267500],#[0,0,0,0,-849716103]]
theorem b2triple_check : validCached 5 BRows b2tripleRows 3 50 1 41 b2tripleC b2tripleX=true := by decide +kernel
theorem b2triple_positive (i : Fin 5) : 0<b2tripleWeight i := by fin_cases i <;> decide
theorem b2triple_count :
    Fintype.card {i // (41/50:ℝ)<(weightedQuotient_isHermitian BMat BHerm b2tripleWeight).eigenvalues i}=2 := by
  have hd (i : Fin 5) : b2tripleWeight i ∣ 3 := by fin_cases i <;> decide
  have he := cached_cut_count_sound 5 BRows b2tripleRows 3 50 1 41 b2tripleC b2tripleX
    b2triple_check BHerm b2triple_positive (by decide) (by decide) hd
  have hh : countPos 5 b2tripleC.d=2 := by decide +kernel
  rw [hh] at he
  norm_num [b2tripleWeight] at he ⊢
  exact he


theorem b2triple_forbidden (w : Fin 5 → Nat) (hw : ∀ i, 0<w i)
    (z : Nat) (hF : (withIsolates BMat w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hPos : Fintype.card {i // 0<y i}=1)
    (hClose : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(2/3:ℝ)) :
    ¬(∀ i, b2tripleWeight i≤w i) :=
  close_forbids_seed BMat BHerm b2tripleWeight w b2triple_positive hw z hF y hPos hClose b2triple_count.ge


def b20Rows : Weights := #[2,1,2,1,1]
def b20Weight : Fin 5 → Nat := weightFn 5 b20Rows
def b20C : Cert := ⟨#[#[1,-100,5000,331900,-5202900],#[0,-41,2050,-205000,1601050],#[0,0,-3319,-500000,3905000],#[0,0,0,341079,-6345000],#[0,0,0,0,2610761]],#[-82,544316,-2264082402,3561903004476,-2998549873425844],#[#[121175049736522401,-295548901796396100,0,-295548901796396100,-295548901796396100],#[0,-2955489017963961,-1825475289793950,-4452378755595000,-6277854045388950],#[0,0,-36509505795879,-53520600500000,-75464046705000],#[0,0,0,355269746119,863421255000],#[0,0,0,0,46413689241]],121175049736522401⟩
def b20X : Rows := #[#[-82,200,0,200,200],#[0,-13276,-8200,-20000,-28200],#[0,0,682158,1000000,1410000],#[0,0,0,10443044,25380000],#[0,0,0,0,-1148534804]]
theorem b20_check : validCached 5 BRows b20Rows 4 50 1 41 b20C b20X=true := by decide +kernel
theorem b20_positive (i : Fin 5) : 0<b20Weight i := by fin_cases i <;> decide
theorem b20_count :
    Fintype.card {i // (41/50:ℝ)<(weightedQuotient_isHermitian BMat BHerm b20Weight).eigenvalues i}=2 := by
  have hd (i : Fin 5) : b20Weight i ∣ 4 := by fin_cases i <;> decide
  have he := cached_cut_count_sound 5 BRows b20Rows 4 50 1 41 b20C b20X
    b20_check BHerm b20_positive (by decide) (by decide) hd
  have hh : countPos 5 b20C.d=2 := by decide +kernel
  rw [hh] at he
  norm_num [b20Weight] at he ⊢
  exact he


theorem b20_forbidden (w : Fin 5 → Nat) (hw : ∀ i, 0<w i)
    (z : Nat) (hF : (withIsolates BMat w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hPos : Fintype.card {i // 0<y i}=1)
    (hClose : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(2/3:ℝ)) :
    ¬(∀ i, b20Weight i≤w i) :=
  close_forbids_seed BMat BHerm b20Weight w b20_positive hw z hF y hPos hClose b20_count.ge


def b21Rows : Weights := #[1,2,2,1,1]
def b21Weight : Fin 5 → Nat := weightFn 5 b21Rows
def b21C : Cert := ⟨#[#[1,-50,5000,415950,-8648950],#[0,-41,4100,-205000,5047100],#[0,0,-3319,-500000,12310000],#[0,0,0,546079,-10547500],#[0,0,0,0,-1591739]],#[-164,272158,-3624872402,-3476860965524,731125204194156],#[#[-118281940831885099,144246269307176950,0,144246269307176950,144246269307176950],#[0,2884925386143539,3563782489662100,4346076206905000,7909858696567100],#[0,0,35637824896621,32630649500000,59387782090000],#[0,0,0,-216602251381,1435293252500],#[0,0,0,0,74309884241]],-118281940831885099⟩
def b21X : Rows := #[#[-164,200,0,200,200],#[0,-6638,-8200,-10000,-18200],#[0,0,1092158,1000000,1820000],#[0,0,0,-6366956,42190000],#[0,0,0,0,-459324804]]
theorem b21_check : validCached 5 BRows b21Rows 4 50 1 41 b21C b21X=true := by decide +kernel
theorem b21_positive (i : Fin 5) : 0<b21Weight i := by fin_cases i <;> decide
theorem b21_count :
    Fintype.card {i // (41/50:ℝ)<(weightedQuotient_isHermitian BMat BHerm b21Weight).eigenvalues i}=2 := by
  have hd (i : Fin 5) : b21Weight i ∣ 4 := by fin_cases i <;> decide
  have he := cached_cut_count_sound 5 BRows b21Rows 4 50 1 41 b21C b21X
    b21_check BHerm b21_positive (by decide) (by decide) hd
  have hh : countPos 5 b21C.d=2 := by decide +kernel
  rw [hh] at he
  norm_num [b21Weight] at he ⊢
  exact he


theorem b21_forbidden (w : Fin 5 → Nat) (hw : ∀ i, 0<w i)
    (z : Nat) (hF : (withIsolates BMat w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hPos : Fintype.card {i // 0<y i}=1)
    (hClose : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(2/3:ℝ)) :
    ¬(∀ i, b21Weight i≤w i) :=
  close_forbids_seed BMat BHerm b21Weight w b21_positive hw z hF y hPos hClose b21_count.ge


def b23Rows : Weights := #[1,1,2,2,1]
def b23Weight : Fin 5 → Nat := weightFn 5 b23Rows
def b23C : Cert := ⟨#[#[1,-50,2500,165950,-2050],#[0,-41,2050,-102500,-2050],#[0,0,-819,-250000,-5000],#[0,0,0,238579,-5000],#[0,0,0,0,5369]],#[-164,134316,-390792402,3251001992238,-9130070404],#[#[43012370329929,-52454110158450,0,-52454110158450,-52454110158450],#[0,-1049082203169,-2625907834550,-3202326627500,-5828234462050],#[0,0,-52518156691,-55032250000,-100158695000],#[0,0,0,180285651,167895000],#[0,0,0,0,8011244241]],43012370329929⟩
def b23X : Rows := #[#[-164,200,0,200,200],#[0,-3276,-8200,-10000,-18200],#[0,0,477158,500000,910000],#[0,0,0,13626522,12690000],#[0,0,0,0,-1700516]]
theorem b23_check : validCached 5 BRows b23Rows 4 50 1 41 b23C b23X=true := by decide +kernel
theorem b23_positive (i : Fin 5) : 0<b23Weight i := by fin_cases i <;> decide
theorem b23_count :
    Fintype.card {i // (41/50:ℝ)<(weightedQuotient_isHermitian BMat BHerm b23Weight).eigenvalues i}=2 := by
  have hd (i : Fin 5) : b23Weight i ∣ 4 := by fin_cases i <;> decide
  have he := cached_cut_count_sound 5 BRows b23Rows 4 50 1 41 b23C b23X
    b23_check BHerm b23_positive (by decide) (by decide) hd
  have hh : countPos 5 b23C.d=2 := by decide +kernel
  rw [hh] at he
  norm_num [b23Weight] at he ⊢
  exact he


theorem b23_forbidden (w : Fin 5 → Nat) (hw : ∀ i, 0<w i)
    (z : Nat) (hF : (withIsolates BMat w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hPos : Fintype.card {i // 0<y i}=1)
    (hClose : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(2/3:ℝ)) :
    ¬(∀ i, b23Weight i≤w i) :=
  close_forbids_seed BMat BHerm b23Weight w b23_positive hw z hF y hPos hClose b23_count.ge


def b3tripleRows : Weights := #[1,1,1,3,1]
def b3tripleWeight : Fin 5 → Nat := weightFn 5 b3tripleRows
def b3tripleC : Cert := ⟨#[#[1,-50,2500,40950,2523550],#[0,-41,2050,-102500,-7726450],#[0,0,-819,-125000,-9422500],#[0,0,0,136079,9232500],#[0,0,0,0,563261]],#[-123,100737,-334346103,76647993619,-478611941891883],#[#[2573762977732401,-3138735338698050,0,-3138735338698050,-3138735338698050],#[0,-62774706773961,-157128386918950,-191619984047500,-348748370966450],#[0,0,-3142567738379,-2886712625000,-5253816977500],#[0,0,0,18913741119,-310018117500],#[0,0,0,0,4569396741]],2573762977732401⟩
def b3tripleX : Rows := #[#[-123,150,0,150,150],#[0,-2457,-6150,-7500,-13650],#[0,0,408237,375000,682500],#[0,0,0,563261,-9232500],#[0,0,0,0,-849716103]]
theorem b3triple_check : validCached 5 BRows b3tripleRows 3 50 1 41 b3tripleC b3tripleX=true := by decide +kernel
theorem b3triple_positive (i : Fin 5) : 0<b3tripleWeight i := by fin_cases i <;> decide
theorem b3triple_count :
    Fintype.card {i // (41/50:ℝ)<(weightedQuotient_isHermitian BMat BHerm b3tripleWeight).eigenvalues i}=2 := by
  have hd (i : Fin 5) : b3tripleWeight i ∣ 3 := by fin_cases i <;> decide
  have he := cached_cut_count_sound 5 BRows b3tripleRows 3 50 1 41 b3tripleC b3tripleX
    b3triple_check BHerm b3triple_positive (by decide) (by decide) hd
  have hh : countPos 5 b3tripleC.d=2 := by decide +kernel
  rw [hh] at he
  norm_num [b3tripleWeight] at he ⊢
  exact he


theorem b3triple_forbidden (w : Fin 5 → Nat) (hw : ∀ i, 0<w i)
    (z : Nat) (hF : (withIsolates BMat w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hPos : Fintype.card {i // 0<y i}=1)
    (hClose : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(2/3:ℝ)) :
    ¬(∀ i, b3tripleWeight i≤w i) :=
  close_forbids_seed BMat BHerm b3tripleWeight w b3triple_positive hw z hF y hPos hClose b3triple_count.ge


def b30Rows : Weights := #[2,1,1,2,1]
def b30Weight : Fin 5 → Nat := weightFn 5 b30Rows
def b30C : Cert := ⟨#[#[1,-100,5000,81900,5047100],#[0,-41,2050,-205000,-8648950],#[0,0,-3319,-250000,-10547500],#[0,0,0,238579,12310000],#[0,0,0,0,-1591739]],#[-82,544316,-3167374804,-759510997762,731125204194156],#[#[-51676748532227599,126040850078603900,0,126040850078603900,126040850078603900],#[0,1260408500786039,778498772706050,1898777494405000,2677276267111050],#[0,0,15569975454121,16315324750000,23004607897500],#[0,0,0,-216602251381,-1675132490000],#[0,0,0,0,32465591741]],-51676748532227599⟩
def b30X : Rows := #[#[-82,200,0,200,200],#[0,-13276,-8200,-20000,-28200],#[0,0,954316,1000000,1410000],#[0,0,0,-3183478,-24620000],#[0,0,0,0,-459324804]]
theorem b30_check : validCached 5 BRows b30Rows 4 50 1 41 b30C b30X=true := by decide +kernel
theorem b30_positive (i : Fin 5) : 0<b30Weight i := by fin_cases i <;> decide
theorem b30_count :
    Fintype.card {i // (41/50:ℝ)<(weightedQuotient_isHermitian BMat BHerm b30Weight).eigenvalues i}=2 := by
  have hd (i : Fin 5) : b30Weight i ∣ 4 := by fin_cases i <;> decide
  have he := cached_cut_count_sound 5 BRows b30Rows 4 50 1 41 b30C b30X
    b30_check BHerm b30_positive (by decide) (by decide) hd
  have hh : countPos 5 b30C.d=2 := by decide +kernel
  rw [hh] at he
  norm_num [b30Weight] at he ⊢
  exact he


theorem b30_forbidden (w : Fin 5 → Nat) (hw : ∀ i, 0<w i)
    (z : Nat) (hF : (withIsolates BMat w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hPos : Fintype.card {i // 0<y i}=1)
    (hClose : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(2/3:ℝ)) :
    ¬(∀ i, b30Weight i≤w i) :=
  close_forbids_seed BMat BHerm b30Weight w b30_positive hw z hF y hPos hClose b30_count.ge


def b31Rows : Weights := #[1,2,1,2,1]
def b31Weight : Fin 5 → Nat := weightFn 5 b31Rows
def b31C : Cert := ⟨#[#[1,-50,5000,165950,1601050],#[0,-41,4100,-205000,-5202900],#[0,0,-3319,-250000,-6345000],#[0,0,0,341079,3905000],#[0,0,0,0,2610761]],#[-164,272158,-4528164804,1780951502238,-2998549873425844],#[#[121175049736522401,-147774450898198050,0,-147774450898198050,-147774450898198050],#[0,-2955489017963961,-3650950579587900,-4452378755595000,-8103329335182900],#[0,0,-36509505795879,-26760300250000,-48703746455000],#[0,0,0,355269746119,-531388495000],#[0,0,0,0,46413689241]],121175049736522401⟩
def b31X : Rows := #[#[-164,200,0,200,200],#[0,-6638,-8200,-10000,-18200],#[0,0,1364316,1000000,1820000],#[0,0,0,5221522,-7810000],#[0,0,0,0,-1148534804]]
theorem b31_check : validCached 5 BRows b31Rows 4 50 1 41 b31C b31X=true := by decide +kernel
theorem b31_positive (i : Fin 5) : 0<b31Weight i := by fin_cases i <;> decide
theorem b31_count :
    Fintype.card {i // (41/50:ℝ)<(weightedQuotient_isHermitian BMat BHerm b31Weight).eigenvalues i}=2 := by
  have hd (i : Fin 5) : b31Weight i ∣ 4 := by fin_cases i <;> decide
  have he := cached_cut_count_sound 5 BRows b31Rows 4 50 1 41 b31C b31X
    b31_check BHerm b31_positive (by decide) (by decide) hd
  have hh : countPos 5 b31C.d=2 := by decide +kernel
  rw [hh] at he
  norm_num [b31Weight] at he ⊢
  exact he


theorem b31_forbidden (w : Fin 5 → Nat) (hw : ∀ i, 0<w i)
    (z : Nat) (hF : (withIsolates BMat w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hPos : Fintype.card {i // 0<y i}=1)
    (hClose : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(2/3:ℝ)) :
    ¬(∀ i, b31Weight i≤w i) :=
  close_forbids_seed BMat BHerm b31Weight w b31_positive hw z hF y hPos hClose b31_count.ge


def b444Rows : Weights := #[4,4,1,1,4]
def b444Weight : Fin 5 → Nat := weightFn 5 b444Rows
def b444C : Cert := ⟨#[#[1,-200,40000,1663800,-8200],#[0,-41,8200,-1640000,-8200],#[0,0,-38319,-2000000,-10000],#[0,0,0,1981079,-10000],#[0,0,0,0,16519]],#[-656,25137264,-4858429836864,249236981511616,-1045924668816],#[#[51414257835647079,-250801257734863800,0,-250801257734863800,-250801257734863800],#[0,-1254006288674319,-268348640808200,-1309017760040000,-1577366400848200],#[0,0,-1341743204041,-1354558000000,-1632242390000],#[0,0,0,25952654001,15710790000],#[0,0,0,0,3112431614241]],51414257835647079⟩
def b444X : Rows := #[#[-656,3200,0,3200,3200],#[0,-613104,-131200,-640000,-771200],#[0,0,126789056,128000000,154240000],#[0,0,0,125808704,76160000],#[0,0,0,0,-63316464]]
theorem b444_check : validCached 5 BRows b444Rows 64 50 1 41 b444C b444X=true := by decide +kernel
theorem b444_positive (i : Fin 5) : 0<b444Weight i := by fin_cases i <;> decide
theorem b444_count :
    Fintype.card {i // (41/50:ℝ)<(weightedQuotient_isHermitian BMat BHerm b444Weight).eigenvalues i}=2 := by
  have hd (i : Fin 5) : b444Weight i ∣ 64 := by fin_cases i <;> decide
  have he := cached_cut_count_sound 5 BRows b444Rows 64 50 1 41 b444C b444X
    b444_check BHerm b444_positive (by decide) (by decide) hd
  have hh : countPos 5 b444C.d=2 := by decide +kernel
  rw [hh] at he
  norm_num [b444Weight] at he ⊢
  exact he


theorem b444_forbidden (w : Fin 5 → Nat) (hw : ∀ i, 0<w i)
    (z : Nat) (hF : (withIsolates BMat w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hPos : Fintype.card {i // 0<y i}=1)
    (hClose : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(2/3:ℝ)) :
    ¬(∀ i, b444Weight i≤w i) :=
  close_forbids_seed BMat BHerm b444Weight w b444_positive hw z hF y hPos hClose b444_count.ge


def p11Rows : Weights := #[1,1,1,11]
def p11Weight : Fin 4 → Nat := weightFn 4 p11Rows
def p11C : Cert := ⟨#[#[1,-50,50,450],#[0,-41,50,-2500],#[0,0,-9,-2500],#[0,0,0,5369]],#[-451,369369,-531531,146954899],#[#[1981161,-2416050,-2416050,-2416050],#[0,-48321,-268450,-147500],#[0,0,-220129,-102500],#[0,0,0,369]],1981161⟩
def p11X : Rows := #[#[-451,550,550,550],#[0,-9009,-50050,-27500],#[0,0,59059,27500],#[0,0,0,27371]]
theorem p11_check : validCached 4 PRows p11Rows 11 50 1 41 p11C p11X=true := by decide +kernel
theorem p11_positive (i : Fin 4) : 0<p11Weight i := by fin_cases i <;> decide
theorem p11_count :
    Fintype.card {i // (41/50:ℝ)<(weightedQuotient_isHermitian PMat PHerm p11Weight).eigenvalues i}=2 := by
  have hd (i : Fin 4) : p11Weight i ∣ 11 := by fin_cases i <;> decide
  have he := cached_cut_count_sound 4 PRows p11Rows 11 50 1 41 p11C p11X
    p11_check PHerm p11_positive (by decide) (by decide) hd
  have hh : countPos 4 p11C.d=2 := by decide +kernel
  rw [hh] at he
  norm_num [p11Weight] at he ⊢
  exact he


theorem p11_forbidden (w : Fin 4 → Nat) (hw : ∀ i, 0<w i)
    (z : Nat) (hF : (withIsolates PMat w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hPos : Fintype.card {i // 0<y i}=1)
    (hClose : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(2/3:ℝ)) :
    ¬(∀ i, p11Weight i≤w i) :=
  close_forbids_seed PMat PHerm p11Weight w p11_positive hw z hF y hPos hClose p11_count.ge


def p777Rows : Weights := #[7,7,7,2]
def p777Weight : Fin 4 → Nat := weightFn 4 p777Rows
def p777C : Cert := ⟨#[#[1,-350,350,108150],#[0,-41,350,-122500],#[0,0,-309,-122500],#[0,0,0,257669]],#[-4018,485450742,-7802732658,22145581996657],#[#[3264408561,-27866902350,-27866902350,-27866902350],#[0,-79619721,-90184150,-80727500],#[0,0,-10564429,-5022500],#[0,0,0,12669]],3264408561⟩
def p777X : Rows := #[#[-4018,34300,34300,34300],#[0,-11840262,-13411300,-12005000],#[0,0,25251562,12005000],#[0,0,0,85945853]]
theorem p777_check : validCached 4 PRows p777Rows 686 50 1 41 p777C p777X=true := by decide +kernel
theorem p777_positive (i : Fin 4) : 0<p777Weight i := by fin_cases i <;> decide
theorem p777_count :
    Fintype.card {i // (41/50:ℝ)<(weightedQuotient_isHermitian PMat PHerm p777Weight).eigenvalues i}=2 := by
  have hd (i : Fin 4) : p777Weight i ∣ 686 := by fin_cases i <;> decide
  have he := cached_cut_count_sound 4 PRows p777Rows 686 50 1 41 p777C p777X
    p777_check PHerm p777_positive (by decide) (by decide) hd
  have hh : countPos 4 p777C.d=2 := by decide +kernel
  rw [hh] at he
  norm_num [p777Weight] at he ⊢
  exact he


theorem p777_forbidden (w : Fin 4 → Nat) (hw : ∀ i, 0<w i)
    (z : Nat) (hF : (withIsolates PMat w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hPos : Fintype.card {i // 0<y i}=1)
    (hClose : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(2/3:ℝ)) :
    ¬(∀ i, p777Weight i≤w i) :=
  close_forbids_seed PMat PHerm p777Weight w p777_positive hw z hF y hPos hClose p777_count.ge

end WeightedSeedPruning


namespace UnitPruning
open Matrix Finset SpectralConjecture20
open scoped BigOperators

theorem symmetric_cut_of_signflip {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (hB : B.IsHermitian) (d : m → ℝ)
    (hd : ∀ i, d i*d i=1) (hflip : ∀ i j, d i*B i j*d j = -B i j)
    (q : ℝ) :
    Fintype.card {i // q < hB.eigenvalues i} =
    Fintype.card {i // q < -hB.eigenvalues i} := by
  let S : Matrix m m ℝ := diagonal d
  let V : Matrix m m ℝ := (1:ℝ) • B - q • (1 : Matrix m m ℝ)
  let W : Matrix m m ℝ := (-1:ℝ) • B - q • (1 : Matrix m m ℝ)
  have hd2 : S*S=1 := by
    dsimp [S]
    rw [diagonal_mul_diagonal]
    ext i j
    by_cases h : i=j
    · subst j
      simp [hd]
    · simp [one_apply,h]
  have hprod : S*V*S=W := by
    ext i j
    simp only [S,V,W,Matrix.diagonal_mul,Matrix.mul_diagonal,Matrix.sub_apply,Matrix.smul_apply,
      smul_eq_mul,one_mul,neg_one_mul]
    by_cases he : i=j
    · subst j
      simp only [one_apply_eq]
      linear_combination hflip i i - q*hd i
    · simp [one_apply,he,hflip]
  have hChar : V.charpoly=W.charpoly := by
    rw [←hprod,Matrix.charpoly_mul_comm (S*V) S,← Matrix.mul_assoc,hd2,one_mul]
  let hV := shifted_isHermitian B hB 1 q
  let hW := shifted_isHermitian B hB (-1) q
  have hE : hV.eigenvalues=hW.eigenvalues := hV.eigenvalues_eq_eigenvalues_iff hW |>.2 hChar
  have e₁ := shifted_positive_index B hB 1 q
  have e₂ := shifted_positive_index B hB (-1) q
  change Fintype.card {i // 0<hV.eigenvalues i}=Fintype.card {i // q<1*hB.eigenvalues i} at e₁
  change Fintype.card {i // 0<hW.eigenvalues i}=Fintype.card {i // q<(-1)*hB.eigenvalues i} at e₂
  rw [hE] at e₁
  simpa only [one_mul,neg_one_mul] using e₁.symm.trans e₂

theorem below_one_positive_cut_against_nonpositive {m : Type*} [Fintype m] (x y : m → ℝ)
    (h : (∑ i,(x i-y i)^2)<1) :
    Fintype.card {i // (2:ℝ)<x i} ≤ Fintype.card {i // 0<y i} := by
  apply Fintype.card_subtype_mono
  intro i hi

  classical
  have he : (x i-y i)^2<1 :=
    (single_le_sum (fun j _ => sq_nonneg (x j-y j)) (mem_univ i)).trans_lt h
  by_contra! hn
  have hh : (2:ℝ)<x i := hi
  have hdiff : 1≤x i-y i := by linarith
  nlinarith [mul_nonneg (sub_nonneg.mpr hdiff) (by linarith : 0≤x i-y i+1)]

theorem no_close_sign_symmetric_spectrum {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (hB : B.IsHermitian) (w : m → Nat) (hw : ∀ i, 0<w i) (z : Nat)
    (hFull : (withIsolates B w z).IsHermitian) (d : m → ℝ) (hd : ∀ i, d i*d i=1)
    (hf : ∀ i j, d i*weightedQuotient B w i j*d j = -(weightedQuotient B w i j))
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hNeg : Fintype.card {i // y i<0}=2)
    (hPos : Fintype.card {i // 0<y i}=1) (hDeep : ∀ i, y i<0 → y i≤ -3) :
    (2/3:ℝ)≤∑ i,(hFull.eigenvalues₀ i-y i)^2 := by
  by_contra! h
  have hc : ∑ i,(hFull.eigenvalues₀ i-y i)^2 < 1 := h.trans (by norm_num)
  have hHi := below_one_positive_cut_against_nonpositive hFull.eigenvalues₀ y hc
  have hLo := below_one_preserves_strict_negative_cut hFull.eigenvalues₀ y hc hDeep
  have e₁ := withIsolates_ordered_cut_count B hB w hw z hFull 1 2 (by norm_num)
  have e₂ := withIsolates_ordered_cut_count B hB w hw z hFull (-1) 2 (by norm_num)
  have he := symmetric_cut_of_signflip _ (weightedQuotient_isHermitian B hB w) d hd hf 2
  simp only [one_mul] at e₁
  simp only [neg_one_mul] at e₂
  rw [hPos,e₁,he,←e₂] at hHi
  rw [hNeg] at hLo
  omega

#print axioms no_close_sign_symmetric_spectrum
end UnitPruning


namespace UnitPruning
open Matrix SpectralConjecture20
open scoped BigOperators

theorem weighted_signflip_from_base {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (w : m → Nat) (d : m → ℝ)
    (hf : ∀ i j, d i*B i j*d j = -B i j) (i j : m) :
    d i*weightedQuotient B w i j*d j = -(weightedQuotient B w i j) := by
  simp [weightedQuotient,sqrtWeights]
  linear_combination Real.sqrt (w i) * Real.sqrt (w j) * hf i j

end UnitPruning


namespace BipartiteNormFence
open Matrix Finset SpectralConjecture20 UnitPruning
open scoped BigOperators Matrix

theorem sum_eigen_sq_eq_sum_matrix_sq {m : Type*} [Fintype m] [DecidableEq m]
    (A : Matrix m m ℝ) (hA : A.IsHermitian) :
    (∑ i,(hA.eigenvalues i)^2)=∑ i,∑ j,(A i j)^2 := by
  let U : Matrix m m ℝ := hA.eigenvectorUnitary
  let D : Matrix m m ℝ := diagonal hA.eigenvalues
  let DD : Matrix m m ℝ := diagonal (fun i => (hA.eigenvalues i)^2)
  have hs : star U=Uᵀ := by rw [star_eq_conjTranspose,conjTranspose_eq_transpose_of_trivial]
  have hU : Uᵀ*U=1 := by rw [←hs]; exact Unitary.coe_star_mul_self hA.eigenvectorUnitary
  have hA' : A=U*D*Uᵀ := by
    have h := hA.spectral_theorem
    rw [Unitary.conjStarAlgAut_apply,←Unitary.coe_star] at h
    change A=U*diagonal (RCLike.ofReal ∘ hA.eigenvalues)*star U at h
    rw [hs] at h
    simpa [D] using h
  have hDD : D*D=DD := by
    dsimp [D,DD]
    rw [diagonal_mul_diagonal]
    simp [pow_two]
  have hSq : A*A=U*DD*Uᵀ := by
    rw [hA']
    calc
      U*D*Uᵀ*(U*D*Uᵀ) = U*D*(Uᵀ*U)*D*Uᵀ := by simp only [Matrix.mul_assoc]
      _ = U*DD*Uᵀ := by rw [hU,Matrix.mul_one,Matrix.mul_assoc U D D,hDD]
  have hTrace : (A*A).trace = ∑ i,(hA.eigenvalues i)^2 := by
    rw [hSq,Matrix.trace_mul_cycle,hU,Matrix.one_mul]
    exact Matrix.trace_diagonal _
  rw [←hTrace]
  unfold Matrix.trace
  apply Finset.sum_congr rfl
  intro i _
  simp only [Matrix.diag_apply,Matrix.mul_apply]
  apply Finset.sum_congr rfl
  intro j _
  have hij : A j i=A i j := by simpa using (Matrix.IsHermitian.ext_iff.mp hA i j)
  rw [hij,pow_two]

theorem no_negative_cut_of_signflip_sq_budget {m : Type*} [Fintype m] [DecidableEq m]
    (A : Matrix m m ℝ) (hA : A.IsHermitian) (d : m → ℝ)
    (hd : ∀ i, d i*d i=1) (hf : ∀ i j, d i*A i j*d j= -A i j) (q : ℝ)
    (hq : 0≤q) (hBudget : (∑ i,∑ j,(A i j)^2)≤2*q^2) :
    Fintype.card {i // q < -hA.eigenvalues i}=0 := by
  classical
  apply Fintype.card_eq_zero_iff.mpr
  refine ⟨fun j => ?_⟩
  have cN : 0 < Fintype.card {i // q < -hA.eigenvalues i} := Fintype.card_pos_iff.mpr ⟨j⟩
  have he := symmetric_cut_of_signflip A hA d hd hf q
  rw [←he] at cN
  obtain ⟨i⟩ := Fintype.card_pos_iff.mp cN
  have hix := i.property
  have hjx := j.property
  have hij : i.val≠j.val := by
    intro hh
    rw [hh] at hix
    linarith
  have hTwo := Finset.sum_le_sum_of_subset_of_nonneg
    (f := fun x => (hA.eigenvalues x)^2) (Finset.subset_univ ({i.val,j.val}:Finset m))
    (fun x _ _ => sq_nonneg (hA.eigenvalues x))
  rw [Finset.sum_pair hij,sum_eigen_sq_eq_sum_matrix_sq A hA] at hTwo
  have hPosS := mul_pos (show 0<hA.eigenvalues i.val-q by linarith)
    (show 0<hA.eigenvalues i.val+q by linarith)
  have hNegS := mul_pos (show 0< -hA.eigenvalues j.val-q by linarith)
    (show 0< -hA.eigenvalues j.val+q by linarith)
  nlinarith only [hTwo,hBudget,hPosS,hNegS]

theorem full_negative_cut_at_most_one_of_principal_signflip
    {m k : Type*} [Fintype m] [DecidableEq m] [Fintype k] [DecidableEq k]
    (B : Matrix m m ℝ) (hB : B.IsHermitian) (w : m → Nat) (hw : ∀ i, 0<w i)
    (z : Nat) (hFull : (withIsolates B w z).IsHermitian)
    (e : k ↪ m) (he : Fintype.card m≤Fintype.card k+1)
    (A : Matrix k k ℝ) (hA : A.IsHermitian) (hEq : A=(weightedQuotient B w).submatrix e e)
    (d : k → ℝ) (hd : ∀ i, d i*d i=1) (hf : ∀ i j, d i*A i j*d j= -A i j)
    (q : ℝ) (hq : 0≤q) (hBudget : (∑ i,∑ j,(A i j)^2)≤2*q^2) :
    Fintype.card {i // q < -hFull.eigenvalues₀ i}≤1 := by
  let hQ := weightedQuotient_isHermitian B hB w
  have h0 := no_negative_cut_of_signflip_sq_budget A hA d hd hf q hq hBudget
  have hQcut := (shifted_principal_interlacing (weightedQuotient B w) hQ e (-1) q).2
  have hT := cut_index_of_matrix_eq hEq hA (hQ.submatrix e) (-1) q
  have hCount := withIsolates_ordered_cut_count B hB w hw z hFull (-1) q hq
  simp only [neg_one_mul] at hT hCount hQcut
  rw [←hCount,←hT,h0,zero_add] at hQcut
  omega

#print axioms sum_eigen_sq_eq_sum_matrix_sq
#print axioms full_negative_cut_at_most_one_of_principal_signflip
end BipartiteNormFence


namespace HouseLarge
open Matrix Finset SpectralConjecture20 UnitPruning WeightedSeedPruning BipartiteNormFence Conj20CutCert
open scoped BigOperators Matrix

def path : Matrix (Fin 4) (Fin 4) ℝ := !![0,1,0,1;1,0,1,0;0,1,0,0;1,0,0,0]
def pathW (a d : Nat) : Fin 4 → Nat := ![a,1,1,d]
def pathSigns : Fin 4 → ℝ := ![1,-1,1,-1]

theorem path_herm : path.IsHermitian := by
  ext i j
  fin_cases i <;> fin_cases j <;> rfl
theorem path_signs (i : Fin 4) : pathSigns i*pathSigns i=1 := by
  fin_cases i <;> norm_num [pathSigns]
theorem path_flip (i j : Fin 4) : pathSigns i*path i j*pathSigns j= -path i j := by
  fin_cases i <;> fin_cases j <;> norm_num [pathSigns,path]

theorem weightedQuotient_submatrix_eq {m k : Type*} [Fintype m] [DecidableEq m]
    [Fintype k] [DecidableEq k] (B : Matrix m m ℝ) (w : m → Nat) (e : k → m) :
    (weightedQuotient B w).submatrix e e = weightedQuotient (B.submatrix e e) (w ∘ e) := by
  ext i j
  simp [weightedQuotient,sqrtWeights,Matrix.submatrix_apply]

theorem path_frobenius (a d : Nat) :
    (∑ i,∑ j,((weightedQuotient path (pathW a d)) i j)^2)=2*(1+(a:ℝ)*(1+(d:ℝ))) := by
  simp [weightedQuotient,sqrtWeights,Fin.sum_univ_four,path,pathW,mul_pow,Real.sq_sqrt (Nat.cast_nonneg _)]
  ring

def houseW (a d e : Nat) : Fin 5 → Nat := ![a,1,1,d,e]
def keepLeft : Fin 4 ↪ Fin 5 where
  toFun := ![0,1,2,3]
  inj' := by decide
def keepRight : Fin 4 ↪ Fin 5 where
  toFun := ![4,2,1,3]
  inj' := by decide

theorem left_path_base : HMat.submatrix keepLeft keepLeft = path := by
  ext i j
  change (entry HRows (keepLeft i) (keepLeft j) : ℝ)=path i j
  fin_cases i <;> fin_cases j <;> norm_num [keepLeft,HRows,entry,path]
theorem right_path_base : HMat.submatrix keepRight keepRight = path := by
  ext i j
  change (entry HRows (keepRight i) (keepRight j) : ℝ)=path i j
  fin_cases i <;> fin_cases j <;> norm_num [keepRight,HRows,entry,path]

theorem left_path_weights (a d e : Nat) : houseW a d e ∘ keepLeft = pathW a d := by
  funext i
  fin_cases i <;> rfl
theorem right_path_weights (a d e : Nat) : houseW a d e ∘ keepRight = pathW e d := by
  funext i
  fin_cases i <;> rfl

theorem house_budget (n a d e : Nat) (hn : 7≤n) (hae : a≤e)
    (hd : d≤2) (hs : a+d+e+2≤3*n) :
    2*(1+(a:ℝ)*(1+(d:ℝ)))≤2*((n:ℝ)-41/50)^2 := by
  have hnr : (7:ℝ)≤n := by exact_mod_cast hn
  have hdr : (d:ℝ)≤2 := by exact_mod_cast hd
  have ha : 2*a≤3*n := by omega
  have hAr : 2*(a:ℝ)≤3*(n:ℝ) := by exact_mod_cast ha
  have hl := mul_le_mul_of_nonneg_left (show 1+(d:ℝ)≤3 by linarith) (Nat.cast_nonneg a)
  have hN := mul_nonneg (show 0≤(n:ℝ)-7 by linarith) (Nat.cast_nonneg n)
  nlinarith only [hAr,hl,hN,hnr]

theorem house_large_excluded (n a d e z : Nat) (hn : 7≤n)
    (ha : 0<a) (hd : 0<d) (hD : d≤2) (he : 0<e) (hSum : a+d+e+2≤3*n)
    (hF : (withIsolates HMat (houseW a d e) z).IsHermitian)
    (y : Fin (Fintype.card (Vertices (houseW a d e) ⊕ Fin z)) → ℝ)
    (hNeg : Fintype.card {i // y i= -(n:ℝ)}=2) :
    (2/3:ℝ)≤∑ i,(hF.eigenvalues₀ i-y i)^2 := by
  by_contra! hc
  have hNear := close_negative_cut_at_least_two hF.eigenvalues₀ y n hc hNeg
  have hnr : (7:ℝ)≤n := by exact_mod_cast hn
  let q : ℝ := (n:ℝ)-41/50
  have hq : 0≤q := by dsimp [q]; linarith
  let w := houseW a d e
  have hw (i : Fin 5) : 0<w i := by
    fin_cases i
    · exact ha
    · exact Nat.zero_lt_succ 0
    · exact Nat.zero_lt_succ 0
    · exact hd
    · exact he
  have finish (j : Nat) (r : Fin 4 ↪ Fin 5)
      (hb : HMat.submatrix r r=path) (hW : w ∘ r=pathW j d)
      (hBudget : 2*(1+(j:ℝ)*(1+(d:ℝ)))≤2*q^2) : False := by
    have hPathEq : weightedQuotient path (pathW j d)=(weightedQuotient HMat w).submatrix r r := by
      rw [weightedQuotient_submatrix_eq HMat w r,hb,hW]
    have hPast := full_negative_cut_at_most_one_of_principal_signflip HMat HHerm w hw z hF r
      (by simp) _ (weightedQuotient_isHermitian path path_herm (pathW j d)) hPathEq
      pathSigns path_signs (weighted_signflip_from_base path (pathW j d) pathSigns path_flip) q hq
      (by rw [path_frobenius]; exact hBudget)
    change 2≤Fintype.card {i // q < -hF.eigenvalues₀ i} at hNear
    exact (by decide : ¬2≤1) (hNear.trans hPast)
  by_cases h : a≤e
  · exact finish a keepLeft left_path_base (left_path_weights a d e) (house_budget n a d e hn h hD hSum)
  · exact finish e keepRight right_path_base (right_path_weights a d e)
      (house_budget n e d a hn (by omega) hD (by omega))

#print axioms house_large_excluded
end HouseLarge


namespace PawBullPrincipal
open Matrix Finset SpectralConjecture20 UnitPruning WeightedSeedPruning BipartiteNormFence Conj20CutCert
open scoped BigOperators Matrix

def removeP0 : Fin 3 ↪ Fin 4 where
  toFun := ![1,2,3]
  inj' := by decide
def remP0 : Matrix (Fin 3) (Fin 3) ℝ := !![0,1,0;1,0,0;0,0,0]
def signsP0 : Fin 3 → ℝ := ![1,-1,1]

theorem actualP0 : PMat.submatrix removeP0 removeP0=remP0 := by
  ext i j
  change (entry PRows (removeP0 i) (removeP0 j) : ℝ)=remP0 i j
  fin_cases i <;> fin_cases j <;> norm_num [entry,PRows,removeP0,remP0]

theorem frobP0 (w : Fin 4 → Nat) :
    (∑ i,∑ j,((weightedQuotient remP0 (w ∘ removeP0)) i j)^2) = 2*((w 1:ℝ)*(w 2:ℝ)) := by
  simp [weightedQuotient,sqrtWeights,Fin.sum_univ_succ,remP0,removeP0,mul_pow,
    Real.sq_sqrt (Nat.cast_nonneg _)]
  ring

theorem boundP0 (w : Fin 4 → Nat) (hw : ∀ i, 0<w i)
    (z : Nat) (hF : (withIsolates PMat w z).IsHermitian)
    (q : ℝ) (hq : 0≤q) (hBudget : ((w 1:ℝ)*(w 2:ℝ))≤q^2) :
    Fintype.card {i // q < -hF.eigenvalues₀ i} ≤ 1 := by
  let A := weightedQuotient remP0 (w ∘ removeP0)
  have hR : remP0.IsHermitian := by ext i j; fin_cases i <;> fin_cases j <;> rfl
  have hA : A.IsHermitian := weightedQuotient_isHermitian remP0 hR _
  have hEq : A=(weightedQuotient PMat w).submatrix removeP0 removeP0 := by
    rw [HouseLarge.weightedQuotient_submatrix_eq PMat w removeP0,actualP0]
  have hd (i : Fin 3) : signsP0 i*signsP0 i=1 := by fin_cases i <;> norm_num [signsP0]
  have hf (i j : Fin 3) : signsP0 i*remP0 i j*signsP0 j= -remP0 i j := by
    fin_cases i <;> fin_cases j <;> norm_num [signsP0,remP0]
  have hb : (∑ i,∑ j,(A i j)^2)≤2*q^2 := by
    dsimp [A]
    rw [frobP0 w]
    linarith only [hBudget]
  exact full_negative_cut_at_most_one_of_principal_signflip PMat PHerm w hw z hF
    removeP0 (by simp) A hA hEq signsP0 hd
    (weighted_signflip_from_base remP0 (w ∘ removeP0) signsP0 hf) q hq hb
#print axioms boundP0

def removeP1 : Fin 3 ↪ Fin 4 where
  toFun := ![0,2,3]
  inj' := by decide
def remP1 : Matrix (Fin 3) (Fin 3) ℝ := !![0,1,1;1,0,0;1,0,0]
def signsP1 : Fin 3 → ℝ := ![1,-1,-1]

theorem actualP1 : PMat.submatrix removeP1 removeP1=remP1 := by
  ext i j
  change (entry PRows (removeP1 i) (removeP1 j) : ℝ)=remP1 i j
  fin_cases i <;> fin_cases j <;> norm_num [entry,PRows,removeP1,remP1]

theorem frobP1 (w : Fin 4 → Nat) :
    (∑ i,∑ j,((weightedQuotient remP1 (w ∘ removeP1)) i j)^2) = 2*((w 0:ℝ)*(w 2:ℝ)+(w 0:ℝ)*(w 3:ℝ)) := by
  simp [weightedQuotient,sqrtWeights,Fin.sum_univ_succ,remP1,removeP1,mul_pow,
    Real.sq_sqrt (Nat.cast_nonneg _)]
  ring

theorem boundP1 (w : Fin 4 → Nat) (hw : ∀ i, 0<w i)
    (z : Nat) (hF : (withIsolates PMat w z).IsHermitian)
    (q : ℝ) (hq : 0≤q) (hBudget : ((w 0:ℝ)*(w 2:ℝ)+(w 0:ℝ)*(w 3:ℝ))≤q^2) :
    Fintype.card {i // q < -hF.eigenvalues₀ i} ≤ 1 := by
  let A := weightedQuotient remP1 (w ∘ removeP1)
  have hR : remP1.IsHermitian := by ext i j; fin_cases i <;> fin_cases j <;> rfl
  have hA : A.IsHermitian := weightedQuotient_isHermitian remP1 hR _
  have hEq : A=(weightedQuotient PMat w).submatrix removeP1 removeP1 := by
    rw [HouseLarge.weightedQuotient_submatrix_eq PMat w removeP1,actualP1]
  have hd (i : Fin 3) : signsP1 i*signsP1 i=1 := by fin_cases i <;> norm_num [signsP1]
  have hf (i j : Fin 3) : signsP1 i*remP1 i j*signsP1 j= -remP1 i j := by
    fin_cases i <;> fin_cases j <;> norm_num [signsP1,remP1]
  have hb : (∑ i,∑ j,(A i j)^2)≤2*q^2 := by
    dsimp [A]
    rw [frobP1 w]
    linarith only [hBudget]
  exact full_negative_cut_at_most_one_of_principal_signflip PMat PHerm w hw z hF
    removeP1 (by simp) A hA hEq signsP1 hd
    (weighted_signflip_from_base remP1 (w ∘ removeP1) signsP1 hf) q hq hb
#print axioms boundP1

def removeP2 : Fin 3 ↪ Fin 4 where
  toFun := ![0,1,3]
  inj' := by decide
def remP2 : Matrix (Fin 3) (Fin 3) ℝ := !![0,1,1;1,0,0;1,0,0]
def signsP2 : Fin 3 → ℝ := ![1,-1,-1]

theorem actualP2 : PMat.submatrix removeP2 removeP2=remP2 := by
  ext i j
  change (entry PRows (removeP2 i) (removeP2 j) : ℝ)=remP2 i j
  fin_cases i <;> fin_cases j <;> norm_num [entry,PRows,removeP2,remP2]

theorem frobP2 (w : Fin 4 → Nat) :
    (∑ i,∑ j,((weightedQuotient remP2 (w ∘ removeP2)) i j)^2) = 2*((w 0:ℝ)*(w 1:ℝ)+(w 0:ℝ)*(w 3:ℝ)) := by
  simp [weightedQuotient,sqrtWeights,Fin.sum_univ_succ,remP2,removeP2,mul_pow,
    Real.sq_sqrt (Nat.cast_nonneg _)]
  ring

theorem boundP2 (w : Fin 4 → Nat) (hw : ∀ i, 0<w i)
    (z : Nat) (hF : (withIsolates PMat w z).IsHermitian)
    (q : ℝ) (hq : 0≤q) (hBudget : ((w 0:ℝ)*(w 1:ℝ)+(w 0:ℝ)*(w 3:ℝ))≤q^2) :
    Fintype.card {i // q < -hF.eigenvalues₀ i} ≤ 1 := by
  let A := weightedQuotient remP2 (w ∘ removeP2)
  have hR : remP2.IsHermitian := by ext i j; fin_cases i <;> fin_cases j <;> rfl
  have hA : A.IsHermitian := weightedQuotient_isHermitian remP2 hR _
  have hEq : A=(weightedQuotient PMat w).submatrix removeP2 removeP2 := by
    rw [HouseLarge.weightedQuotient_submatrix_eq PMat w removeP2,actualP2]
  have hd (i : Fin 3) : signsP2 i*signsP2 i=1 := by fin_cases i <;> norm_num [signsP2]
  have hf (i j : Fin 3) : signsP2 i*remP2 i j*signsP2 j= -remP2 i j := by
    fin_cases i <;> fin_cases j <;> norm_num [signsP2,remP2]
  have hb : (∑ i,∑ j,(A i j)^2)≤2*q^2 := by
    dsimp [A]
    rw [frobP2 w]
    linarith only [hBudget]
  exact full_negative_cut_at_most_one_of_principal_signflip PMat PHerm w hw z hF
    removeP2 (by simp) A hA hEq signsP2 hd
    (weighted_signflip_from_base remP2 (w ∘ removeP2) signsP2 hf) q hq hb
#print axioms boundP2

def removeB0 : Fin 4 ↪ Fin 5 where
  toFun := ![1,2,3,4]
  inj' := by decide
def remB0 : Matrix (Fin 4) (Fin 4) ℝ := !![0,1,0,1;1,0,0,0;0,0,0,0;1,0,0,0]
def signsB0 : Fin 4 → ℝ := ![1,-1,1,-1]

theorem actualB0 : BMat.submatrix removeB0 removeB0=remB0 := by
  ext i j
  change (entry BRows (removeB0 i) (removeB0 j) : ℝ)=remB0 i j
  fin_cases i <;> fin_cases j <;> norm_num [entry,BRows,removeB0,remB0]

theorem frobB0 (w : Fin 5 → Nat) :
    (∑ i,∑ j,((weightedQuotient remB0 (w ∘ removeB0)) i j)^2) = 2*((w 1:ℝ)*(w 2:ℝ)+(w 1:ℝ)*(w 4:ℝ)) := by
  simp [weightedQuotient,sqrtWeights,Fin.sum_univ_succ,remB0,removeB0,mul_pow,
    Real.sq_sqrt (Nat.cast_nonneg _)]
  ring

theorem boundB0 (w : Fin 5 → Nat) (hw : ∀ i, 0<w i)
    (z : Nat) (hF : (withIsolates BMat w z).IsHermitian)
    (q : ℝ) (hq : 0≤q) (hBudget : ((w 1:ℝ)*(w 2:ℝ)+(w 1:ℝ)*(w 4:ℝ))≤q^2) :
    Fintype.card {i // q < -hF.eigenvalues₀ i} ≤ 1 := by
  let A := weightedQuotient remB0 (w ∘ removeB0)
  have hR : remB0.IsHermitian := by ext i j; fin_cases i <;> fin_cases j <;> rfl
  have hA : A.IsHermitian := weightedQuotient_isHermitian remB0 hR _
  have hEq : A=(weightedQuotient BMat w).submatrix removeB0 removeB0 := by
    rw [HouseLarge.weightedQuotient_submatrix_eq BMat w removeB0,actualB0]
  have hd (i : Fin 4) : signsB0 i*signsB0 i=1 := by fin_cases i <;> norm_num [signsB0]
  have hf (i j : Fin 4) : signsB0 i*remB0 i j*signsB0 j= -remB0 i j := by
    fin_cases i <;> fin_cases j <;> norm_num [signsB0,remB0]
  have hb : (∑ i,∑ j,(A i j)^2)≤2*q^2 := by
    dsimp [A]
    rw [frobB0 w]
    linarith only [hBudget]
  exact full_negative_cut_at_most_one_of_principal_signflip BMat BHerm w hw z hF
    removeB0 (by simp) A hA hEq signsB0 hd
    (weighted_signflip_from_base remB0 (w ∘ removeB0) signsB0 hf) q hq hb
#print axioms boundB0

def removeB1 : Fin 4 ↪ Fin 5 where
  toFun := ![0,2,3,4]
  inj' := by decide
def remB1 : Matrix (Fin 4) (Fin 4) ℝ := !![0,0,1,1;0,0,0,0;1,0,0,0;1,0,0,0]
def signsB1 : Fin 4 → ℝ := ![1,1,-1,-1]

theorem actualB1 : BMat.submatrix removeB1 removeB1=remB1 := by
  ext i j
  change (entry BRows (removeB1 i) (removeB1 j) : ℝ)=remB1 i j
  fin_cases i <;> fin_cases j <;> norm_num [entry,BRows,removeB1,remB1]

theorem frobB1 (w : Fin 5 → Nat) :
    (∑ i,∑ j,((weightedQuotient remB1 (w ∘ removeB1)) i j)^2) = 2*((w 0:ℝ)*(w 3:ℝ)+(w 0:ℝ)*(w 4:ℝ)) := by
  simp [weightedQuotient,sqrtWeights,Fin.sum_univ_succ,remB1,removeB1,mul_pow,
    Real.sq_sqrt (Nat.cast_nonneg _)]
  ring

theorem boundB1 (w : Fin 5 → Nat) (hw : ∀ i, 0<w i)
    (z : Nat) (hF : (withIsolates BMat w z).IsHermitian)
    (q : ℝ) (hq : 0≤q) (hBudget : ((w 0:ℝ)*(w 3:ℝ)+(w 0:ℝ)*(w 4:ℝ))≤q^2) :
    Fintype.card {i // q < -hF.eigenvalues₀ i} ≤ 1 := by
  let A := weightedQuotient remB1 (w ∘ removeB1)
  have hR : remB1.IsHermitian := by ext i j; fin_cases i <;> fin_cases j <;> rfl
  have hA : A.IsHermitian := weightedQuotient_isHermitian remB1 hR _
  have hEq : A=(weightedQuotient BMat w).submatrix removeB1 removeB1 := by
    rw [HouseLarge.weightedQuotient_submatrix_eq BMat w removeB1,actualB1]
  have hd (i : Fin 4) : signsB1 i*signsB1 i=1 := by fin_cases i <;> norm_num [signsB1]
  have hf (i j : Fin 4) : signsB1 i*remB1 i j*signsB1 j= -remB1 i j := by
    fin_cases i <;> fin_cases j <;> norm_num [signsB1,remB1]
  have hb : (∑ i,∑ j,(A i j)^2)≤2*q^2 := by
    dsimp [A]
    rw [frobB1 w]
    linarith only [hBudget]
  exact full_negative_cut_at_most_one_of_principal_signflip BMat BHerm w hw z hF
    removeB1 (by simp) A hA hEq signsB1 hd
    (weighted_signflip_from_base remB1 (w ∘ removeB1) signsB1 hf) q hq hb
#print axioms boundB1

def removeB4 : Fin 4 ↪ Fin 5 where
  toFun := ![0,1,2,3]
  inj' := by decide
def remB4 : Matrix (Fin 4) (Fin 4) ℝ := !![0,1,0,1;1,0,1,0;0,1,0,0;1,0,0,0]
def signsB4 : Fin 4 → ℝ := ![1,-1,1,-1]

theorem actualB4 : BMat.submatrix removeB4 removeB4=remB4 := by
  ext i j
  change (entry BRows (removeB4 i) (removeB4 j) : ℝ)=remB4 i j
  fin_cases i <;> fin_cases j <;> norm_num [entry,BRows,removeB4,remB4]

theorem frobB4 (w : Fin 5 → Nat) :
    (∑ i,∑ j,((weightedQuotient remB4 (w ∘ removeB4)) i j)^2) = 2*((w 0:ℝ)*(w 1:ℝ)+(w 0:ℝ)*(w 3:ℝ)+(w 1:ℝ)*(w 2:ℝ)) := by
  simp [weightedQuotient,sqrtWeights,Fin.sum_univ_succ,remB4,removeB4,mul_pow,
    Real.sq_sqrt (Nat.cast_nonneg _)]
  ring

theorem boundB4 (w : Fin 5 → Nat) (hw : ∀ i, 0<w i)
    (z : Nat) (hF : (withIsolates BMat w z).IsHermitian)
    (q : ℝ) (hq : 0≤q) (hBudget : ((w 0:ℝ)*(w 1:ℝ)+(w 0:ℝ)*(w 3:ℝ)+(w 1:ℝ)*(w 2:ℝ))≤q^2) :
    Fintype.card {i // q < -hF.eigenvalues₀ i} ≤ 1 := by
  let A := weightedQuotient remB4 (w ∘ removeB4)
  have hR : remB4.IsHermitian := by ext i j; fin_cases i <;> fin_cases j <;> rfl
  have hA : A.IsHermitian := weightedQuotient_isHermitian remB4 hR _
  have hEq : A=(weightedQuotient BMat w).submatrix removeB4 removeB4 := by
    rw [HouseLarge.weightedQuotient_submatrix_eq BMat w removeB4,actualB4]
  have hd (i : Fin 4) : signsB4 i*signsB4 i=1 := by fin_cases i <;> norm_num [signsB4]
  have hf (i j : Fin 4) : signsB4 i*remB4 i j*signsB4 j= -remB4 i j := by
    fin_cases i <;> fin_cases j <;> norm_num [signsB4,remB4]
  have hb : (∑ i,∑ j,(A i j)^2)≤2*q^2 := by
    dsimp [A]
    rw [frobB4 w]
    linarith only [hBudget]
  exact full_negative_cut_at_most_one_of_principal_signflip BMat BHerm w hw z hF
    removeB4 (by simp) A hA hEq signsB4 hd
    (weighted_signflip_from_base remB4 (w ∘ removeB4) signsB4 hf) q hq hb
#print axioms boundB4

end PawBullPrincipal


namespace PawBullPrincipal
open Matrix Finset SpectralConjecture20 WeightedSeedPruning
open scoped BigOperators Matrix

theorem upper_square_fence_paw (n : Nat) (hn : 28≤n) :
    (24:ℝ)*(n:ℝ)+60≤((n:ℝ)-41/50)^2 := by
  have h : (28:ℝ)≤n := by exact_mod_cast hn
  have he := mul_nonneg (show 0≤(n:ℝ)-28 by linarith) (show 0≤(n:ℝ) by positivity)
  nlinarith only [h,he]

theorem upper_square_fence_bull (n : Nat) (hn : 8≤n) :
    (6:ℝ)*(n:ℝ)+3≤((n:ℝ)-41/50)^2 := by
  have h : (8:ℝ)≤n := by exact_mod_cast hn
  have he := mul_nonneg (show 0≤(n:ℝ)-8 by linarith) (show 0≤(n:ℝ) by positivity)
  nlinarith only [h,he]

theorem paw_class_bounds (w : Fin 4 → Nat) (hw : ∀ i, 0<w i) (hwL : 2≤w 3)
    (z : Nat) (hF : (withIsolates PMat w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hPos : Fintype.card {i // 0<y i}=1)
    (hC : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(2/3:ℝ)) :
    w 3≤10 ∧ (w 0≤6 ∨ w 1≤6 ∨ w 2≤6) := by
  constructor
  · by_contra! hb
    apply p11_forbidden w hw z hF y hPos hC
    intro i
    fin_cases i
    · exact Nat.succ_le_of_lt (hw 0)
    · exact Nat.succ_le_of_lt (hw 1)
    · exact Nat.succ_le_of_lt (hw 2)
    · exact hb
  · by_contra! hb
    obtain ⟨h0,h1,h2⟩ := hb
    apply p777_forbidden w hw z hF y hPos hC
    intro i
    fin_cases i
    · exact h0
    · exact h1
    · exact h2
    · exact hwL

theorem paw_huge_excluded (n : Nat) (hn : 28≤n) (w : Fin 4 → Nat)
    (hw : ∀ i, 0<w i) (hTot : (∑ i,w i) ≤ 3*n) (hwL : 2≤w 3)
    (z : Nat) (hF : (withIsolates PMat w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hPos : Fintype.card {i // 0<y i}=1) (hNeg : Fintype.card {i // y i= -(n:ℝ)}=2) :
    (2/3:ℝ)≤∑ i,(hF.eigenvalues₀ i-y i)^2 := by
  by_contra! hC
  obtain ⟨hT,hmin⟩ := paw_class_bounds w hw hwL z hF y hPos hC
  let q : ℝ := (n:ℝ)-41/50
  have hnr : (28:ℝ)≤n := by exact_mod_cast hn
  have hq : 0≤q := by dsimp [q]; linarith
  have hNear := close_negative_cut_at_least_two hF.eigenvalues₀ y n hC hNeg
  change 2≤Fintype.card {i // q < -hF.eigenvalues₀ i} at hNear
  have hBad (h : Fintype.card {i // q < -hF.eigenvalues₀ i}≤1) : False :=
    (by decide : ¬2≤1) (hNear.trans h)
  have hBudget (u v : Nat) (hu : u≤6) (hv : 2*v≤3*n) :
      (u:ℝ)*v+(u:ℝ)*w 3+(v:ℝ)*w 3≤q^2 := by
    have hu' : (u:ℝ)≤6 := by exact_mod_cast hu
    have hv' : 2*(v:ℝ)≤3*(n:ℝ) := by exact_mod_cast hv
    have ht' : (w 3:ℝ)≤10 := by exact_mod_cast hT
    have H1 := mul_le_mul_of_nonneg_right hu' (Nat.cast_nonneg v)
    have H2 := mul_le_mul hu' ht' (Nat.cast_nonneg _) (show (0:ℝ)≤6 by norm_num)
    have H3 := mul_le_mul_of_nonneg_left ht' (Nat.cast_nonneg v)
    have h := upper_square_fence_paw n hn
    dsimp [q]
    nlinarith only [hv',H1,H2,H3,h]
  rw [Fin.sum_univ_four] at hTot
  rcases hmin with h | h | h
  · by_cases hL : w 1≤w 2
    · have hb := hBudget (w 0) (w 1) h (by omega)
      apply hBad (boundP2 _ hw z hF q hq _)
      nlinarith only [hb,show 0≤(w 1:ℝ)*w 3 by positivity]
    · have hb := hBudget (w 0) (w 2) h (by omega)
      apply hBad (boundP1 _ hw z hF q hq _)
      nlinarith only [hb,show 0≤(w 2:ℝ)*w 3 by positivity]
  · by_cases hL : w 0≤w 2
    · have hb := hBudget (w 1) (w 0) h (by omega)
      apply hBad (boundP2 _ hw z hF q hq _)
      nlinarith only [hb,show 0≤(w 1:ℝ)*w 3 by positivity]
    · have hb := hBudget (w 1) (w 2) h (by omega)
      apply hBad (boundP0 _ hw z hF q hq _)
      nlinarith only [hb,show 0≤(w 1:ℝ)*w 3 by positivity,show 0≤(w 2:ℝ)*w 3 by positivity]
  · by_cases hL : w 0≤w 1
    · have hb := hBudget (w 2) (w 0) h (by omega)
      apply hBad (boundP1 _ hw z hF q hq _)
      nlinarith only [hb,show 0≤(w 2:ℝ)*w 3 by positivity]
    · have hb := hBudget (w 2) (w 1) h (by omega)
      apply hBad (boundP0 _ hw z hF q hq _)
      nlinarith only [hb,show 0≤(w 2:ℝ)*w 3 by positivity,show 0≤(w 1:ℝ)*w 3 by positivity]

#print axioms paw_huge_excluded
end PawBullPrincipal


namespace PawBullPrincipal
open Matrix Finset SpectralConjecture20 WeightedSeedPruning
open scoped BigOperators Matrix

theorem bull_single_leaf_controls (w : Fin 5 → Nat) (hw : ∀ i, 0<w i)
    (z : Nat) (hF : (withIsolates BMat w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hPos : Fintype.card {i // 0<y i}=1)
    (hC : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(2/3:ℝ)) :
    w 2≤2 ∧ w 3≤2 ∧
    (2≤w 2 → w 0=1 ∧ w 1=1 ∧ w 3=1) ∧ (2≤w 3 → w 0=1 ∧ w 1=1 ∧ w 2=1) ∧
    (w 0≤3 ∨ w 1≤3 ∨ w 4≤3) := by
  constructor
  · by_contra! hb
    apply b2triple_forbidden w hw z hF y hPos hC
    intro i
    fin_cases i
    · exact Nat.succ_le_of_lt (hw 0)
    · exact Nat.succ_le_of_lt (hw 1)
    · exact hb
    · exact Nat.succ_le_of_lt (hw 3)
    · exact Nat.succ_le_of_lt (hw 4)
  constructor
  · by_contra! hb
    apply b3triple_forbidden w hw z hF y hPos hC
    intro i
    fin_cases i
    · exact Nat.succ_le_of_lt (hw 0)
    · exact Nat.succ_le_of_lt (hw 1)
    · exact Nat.succ_le_of_lt (hw 2)
    · exact hb
    · exact Nat.succ_le_of_lt (hw 4)
  constructor
  · intro hL
    constructor
    · by_contra! hh
      have hbad : 2≤w 0 := by have := hw 0; omega
      apply b20_forbidden w hw z hF y hPos hC
      intro i
      fin_cases i
      · exact hbad
      · exact Nat.succ_le_of_lt (hw 1)
      · exact hL
      · exact Nat.succ_le_of_lt (hw 3)
      · exact Nat.succ_le_of_lt (hw 4)
    constructor
    · by_contra! hh
      have hbad : 2≤w 1 := by have := hw 1; omega
      apply b21_forbidden w hw z hF y hPos hC
      intro i
      fin_cases i
      · exact Nat.succ_le_of_lt (hw 0)
      · exact hbad
      · exact hL
      · exact Nat.succ_le_of_lt (hw 3)
      · exact Nat.succ_le_of_lt (hw 4)
    · by_contra! hh
      have hbad : 2≤w 3 := by have := hw 3; omega
      apply b23_forbidden w hw z hF y hPos hC
      intro i
      fin_cases i
      · exact Nat.succ_le_of_lt (hw 0)
      · exact Nat.succ_le_of_lt (hw 1)
      · exact hL
      · exact hbad
      · exact Nat.succ_le_of_lt (hw 4)
  constructor
  · intro hL
    constructor
    · by_contra! hh
      have hbad : 2≤w 0 := by have := hw 0; omega
      apply b30_forbidden w hw z hF y hPos hC
      intro i
      fin_cases i
      · exact hbad
      · exact Nat.succ_le_of_lt (hw 1)
      · exact Nat.succ_le_of_lt (hw 2)
      · exact hL
      · exact Nat.succ_le_of_lt (hw 4)
    constructor
    · by_contra! hh
      have hbad : 2≤w 1 := by have := hw 1; omega
      apply b31_forbidden w hw z hF y hPos hC
      intro i
      fin_cases i
      · exact Nat.succ_le_of_lt (hw 0)
      · exact hbad
      · exact Nat.succ_le_of_lt (hw 2)
      · exact hL
      · exact Nat.succ_le_of_lt (hw 4)
    · by_contra! hh
      have hbad : 2≤w 2 := by have := hw 2; omega
      apply b23_forbidden w hw z hF y hPos hC
      intro i
      fin_cases i
      · exact Nat.succ_le_of_lt (hw 0)
      · exact Nat.succ_le_of_lt (hw 1)
      · exact hbad
      · exact hL
      · exact Nat.succ_le_of_lt (hw 4)
  · by_contra! hh
    obtain ⟨h0,h1,h4⟩ := hh
    apply b444_forbidden w hw z hF y hPos hC
    intro i
    fin_cases i
    · exact h0
    · exact h1
    · exact Nat.succ_le_of_lt (hw 2)
    · exact Nat.succ_le_of_lt (hw 3)
    · exact h4

theorem bull_close_leaf_singletons (n : Nat) (hn : 3≤n) (w : Fin 5 → Nat) (hw : ∀ i, 0<w i)
    (z : Nat) (hF : (withIsolates BMat w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hPos : Fintype.card {i // 0<y i}=1) (hNeg : Fintype.card {i // y i= -(n:ℝ)}=2)
    (hC : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(2/3:ℝ)) :
    w 2=1 ∧ w 3=1 ∧ (w 0≤3 ∨ w 1≤3 ∨ w 4≤3) := by
  obtain ⟨h2,h3,h2cond,h3cond,hmin⟩ := bull_single_leaf_controls w hw z hF y hPos hC
  let q : ℝ := (n:ℝ)-41/50
  have hnr : (3:ℝ)≤n := by exact_mod_cast hn
  have hq' : 2≤q := by dsimp [q]; linarith
  have hq : 0≤q := by linarith
  have hq2 : 4≤q^2 := by
    have hsq := mul_nonneg (show 0≤q-2 by linarith) (show 0≤q+2 by linarith)
    nlinarith only [hsq]
  have hNear := close_negative_cut_at_least_two hF.eigenvalues₀ y n hC hNeg
  change 2≤Fintype.card {i // q < -hF.eigenvalues₀ i} at hNear
  have hBad (h : Fintype.card {i // q < -hF.eigenvalues₀ i}≤1) : False :=
    (by decide : ¬2≤1) (hNear.trans h)
  constructor
  · by_contra! hh
    have hB : 2≤w 2 := by have := hw 2; omega
    obtain ⟨h0,h1,h3'⟩ := h2cond hB
    have hEq : w 2=2 := by omega
    have hCut := boundB4 w hw z hF q hq (by rw [h0,h1,h3',hEq]; norm_num; exact hq2)
    exact hBad hCut
  constructor
  · by_contra! hh
    have hB : 2≤w 3 := by have := hw 3; omega
    obtain ⟨h0,h1,h2'⟩ := h3cond hB
    have hEq : w 3=2 := by omega
    have hCut := boundB4 w hw z hF q hq (by rw [h0,h1,h2',hEq]; norm_num; exact hq2)
    exact hBad hCut
  exact hmin

#print axioms bull_close_leaf_singletons
end PawBullPrincipal


namespace PawBullPrincipal
open Matrix Finset SpectralConjecture20 WeightedSeedPruning
open scoped BigOperators Matrix

theorem bull_huge_excluded (n : Nat) (hn : 8≤n) (w : Fin 5 → Nat)
    (hw : ∀ i, 0<w i) (hTot : (∑ i,w i) ≤ 3*n)
    (z : Nat) (hF : (withIsolates BMat w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hPos : Fintype.card {i // 0<y i}=1) (hNeg : Fintype.card {i // y i= -(n:ℝ)}=2) :
    (2/3:ℝ)≤∑ i,(hF.eigenvalues₀ i-y i)^2 := by
  by_contra! hC
  obtain ⟨h2,h3,hmin⟩ := bull_close_leaf_singletons n (by omega) w hw z hF y hPos hNeg hC
  let q : ℝ := (n:ℝ)-41/50
  have hnr : (8:ℝ)≤n := by exact_mod_cast hn
  have hq : 0≤q := by dsimp [q]; linarith
  have hNear := close_negative_cut_at_least_two hF.eigenvalues₀ y n hC hNeg
  change 2≤Fintype.card {i // q < -hF.eigenvalues₀ i} at hNear
  have hBad (h : Fintype.card {i // q < -hF.eigenvalues₀ i}≤1) : False :=
    (by decide : ¬2≤1) (hNear.trans h)
  have hBudget (u v : Nat) (hu : u≤3) (hv : 2*v≤3*n) :
      (u:ℝ)*v+(u:ℝ)+v≤q^2 := by
    have hu' : (u:ℝ)≤3 := by exact_mod_cast hu
    have hv' : 2*(v:ℝ)≤3*(n:ℝ) := by exact_mod_cast hv
    have hProd := mul_le_mul_of_nonneg_right hu' (Nat.cast_nonneg v)
    have h := upper_square_fence_bull n hn
    dsimp [q]
    nlinarith only [hu',hv',hProd,h]
  simp [Fin.sum_univ_succ,h2,h3] at hTot
  rcases hmin with h | h | h
  · by_cases hL : w 1≤w 4
    · have hb := hBudget (w 0) (w 1) h (by omega)
      apply hBad (boundB4 _ hw z hF q hq _)
      simp [h2,h3]
      nlinarith only [hb,Nat.cast_nonneg (α:=ℝ) (w 0),Nat.cast_nonneg (α:=ℝ) (w 1)]
    · have hb := hBudget (w 0) (w 4) h (by omega)
      apply hBad (boundB1 _ hw z hF q hq _)
      simp [h3]
      nlinarith only [hb,Nat.cast_nonneg (α:=ℝ) (w 0),Nat.cast_nonneg (α:=ℝ) (w 4)]
  · by_cases hL : w 0≤w 4
    · have hb := hBudget (w 1) (w 0) h (by omega)
      apply hBad (boundB4 _ hw z hF q hq _)
      simp [h2,h3]
      nlinarith only [hb,Nat.cast_nonneg (α:=ℝ) (w 1),Nat.cast_nonneg (α:=ℝ) (w 0)]
    · have hb := hBudget (w 1) (w 4) h (by omega)
      apply hBad (boundB0 _ hw z hF q hq _)
      simp [h2]
      nlinarith only [hb,Nat.cast_nonneg (α:=ℝ) (w 1),Nat.cast_nonneg (α:=ℝ) (w 4)]
  · by_cases hL : w 0≤w 1
    · have hb := hBudget (w 4) (w 0) h (by omega)
      apply hBad (boundB1 _ hw z hF q hq _)
      simp [h3]
      nlinarith only [hb,Nat.cast_nonneg (α:=ℝ) (w 4),Nat.cast_nonneg (α:=ℝ) (w 0)]
    · have hb := hBudget (w 4) (w 1) h (by omega)
      apply hBad (boundB0 _ hw z hF q hq _)
      simp [h2]
      nlinarith only [hb,Nat.cast_nonneg (α:=ℝ) (w 4),Nat.cast_nonneg (α:=ℝ) (w 1)]

#print axioms bull_huge_excluded
end PawBullPrincipal


namespace PawLargestFence

def poly (e f g x : ℝ) : ℝ := x^4-e*x^2-f*x+g

theorem eval_pos_of_shift_coeff_nonneg (e f g q x : ℝ) (hx : q < x)
    (hq : 0≤q)
    (h₀ : 0≤ poly e f g q)
    (h₁ : 0≤4*q^3-2*e*q-f)
    (h₂ : 0≤6*q*q-e) :
    0<poly e f g x := by
  have h : 0<x-q := sub_pos.mpr hx
  have he : poly e f g x = (x-q)^4 + (4*q)*(x-q)^3 +
      (6*q*q-e)*(x-q)^2 + (4*q^3-2*e*q-f)*(x-q) + poly e f g q := by
    unfold poly
    ring
  rw [he]
  have h₄ : 0<(x-q)^4 := pow_pos h 4
  have h₃ : 0≤(4*q)*(x-q)^3 := mul_nonneg (by positivity) (by positivity)
  have hh₂ : 0≤(6*q*q-e)*(x-q)^2 := mul_nonneg h₂ (sq_nonneg _)
  have hh₁ : 0≤(4*q^3-2*e*q-f)*(x-q) := mul_nonneg h₁ h.le
  linarith

theorem poly_mono_product (a t r q p P : ℝ)
    (ha : 0≤a) (ht : t≤2*q) (hp : p≤P) :
    poly (a*(r+t)+P) (2*a*P) (a*t*P) q ≤ poly (a*(r+t)+p) (2*a*p) (a*t*p) q := by
  have hq2 : 0≤q^2 := sq_nonneg q
  have hd : 0≤a*(2*q-t) := mul_nonneg ha (sub_nonneg.mpr ht)
  have h := mul_nonneg (add_nonneg hq2 hd) (sub_nonneg.mpr hp)
  unfold poly
  nlinarith only [h]

#print axioms eval_pos_of_shift_coeff_nonneg
#print axioms poly_mono_product
end PawLargestFence



namespace HouseButterflyFinite

def valid (n : Nat) (e f g : Int) : Bool :=
  let u : Int := 100*(n:Int)-41
  let v : Int := 50
  decide (0≤u^4-e*u^2*v^2-f*u*v^3+g*v^4) &&
    decide (0≤4*u^3-2*e*u*v^2-f*v^3) &&
    decide (0≤6*u^2-e*v^2)

def house (n a d e : Nat) : Bool :=
  let A : Int := a
  let D : Int := d
  let E : Int := e
  valid n (A+A*D+A*E+1+E+D*E) (2*A*D*E) (A*D+2*A*D*E+D*E)

def butterfly (n a b c : Nat) : Bool :=
  let A : Int := a
  let B : Int := b
  let C : Int := c
  valid n (A*B+A+A*C+B+B*C) (2*A*B*C) (A*B+2*A*B*C)

def checkHouse (n : Nat) : Bool :=
  (List.range 2).all fun dd =>
   let d := dd+1
   (List.range (3*n-d-3)).all fun aa =>
    let a := aa+1
    (List.range (3*n-d-a-2)).all fun ee => house n a d (ee+1)

def checkButterfly (n : Nat) : Bool :=
  (List.range (3*n-4)).all fun aa =>
   let a := aa+1
   (List.range (3*n-a-3)).all fun bb =>
    let b := bb+1
    let nC := 3*n-a-b-2
    (List.range (if 3<a ∧ 3<b then min 3 nC else nC)).all fun cc =>
     butterfly n a b (cc+1)

set_option maxRecDepth 10000
set_option maxHeartbeats 0
theorem checkedHouse3 : checkHouse 3=true := by decide +kernel
theorem checkedHouse4 : checkHouse 4=true := by decide +kernel
theorem checkedHouse5 : checkHouse 5=true := by decide +kernel
theorem checkedHouse6 : checkHouse 6=true := by decide +kernel
theorem checkedButterfly3 : checkButterfly 3=true := by decide +kernel
theorem checkedButterfly4 : checkButterfly 4=true := by decide +kernel
theorem checkedButterfly5 : checkButterfly 5=true := by decide +kernel
theorem checkedButterfly6 : checkButterfly 6=true := by decide +kernel
theorem checkedButterfly7 : checkButterfly 7=true := by decide +kernel
theorem allHouse (n : Nat) (hn : 3≤n) (hN : n≤6) : checkHouse n=true := by
  have h : n=3 ∨ n=4 ∨ n=5 ∨ n=6 := by omega
  rcases h with rfl | rfl | rfl | rfl
  · exact checkedHouse3
  · exact checkedHouse4
  · exact checkedHouse5
  · exact checkedHouse6

theorem allButterfly (n : Nat) (hn : 3≤n) (hN : n≤7) : checkButterfly n=true := by
  have h : n=3 ∨ n=4 ∨ n=5 ∨ n=6 ∨ n=7 := by omega
  rcases h with rfl | rfl | rfl | rfl | rfl
  · exact checkedButterfly3
  · exact checkedButterfly4
  · exact checkedButterfly5
  · exact checkedButterfly6
  · exact checkedButterfly7

theorem house_valid (n a d e : Nat) (hn : 3≤n) (hN : n≤6)
    (ha : 0<a) (hd : 0<d) (hD : d≤2) (he : 0<e) (hSum : a+d+e+2≤3*n) :
    house n a d e=true := by
  have H := allHouse n hn hN
  unfold checkHouse at H
  have h₁ := List.all_eq_true.mp H (d-1) (List.mem_range.mpr (by omega))
  have hd' : d-1+1=d := by omega
  simp only [hd'] at h₁
  have h₂ := List.all_eq_true.mp h₁ (a-1) (List.mem_range.mpr (by omega))
  have ha' : a-1+1=a := by omega
  simp only [ha'] at h₂
  have h₃ := List.all_eq_true.mp h₂ (e-1) (List.mem_range.mpr (by omega))
  have he' : e-1+1=e := by omega
  simpa only [he'] using h₃

theorem butterfly_valid (n a b c : Nat) (hn : 3≤n) (hN : n≤7)
    (ha : 0<a) (hb : 0<b) (hc : 0<c) (hSum : a+b+c+2≤3*n)
    (hmin : a≤3 ∨ b≤3 ∨ c≤3) : butterfly n a b c=true := by
  have H := allButterfly n hn hN
  unfold checkButterfly at H
  have h₁ := List.all_eq_true.mp H (a-1) (List.mem_range.mpr (by omega))
  have ha' : a-1+1=a := by omega
  simp only [ha'] at h₁
  have h₂ := List.all_eq_true.mp h₁ (b-1) (List.mem_range.mpr (by omega))
  have hb' : b-1+1=b := by omega
  simp only [hb'] at h₂
  have hlim : c-1 < (if 3<a ∧ 3<b then min 3 (3*n-a-b-2) else 3*n-a-b-2) := by
    split <;> omega
  have h₃ := List.all_eq_true.mp h₂ (c-1) (List.mem_range.mpr hlim)
  have hc' : c-1+1=c := by omega
  simpa only [hc'] using h₃

#print axioms house_valid
#print axioms butterfly_valid
end HouseButterflyFinite

set_option maxHeartbeats 1000000

namespace HouseButterflyFence
open Matrix SpectralConjecture20
open scoped BigOperators Matrix

theorem real_coeff_of_valid (n : Nat) (e f g : Int)
    (h : HouseButterflyFinite.valid n e f g=true) :
    let q : ℝ := (100*(n:ℝ)-41)/50
    0≤PawLargestFence.poly e f g q ∧ 0≤4*q^3-2*(e:ℝ)*q-(f:ℝ) ∧ 0≤6*q*q-(e:ℝ) := by

  let u : Int := 100*(n:Int)-41
  let v : Int := 50
  change (decide (0≤u^4-e*u^2*v^2-f*u*v^3+g*v^4) &&
    decide (0≤4*u^3-2*e*u*v^2-f*v^3) &&
    decide (0≤6*u^2-e*v^2)) = true at h
  rw [Bool.and_eq_true, Bool.and_eq_true] at h
  have h₀ : 0≤(u:ℝ)^4-(e:ℝ)*(u:ℝ)^2*(v:ℝ)^2-(f:ℝ)*(u:ℝ)*(v:ℝ)^3+(g:ℝ)*(v:ℝ)^4 := by
    exact_mod_cast of_decide_eq_true h.1.1
  have h₁ : 0≤4*(u:ℝ)^3-2*(e:ℝ)*(u:ℝ)*(v:ℝ)^2-(f:ℝ)*(v:ℝ)^3 := by
    exact_mod_cast of_decide_eq_true h.1.2
  have h₂ : 0≤6*(u:ℝ)^2-(e:ℝ)*(v:ℝ)^2 := by
    exact_mod_cast of_decide_eq_true h.2
  dsimp [u,v] at h₀ h₁ h₂
  push_cast at h₀ h₁ h₂
  dsimp [PawLargestFence.poly]
  exact ⟨by nlinarith only [h₀], by nlinarith only [h₁], by nlinarith only [h₂]⟩

theorem full_eigen_le_of_det_factor {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (hB : B.IsHermitian) (w : m → Nat) (hw : ∀ j, 0<w j)
    (z : Nat) (hFull : (withIsolates B w z).IsHermitian)
    (e f g q : ℝ) (hq : 0≤q)
    (h₀ : 0≤PawLargestFence.poly e f g q)
    (h₁ : 0≤4*q^3-2*e*q-f) (h₂ : 0≤6*q*q-e)
    (hD : ∀ x : ℝ, (Matrix.scalar _ x-weightedQuotient B w).det =
      x*PawLargestFence.poly e f g x)
    (i : Fin (Fintype.card (Vertices w ⊕ Fin z))) :
    hFull.eigenvalues₀ i≤q := by
  let hQ := weightedQuotient_isHermitian B hB w
  have hBound (j : m) : hQ.eigenvalues j≤q := by
    by_contra! hh
    have he : (weightedQuotient B w).charpoly.eval (hQ.eigenvalues j) = 0 := by
      rw [hQ.charpoly_eq,Polynomial.eval_prod]
      apply Finset.prod_eq_zero (Finset.mem_univ j)
      simp
    rw [Matrix.eval_charpoly,hD] at he
    have hp := PawLargestFence.eval_pos_of_shift_coeff_nonneg e f g q _ hh hq h₀ h₁ h₂
    have hh0 : 0<hQ.eigenvalues j := hq.trans_lt hh
    exact (mul_pos hh0 hp).ne' he
  have hCard : Fintype.card {j // q < hQ.eigenvalues j}=0 := by
    apply Fintype.card_eq_zero_iff.mpr
    exact ⟨fun j => (hBound j.val).not_gt j.property⟩
  have he := withIsolates_ordered_cut_count B hB w hw z hFull 1 q hq
  simp only [one_mul,hCard] at he
  by_contra! h
  exact (Fintype.card_eq_zero_iff.mp he).false ⟨i,h⟩

#print axioms full_eigen_le_of_det_factor


def house : Matrix (Fin 5) (Fin 5) ℝ := !![0,1,0,1,1;1,0,1,0,0;0,1,0,0,1;1,0,0,0,1;1,0,1,1,0]
theorem house_herm : house.IsHermitian := by
  rw [Matrix.IsHermitian.ext_iff]
  intro i j
  fin_cases i <;> fin_cases j <;> rfl

def houseW (a d e : Nat) : Fin 5 → Nat := ![a,1,1,d,e]
def houseQ (a d e : ℝ) : Matrix (Fin 5) (Fin 5) ℝ := !![0,a*1,0,a*d,a*e;1*a,0,1*1,0,0;0,1*1,0,0,1*e;d*a,0,0,0,d*e;e*a,0,e*1,e*d,0]
theorem house_quotient (a d e : Nat) :
    weightedQuotient house (houseW a d e) = houseQ (Real.sqrt a) (Real.sqrt d) (Real.sqrt e) := by
  ext i j
  simp [weightedQuotient,sqrtWeights]
  fin_cases i <;> fin_cases j <;> simp [house,houseW,houseQ]

set_option linter.unusedSimpArgs false in
theorem det_house_Q (a d e x : ℝ) :
    (Matrix.scalar (Fin 5) x - houseQ a d e).det =
      x * PawLargestFence.poly (a^2+a^2*d^2+a^2*e^2+1+e^2+d^2*e^2) (2*a^2*d^2*e^2)
        (a^2*d^2+2*a^2*d^2*e^2+d^2*e^2) x := by
  unfold houseQ PawLargestFence.poly
  have s00 : ((0 : Fin 5).succAbove (0 : Fin 4)) = (1 : Fin 5) := by decide
  have s01 : ((0 : Fin 5).succAbove (1 : Fin 4)) = (2 : Fin 5) := by decide
  have s02 : ((0 : Fin 5).succAbove (2 : Fin 4)) = (3 : Fin 5) := by decide
  have s03 : ((0 : Fin 5).succAbove (3 : Fin 4)) = (4 : Fin 5) := by decide
  have s10 : ((1 : Fin 5).succAbove (0 : Fin 4)) = (0 : Fin 5) := by decide
  have s11 : ((1 : Fin 5).succAbove (1 : Fin 4)) = (2 : Fin 5) := by decide
  have s12 : ((1 : Fin 5).succAbove (2 : Fin 4)) = (3 : Fin 5) := by decide
  have s13 : ((1 : Fin 5).succAbove (3 : Fin 4)) = (4 : Fin 5) := by decide
  have s20 : ((2 : Fin 5).succAbove (0 : Fin 4)) = (0 : Fin 5) := by decide
  have s21 : ((2 : Fin 5).succAbove (1 : Fin 4)) = (1 : Fin 5) := by decide
  have s22 : ((2 : Fin 5).succAbove (2 : Fin 4)) = (3 : Fin 5) := by decide
  have s23 : ((2 : Fin 5).succAbove (3 : Fin 4)) = (4 : Fin 5) := by decide
  have s30 : ((3 : Fin 5).succAbove (0 : Fin 4)) = (0 : Fin 5) := by decide
  have s31 : ((3 : Fin 5).succAbove (1 : Fin 4)) = (1 : Fin 5) := by decide
  have s32 : ((3 : Fin 5).succAbove (2 : Fin 4)) = (2 : Fin 5) := by decide
  have s33 : ((3 : Fin 5).succAbove (3 : Fin 4)) = (4 : Fin 5) := by decide
  have s40 : ((4 : Fin 5).succAbove (0 : Fin 4)) = (0 : Fin 5) := by decide
  have s41 : ((4 : Fin 5).succAbove (1 : Fin 4)) = (1 : Fin 5) := by decide
  have s42 : ((4 : Fin 5).succAbove (2 : Fin 4)) = (2 : Fin 5) := by decide
  have s43 : ((4 : Fin 5).succAbove (3 : Fin 4)) = (3 : Fin 5) := by decide
  have p200 : ((0 : Fin 2).succAbove (0 : Fin 1)) = (1 : Fin 2) := by decide
  have p210 : ((1 : Fin 2).succAbove (0 : Fin 1)) = (0 : Fin 2) := by decide
  have q20 : (0:Fin 2).succ = (1:Fin 3) := by decide
  have q21 : (1:Fin 2).succ = (2:Fin 3) := by decide
  have p300 : ((0 : Fin 3).succAbove (0 : Fin 2)) = (1 : Fin 3) := by decide
  have p301 : ((0 : Fin 3).succAbove (1 : Fin 2)) = (2 : Fin 3) := by decide
  have p310 : ((1 : Fin 3).succAbove (0 : Fin 2)) = (0 : Fin 3) := by decide
  have p311 : ((1 : Fin 3).succAbove (1 : Fin 2)) = (2 : Fin 3) := by decide
  have p320 : ((2 : Fin 3).succAbove (0 : Fin 2)) = (0 : Fin 3) := by decide
  have p321 : ((2 : Fin 3).succAbove (1 : Fin 2)) = (1 : Fin 3) := by decide
  have q30 : (0:Fin 3).succ = (1:Fin 4) := by decide
  have q31 : (1:Fin 3).succ = (2:Fin 4) := by decide
  have q32 : (2:Fin 3).succ = (3:Fin 4) := by decide
  have p400 : ((0 : Fin 4).succAbove (0 : Fin 3)) = (1 : Fin 4) := by decide
  have p401 : ((0 : Fin 4).succAbove (1 : Fin 3)) = (2 : Fin 4) := by decide
  have p402 : ((0 : Fin 4).succAbove (2 : Fin 3)) = (3 : Fin 4) := by decide
  have p410 : ((1 : Fin 4).succAbove (0 : Fin 3)) = (0 : Fin 4) := by decide
  have p411 : ((1 : Fin 4).succAbove (1 : Fin 3)) = (2 : Fin 4) := by decide
  have p412 : ((1 : Fin 4).succAbove (2 : Fin 3)) = (3 : Fin 4) := by decide
  have p420 : ((2 : Fin 4).succAbove (0 : Fin 3)) = (0 : Fin 4) := by decide
  have p421 : ((2 : Fin 4).succAbove (1 : Fin 3)) = (1 : Fin 4) := by decide
  have p422 : ((2 : Fin 4).succAbove (2 : Fin 3)) = (3 : Fin 4) := by decide
  have p430 : ((3 : Fin 4).succAbove (0 : Fin 3)) = (0 : Fin 4) := by decide
  have p431 : ((3 : Fin 4).succAbove (1 : Fin 3)) = (1 : Fin 4) := by decide
  have p432 : ((3 : Fin 4).succAbove (2 : Fin 3)) = (2 : Fin 4) := by decide
  have q40 : (0:Fin 4).succ = (1:Fin 5) := by decide
  have q41 : (1:Fin 4).succ = (2:Fin 5) := by decide
  have q42 : (2:Fin 4).succ = (3:Fin 5) := by decide
  have q43 : (3:Fin 4).succ = (4:Fin 5) := by decide
  simp [Matrix.det_succ_row_zero, Fin.sum_univ_succ, Matrix.sub_apply, Matrix.scalar_apply,
    Matrix.submatrix_apply, Matrix.diagonal_apply, s00, s01, s02, s03, s10, s11, s12, s13, s20, s21, s22, s23, s30, s31, s32, s33, s40, s41, s42, s43, p200, p210, q20, q21, p300, p301, p310, p311, p320, p321, q30, q31, q32, p400, p401, p402, p410, p411, p412, p420, p421, p422, p430, p431, p432, q40, q41, q42, q43]
  ring

def butterfly : Matrix (Fin 5) (Fin 5) ℝ := !![0,1,0,1,1;1,0,1,0,1;0,1,0,0,0;1,0,0,0,0;1,1,0,0,0]
theorem butterfly_herm : butterfly.IsHermitian := by
  rw [Matrix.IsHermitian.ext_iff]
  intro i j
  fin_cases i <;> fin_cases j <;> rfl

def butterflyW (a b c : Nat) : Fin 5 → Nat := ![a,b,1,1,c]
def butterflyQ (a b c : ℝ) : Matrix (Fin 5) (Fin 5) ℝ := !![0,a*b,0,a*1,a*c;b*a,0,b*1,0,b*c;0,1*b,0,0,0;1*a,0,0,0,0;c*a,c*b,0,0,0]
theorem butterfly_quotient (a b c : Nat) :
    weightedQuotient butterfly (butterflyW a b c) = butterflyQ (Real.sqrt a) (Real.sqrt b) (Real.sqrt c) := by
  ext i j
  simp [weightedQuotient,sqrtWeights]
  fin_cases i <;> fin_cases j <;> simp [butterfly,butterflyW,butterflyQ]

set_option linter.unusedSimpArgs false in
theorem det_butterfly_Q (a b c x : ℝ) :
    (Matrix.scalar (Fin 5) x - butterflyQ a b c).det =
      x * PawLargestFence.poly (a^2*b^2+a^2+a^2*c^2+b^2+b^2*c^2) (2*a^2*b^2*c^2)
        (a^2*b^2+2*a^2*b^2*c^2) x := by
  unfold butterflyQ PawLargestFence.poly
  have s00 : ((0 : Fin 5).succAbove (0 : Fin 4)) = (1 : Fin 5) := by decide
  have s01 : ((0 : Fin 5).succAbove (1 : Fin 4)) = (2 : Fin 5) := by decide
  have s02 : ((0 : Fin 5).succAbove (2 : Fin 4)) = (3 : Fin 5) := by decide
  have s03 : ((0 : Fin 5).succAbove (3 : Fin 4)) = (4 : Fin 5) := by decide
  have s10 : ((1 : Fin 5).succAbove (0 : Fin 4)) = (0 : Fin 5) := by decide
  have s11 : ((1 : Fin 5).succAbove (1 : Fin 4)) = (2 : Fin 5) := by decide
  have s12 : ((1 : Fin 5).succAbove (2 : Fin 4)) = (3 : Fin 5) := by decide
  have s13 : ((1 : Fin 5).succAbove (3 : Fin 4)) = (4 : Fin 5) := by decide
  have s20 : ((2 : Fin 5).succAbove (0 : Fin 4)) = (0 : Fin 5) := by decide
  have s21 : ((2 : Fin 5).succAbove (1 : Fin 4)) = (1 : Fin 5) := by decide
  have s22 : ((2 : Fin 5).succAbove (2 : Fin 4)) = (3 : Fin 5) := by decide
  have s23 : ((2 : Fin 5).succAbove (3 : Fin 4)) = (4 : Fin 5) := by decide
  have s30 : ((3 : Fin 5).succAbove (0 : Fin 4)) = (0 : Fin 5) := by decide
  have s31 : ((3 : Fin 5).succAbove (1 : Fin 4)) = (1 : Fin 5) := by decide
  have s32 : ((3 : Fin 5).succAbove (2 : Fin 4)) = (2 : Fin 5) := by decide
  have s33 : ((3 : Fin 5).succAbove (3 : Fin 4)) = (4 : Fin 5) := by decide
  have s40 : ((4 : Fin 5).succAbove (0 : Fin 4)) = (0 : Fin 5) := by decide
  have s41 : ((4 : Fin 5).succAbove (1 : Fin 4)) = (1 : Fin 5) := by decide
  have s42 : ((4 : Fin 5).succAbove (2 : Fin 4)) = (2 : Fin 5) := by decide
  have s43 : ((4 : Fin 5).succAbove (3 : Fin 4)) = (3 : Fin 5) := by decide
  have p200 : ((0 : Fin 2).succAbove (0 : Fin 1)) = (1 : Fin 2) := by decide
  have p210 : ((1 : Fin 2).succAbove (0 : Fin 1)) = (0 : Fin 2) := by decide
  have q20 : (0:Fin 2).succ = (1:Fin 3) := by decide
  have q21 : (1:Fin 2).succ = (2:Fin 3) := by decide
  have p300 : ((0 : Fin 3).succAbove (0 : Fin 2)) = (1 : Fin 3) := by decide
  have p301 : ((0 : Fin 3).succAbove (1 : Fin 2)) = (2 : Fin 3) := by decide
  have p310 : ((1 : Fin 3).succAbove (0 : Fin 2)) = (0 : Fin 3) := by decide
  have p311 : ((1 : Fin 3).succAbove (1 : Fin 2)) = (2 : Fin 3) := by decide
  have p320 : ((2 : Fin 3).succAbove (0 : Fin 2)) = (0 : Fin 3) := by decide
  have p321 : ((2 : Fin 3).succAbove (1 : Fin 2)) = (1 : Fin 3) := by decide
  have q30 : (0:Fin 3).succ = (1:Fin 4) := by decide
  have q31 : (1:Fin 3).succ = (2:Fin 4) := by decide
  have q32 : (2:Fin 3).succ = (3:Fin 4) := by decide
  have p400 : ((0 : Fin 4).succAbove (0 : Fin 3)) = (1 : Fin 4) := by decide
  have p401 : ((0 : Fin 4).succAbove (1 : Fin 3)) = (2 : Fin 4) := by decide
  have p402 : ((0 : Fin 4).succAbove (2 : Fin 3)) = (3 : Fin 4) := by decide
  have p410 : ((1 : Fin 4).succAbove (0 : Fin 3)) = (0 : Fin 4) := by decide
  have p411 : ((1 : Fin 4).succAbove (1 : Fin 3)) = (2 : Fin 4) := by decide
  have p412 : ((1 : Fin 4).succAbove (2 : Fin 3)) = (3 : Fin 4) := by decide
  have p420 : ((2 : Fin 4).succAbove (0 : Fin 3)) = (0 : Fin 4) := by decide
  have p421 : ((2 : Fin 4).succAbove (1 : Fin 3)) = (1 : Fin 4) := by decide
  have p422 : ((2 : Fin 4).succAbove (2 : Fin 3)) = (3 : Fin 4) := by decide
  have p430 : ((3 : Fin 4).succAbove (0 : Fin 3)) = (0 : Fin 4) := by decide
  have p431 : ((3 : Fin 4).succAbove (1 : Fin 3)) = (1 : Fin 4) := by decide
  have p432 : ((3 : Fin 4).succAbove (2 : Fin 3)) = (2 : Fin 4) := by decide
  have q40 : (0:Fin 4).succ = (1:Fin 5) := by decide
  have q41 : (1:Fin 4).succ = (2:Fin 5) := by decide
  have q42 : (2:Fin 4).succ = (3:Fin 5) := by decide
  have q43 : (3:Fin 4).succ = (4:Fin 5) := by decide
  simp [Matrix.det_succ_row_zero, Fin.sum_univ_succ, Matrix.sub_apply, Matrix.scalar_apply,
    Matrix.submatrix_apply, Matrix.diagonal_apply, s00, s01, s02, s03, s10, s11, s12, s13, s20, s21, s22, s23, s30, s31, s32, s33, s40, s41, s42, s43, p200, p210, q20, q21, p300, p301, p310, p311, p320, p321, q30, q31, q32, p400, p401, p402, p410, p411, p412, p420, p421, p422, p430, p431, p432, q40, q41, q42, q43]
  ring


theorem weighted_house_bounded_fence (n a d e z : Nat) (hn : 3≤n)
    (hN : n≤6) (ha : 0<a) (hd : 0<d) (hD : d≤2) (he : 0<e) (hSum : a+d+e+2≤3*n)
    (hFull : (withIsolates house (houseW a d e) z).IsHermitian)
    (i : Fin (Fintype.card (Vertices (houseW a d e) ⊕ Fin z))) :
    hFull.eigenvalues₀ i ≤ (100*(n:ℝ)-41)/50 := by
  have hV := HouseButterflyFinite.house_valid n a d e hn hN ha hd hD he hSum
  change HouseButterflyFinite.valid n ((a:Int)+(a:Int)*(d:Int)+(a:Int)*(e:Int)+1+(e:Int)+(d:Int)*(e:Int)) (2*(a:Int)*(d:Int)*(e:Int)) ((a:Int)*(d:Int)+2*(a:Int)*(d:Int)*(e:Int)+(d:Int)*(e:Int)) = true at hV
  obtain ⟨h₀,h₁,h₂⟩ := real_coeff_of_valid n _ _ _ hV
  push_cast at h₀ h₁ h₂
  have hnr : (3:ℝ)≤n := by exact_mod_cast hn
  have hw (j : Fin 5) : 0<houseW a d e j := by
    fin_cases j <;> simp [houseW] <;> omega
  apply full_eigen_le_of_det_factor house house_herm _ hw z hFull ((a:ℝ)+(a:ℝ)*(d:ℝ)+(a:ℝ)*(e:ℝ)+1+(e:ℝ)+(d:ℝ)*(e:ℝ)) (2*(a:ℝ)*(d:ℝ)*(e:ℝ)) ((a:ℝ)*(d:ℝ)+2*(a:ℝ)*(d:ℝ)*(e:ℝ)+(d:ℝ)*(e:ℝ)) _ (by linarith) h₀ h₁ h₂ _ i
  intro x
  rw [house_quotient,det_house_Q]
  simp only [Real.sq_sqrt (Nat.cast_nonneg _)]
#print axioms weighted_house_bounded_fence

theorem weighted_butterfly_bounded_fence (n a b c z : Nat) (hn : 3≤n)
    (hN : n≤7) (ha : 0<a) (hb : 0<b) (hc : 0<c) (hSum : a+b+c+2≤3*n) (hmin : a≤3 ∨ b≤3 ∨ c≤3)
    (hFull : (withIsolates butterfly (butterflyW a b c) z).IsHermitian)
    (i : Fin (Fintype.card (Vertices (butterflyW a b c) ⊕ Fin z))) :
    hFull.eigenvalues₀ i ≤ (100*(n:ℝ)-41)/50 := by
  have hV := HouseButterflyFinite.butterfly_valid n a b c hn hN ha hb hc hSum hmin
  change HouseButterflyFinite.valid n ((a:Int)*(b:Int)+(a:Int)+(a:Int)*(c:Int)+(b:Int)+(b:Int)*(c:Int)) (2*(a:Int)*(b:Int)*(c:Int)) ((a:Int)*(b:Int)+2*(a:Int)*(b:Int)*(c:Int)) = true at hV
  obtain ⟨h₀,h₁,h₂⟩ := real_coeff_of_valid n _ _ _ hV
  push_cast at h₀ h₁ h₂
  have hnr : (3:ℝ)≤n := by exact_mod_cast hn
  have hw (j : Fin 5) : 0<butterflyW a b c j := by
    fin_cases j <;> simp [butterflyW] <;> omega
  apply full_eigen_le_of_det_factor butterfly butterfly_herm _ hw z hFull ((a:ℝ)*(b:ℝ)+(a:ℝ)+(a:ℝ)*(c:ℝ)+(b:ℝ)+(b:ℝ)*(c:ℝ)) (2*(a:ℝ)*(b:ℝ)*(c:ℝ)) ((a:ℝ)*(b:ℝ)+2*(a:ℝ)*(b:ℝ)*(c:ℝ)) _ (by linarith) h₀ h₁ h₂ _ i
  intro x
  rw [butterfly_quotient,det_butterfly_Q]
  simp only [Real.sq_sqrt (Nat.cast_nonneg _)]
#print axioms weighted_butterfly_bounded_fence

end HouseButterflyFence




namespace PawLargestFence
open Matrix
open scoped Matrix

def pawQ (a b c t : ℝ) : Matrix (Fin 4) (Fin 4) ℝ :=
  !![0,a*b,a*c,a*t;
     a*b,0,b*c,0;
     a*c,b*c,0,0;
     a*t,0,0,0]

def pawE (a b c t : ℝ) := a*b+a*c+b*c+a*t
def pawF (a b c : ℝ) := 2*a*b*c
def pawG (a b c t : ℝ) := a*b*c*t

theorem det_paw (a b c t x : ℝ) :
    (Matrix.scalar (Fin 4) x - pawQ a b c t).det =
      poly (pawE (a*a) (b*b) (c*c) (t*t)) (pawF (a*a) (b*b) (c*c))
        (pawG (a*a) (b*b) (c*c) (t*t)) x := by
  unfold pawQ pawE pawF pawG poly
  have _s00 : ((0 : Fin 4).succAbove (0 : Fin 3)) = (1 : Fin 4) := by decide
  have s01 : ((0 : Fin 4).succAbove (1 : Fin 3)) = (2 : Fin 4) := by decide
  have s02 : ((0 : Fin 4).succAbove (2 : Fin 3)) = (3 : Fin 4) := by decide
  have s12 : ((1 : Fin 4).succAbove (2 : Fin 3)) = (3 : Fin 4) := by decide
  have s22 : ((2 : Fin 4).succAbove (2 : Fin 3)) = (3 : Fin 4) := by decide
  have s32 : ((3 : Fin 4).succAbove (2 : Fin 3)) = (2 : Fin 4) := by decide
  simp [Matrix.det_succ_row_zero, Fin.sum_univ_succ, Matrix.sub_apply,
    Matrix.scalar_apply, Matrix.submatrix_apply, Matrix.diagonal_apply, _s00, s01, s02, s12, s22, s32]
  ring

theorem paw_eigen_le (a b c t q : ℝ) (hQ : (pawQ a b c t).IsHermitian)
    (hq : 0≤q)
    (h₀ : 0≤ poly (pawE (a*a) (b*b) (c*c) (t*t)) (pawF (a*a) (b*b) (c*c)) (pawG (a*a) (b*b) (c*c) (t*t)) q)
    (h₁ : 0≤4*q^3-2*(pawE (a*a) (b*b) (c*c) (t*t))*q-(pawF (a*a) (b*b) (c*c)))
    (h₂ : 0≤6*q*q-(pawE (a*a) (b*b) (c*c) (t*t)))
    (i : Fin 4) : hQ.eigenvalues i ≤ q := by
  by_contra! h
  have he : (pawQ a b c t).charpoly.eval (hQ.eigenvalues i) = 0 := by
    rw [hQ.charpoly_eq, Polynomial.eval_prod]
    apply Finset.prod_eq_zero (Finset.mem_univ i)
    simp
  rw [Matrix.eval_charpoly,det_paw] at he
  have hp := eval_pos_of_shift_coeff_nonneg _ _ _ q _ h hq h₀ h₁ h₂
  linarith
#print axioms paw_eigen_le
end PawLargestFence





namespace PawLargestFinite

def valid (n a b c t : Nat) : Bool :=
  let u : Int := 100*(n:Int)-41
  let v : Int := 50
  let A : Int := a
  let B : Int := b
  let C : Int := c
  let T : Int := t
  let e := A*B+A*C+B*C+A*T
  let f := 2*A*B*C
  let g := A*B*C*T
  decide (0≤u^4-e*u^2*v^2-f*u*v^3+g*v^4) &&
    decide (0≤4*u^3-2*e*u*v^2-f*v^3) &&
    decide (0≤6*u^2-e*v^2)

def check (n : Nat) : Bool :=
  (List.range 9).all fun tt =>
   let t := tt+2
   (List.range 2).all fun z =>
    let m := 3*n-t-z
    (List.range (m-2)).all fun aa =>
     let a := aa+1
     let r := m-a
     let b := if a>6 then min 6 (r/2) else r/2
     valid n a b (r-b) t

set_option maxRecDepth 10000
set_option maxHeartbeats 0

theorem checked_3 : check 3 = true := by decide +kernel
theorem checked_4 : check 4 = true := by decide +kernel
theorem checked_5 : check 5 = true := by decide +kernel
theorem checked_6 : check 6 = true := by decide +kernel
theorem checked_7 : check 7 = true := by decide +kernel
theorem checked_8 : check 8 = true := by decide +kernel
theorem checked_9 : check 9 = true := by decide +kernel
theorem checked_10 : check 10 = true := by decide +kernel
theorem checked_11 : check 11 = true := by decide +kernel
theorem checked_12 : check 12 = true := by decide +kernel
theorem checked_13 : check 13 = true := by decide +kernel
theorem checked_14 : check 14 = true := by decide +kernel
theorem checked_15 : check 15 = true := by decide +kernel
theorem checked_16 : check 16 = true := by decide +kernel
theorem checked_17 : check 17 = true := by decide +kernel
theorem checked_18 : check 18 = true := by decide +kernel
theorem checked_19 : check 19 = true := by decide +kernel
theorem checked_20 : check 20 = true := by decide +kernel
theorem checked_21 : check 21 = true := by decide +kernel
theorem checked_22 : check 22 = true := by decide +kernel
theorem checked_23 : check 23 = true := by decide +kernel
theorem checked_24 : check 24 = true := by decide +kernel
theorem checked_25 : check 25 = true := by decide +kernel
theorem checked_26 : check 26 = true := by decide +kernel
theorem checked_27 : check 27 = true := by decide +kernel

theorem all_checked (n : Nat) (hn : 3≤n) (hN : n≤27) : check n = true := by
  have cases : n=3 ∨ n=4 ∨ n=5 ∨ n=6 ∨ n=7 ∨ n=8 ∨ n=9 ∨ n=10 ∨ n=11 ∨ n=12 ∨ n=13 ∨ n=14 ∨ n=15 ∨ n=16 ∨ n=17 ∨ n=18 ∨ n=19 ∨ n=20 ∨ n=21 ∨ n=22 ∨ n=23 ∨ n=24 ∨ n=25 ∨ n=26 ∨ n=27 := by omega
  rcases cases with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact checked_3
  · exact checked_4
  · exact checked_5
  · exact checked_6
  · exact checked_7
  · exact checked_8
  · exact checked_9
  · exact checked_10
  · exact checked_11
  · exact checked_12
  · exact checked_13
  · exact checked_14
  · exact checked_15
  · exact checked_16
  · exact checked_17
  · exact checked_18
  · exact checked_19
  · exact checked_20
  · exact checked_21
  · exact checked_22
  · exact checked_23
  · exact checked_24
  · exact checked_25
  · exact checked_26
  · exact checked_27

#print axioms all_checked
end PawLargestFinite

namespace PawLargestFinite

theorem valid_at_balanced (n a b c t z : Nat) (hn : 3≤n) (hN : n≤27)
    (ha : 0<a) (hb : 0<b) (_hbc : b≤c) (ht : 2≤t) (hT : t≤10) (hz : z≤1)
    (hSum : a+b+c+t+z=3*n) (_hmin : a≤6 ∨ b≤6) :
    let B := if a>6 then min 6 ((b+c)/2) else (b+c)/2
    valid n a B (b+c-B) t = true := by
  have h := all_checked n hn hN
  unfold check at h
  have h1 := List.all_eq_true.mp h (t-2) (List.mem_range.mpr (by omega))
  have ht' : t-2+2=t := by omega
  simp only [ht'] at h1
  have h2 := List.all_eq_true.mp h1 z (List.mem_range.mpr (by omega))
  let m := 3*n-t-z
  have hm : m=a+b+c := by omega
  change (List.range (m-2)).all _ = true at h2
  have h3 := List.all_eq_true.mp h2 (a-1) (List.mem_range.mpr (by omega))
  have ha' : a-1+1=a := by omega
  simp only [ha'] at h3
  have hr : m-a=b+c := by omega

  change (let B := if a>6 then min 6 ((m-a)/2) else (m-a)/2
          valid n a B (m-a-B) t) = true at h3
  simpa only [hr] using h3

#print axioms valid_at_balanced
end PawLargestFinite


namespace PawLargestFence
open PawLargestFinite

theorem real_coeff_of_valid (n a b c t : Nat) (h : valid n a b c t=true) :
    let q : ℝ := (100*(n:ℝ)-41)/50
    let e := pawE a b c t
    let f := pawF a b c
    let g := pawG a b c t
    0≤poly e f g q ∧ 0≤4*q^3-2*e*q-f ∧ 0≤6*q*q-e := by
  let u : Int := 100*(n:Int)-41
  let v : Int := 50
  let e : Int := (a:Int)*b+(a:Int)*c+(b:Int)*c+(a:Int)*t
  let f : Int := 2*(a:Int)*b*c
  let g : Int := (a:Int)*b*c*t
  change (decide (0≤u^4-e*u^2*v^2-f*u*v^3+g*v^4) &&
    decide (0≤4*u^3-2*e*u*v^2-f*v^3) &&
    decide (0≤6*u^2-e*v^2)) = true at h
  rw [Bool.and_eq_true, Bool.and_eq_true] at h
  have h₀ : 0≤(u:ℝ)^4-(e:ℝ)*(u:ℝ)^2*(v:ℝ)^2-(f:ℝ)*(u:ℝ)*(v:ℝ)^3+(g:ℝ)*(v:ℝ)^4 := by
    exact_mod_cast of_decide_eq_true h.1.1
  have h₁ : 0≤4*(u:ℝ)^3-2*(e:ℝ)*(u:ℝ)*(v:ℝ)^2-(f:ℝ)*(v:ℝ)^3 := by
    exact_mod_cast of_decide_eq_true h.1.2
  have h₂ : 0≤6*(u:ℝ)^2-(e:ℝ)*(v:ℝ)^2 := by
    exact_mod_cast of_decide_eq_true h.2
  dsimp [u,v,e,f,g] at h₀ h₁ h₂
  push_cast at h₀ h₁ h₂
  dsimp [poly,pawE,pawF,pawG]
  exact ⟨by nlinarith only [h₀], by nlinarith only [h₁], by nlinarith only [h₂]⟩

theorem paw_eigen_le_of_valid (n a b c t : Nat) (hn : 3≤n)
    (h : valid n a b c t=true)
    (hQ : (pawQ (Real.sqrt a) (Real.sqrt b) (Real.sqrt c) (Real.sqrt t)).IsHermitian)
    (i : Fin 4) : hQ.eigenvalues i ≤ (100*(n:ℝ)-41)/50 := by
  have hnr : (3:ℝ)≤n := by exact_mod_cast hn
  obtain ⟨h₀,h₁,h₂⟩ := real_coeff_of_valid n a b c t h
  apply paw_eigen_le _ _ _ _ _ hQ (by linarith) _ _ _ i
  all_goals
    simp only [← pow_two,Real.sq_sqrt (Nat.cast_nonneg _)]
    assumption
#print axioms paw_eigen_le_of_valid
end PawLargestFence


namespace PawLargestFence

theorem real_coeff_of_balanced (n a b c t : Nat) (hn : 3≤n) (ht : t≤10)
    (hbc : b≤c) (hmin : a≤6 ∨ b≤6)
    (h : let B := if a>6 then min 6 ((b+c)/2) else (b+c)/2
      PawLargestFinite.valid n a B (b+c-B) t=true) :
    let q : ℝ := (100*(n:ℝ)-41)/50
    let e := pawE a b c t
    let f := pawF a b c
    let g := pawG a b c t
    0≤poly e f g q ∧ 0≤4*q^3-2*e*q-f ∧ 0≤6*q*q-e := by
  let B := if a>6 then min 6 ((b+c)/2) else (b+c)/2
  let C := b+c-B
  let q : ℝ := (100*(n:ℝ)-41)/50
  have Bbounds : b≤B ∧ B≤c := by
    dsimp [B]
    split <;> omega
  have hBC : B+C=b+c := by dsimp [C]; omega
  have hB : (b:ℝ)≤B := by exact_mod_cast Bbounds.1
  have hC : (B:ℝ)≤c := by exact_mod_cast Bbounds.2
  have hsum : (B:ℝ)+(C:ℝ)=(b:ℝ)+(c:ℝ) := by exact_mod_cast hBC
  have hp : (b:ℝ)*c ≤ (B:ℝ)*C := by
    have h := mul_nonneg (sub_nonneg.mpr hB) (sub_nonneg.mpr hC)
    nlinarith only [h, congrArg (fun x : ℝ => (B:ℝ)*x) hsum]
  have hnr : (3:ℝ)≤n := by exact_mod_cast hn
  have htr : (t:ℝ)≤10 := by exact_mod_cast ht
  have hq : 0≤q := by dsimp [q]; linarith
  have hT : (t:ℝ)≤2*q := by dsimp [q]; linarith
  have he : pawE a b c t ≤ pawE a B C t := by
    unfold pawE
    nlinarith only [hp,congrArg (fun x : ℝ => (a:ℝ)*x) hsum]
  have hf : pawF a b c ≤ pawF a B C := by
    unfold pawF
    nlinarith only [mul_nonneg (show 0≤(a:ℝ) by positivity) (sub_nonneg.mpr hp)]
  have heq : (a:ℝ)*((b:ℝ)+(c:ℝ)+t)+(b:ℝ)*c = pawE a b c t := by unfold pawE; ring
  have heq' : (a:ℝ)*((b:ℝ)+(c:ℝ)+t)+(B:ℝ)*C = pawE a B C t := by rw [← hsum]; unfold pawE; ring
  have hpoly := poly_mono_product a t ((b:ℝ)+(c:ℝ)) q ((b:ℝ)*c) ((B:ℝ)*C)
    (by positivity) hT hp
  rw [heq,heq'] at hpoly
  have eqF : ∀ b c : ℝ, 2*(a:ℝ)*(b*c)=pawF a b c := by intros; unfold pawF; ring
  have eqG : ∀ b c : ℝ, (a:ℝ)*t*(b*c)=pawG a b c t := by intros; unfold pawG; ring
  simp only [eqF,eqG] at hpoly
  obtain ⟨h₀,h₁,h₂⟩ := real_coeff_of_valid n a B C t h
  change 0≤poly _ _ _ q ∧ 0≤4*q^3-2*pawE a b c t*q-pawF a b c ∧ 0≤6*q*q-pawE a b c t
  change 0≤poly _ _ _ q at h₀
  change 0≤4*q^3-2*pawE a B C t*q-pawF a B C at h₁
  change 0≤6*q*q-pawE a B C t at h₂
  exact ⟨h₀.trans hpoly, by nlinarith only [h₁,hf,mul_nonneg (sub_nonneg.mpr he) hq], by linarith⟩

#print axioms real_coeff_of_balanced
end PawLargestFence


namespace PawLargestFence
open Matrix SpectralConjecture20 PawLargestFinite
open scoped BigOperators Matrix

def paw : Matrix (Fin 4) (Fin 4) ℝ :=
  !![0,1,1,1;1,0,1,0;1,1,0,0;1,0,0,0]
theorem paw_herm : paw.IsHermitian := by
  rw [Matrix.IsHermitian.ext_iff]
  intro i j
  fin_cases i <;> fin_cases j <;> rfl
def pawWeights (a b c t : Nat) : Fin 4 → Nat := ![a,b,c,t]
theorem paw_quotient_explicit (a b c t : Nat) :
    weightedQuotient paw (pawWeights a b c t) = pawQ (Real.sqrt a) (Real.sqrt b) (Real.sqrt c) (Real.sqrt t) := by
  ext i j
  simp [weightedQuotient,sqrtWeights]
  fin_cases i <;> fin_cases j <;> simp [paw,pawWeights,pawQ,mul_comm]

theorem weighted_paw_bounded_fence (n a b c t z : Nat) (hn : 3≤n) (hN : n≤27)
    (ha : 0<a) (hb : 0<b) (hbc : b≤c) (ht : 2≤t) (hT : t≤10) (hz : z≤1)
    (hSum : a+b+c+t+z=3*n) (hmin : a≤6 ∨ b≤6)
    (hFull : (withIsolates paw (pawWeights a b c t) z).IsHermitian)
    (i : Fin (Fintype.card (Vertices (pawWeights a b c t) ⊕ Fin z))) :
    hFull.eigenvalues₀ i ≤ (100*(n:ℝ)-41)/50 := by
  let w := pawWeights a b c t
  let q : ℝ := (100*(n:ℝ)-41)/50
  have hnr : (3:ℝ)≤n := by exact_mod_cast hn
  have hq : 0≤q := by dsimp [q]; linarith
  have hw (j : Fin 4) : 0<w j := by
    dsimp [w,pawWeights]
    fin_cases j <;> simp <;> omega
  let hQ := weightedQuotient_isHermitian paw paw_herm w
  let Q := pawQ (Real.sqrt a) (Real.sqrt b) (Real.sqrt c) (Real.sqrt t)
  have hE : Q.IsHermitian := by
    rw [Matrix.IsHermitian.ext_iff]
    intro i j
    fin_cases i <;> fin_cases j <;> simp [Q,pawQ]
  have hBound (j : Fin 4) : hE.eigenvalues j≤q := by
    obtain ⟨h₀,h₁,h₂⟩ := real_coeff_of_balanced n a b c t hn hT hbc hmin
      (valid_at_balanced n a b c t z hn hN ha hb hbc ht hT hz hSum hmin)
    apply paw_eigen_le _ _ _ _ _ hE hq _ _ _ j
    all_goals
      simp only [← pow_two,Real.sq_sqrt (Nat.cast_nonneg _)]
      assumption
  have hCardE : Fintype.card {j // q < hE.eigenvalues j}=0 := by
    apply Fintype.card_eq_zero_iff.mpr
    exact ⟨fun j => (hBound j.val).not_gt j.property⟩
  have heq := cut_index_of_matrix_eq (paw_quotient_explicit a b c t) hQ hE 1 q
  have hCard : Fintype.card {j // q < hQ.eigenvalues j}=0 := by
    simpa only [one_mul, hCardE] using heq
  have he := withIsolates_ordered_cut_count paw paw_herm w hw z hFull 1 q hq
  simp only [one_mul, hCard] at he
  by_contra! h
  have em := Fintype.card_eq_zero_iff.mp he
  exact em.false ⟨i,h⟩
#print axioms weighted_paw_bounded_fence
end PawLargestFence


namespace PawLargestFence
open scoped BigOperators

theorem squared_discrepancy_of_upper_fence {m : Type*} [Fintype m] (x y : m → ℝ) (n : ℕ)
    (i : m) (hx : x i ≤ (100*(n:ℝ)-41)/50) (hy : 2*(n:ℝ) ≤ y i) :
    (2:ℝ)/3 ≤ ∑ j,(x j-y j)^2 := by
  classical
  have hgap : (41:ℝ)/50 ≤ y i-x i := by linarith
  have hm : ((41:ℝ)/50)^2 ≤ (x i-y i)^2 := by
    have h : 0≤(y i-x i-41/50)*(y i-x i+41/50) :=
      mul_nonneg (by linarith) (by linarith)
    nlinarith only [h]
  have hs := Finset.single_le_sum (s := Finset.univ) (f := fun j => (x j-y j)^2)
    (fun j _ => sq_nonneg (x j-y j)) (Finset.mem_univ i)
  exact (by norm_num : (2:ℝ)/3 ≤ ((41:ℝ)/50)^2).trans (hm.trans hs)

#print axioms squared_discrepancy_of_upper_fence
end PawLargestFence


namespace HouseLarge
open Matrix
theorem padded_eigenvalues_eq {m : Type*} [Fintype m] [DecidableEq m]
    {A B : Matrix m m ℝ} (h : A=B) (hA : A.IsHermitian) (hB : B.IsHermitian) :
    hA.eigenvalues₀ = hB.eigenvalues₀ := by subst B; rfl

end HouseLarge


namespace PawBullPrincipal
open Matrix Finset SpectralConjecture20 WeightedSeedPruning Conj20CutCert
open scoped BigOperators Matrix

theorem bull_raw_exact : BMat=HouseButterflyFence.butterfly := by
  ext i j
  change (entry BRows i j : ℝ)=HouseButterflyFence.butterfly i j
  fin_cases i <;> fin_cases j <;> norm_num [entry,BRows,HouseButterflyFence.butterfly]

theorem all_weighted_bull_excluded (n : Nat) (hn : 3≤n)
    (w : Fin 5 → Nat) (hw : ∀ i,0<w i) (hTotal : (∑ i,w i)≤3*n)
    (z : Nat) (hF : (withIsolates BMat w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hPos : Fintype.card {i // 0<y i}=1)
    (hNeg : Fintype.card {i // y i= -(n:ℝ)}=2)
    (hTop : ∃ i, 2*(n:ℝ)≤y i) :
    (2/3:ℝ)≤∑ i,(hF.eigenvalues₀ i-y i)^2 := by
  by_cases hN : 8≤n
  · exact bull_huge_excluded n hN w hw hTotal z hF y hPos hNeg
  by_contra! hC
  obtain ⟨h2,h3,hmin⟩ := bull_close_leaf_singletons n hn w hw z hF y hPos hNeg hC
  let a := w 0
  let b := w 1
  let c := w 4
  have hS : a+b+c+2≤3*n := by
    simp [Fin.sum_univ_succ,h2,h3] at hTotal
    dsimp [a,b,c]
    omega
  have hW : w=HouseButterflyFence.butterflyW a b c := by
    funext i
    fin_cases i
    · rfl
    · rfl
    · exact h2
    · exact h3
    · rfl
  have hGen (v : Fin 5 → Nat) (hv : v=HouseButterflyFence.butterflyW a b c)
      (hH : (withIsolates BMat v z).IsHermitian) (Y : Fin (Fintype.card (Vertices v ⊕ Fin z))→ℝ)
      (hTop : ∃ i, 2*(n:ℝ)≤Y i) :
      (2/3:ℝ)≤∑ i,(hH.eigenvalues₀ i-Y i)^2 := by
    subst v
    let v := HouseButterflyFence.butterflyW a b c
    have hK : withIsolates BMat v z=withIsolates HouseButterflyFence.butterfly v z :=
      congrArg (fun M => withIsolates M v z) bull_raw_exact
    have hH' : (withIsolates HouseButterflyFence.butterfly v z).IsHermitian := hK ▸ hH
    obtain ⟨i,hY⟩ := hTop
    have hx := HouseButterflyFence.weighted_butterfly_bounded_fence n a b c z hn (by omega)
      (hw 0) (hw 1) (hw 4) hS hmin hH' i
    rw [HouseLarge.padded_eigenvalues_eq hK hH hH']
    exact PawLargestFence.squared_discrepancy_of_upper_fence hH'.eigenvalues₀ Y n i hx hY
  exact hC.not_ge (hGen w hW hF y hTop)

theorem paw_raw_exact : PMat=PawLargestFence.paw := by
  ext i j
  change (entry PRows i j : ℝ)=PawLargestFence.paw i j
  fin_cases i <;> fin_cases j <;> norm_num [entry,PRows,PawLargestFence.paw]

theorem all_nonsingleton_paw_excluded (n : Nat) (hn : 3≤n)
    (w : Fin 4 → Nat) (hw : ∀ i,0<w i) (hwL : 2≤w 3) (hOrder : w 1≤w 2)
    (z : Nat) (hz : z≤1) (hTotal : (∑ i,w i)+z=3*n)
    (hF : (withIsolates PMat w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hPos : Fintype.card {i // 0<y i}=1)
    (hNeg : Fintype.card {i // y i= -(n:ℝ)}=2)
    (hTop : ∃ i, 2*(n:ℝ)≤y i) :
    (2/3:ℝ)≤∑ i,(hF.eigenvalues₀ i-y i)^2 := by
  by_cases hN : 28≤n
  · exact paw_huge_excluded n hN w hw (by omega) hwL z hF y hPos hNeg
  by_contra! hC
  obtain ⟨hT,hMin⟩ := paw_class_bounds w hw hwL z hF y hPos hC
  let a := w 0
  let b := w 1
  let c := w 2
  let t := w 3
  have hSum : a+b+c+t+z=3*n := by
    rw [Fin.sum_univ_four] at hTotal
    exact hTotal
  have hMin' : a≤6 ∨ b≤6 := by
    dsimp [a,b]
    omega
  have hW : w=PawLargestFence.pawWeights a b c t := by
    funext i
    fin_cases i <;> rfl
  have hGen (v : Fin 4 → Nat) (hv : v=PawLargestFence.pawWeights a b c t)
      (hH : (withIsolates PMat v z).IsHermitian) (Y : Fin (Fintype.card (Vertices v ⊕ Fin z))→ℝ)
      (hTop : ∃ i, 2*(n:ℝ)≤Y i) :
      (2/3:ℝ)≤∑ i,(hH.eigenvalues₀ i-Y i)^2 := by
    subst v
    let v := PawLargestFence.pawWeights a b c t
    have hK : withIsolates PMat v z=withIsolates PawLargestFence.paw v z :=
      congrArg (fun M => withIsolates M v z) paw_raw_exact
    have hH' : (withIsolates PawLargestFence.paw v z).IsHermitian := hK ▸ hH
    obtain ⟨i,hY⟩ := hTop
    have hx := PawLargestFence.weighted_paw_bounded_fence n a b c t z hn (by omega)
      (hw 0) (hw 1) hOrder hwL hT hz hSum hMin' hH' i
    rw [HouseLarge.padded_eigenvalues_eq hK hH hH']
    exact PawLargestFence.squared_discrepancy_of_upper_fence hH'.eigenvalues₀ Y n i hx hY
  exact hC.not_ge (hGen w hW hF y hTop)

#print axioms all_weighted_bull_excluded
#print axioms all_nonsingleton_paw_excluded
end PawBullPrincipal

namespace PawUnbounded
open Matrix SpectralConjecture20 Conj20CutCert
def seedRows : Rows := #[#[0,1,1,1],#[1,0,1,0],#[1,1,0,0],#[1,0,0,0]]
def seedWeights : Weights := #[17,17,17,1]
def seedX : Rows := #[#[-578,24565,24565,24565],#[0,-2086869,-2137155,-2088025],#[0,0,4224024,2088025],#[0,0,0,29689259]]
def seedCert : Cert := ⟨#[#[1,-85,85,7055],#[0,-2,85,-7225],#[0,0,-83,-7225],#[0,0,0,14616]], #[-578,4173738,-350593992,433938209544], #[#[2426256,-103115880,-103115880,-103115880],#[0,-1213128,-1242360,-1213800],#[0,0,-29232,-14450],#[0,0,0,166]], 2426256⟩

def seedPaw : Matrix (Fin 4) (Fin 4) ℝ := intMatrixToReal (ofRows 4 seedRows)
def seedW : Fin 4 → Nat := weightFn 4 seedWeights
theorem seedHerm : seedPaw.IsHermitian := by
  ext i j
  fin_cases i <;> fin_cases j <;> rfl
theorem seedCheck : validCached 4 seedRows seedWeights 4913 5 1 2 seedCert seedX = true := by decide +kernel
theorem seedCount :
    Fintype.card {j // (2:ℝ)/5 < (weightedQuotient_isHermitian seedPaw seedHerm seedW).eigenvalues j}=2 := by
  have hw (j : Fin 4) : 0<seedW j := by fin_cases j <;> decide
  have hd (j : Fin 4) : seedW j ∣ 4913 := by fin_cases j <;> decide
  have he := cached_cut_count_sound 4 seedRows seedWeights 4913 5 1 2 seedCert seedX seedCheck
    seedHerm hw (by decide) (by decide) hd
  have hh : countPos 4 seedCert.d=2 := by decide +kernel
  rw [hh] at he
  norm_num [seedW] at he ⊢
  exact he

theorem seed_count_monotone (w : Fin 4 → Nat) (hw : ∀ i, seedW i≤w i) :
    2 ≤ Fintype.card {j // (2:ℝ)/5 < (weightedQuotient_isHermitian seedPaw seedHerm w).eigenvalues j} := by
  have hSeedPos (i : Fin 4) : 0<seedW i := by fin_cases i <;> decide
  have he := weighted_spectral_cut_mono seedPaw seedHerm seedW w hSeedPos hw 1 (2/5) (by norm_num)
  simpa only [one_mul,seedCount] using he
#print axioms seed_count_monotone
end PawUnbounded



namespace SpectralConjecture20
def offsetCheck (a b : Fin 11) : Bool :=
  let A := (a.val : Int)-7
  let B := (b.val : Int)-7
  let C := -1-A-B
  let P := A*B+A*C+B*C
  let Q := A*B*C
  let k := A+1-P
  if decide (B ≤ C ∧ C ≤ 3 ∧ ¬ (A=-1 ∧ B=0 ∧ C=0)) then
    decide (2*k=(A+1)^2+B^2+C^2 ∧ 1≤k ∧ 7*(2*Q+P)≤16*k ∧ 7*Q≤12*k)
  else true
theorem all_offsets_checked : (List.ofFn fun a => (List.ofFn fun b => offsetCheck a b).all id).all id = true :=
  by decide +kernel
#print axioms all_offsets_checked

theorem offset_certificate (A B C : Int) (hA : -7 ≤ A ∧ A ≤ 3)
    (hB : -7 ≤ B ∧ B ≤ 3) (hBC : B ≤ C ∧ C ≤ 3)
    (hs : A+B+C = -1) (he : ¬ (A=-1 ∧ B=0 ∧ C=0)) :
    let P := A*B+A*C+B*C
    let Q := A*B*C
    let k := A+1-P
    2*k=(A+1)^2+B^2+C^2 ∧ 1≤k ∧ 7*(2*Q+P)≤16*k ∧ 7*Q≤12*k := by
  let a : Fin 11 := ⟨(A+7).toNat,by omega⟩
  let b : Fin 11 := ⟨(B+7).toNat,by omega⟩
  have h1 := List.all_eq_true.mp all_offsets_checked _ (List.mem_ofFn.mpr ⟨a,rfl⟩)
  have h2 := List.all_eq_true.mp h1 _ (List.mem_ofFn.mpr ⟨b,rfl⟩)
  change offsetCheck a b = true at h2
  have ea : (a.val : Int)-7 = A := by dsimp [a]; omega
  have eb : (b.val : Int)-7 = B := by dsimp [b]; omega
  have ec : -1-A-B = C := by omega
  simpa [offsetCheck,ea,eb,ec,hBC.1,hBC.2,he] using h2
#print axioms offset_certificate
end SpectralConjecture20

namespace PawUnbounded
open SpectralConjecture20 PawLargestFence

theorem paw_poly_offset (n A B C : ℝ) (hs : A+B+C = -1) :
    let a := n+A
    let b := n+B
    let c := n+C
    let P := A*B+A*C+B*C
    let Q := A*B*C
    let k := A+1-P
    poly (pawE a b c 1) (pawF a b c) (pawG a b c 1) (-n) =
      -k*n^2+(2*Q+P)*n+Q := by
  have he : C= -1-A-B := by linarith
  rw [he]
  dsimp [poly,pawE,pawF,pawG]
  ring

theorem paw_value_upper (n : ℕ) (hn : 24≤n) (A B C : ℤ)
    (hA : -7≤A ∧ A≤3) (hB : -7≤B ∧ B≤3) (hBC : B≤C ∧ C≤3)
    (hs : A+B+C= -1) (hneq : ¬(A= -1 ∧ B=0 ∧ C=0)) :
    let a : ℝ := (n:ℝ)+A
    let b : ℝ := (n:ℝ)+B
    let c : ℝ := (n:ℝ)+C
    poly (pawE a b c 1) (pawF a b c) (pawG a b c 1) (-(n:ℝ)) ≤ -(9/10:ℝ)*(n:ℝ)^2 := by
  let P : ℤ := A*B+A*C+B*C
  let Q : ℤ := A*B*C
  let k : ℤ := A+1-P
  obtain ⟨_,hk,hP,hQ⟩ := offset_certificate A B C hA hB hBC hs hneq
  change 1≤k at hk
  change 7*(2*Q+P)≤16*k at hP
  change 7*Q≤12*k at hQ
  have hs' : (A:ℝ)+(B:ℝ)+(C:ℝ)= -1 := by exact_mod_cast hs
  have hn' : (24:ℝ)≤n := by exact_mod_cast hn
  have hPos : (0:ℝ)≤n := by positivity
  have hKReal : (1:ℝ)≤(k:ℝ) := by exact_mod_cast hk
  have hp : (2*(Q:ℝ)+(P:ℝ))≤(16/7:ℝ)*(k:ℝ) := by
    have hR : (7:ℝ)*(2*(Q:ℝ)+(P:ℝ))≤16*(k:ℝ) := by exact_mod_cast hP
    linarith
  have hq : (Q:ℝ)≤(12/7:ℝ)*(k:ℝ) := by
    have hR : (7:ℝ)*(Q:ℝ)≤12*(k:ℝ) := by exact_mod_cast hQ
    linarith
  have hpN := mul_le_mul_of_nonneg_right hp hPos
  have hBracket : (16/7:ℝ)*(n:ℝ)+12/7≤(1/10:ℝ)*(n:ℝ)^2 := by
    have hb := mul_nonneg (sub_nonneg.mpr hn') (show 0≤7*(n:ℝ)+8 by positivity)
    nlinarith only [hb]
  have hKpos : (0:ℝ)≤(k:ℝ) := by linarith
  have hKN := mul_le_mul_of_nonneg_right hBracket hKpos
  have hKsq := mul_le_mul_of_nonneg_right hKReal (sq_nonneg (n:ℝ))
  dsimp
  rw [paw_poly_offset (n:ℝ) (A:ℝ) (B:ℝ) (C:ℝ) hs']
  change -((A:ℝ)+1-((A:ℝ)*(B:ℝ)+(A:ℝ)*(C:ℝ)+(B:ℝ)*(C:ℝ)))*(n:ℝ)^2 +
      (2*((A:ℝ)*(B:ℝ)*(C:ℝ))+((A:ℝ)*(B:ℝ)+(A:ℝ)*(C:ℝ)+(B:ℝ)*(C:ℝ)))*(n:ℝ) +
      (A:ℝ)*(B:ℝ)*(C:ℝ) ≤ _
  have eP : (P:ℝ)=(A:ℝ)*(B:ℝ)+(A:ℝ)*(C:ℝ)+(B:ℝ)*(C:ℝ) := by dsimp [P]; push_cast; rfl
  have eQ : (Q:ℝ)=(A:ℝ)*(B:ℝ)*(C:ℝ) := by dsimp [Q]; push_cast; rfl
  have eK : (k:ℝ)=(A:ℝ)+1-(P:ℝ) := by dsimp [k]; push_cast; rfl
  rw [←eP,←eQ,←eK]
  nlinarith only [hpN,hq,hKN,hKsq]

theorem squared_offset_fence (n u v s t : ℝ) (hn : 24≤n)
    (hu : 0≤u) (hU : u≤2*n+41/50) (hv : 2/5<v) (hV : v≤41/50)
    (hF : (n+u)*(n+v)*(n+s)*(n+t) ≤ -(9/10:ℝ)*n^2) :
    (2/3:ℝ) ≤ (u-2*n)^2+v^2+(s+n)^2+(t+n)^2 := by
  have hnp : 0<n := by linarith
  have hnu : 0<n+u := by linarith
  have hnv : 0<n+v := by linarith
  have h₁ : n+u≤(61/20:ℝ)*n := by linarith
  have h₂ : n+v≤(21/20:ℝ)*n := by linarith

  have h₃ : (n+u)*(n+v)≤(13/4:ℝ)*n^2 := by
    have hh := mul_le_mul h₁ h₂ hnv.le (by positivity : 0≤(61/20:ℝ)*n)
    nlinarith only [hh,sq_nonneg n]
  let d : ℝ := (n+s)*(n+t)
  have hneg : d<0 := by
    by_contra! hh
    have hp := mul_nonneg (mul_pos hnu hnv).le hh
    have hn2 := sq_pos_of_pos hnp
    change 0≤(n+u)*(n+v)*((n+s)*(n+t)) at hp
    nlinarith only [hp,hF,hn2]
  have hprod : (9/10:ℝ)*n^2≤(n+u)*(n+v)*|d| := by
    rw [abs_of_neg hneg]
    dsimp [d]
    nlinarith only [hF]
  have habs : (18/65:ℝ)≤|d| := by
    by_contra! hh
    have hLess := mul_lt_mul_of_pos_left hh (show 0<(13/4:ℝ)*n^2 by positivity)
    have hLe := mul_le_mul_of_nonneg_right h₃ (abs_nonneg d)
    nlinarith only [hprod,hLess,hLe]
  have hst : (36/65:ℝ) ≤ (s+n)^2+(t+n)^2 := by
    have hss := sq_nonneg (|n+s|-|n+t|)
    rw [abs_mul] at habs
    simp only [sub_sq,sq_abs] at hss
    nlinarith only [hss,habs]
  have hvv : (4/25:ℝ)≤v^2 := by
    have hh := mul_nonneg (show 0≤v-2/5 by linarith) (show 0≤v+2/5 by linarith)
    nlinarith only [hh]
  nlinarith only [hst,hvv,sq_nonneg (u-2*n)]

#print axioms paw_value_upper
#print axioms squared_offset_fence
end PawUnbounded


namespace PawUnbounded

def prefixEquiv (n k : Nat) (h : k ≤ n) : {j : Fin n // j.val < k} ≃ Fin k where
  toFun j := ⟨j.val.val,j.property⟩
  invFun j := ⟨⟨j.val,j.isLt.trans_le h⟩,j.isLt⟩
  left_inv _ := rfl
  right_inv _ := rfl

theorem cut_count_rank_iff {n : Nat} (x : Fin n → ℝ) (hx : Antitone x)
    (q : ℝ) (i : Fin n) :
    q < x i ↔ i.val < Fintype.card {j // q < x j} := by
  classical
  constructor
  · intro hi
    have hsub : Fintype.card {j : Fin n // j.val < i.val+1}≤
        Fintype.card {j // q < x j} := by
      apply Fintype.card_subtype_mono
      intro j hj
      exact hi.trans_le (hx (by change j.val ≤ i.val; omega))
    rw [Fintype.card_congr (prefixEquiv n (i.val+1) i.isLt), Fintype.card_fin] at hsub
    omega
  · intro h
    by_contra! hc
    have hsub : Fintype.card {j // q < x j} ≤ Fintype.card {j : Fin n // j.val < i.val} := by
      apply Fintype.card_subtype_mono
      intro j hj
      by_contra! hbad
      exact (((hx (by exact hbad : i ≤ j)).trans hc).not_gt) hj
    rw [Fintype.card_congr (prefixEquiv n i.val i.isLt.le),Fintype.card_fin] at hsub
    omega

theorem equal_coord_of_nonnegative_cut_counts {n m : Nat} (x : Fin n → ℝ) (y : Fin m → ℝ)
    (hx : Antitone x) (hy : Antitone y) (i : Fin n) (j : Fin m)
    (hI : i.val=j.val) (hxi : 0 ≤ x i) (hyj : 0 ≤ y j)
    (hC : ∀ q : ℝ, 0 ≤ q → Fintype.card {a // q < x a}=Fintype.card {b // q < y b}) :
    x i=y j := by
  have hiff (q : ℝ) (hq : 0 ≤ q) : q < x i ↔ q < y j := by
    rw [cut_count_rank_iff x hx q i,cut_count_rank_iff y hy q j,hI,hC q hq]
  apply le_antisymm
  · by_contra! h
    exact (lt_irrefl _) ((hiff _ hyj).mp h)
  · by_contra! h
    exact (lt_irrefl _) ((hiff _ hxi).mpr h)

#print axioms equal_coord_of_nonnegative_cut_counts
end PawUnbounded


namespace PawUnbounded
open Matrix Finset
open scoped BigOperators

theorem eval_charpoly_by_ordered_roots {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (hB : B.IsHermitian) (x : ℝ) :
    B.charpoly.eval x = ∏ i, (x-hB.eigenvalues₀ i) := by
  rw [hB.charpoly_eq,Polynomial.eval_prod]
  simp only [Polynomial.eval_sub,Polynomial.eval_X,Polynomial.eval_C]
  change (∏ i : m, (x-hB.eigenvalues₀ ((Fintype.equivOfCardEq (Fintype.card_fin _)).symm i))) = _
  exact Equiv.prod_comp (Fintype.equivOfCardEq (Fintype.card_fin _)).symm
    (fun i => x-hB.eigenvalues₀ i)

#print axioms eval_charpoly_by_ordered_roots
end PawUnbounded


namespace PawUnbounded
open Matrix SpectralConjecture20 PawLargestFence Conj20CutCert
open scoped BigOperators Matrix

theorem index_cut_eigenvalues₀ {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (hB : B.IsHermitian) (p : ℝ → Prop) [DecidablePred p] :
    Fintype.card {j // p (hB.eigenvalues j)} = Fintype.card {j // p (hB.eigenvalues₀ j)} :=
  Fintype.card_congr (Equiv.subtypeEquiv (Fintype.equivOfCardEq (Fintype.card_fin _)).symm (fun _ => Iff.rfl))

def singletonWeights (a b c : Nat) : Fin 4 → Nat := ![a,b,c,1]

noncomputable def singletonQEigen (a b c : Nat) : Fin 4 → ℝ :=
  fun j => (weightedQuotient_isHermitian seedPaw seedHerm (singletonWeights a b c)).eigenvalues₀
    (Fin.cast (Fintype.card_fin 4).symm j)

theorem seed_paw_exact : seedPaw=paw := by
  ext i j
  change (entry seedRows i j : ℝ)=paw i j
  fin_cases i <;> fin_cases j <;> norm_num [entry,seedRows,paw]

theorem singleton_seed_lower (a b c : Nat) (ha : 17≤a) (hb : 17≤b) (hc : 17≤c) :
    (2/5:ℝ) < singletonQEigen a b c 1 := by
  let w := singletonWeights a b c
  let hB := weightedQuotient_isHermitian seedPaw seedHerm w
  have hw (j : Fin 4) : seedW j≤w j := by
    fin_cases j <;> first
    | exact ha
    | exact hb
    | exact hc
    | exact Nat.le_refl 1
  have hCt := seed_count_monotone w hw
  rw [index_cut_eigenvalues₀ _ hB ((2/5:ℝ) < ·)] at hCt
  let j : Fin (Fintype.card (Fin 4)) := Fin.cast (Fintype.card_fin 4).symm 1
  change (2/5:ℝ) < hB.eigenvalues₀ j
  apply (cut_count_rank_iff _ hB.eigenvalues₀_antitone _ j).mpr
  have hj : j.val=1 := by rfl
  omega

theorem singleton_factored_value (a b c : Nat) (n : ℝ) :
    let x := singletonQEigen a b c
    (n+x 0)*(n+x 1)*(n+x 2)*(n+x 3) =
      poly (pawE a b c 1) (pawF a b c) (pawG a b c 1) (-n) := by
  let w := singletonWeights a b c
  let hB := weightedQuotient_isHermitian seedPaw seedHerm w
  have he := eval_charpoly_by_ordered_roots (weightedQuotient seedPaw w) hB (-n)
  have hLeft : (weightedQuotient seedPaw w).charpoly.eval (-n) =
      poly (pawE a b c 1) (pawF a b c) (pawG a b c 1) (-n) := by
    rw [Matrix.eval_charpoly,seed_paw_exact]
    change (Matrix.scalar (Fin 4) (-n)-weightedQuotient paw (pawWeights a b c 1)).det=_
    rw [paw_quotient_explicit,det_paw]
    simp only [←pow_two, Real.sq_sqrt (Nat.cast_nonneg _), Nat.cast_one, Real.sqrt_one,one_pow]
  have hRight : (∏ i, (-n-hB.eigenvalues₀ i)) =
      ∏ j : Fin 4,(-n-singletonQEigen a b c j) := by
    symm
    exact Equiv.prod_comp (finCongr (Fintype.card_fin 4).symm)
      (fun i => -n-hB.eigenvalues₀ i)
  rw [hLeft,hRight] at he
  dsimp
  simp [Fin.prod_univ_succ] at he
  rw [he]
  ring

theorem weighted_singleton_paw_large_quartet_fence (n a b c : Nat) (hn : 24≤n)
    (hA : -7≤(a:ℤ)-n ∧ (a:ℤ)-n≤3) (hB : -7≤(b:ℤ)-n ∧ (b:ℤ)-n≤3)
    (hBC : b≤c ∧ (c:ℤ)-n≤3) (hSum : a+b+c+1=3*n)
    (hne : ¬(a+1=n ∧ b=n ∧ c=n))
    (hU : singletonQEigen a b c 0≤2*(n:ℝ)+41/50) (hV : singletonQEigen a b c 1≤41/50) :
    let x := singletonQEigen a b c
    (2/3:ℝ) ≤ (x 0-2*(n:ℝ))^2+(x 1)^2+(x 2+(n:ℝ))^2+(x 3+(n:ℝ))^2 := by
  have hs : ((a:ℤ)-n)+((b:ℤ)-n)+((c:ℤ)-n)= -1 := by omega
  have hcLo : 17≤c := by omega
  have hv := singleton_seed_lower a b c (by omega) (by omega) hcLo
  have hx : Antitone (singletonQEigen a b c) := by
    intro i j hij
    exact (weightedQuotient_isHermitian seedPaw seedHerm (singletonWeights a b c)).eigenvalues₀_antitone hij
  have hu : 0≤singletonQEigen a b c 0 := by
    have hh := hx (show (0:Fin 4)≤1 by decide)
    linarith
  have hValue := paw_value_upper n hn ((a:ℤ)-n) ((b:ℤ)-n) ((c:ℤ)-n)
    hA hB (by exact ⟨by omega,hBC.2⟩) hs (by
      rintro ⟨ha,hb,hc⟩
      exact hne ⟨by omega,by omega,by omega⟩)
  dsimp at hValue
  push_cast at hValue
  ring_nf at hValue
  have hnr : (24:ℝ)≤n := by exact_mod_cast hn
  apply squared_offset_fence _ _ _ _ _ hnr hu hU hv hV
  rw [singleton_factored_value]
  ring_nf
  exact hValue

#print axioms weighted_singleton_paw_large_quartet_fence
end PawUnbounded


namespace PawUnbounded
open Matrix SpectralConjecture20
open scoped BigOperators Matrix

theorem withIsolates_quotient_sorted_cut {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (hB : B.IsHermitian) (w : m → Nat) (hw : ∀ i, 0<w i)
    (z : Nat) (hF : (withIsolates B w z).IsHermitian)
    (s q : ℝ) (hq : 0≤q) :
    Fintype.card {i // q < s*hF.eigenvalues₀ i} =
      Fintype.card {i // q < s*(weightedQuotient_isHermitian B hB w).eigenvalues₀ i} := by
  classical
  have hc := withIsolates_ordered_cut_count B hB w hw z hF s q hq
  exact hc.trans (index_cut_eigenvalues₀ _ _ (fun x => q<s*x))

theorem normalized_paw_sorted_cut (a b c z : Nat) (ha : 0<a) (hb : 0<b) (hc : 0<c)
    (hF : (withIsolates seedPaw (singletonWeights a b c) z).IsHermitian) (s q : ℝ) (hq : 0≤q) :
    Fintype.card {i // q < s*hF.eigenvalues₀ i} =
      Fintype.card {j // q < s*singletonQEigen a b c j} := by
  let w := singletonWeights a b c
  have hw (i : Fin 4) : 0<w i := by
    fin_cases i
    · exact ha
    · exact hb
    · exact hc
    · exact Nat.zero_lt_succ 0
  rw [withIsolates_quotient_sorted_cut seedPaw seedHerm w hw z hF s q hq]
  exact Fintype.card_congr (Equiv.subtypeEquiv (finCongr (Fintype.card_fin 4)) (fun _ => Iff.rfl))

theorem antitone_neg_rev {n : Nat} (x : Fin n → ℝ) (hx : Antitone x) :
    Antitone (fun i : Fin n => -x i.rev) := by
  intro i j h
  exact neg_le_neg (hx (Fin.rev_le_rev.mpr h))

theorem signed_reversed_cuts {n : Nat} (x : Fin n → ℝ) (q : ℝ) :
    Fintype.card {i // q < -x i} = Fintype.card {i : Fin n // q < -x i.rev} := by
  exact Fintype.card_congr (Equiv.subtypeEquiv Fin.revPerm (by intro i; simp))

theorem sum_of_four_coords_le {m : Type*} [Fintype m] [DecidableEq m]
    (f : m → ℝ) (hf : ∀ x, 0≤f x) (e : Fin 4 ↪ m) :
    f (e 0)+f (e 1)+f (e 2)+f (e 3)≤∑ i,f i := by
  rw [←Fin.sum_univ_four (fun i => f (e i)),← Finset.sum_map]
  exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _) (fun i _ _ => hf i)

#print axioms normalized_paw_sorted_cut
#print axioms sum_of_four_coords_le
end PawUnbounded


namespace PawUnbounded
open Matrix SpectralConjecture20 Finset
open scoped BigOperators Matrix

theorem weighted_singleton_paw_large_excluded (n a b c z : Nat) (hn : 24≤n)
    (hA : -7≤(a:ℤ)-n ∧ (a:ℤ)-n≤3) (hB : -7≤(b:ℤ)-n ∧ (b:ℤ)-n≤3)
    (hBC : b≤c ∧ (c:ℤ)-n≤3) (hSum : a+b+c+1=3*n)
    (hne : ¬(a+1=n ∧ b=n ∧ c=n))
    (hF : (withIsolates seedPaw (singletonWeights a b c) z).IsHermitian)
    (hN : 4≤Fintype.card (Vertices (singletonWeights a b c) ⊕ Fin z))
    (y : Fin (Fintype.card (Vertices (singletonWeights a b c) ⊕ Fin z)) → ℝ)
    (hy0 : y ⟨0,by omega⟩=2*(n:ℝ)) (hy1 : y ⟨1,by omega⟩=0)
    (hy2 : y (Fin.rev ⟨1,by omega⟩)= -(n:ℝ))
    (hy3 : y (Fin.rev ⟨0,by omega⟩)= -(n:ℝ)) :
    (2/3:ℝ)≤∑ i,(hF.eigenvalues₀ i-y i)^2 := by
  let N := Fintype.card (Vertices (singletonWeights a b c) ⊕ Fin z)
  let f : Fin N → ℝ := hF.eigenvalues₀
  let q := singletonQEigen a b c
  let i0 : Fin N := ⟨0,by dsimp [N]; omega⟩
  let i1 : Fin N := ⟨1,by dsimp [N]; omega⟩
  have ha : 17≤a := by omega
  have hb : 17≤b := by omega
  have hc : 17≤c := by omega
  have hf : Antitone f := hF.eigenvalues₀_antitone
  have hq : Antitone q := by
    intro i j hij
    exact (weightedQuotient_isHermitian seedPaw seedHerm (singletonWeights a b c)).eigenvalues₀_antitone hij
  have hcPos (u : ℝ) (hu : 0≤u) :
      Fintype.card {i // u < f i} = Fintype.card {j // u < q j} := by
    simpa only [one_mul] using normalized_paw_sorted_cut a b c z (by omega) (by omega) (by omega) hF 1 u hu
  have hcNeg (u : ℝ) (hu : 0≤u) :
      Fintype.card {i : Fin N // u < -f i.rev} = Fintype.card {j : Fin 4 // u < -q j.rev} := by
    rw [←signed_reversed_cuts f,←signed_reversed_cuts q]
    simpa only [neg_one_mul] using normalized_paw_sorted_cut a b c z (by omega) (by omega) (by omega) hF (-1) u hu
  have hqP : (2/5:ℝ)<q 1 := singleton_seed_lower a b c ha hb hc
  have hfP : (2/5:ℝ)<f i1 := by
    rw [cut_count_rank_iff _ hf, hcPos _ (by norm_num)]
    change 1 < _
    exact (cut_count_rank_iff _ hq _ 1).mp hqP
  have he1 : f i1=q 1 :=
    equal_coord_of_nonnegative_cut_counts _ _ hf hq _ _ rfl (by linarith) (by linarith) hcPos
  have he0 : f i0=q 0 :=
    equal_coord_of_nonnegative_cut_counts _ _ hf hq _ _ rfl
      ((by linarith : 0≤f i1).trans (hf (by change (0:Nat)≤1; exact Nat.zero_le _)))
      ((by linarith : 0≤q 1).trans (hq (by decide))) hcPos
  by_contra! hClose
  have hs (i : Fin N) : (f i-y i)^2<(2/3:ℝ) := by
    have h := Finset.single_le_sum (s := Finset.univ) (f := fun i => (f i-y i)^2)
      (fun j _ => sq_nonneg (f j-y j)) (Finset.mem_univ i)
    exact h.trans_lt hClose
  have hTop : q 0≤2*(n:ℝ)+41/50 := by
    have h := hs i0
    change y i0=2*(n:ℝ) at hy0
    rw [hy0,he0] at h
    by_contra! hx
    have ht := mul_nonneg (show 0≤q 0-2*(n:ℝ)-41/50 by linarith)
      (show 0≤q 0-2*(n:ℝ)+41/50 by linarith)
    nlinarith only [h,ht]
  have hV : q 1≤(41/50:ℝ) := by
    have h := hs i1
    change y i1=0 at hy1
    rw [hy1,sub_zero,he1] at h
    by_contra! hx
    have ht := mul_nonneg (show 0≤q 1-41/50 by linarith) (show 0≤q 1+41/50 by linarith)
    nlinarith only [h,ht]
  have hNegAt (i : Fin N) (hY : y i = -(n:ℝ)) : (2:ℝ)< -f i := by
    have hnR : (24:ℝ)≤n := by exact_mod_cast hn
    have h := hs i
    rw [hY] at h
    by_contra! hNo
    have ht := mul_nonneg (show 0≤f i+(n:ℝ)-1 by linarith) (show 0≤f i+(n:ℝ)+1 by linarith)
    nlinarith only [h,ht]
  have hnF₁ := hNegAt i1.rev hy2
  have hnF₀ := hNegAt i0.rev hy3
  have hfr := antitone_neg_rev f hf
  have hqr := antitone_neg_rev q hq
  have sortNegative (i : Fin N) (j : Fin 4) (hij : i.val=j.val) (hFNeg : (2:ℝ)< -f i.rev) :
      f i.rev=q j.rev := by
    have hqNeg : (2:ℝ)< -q j.rev := by
      apply (cut_count_rank_iff _ hqr 2 j).mpr
      rw [←hij,←hcNeg _ (by norm_num)]
      exact (cut_count_rank_iff _ hfr 2 i).mp hFNeg
    have he := equal_coord_of_nonnegative_cut_counts _ _ hfr hqr i j hij
      (by linarith) (by linarith) hcNeg
    linarith only [he]
  have he2 : f i1.rev=q 2 := sortNegative i1 1 rfl hnF₁
  have he3 : f i0.rev=q 3 := sortNegative i0 0 rfl hnF₀
  let eFun : Fin 4 → Fin N := ![i0,i1,i1.rev,i0.rev]
  have hInj : Function.Injective eFun := by
    intro i j he
    have hv := congrArg Fin.val he
    fin_cases i <;> fin_cases j <;>
      simp [eFun,i0,i1,Fin.val_rev] at hv ⊢ <;> omega
  let e : Fin 4 ↪ Fin N := ⟨eFun,hInj⟩
  have hsum := sum_of_four_coords_le (fun j => (f j-y j)^2)
    (fun j => sq_nonneg (f j-y j)) e
  change (f i0-y i0)^2+(f i1-y i1)^2+(f i1.rev-y i1.rev)^2+(f i0.rev-y i0.rev)^2≤_ at hsum
  change y i0=2*(n:ℝ) at hy0
  change y i1.rev= -(n:ℝ) at hy2
  change y i0.rev= -(n:ℝ) at hy3
  rw [he0,he1,he2,he3,hy0,hy1,hy2,hy3,sub_zero,sub_neg_eq_add,sub_neg_eq_add] at hsum
  have hFence := weighted_singleton_paw_large_quartet_fence n a b c hn hA hB hBC hSum hne hTop hV
  exact hClose.not_ge (hFence.trans hsum)

#print axioms weighted_singleton_paw_large_excluded
end PawUnbounded


namespace PawWindow
open Matrix Finset SpectralConjecture20 PawLargestFence
open scoped BigOperators Matrix

theorem paw_shift_quad (a b c q : ℝ) (hq : q≠0) (v : Fin 4 → ℝ) :
    (v ⬝ᵥ (((-1:ℝ) • pawQ a b c 1-q • (1 : Matrix (Fin 4) (Fin 4) ℝ)) *ᵥ v)) =
    (a^2+a^2/q-q)*(v 0)^2+(b^2-q)*(v 1)^2+(c^2-q)*(v 2)^2 -
      q*(v 3+a*v 0/q)^2-(a*v 0+b*v 1+c*v 2)^2 := by
  simp [dotProduct,Matrix.mulVec,Fin.sum_univ_four,Matrix.sub_apply,Matrix.smul_apply,
    Matrix.one_apply,pawQ]
  field_simp [hq]
  ring

noncomputable def lowerDiag (a b c q : ℝ) : Fin 4 → ℝ :=
  ![a+a/q-q,b-q,c-q,0]

theorem paw_negative_count_le_diagonal (a b c : Nat) (q : ℝ) (hq : 0<q)
    (hP : (pawQ (Real.sqrt a) (Real.sqrt b) (Real.sqrt c) 1).IsHermitian) :
    Fintype.card {i // q < -hP.eigenvalues i} ≤
      Fintype.card {i // 0<lowerDiag a b c q i} := by
  let M := pawQ (Real.sqrt a) (Real.sqrt b) (Real.sqrt c) 1
  let hS := shifted_isHermitian M hP (-1) q
  have he := shifted_positive_index M hP (-1) q
  simp only [neg_one_mul] at he
  rw [←he]
  obtain ⟨V,hDim,hPos⟩ := positive_index_subspace _ hS
  change Fintype.card {i // 0<hS.eigenvalues i} ≤ _
  rw [←hDim]
  apply positive_diagonal_dimension_bound (lowerDiag a b c q) V
  intro x hx hx0
  have h := hPos x hx hx0
  change 0 < x ⬝ᵥ (((-1:ℝ) • M-q • (1 : Matrix (Fin 4) (Fin 4) ℝ)) *ᵥ x) at h
  dsimp [M] at h
  rw [paw_shift_quad _ _ _ _ hq.ne'] at h
  simp only [Real.sq_sqrt (Nat.cast_nonneg _)] at h
  simp [Fin.sum_univ_four,lowerDiag]
  have hSq : 0≤q*(x 3+Real.sqrt a*x 0/q)^2 := mul_nonneg hq.le (sq_nonneg _)
  have hSq' : 0≤(Real.sqrt a*x 0+Real.sqrt b*x 1+Real.sqrt c*x 2)^2 := sq_nonneg _
  linarith only [h,hSq,hSq']

def triangleWeights (a b c : Nat) : Fin 4 → Nat := ![a,b,c,1]

theorem at_least_two_large_of_paw_negative_cut (n a b c : Nat) (hn : 8≤n)
    (hP : (pawQ (Real.sqrt a) (Real.sqrt b) (Real.sqrt c) 1).IsHermitian)
    (hCut : 2≤Fintype.card {i // (n:ℝ)-41/50 < -hP.eigenvalues i}) :
    2≤Fintype.card {i // n-1≤triangleWeights a b c i} := by
  have hnr : (8:ℝ)≤n := by exact_mod_cast hn
  let q : ℝ := (n:ℝ)-41/50
  have hq : 0<q := by dsimp [q]; linarith
  have hLow := hCut.trans (paw_negative_count_le_diagonal a b c q hq hP)
  refine hLow.trans (Fintype.card_subtype_mono _ _ ?_)
  intro i hi
  fin_cases i
  · change 0<(a:ℝ)+(a:ℝ)/q-q at hi
    change n-1≤a
    by_contra! h
    have hNa : a+2≤n := by omega
    have hR : (a:ℝ)+2≤n := by exact_mod_cast hNa
    have hAq : (a:ℝ)<q := by dsimp [q]; linarith
    have hdiv : (a:ℝ)/q<1 := (div_lt_iff₀ hq).mpr (by simpa using hAq)
    dsimp [q] at hi
    -- Keep the exact denominator for the linear comparison below.
    change (a:ℝ)/((n:ℝ)-41/50)<1 at hdiv
    linarith
  · change 0<(b:ℝ)-q at hi
    change n-1≤b
    by_contra! h
    have hb : b+2≤n := by omega
    have hbR : (b:ℝ)+2≤n := by exact_mod_cast hb
    dsimp [q] at hi
    linarith
  · change 0<(c:ℝ)-q at hi
    change n-1≤c
    by_contra! h
    have hc : c+2≤n := by omega
    have hcR : (c:ℝ)+2≤n := by exact_mod_cast hc
    dsimp [q] at hi
    linarith
  · change (0:ℝ)<0 at hi
    exact (lt_irrefl _ hi).elim

#print axioms at_least_two_large_of_paw_negative_cut
end PawWindow


namespace PawWindow
open Matrix Finset SpectralConjecture20 PawLargestFence
open scoped BigOperators Matrix

theorem form_nonpos_of_no_positive {m : Type*} [Fintype m] [DecidableEq m]
    (M : Matrix m m ℝ) (hM : M.IsHermitian)
    (hNo : Fintype.card {i // 0<hM.eigenvalues i}=0) (v : m → ℝ) :
    v ⬝ᵥ (M *ᵥ v)≤0 := by
  let U : Matrix m m ℝ := hM.eigenvectorUnitary
  have hstar : star U = Uᵀ := by
    rw [star_eq_conjTranspose,conjTranspose_eq_transpose_of_trivial]
  have hDiag : M=U*diagonal hM.eigenvalues*Uᵀ := by
    have h := hM.spectral_theorem
    rw [Unitary.conjStarAlgAut_apply,←Unitary.coe_star] at h
    change M=U*diagonal (RCLike.ofReal ∘ hM.eigenvalues)*star U at h
    rw [hstar] at h
    simpa using h
  have he : v ⬝ᵥ (M *ᵥ v) = ∑ i, hM.eigenvalues i*((Uᵀ *ᵥ v) i)^2 :=
    (congrArg (fun A : Matrix m m ℝ => v ⬝ᵥ (A *ᵥ v)) hDiag).trans
      (quadratic_form_of_diagonalization U hM.eigenvalues v)
  rw [he]
  apply Finset.sum_nonpos
  intro i _
  have hh : hM.eigenvalues i≤0 := by
    by_contra! hc
    exact (Fintype.card_eq_zero_iff.mp hNo).false ⟨i,hc⟩
  exact mul_nonpos_of_nonpos_of_nonneg hh (sq_nonneg _)

theorem paw_upper_pair_bounds (a b c : Nat) (q : ℝ)
    (hP : (pawQ (Real.sqrt a) (Real.sqrt b) (Real.sqrt c) 1).IsHermitian)
    (hCut : Fintype.card {i // q < -hP.eigenvalues i}=0) :
    2*(a:ℝ)*b≤q*((a:ℝ)+b) ∧
    2*(a:ℝ)*c≤q*((a:ℝ)+c) ∧
    2*(b:ℝ)*c≤q*((b:ℝ)+c) := by
  let A := Real.sqrt (a:ℝ)
  let B := Real.sqrt (b:ℝ)
  let C := Real.sqrt (c:ℝ)
  let M := pawQ A B C 1
  let hS := shifted_isHermitian M hP (-1) q
  have hNo := shifted_positive_index M hP (-1) q
  simp only [neg_one_mul,hCut] at hNo
  have hForm (v : Fin 4 → ℝ) :
      v ⬝ᵥ (((-1:ℝ) • M-q • (1:Matrix (Fin 4) (Fin 4) ℝ)) *ᵥ v)≤0 :=
    form_nonpos_of_no_positive _ hS hNo v

  let v0 : Fin 4 → ℝ := ![B,-A,0,0]
  have eq0 : v0 ⬝ᵥ (((-1:ℝ) • M-q • (1:Matrix (Fin 4) (Fin 4) ℝ)) *ᵥ v0) =
      2*A^2*B^2-q*(A^2+B^2) := by
    simp [v0,M,pawQ,dotProduct,Matrix.mulVec,Fin.sum_univ_four,
      Matrix.sub_apply,Matrix.smul_apply,Matrix.one_apply]
    ring
  have H0 := hForm v0
  rw [eq0] at H0
  dsimp [A,B,C] at H0
  simp only [Real.sq_sqrt (Nat.cast_nonneg _)] at H0

  let v1 : Fin 4 → ℝ := ![C,0,-A,0]
  have eq1 : v1 ⬝ᵥ (((-1:ℝ) • M-q • (1:Matrix (Fin 4) (Fin 4) ℝ)) *ᵥ v1) =
      2*A^2*C^2-q*(A^2+C^2) := by
    simp [v1,M,pawQ,dotProduct,Matrix.mulVec,Fin.sum_univ_four,
      Matrix.sub_apply,Matrix.smul_apply,Matrix.one_apply]
    ring
  have H1 := hForm v1
  rw [eq1] at H1
  dsimp [A,B,C] at H1
  simp only [Real.sq_sqrt (Nat.cast_nonneg _)] at H1

  let v2 : Fin 4 → ℝ := ![0,C,-B,0]
  have eq2 : v2 ⬝ᵥ (((-1:ℝ) • M-q • (1:Matrix (Fin 4) (Fin 4) ℝ)) *ᵥ v2) =
      2*B^2*C^2-q*(B^2+C^2) := by
    simp [v2,M,pawQ,dotProduct,Matrix.mulVec,Fin.sum_univ_four,
      Matrix.sub_apply,Matrix.smul_apply,Matrix.one_apply]
    ring
  have H2 := hForm v2
  rw [eq2] at H2
  dsimp [A,B,C] at H2
  simp only [Real.sq_sqrt (Nat.cast_nonneg _)] at H2

  constructor
  · linarith only [H0]
  constructor
  · linarith only [H1]
  · linarith only [H2]

theorem weight_upper_of_harmonic (n h w : Nat) (hn : 8≤n) (hw : n-1≤w)
    (hPair : 2*(h:ℝ)*w≤((n:ℝ)+41/50)*((h:ℝ)+w)) : h≤n+3 := by
  have hn' : (8:ℝ)≤n := by exact_mod_cast hn
  have hw' : (n:ℝ)-1≤w := by
    have h : n≤w+1 := by omega
    have hR : (n:ℝ)≤(w:ℝ)+1 := by exact_mod_cast h
    linarith
  by_contra! hBig
  have hBigN : n+4≤h := by omega
  have hBigR : (n:ℝ)+4≤h := by exact_mod_cast hBigN
  have hPos := mul_nonneg (show 0≤(h:ℝ)-((n:ℝ)+4) by linarith)
    (show 0≤2*(w:ℝ)-((n:ℝ)+41/50) by linarith)
  have hPos' := mul_nonneg (show 0≤(w:ℝ)-((n:ℝ)-1) by linarith)
    (show 0≤2*((n:ℝ)+4)-((n:ℝ)+41/50) by linarith)
  nlinarith only [hPair,hPos,hPos',hn']

#print axioms paw_upper_pair_bounds
#print axioms weight_upper_of_harmonic
end PawWindow


namespace PawWindow
open Matrix Finset PawLargestFence
open scoped BigOperators Matrix

theorem two_large_weights_disj (n a b c : Nat) (hn : 8≤n)
    (h : 2≤Fintype.card {i // n-1≤triangleWeights a b c i}) :
    (n-1≤a ∧ n-1≤b) ∨ (n-1≤a ∧ n-1≤c) ∨ (n-1≤b ∧ n-1≤c) := by
  classical
  rw [Fintype.card_subtype,Finset.card_eq_sum_ones,Finset.sum_filter] at h
  have hlast : ¬n-1≤1 := by omega
  change 2≤∑ i : Fin 4, (if n-1≤triangleWeights a b c i then (1:Nat) else 0) at h
  rw [Fin.sum_univ_four] at h
  change 2≤(if n-1≤a then 1 else 0)+(if n-1≤b then 1 else 0)+
    (if n-1≤c then 1 else 0)+(if n-1≤1 then 1 else 0) at h
  by_cases ha : n-1≤a <;> by_cases hb : n-1≤b <;> by_cases hc : n-1≤c <;>
    simp [ha,hb,hc,hlast] at h ⊢

theorem paw_singleton_offset_window (n a b c : Nat) (hn : 8≤n)
    (hSum : a+b+c+1=3*n)
    (hP : (pawQ (Real.sqrt a) (Real.sqrt b) (Real.sqrt c) 1).IsHermitian)
    (hNear : 2≤Fintype.card {i // (n:ℝ)-41/50 < -hP.eigenvalues i})
    (hFar : Fintype.card {i // (n:ℝ)+41/50 < -hP.eigenvalues i}=0) :
    (-7≤(a:ℤ)-n ∧ (a:ℤ)-n≤3) ∧
    (-7≤(b:ℤ)-n ∧ (b:ℤ)-n≤3) ∧
    (-7≤(c:ℤ)-n ∧ (c:ℤ)-n≤3) := by
  have hTwo := two_large_weights_disj n a b c hn
    (at_least_two_large_of_paw_negative_cut n a b c hn hP hNear)
  obtain ⟨hab,hac,hbc⟩ := paw_upper_pair_bounds a b c ((n:ℝ)+41/50) hP hFar
  have hba : 2*(b:ℝ)*a≤((n:ℝ)+41/50)*((b:ℝ)+a) := by nlinarith only [hab]
  have hca : 2*(c:ℝ)*a≤((n:ℝ)+41/50)*((c:ℝ)+a) := by nlinarith only [hac]
  have hcb : 2*(c:ℝ)*b≤((n:ℝ)+41/50)*((c:ℝ)+b) := by nlinarith only [hbc]
  have hUpper : a≤n+3 ∧ b≤n+3 ∧ c≤n+3 := by
    rcases hTwo with ⟨hA,hB⟩ | ⟨hA,hC⟩ | ⟨hB,hC⟩
    · exact ⟨weight_upper_of_harmonic n a b hn hB hab,weight_upper_of_harmonic n b a hn hA hba,
        weight_upper_of_harmonic n c a hn hA hca⟩
    · exact ⟨weight_upper_of_harmonic n a c hn hC hac,weight_upper_of_harmonic n b a hn hA hba,
        weight_upper_of_harmonic n c a hn hA hca⟩
    · exact ⟨weight_upper_of_harmonic n a b hn hB hab,weight_upper_of_harmonic n b c hn hC hbc,
        weight_upper_of_harmonic n c b hn hB hcb⟩
  obtain ⟨hA,hB,hC⟩ := hUpper
  exact ⟨⟨by omega,by omega⟩,⟨by omega,by omega⟩,⟨by omega,by omega⟩⟩

#print axioms paw_singleton_offset_window
end PawWindow


namespace PawUnbounded
open Matrix SpectralConjecture20 PawLargestFence Finset
open scoped BigOperators Matrix

theorem all_coords_error_lt_fence {m : Type*} [Fintype m] (x y : m → ℝ)
    (h : (∑ i,(x i-y i)^2)<(2/3:ℝ)) (i : m) :
    |x i-y i|<(41/50:ℝ) := by
  classical
  have hs := Finset.single_le_sum (s := Finset.univ) (f := fun i => (x i-y i)^2)
    (fun j _ => sq_nonneg (x j-y j)) (Finset.mem_univ i)
  have hh := hs.trans_lt h
  by_contra! hc
  have ht := mul_nonneg (show 0≤|x i-y i|-41/50 by linarith)
    (show 0≤|x i-y i|+41/50 by linarith [abs_nonneg (x i-y i)])
  nlinarith only [ht,hh,sq_abs (x i-y i)]

theorem close_large_singleton_paw_is_Hn (n a b c z : Nat) (hn : 24≤n)
    (ha : 0<a) (hb : 0<b) (hc : 0<c) (hBC : b≤c) (hSum : a+b+c+1=3*n)
    (hF : (withIsolates seedPaw (singletonWeights a b c) z).IsHermitian)
    (hN : 4≤Fintype.card (Vertices (singletonWeights a b c) ⊕ Fin z))
    (y : Fin (Fintype.card (Vertices (singletonWeights a b c) ⊕ Fin z)) → ℝ)
    (hy0 : y ⟨0,by omega⟩=2*(n:ℝ)) (hy1 : y ⟨1,by omega⟩=0)
    (hy2 : y (Fin.rev ⟨1,by omega⟩)= -(n:ℝ))
    (hy3 : y (Fin.rev ⟨0,by omega⟩)= -(n:ℝ))
    (hyLow : ∀ i, -(n:ℝ)≤y i)
    (hClose : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(2/3:ℝ)) :
    a+1=n ∧ b=n ∧ c=n := by
  let w := singletonWeights a b c
  have hw (i : Fin 4) : 0<w i := by
    fin_cases i
    · exact ha
    · exact hb
    · exact hc
    · exact Nat.zero_lt_succ 0
  let N := Fintype.card (Vertices w ⊕ Fin z)
  let i1 : Fin N := ⟨1,by change 1 < Fintype.card (Vertices (singletonWeights a b c) ⊕ Fin z); omega⟩
  let f : Fin N → ℝ := hF.eigenvalues₀
  let qL := (n:ℝ)-41/50
  let qU := (n:ℝ)+41/50
  have hnR : (24:ℝ)≤n := by exact_mod_cast hn
  have hqL : 0≤qL := by dsimp [qL]; linarith
  have hqU : 0≤qU := by dsimp [qU]; linarith
  have hDiv (i : Fin N) := abs_lt.mp (all_coords_error_lt_fence f y hClose i)
  have hNearAt : qL < -f i1.rev := by
    have h := (hDiv i1.rev).2
    change y i1.rev= -(n:ℝ) at hy2
    rw [hy2] at h
    dsimp [qL]
    linarith
  have hNear0 : 2≤Fintype.card {i : Fin N // qL < -f i.rev} := by
    have h := (cut_count_rank_iff _ (antitone_neg_rev f hF.eigenvalues₀_antitone) qL i1).mp hNearAt
    exact h
  rw [←signed_reversed_cuts f] at hNear0
  have hFar0 : Fintype.card {i // qU < -f i}=0 := by
    apply Fintype.card_eq_zero_iff.mpr
    refine ⟨fun i => ?_⟩
    have hl := (hDiv i.val).1
    have hly := hyLow i.val
    have hp := i.property
    dsimp [qU] at hp
    linarith
  let P := pawQ (Real.sqrt a) (Real.sqrt b) (Real.sqrt c) 1
  have hEq : weightedQuotient seedPaw w=P := by
    rw [seed_paw_exact]
    change weightedQuotient paw (pawWeights a b c 1)=_
    rw [paw_quotient_explicit]
    simp [P]
  let hQ := weightedQuotient_isHermitian seedPaw seedHerm w
  have hP : P.IsHermitian := hEq ▸ hQ
  have hCut (q : ℝ) (hq : 0≤q) :
      Fintype.card {i // q < -f i} = Fintype.card {i // q < -hP.eigenvalues i} := by
    have e₁ := withIsolates_ordered_cut_count seedPaw seedHerm w hw z hF (-1) q hq
    have e₂ := cut_index_of_matrix_eq hEq hQ hP (-1) q
    simpa only [neg_one_mul] using e₁.trans e₂
  rw [hCut qL hqL] at hNear0
  rw [hCut qU hqU] at hFar0
  have hWin := PawWindow.paw_singleton_offset_window n a b c (by omega) hSum hP hNear0 hFar0
  by_contra hne
  have hDis := weighted_singleton_paw_large_excluded n a b c z hn
    hWin.1 hWin.2.1 ⟨hBC,hWin.2.2.2⟩ hSum hne hF hN y hy0 hy1 hy2 hy3
  exact hClose.not_ge hDis

#print axioms close_large_singleton_paw_is_Hn
end PawUnbounded



namespace PawSmallCore

structure Witness where
  n : Nat
  a : Nat
  b : Nat
  c : Nat
  h : Nat
  j : Nat
  k : Nat
  l : Nat

def witnesses : List Witness := [
⟨3,2,2,4,15,12,5,7⟩,
  ⟨3,3,2,3,10,12,9,7⟩,
  ⟨4,3,3,5,13,12,7,8⟩,
  ⟨4,4,3,4,10,12,10,8⟩,
  ⟨5,4,4,6,12,12,7,8⟩,
  ⟨5,5,4,5,10,12,10,8⟩,
  ⟨6,5,5,7,12,12,8,8⟩,
  ⟨6,6,5,6,10,12,10,8⟩,
  ⟨7,5,7,8,14,15,10,9⟩,
  ⟨7,6,6,8,12,12,8,9⟩,
  ⟨7,7,6,7,10,11,10,9⟩,
  ⟨8,6,8,9,13,15,10,9⟩,
  ⟨8,7,7,9,11,11,9,9⟩,
  ⟨8,8,7,8,10,11,10,9⟩,
  ⟨9,7,9,10,13,14,10,9⟩,
  ⟨9,8,8,10,11,11,9,9⟩,
  ⟨9,9,8,9,10,11,10,9⟩,
  ⟨10,8,10,11,12,14,10,9⟩,
  ⟨10,9,9,11,11,11,9,9⟩,
  ⟨10,10,9,10,10,11,10,9⟩,
  ⟨11,9,11,12,12,14,10,9⟩,
  ⟨11,10,10,12,11,11,9,9⟩,
  ⟨11,11,10,11,10,11,11,9⟩,
  ⟨12,10,12,13,12,13,10,9⟩,
  ⟨12,11,11,13,11,11,10,9⟩,
  ⟨12,12,11,12,10,11,11,9⟩,
  ⟨13,11,13,14,12,13,10,9⟩,
  ⟨13,12,12,14,11,11,10,9⟩,
  ⟨13,13,12,13,10,11,11,9⟩,
  ⟨14,12,14,15,12,13,11,9⟩,
  ⟨14,13,13,15,11,11,10,9⟩,
  ⟨14,14,13,14,10,11,11,9⟩,
  ⟨15,13,15,16,11,13,11,9⟩,
  ⟨15,14,14,16,10,11,10,9⟩,
  ⟨15,15,14,15,10,11,11,9⟩,
  ⟨16,14,16,17,11,13,11,9⟩,
  ⟨16,15,15,17,10,11,10,9⟩,
  ⟨16,16,15,16,10,11,11,9⟩,
  ⟨17,15,17,18,11,13,11,9⟩,
  ⟨17,16,16,18,10,11,10,9⟩,
  ⟨17,17,16,17,10,11,11,9⟩,
  ⟨18,16,18,19,11,13,11,9⟩,
  ⟨18,17,17,19,10,11,10,9⟩,
  ⟨18,18,17,18,10,11,11,9⟩,
  ⟨19,17,19,20,11,13,11,9⟩,
  ⟨19,18,18,20,10,11,10,9⟩,
  ⟨19,19,18,19,10,11,11,9⟩,
  ⟨20,18,20,21,11,12,11,9⟩,
  ⟨20,19,19,21,10,11,10,9⟩,
  ⟨20,20,19,20,10,11,11,9⟩,
  ⟨21,19,21,22,11,12,11,9⟩,
  ⟨21,20,20,22,10,11,10,9⟩,
  ⟨21,21,20,21,10,11,11,9⟩,
  ⟨22,20,22,23,11,12,11,9⟩,
  ⟨22,21,21,23,10,11,10,9⟩,
  ⟨22,22,21,22,10,11,11,9⟩,
  ⟨23,21,23,24,11,12,11,9⟩,
  ⟨23,22,22,24,10,11,10,9⟩,
  ⟨23,23,22,23,10,11,11,9⟩
]

def E (a b c : Nat) : Int := (a:Int)*b+(a:Int)*c+(b:Int)*c+a
def F (a b c : Nat) : Int := 2*(a:Int)*b*c
def G (a b c : Nat) : Int := (a:Int)*b*c

def cutValue (a b c : Nat) (u v : Int) : Int :=
  u^4-E a b c*u^2*v^2-F a b c*u*v^3+G a b c*v^4

def upper (a b c : Nat) (u v : Int) : Bool :=
  decide (0≤cutValue a b c u v) &&
  decide (0≤4*u^3-2*E a b c*u*v^2-F a b c*v^3) &&
  decide (0≤6*u^2-E a b c*v^2)

def target (n a b c : Nat) : Bool := decide (a+1=n ∧ b=n ∧ c=n)
def first (n a b c : Nat) : Bool := upper a b c (100*(n:Int)-41) 50
def second (n a b c : Nat) : Bool := decide (cutValue a b c (-50*(n:Int)+41) 50<0)

def valid (n a b c : Nat) (w : Witness) : Bool :=
  decide (w.n=n ∧ w.a=a ∧ w.b=b ∧ w.c=c) &&
  decide (w.h≤20 ∧ w.j≤20 ∧ w.k≤20 ∧ w.l≤20) &&
  decide (800≤3*(w.h^2+w.j^2+w.k^2+w.l^2)) &&
  upper a b c (40*(n:Int)-(w.h:Int)) 20 &&
  decide (cutValue a b c (-20*(n:Int)+(w.j:Int)) 20<0) &&
  decide (cutValue a b c (-20*(n:Int)-(w.k:Int)) 20<0) &&
  decide (0<cutValue a b c (w.l:Int) 20)

def row (n a b c : Nat) : Bool :=
  target n a b c || first n a b c || second n a b c || witnesses.any (valid n a b c)

def check (n : Nat) : Bool :=
  (List.range (3*n-3)).all fun aa =>
   let a := aa+1
   let r := 3*n-a-1
   (List.range (r/2)).all fun bb => row n a (bb+1) (r-(bb+1))

set_option maxRecDepth 10000
set_option maxHeartbeats 0
theorem checked3 : check 3=true := by decide +kernel
theorem checked4 : check 4=true := by decide +kernel
theorem checked5 : check 5=true := by decide +kernel
theorem checked6 : check 6=true := by decide +kernel
theorem checked7 : check 7=true := by decide +kernel
theorem checked8 : check 8=true := by decide +kernel
theorem checked9 : check 9=true := by decide +kernel
theorem checked10 : check 10=true := by decide +kernel
theorem checked11 : check 11=true := by decide +kernel
theorem checked12 : check 12=true := by decide +kernel
theorem checked13 : check 13=true := by decide +kernel
theorem checked14 : check 14=true := by decide +kernel
theorem checked15 : check 15=true := by decide +kernel
theorem checked16 : check 16=true := by decide +kernel
theorem checked17 : check 17=true := by decide +kernel
theorem checked18 : check 18=true := by decide +kernel
theorem checked19 : check 19=true := by decide +kernel
theorem checked20 : check 20=true := by decide +kernel
theorem checked21 : check 21=true := by decide +kernel
theorem checked22 : check 22=true := by decide +kernel
theorem checked23 : check 23=true := by decide +kernel

theorem all_checked (n : Nat) (hn : 3≤n) (hN : n≤23) : check n = true := by
  have h : n=3 ∨ n=4 ∨ n=5 ∨ n=6 ∨ n=7 ∨ n=8 ∨ n=9 ∨ n=10 ∨ n=11 ∨ n=12 ∨ n=13 ∨ n=14 ∨ n=15 ∨ n=16 ∨ n=17 ∨ n=18 ∨ n=19 ∨ n=20 ∨ n=21 ∨ n=22 ∨ n=23 := by omega
  rcases h with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact checked3
  · exact checked4
  · exact checked5
  · exact checked6
  · exact checked7
  · exact checked8
  · exact checked9
  · exact checked10
  · exact checked11
  · exact checked12
  · exact checked13
  · exact checked14
  · exact checked15
  · exact checked16
  · exact checked17
  · exact checked18
  · exact checked19
  · exact checked20
  · exact checked21
  · exact checked22
  · exact checked23

theorem rows_valid (n a b c : Nat) (hn : 3≤n) (hN : n≤23) (ha : 0<a) (hb : 0<b)
    (hbc : b≤c) (hSum : a+b+c+1=3*n) (hne : ¬(a+1=n ∧ b=n ∧ c=n)) :
    first n a b c=true ∨ second n a b c=true ∨ ∃ w, valid n a b c w=true := by
  have H := all_checked n hn hN
  unfold check at H
  have h₁ := List.all_eq_true.mp H (a-1) (List.mem_range.mpr (by omega))
  have ha' : a-1+1=a := by omega
  simp only [ha'] at h₁
  have hr : 3*n-a-1=b+c := by omega
  simp only [hr] at h₁
  have h₂ := List.all_eq_true.mp h₁ (b-1) (List.mem_range.mpr (by omega))
  have hb' : b-1+1=b := by omega
  have hc' : b+c-b=c := by omega
  simp only [hb',hc',row,target,decide_eq_false hne,Bool.false_or,Bool.or_eq_true] at h₂
  rcases h₂ with (h | h) | h
  · exact Or.inl h
  · exact Or.inr (Or.inl h)
  · obtain ⟨w,_,hw⟩ := List.any_eq_true.mp h
    exact Or.inr (Or.inr ⟨w,hw⟩)

#print axioms rows_valid
end PawSmallCore


namespace PawSmall
open PawSmallCore PawLargestFence

theorem lt_zero_of_positive_scale (x c : ℝ) (hc : 0<c) (h : x*c<0) : x<0 := by
  by_contra! hn
  exact (mul_nonneg hn hc.le).not_gt h

theorem zero_lt_of_positive_scale (x c : ℝ) (hc : 0<c) (h : 0<x*c) : 0<x := by
  by_contra! hn
  exact (mul_nonpos_of_nonpos_of_nonneg hn hc.le).not_gt h

theorem zero_le_of_positive_scale (x c : ℝ) (hc : 0<c) (h : 0≤x*c) : 0≤x := by
  by_contra! hn
  exact (mul_neg_of_neg_of_pos hn hc).not_ge h

theorem strict_value_of_neg (a b c : Nat) (u v : Int) (hv : 0<v)
    (h : cutValue a b c u v<0) :
    poly (pawE a b c 1) (pawF a b c) (pawG a b c 1) ((u:ℝ)/(v:ℝ))<0 := by
  dsimp [cutValue,E,F,G] at h
  have hR := Int.cast_lt (R:=ℝ).mpr h
  push_cast at hR
  have hV : (0:ℝ)<v := by exact_mod_cast hv
  dsimp [poly,pawE,pawF,pawG]
  apply lt_zero_of_positive_scale _ _ (pow_pos hV 4)
  field_simp [hV.ne']
  nlinarith only [hR]

theorem strict_value_of_pos (a b c : Nat) (u v : Int) (hv : 0<v)
    (h : 0<cutValue a b c u v) :
    0<poly (pawE a b c 1) (pawF a b c) (pawG a b c 1) ((u:ℝ)/(v:ℝ)) := by
  dsimp [cutValue,E,F,G] at h
  have hR := Int.cast_lt (R:=ℝ).mpr h
  push_cast at hR
  have hV : (0:ℝ)<v := by exact_mod_cast hv
  dsimp [poly,pawE,pawF,pawG]
  apply zero_lt_of_positive_scale _ _ (pow_pos hV 4)
  field_simp [hV.ne']
  nlinarith only [hR]

theorem upper_sound (a b c : Nat) (u v : Int) (hu : 0≤u) (hv : 0<v)
    (h : upper a b c u v=true) (x : ℝ)
    (hr : poly (pawE a b c 1) (pawF a b c) (pawG a b c 1) x=0) :
    x≤(u:ℝ)/(v:ℝ) := by
  unfold upper at h
  rw [Bool.and_eq_true,Bool.and_eq_true] at h
  have h0 := Int.cast_le (R:=ℝ).mpr (of_decide_eq_true h.1.1)
  have h1 := Int.cast_le (R:=ℝ).mpr (of_decide_eq_true h.1.2)
  have h2 := Int.cast_le (R:=ℝ).mpr (of_decide_eq_true h.2)
  dsimp [cutValue,E,F,G] at h0 h1 h2
  push_cast at h0 h1 h2
  have hvR : (0:ℝ)<v := by exact_mod_cast hv
  have huR : 0≤(u:ℝ) := by exact_mod_cast hu
  by_contra! hgt
  have hpos := eval_pos_of_shift_coeff_nonneg (pawE a b c 1) (pawF a b c) (pawG a b c 1)
    ((u:ℝ)/(v:ℝ)) x hgt (div_nonneg huR hvR.le) ?_ ?_ ?_
  · exact hpos.ne' hr
  · dsimp [poly,pawE,pawF,pawG]
    apply zero_le_of_positive_scale _ _ (pow_pos hvR 4)
    field_simp [hvR.ne']
    nlinarith only [h0]
  · dsimp [pawE,pawF]
    apply zero_le_of_positive_scale _ _ (pow_pos hvR 3)
    field_simp [hvR.ne']
    nlinarith only [h1]
  · dsimp [pawE]
    apply zero_le_of_positive_scale _ _ (pow_pos hvR 2)
    field_simp [hvR.ne']
    nlinarith only [h2]

theorem inside_negative_pair (P : ℝ → ℝ) (x₀ x₁ x₂ x₃ t : ℝ)
    (hF : ∀ z, P z=(z-x₀)*(z-x₁)*(z-x₂)*(z-x₃))
    (h0 : t<x₀) (h1 : t<x₁) (hOrd : x₃≤x₂) (hNeg : P t<0) :
    x₃<t ∧ t<x₂ := by
  rw [hF] at hNeg
  have hA : 0<(t-x₀)*(t-x₁) := mul_pos_of_neg_of_neg (sub_neg.mpr h0) (sub_neg.mpr h1)
  have hB : (t-x₂)*(t-x₃)<0 := by
    by_contra! hc
    have h := mul_nonneg hA.le hc
    nlinarith only [h,hNeg]
  constructor
  · by_contra! h
    have hs := mul_nonneg_of_nonpos_of_nonpos (show t-x₂≤0 by linarith) (show t-x₃≤0 by linarith)
    linarith
  · by_contra! h
    have hs := mul_nonneg (show 0≤t-x₂ by linarith) (show 0≤t-x₃ by linarith)
    linarith

theorem second_root_gt_positive (P : ℝ → ℝ) (x₀ x₁ x₂ x₃ t : ℝ)
    (hF : ∀ z, P z=(z-x₀)*(z-x₁)*(z-x₂)*(z-x₃))
    (h0 : t<x₀) (h2 : x₂<t) (h3 : x₃<t) (hPos : 0<P t) :
    t<x₁ := by
  rw [hF] at hPos
  by_contra! hn
  have h := mul_nonpos_of_nonpos_of_nonneg
    (mul_nonpos_of_nonpos_of_nonneg (sub_nonpos.mpr h0.le) (sub_nonneg.mpr hn))
    (mul_nonneg (sub_nonneg.mpr h2.le) (sub_nonneg.mpr h3.le))
  nlinarith only [h,hPos]

theorem abs_error_of_sq_lt (x : ℝ) (h : x^2<(2/3:ℝ)) : |x|<(41/50:ℝ) := by
  by_contra! hh
  have he := mul_nonneg (show 0≤|x|-41/50 by linarith) (show 0≤|x|+41/50 by linarith)
  nlinarith only [he,h,sq_abs x]

#print axioms upper_sound
#print axioms inside_negative_pair
#print axioms second_root_gt_positive
end PawSmall


namespace PawSmall
open PawSmallCore PawLargestFence

theorem squared_mono_nonneg (x y : ℝ) (hy : 0≤y) (h : y≤x) : y^2≤x^2 := by
  have hh := mul_nonneg (show 0≤x-y by linarith) (show 0≤x+y by linarith)
  nlinarith only [hh]

theorem close_small_paw_quartet_is_Hn (n a b c : Nat) (hn : 3≤n) (hN : n≤23)
    (ha : 0<a) (hb : 0<b) (hbc : b≤c) (hSum : a+b+c+1=3*n)
    (x₀ x₁ x₂ x₃ : ℝ) (hOrd : x₃≤x₂)
    (hF : ∀ q, poly (pawE a b c 1) (pawF a b c) (pawG a b c 1) q =
      (q-x₀)*(q-x₁)*(q-x₂)*(q-x₃))
    (hScore : (x₀-2*(n:ℝ))^2+x₁^2+(x₂+(n:ℝ))^2+(x₃+(n:ℝ))^2<(2/3:ℝ)) :
    a+1=n ∧ b=n ∧ c=n := by
  by_contra hne
  have M0 := sq_nonneg (x₀-2*(n:ℝ))
  have M1 := sq_nonneg x₁
  have M2 := sq_nonneg (x₂+(n:ℝ))
  have M3 := sq_nonneg (x₃+(n:ℝ))
  have E0 := abs_lt.mp (abs_error_of_sq_lt (x₀-2*(n:ℝ)) (by nlinarith only [hScore,M1,M2,M3]))

  have E1 := abs_lt.mp (abs_error_of_sq_lt x₁ (by nlinarith only [hScore,M0,M2,M3]))
  have E2 := abs_lt.mp (abs_error_of_sq_lt (x₂+(n:ℝ)) (by nlinarith only [hScore,M0,M1,M3]))
  have E3 := abs_lt.mp (abs_error_of_sq_lt (x₃+(n:ℝ)) (by nlinarith only [hScore,M0,M1,M2]))
  have hnR : (3:ℝ)≤n := by exact_mod_cast hn
  let P := poly (pawE a b c 1) (pawF a b c) (pawG a b c 1)
  have hRoot : P x₀=0 := by dsimp [P]; rw [hF]; simp
  rcases rows_valid n a b c hn hN ha hb hbc hSum hne with h | h | ⟨w,hw⟩
  · have hu : (0:ℤ)≤100*(n:ℤ)-41 := by omega
    have hL := upper_sound a b c _ _ hu (by decide) h x₀ hRoot
    push_cast at hL
    linarith only [hL,E0.1]
  · let q : ℝ := -(n:ℝ)+41/50
    have hh : cutValue a b c (-50*(n:ℤ)+41) 50<0 := of_decide_eq_true h
    have hp := strict_value_of_neg _ _ _ _ _ (by decide) hh
    push_cast at hp
    have he : ((-50*(n:ℝ)+41)/50)=q := by dsimp [q]; ring
    have hp' : P q<0 := by simpa only [P,he] using hp
    have hz := inside_negative_pair P x₀ x₁ x₂ x₃ q hF (by dsimp [q]; linarith)
      (by dsimp [q]; linarith) hOrd hp'
    dsimp [q] at hz
    linarith only [E2.2,hz.2]
  · unfold valid at hw
    simp only [Bool.and_eq_true] at hw
    obtain ⟨⟨⟨⟨⟨⟨_,hBound⟩,hMass⟩,hUpper⟩,hPlus⟩,hMinus⟩,hPos⟩ := hw
    have hB : w.h≤20 ∧ w.j≤20 ∧ w.k≤20 ∧ w.l≤20 := of_decide_eq_true hBound
    have hMassN : 800≤3*(w.h^2+w.j^2+w.k^2+w.l^2) := of_decide_eq_true hMass
    have hNR : (800:ℝ)≤3*((w.h:ℝ)^2+(w.j:ℝ)^2+(w.k:ℝ)^2+(w.l:ℝ)^2) := by exact_mod_cast hMassN
    have hj : (w.j:ℝ)≤20 := by exact_mod_cast hB.2.1
    have hl : (w.l:ℝ)≤20 := by exact_mod_cast hB.2.2.2
    have hwj : (0:ℝ)≤w.j := Nat.cast_nonneg _
    have hwk : (0:ℝ)≤w.k := Nat.cast_nonneg _
    have hwl : (0:ℝ)≤w.l := Nat.cast_nonneg _
    have hwh : (0:ℝ)≤w.h := Nat.cast_nonneg _
    have hhA : (0:ℤ)≤40*(n:ℤ)-(w.h:ℤ) := by have := hB.1; omega
    have hUpperX := upper_sound a b c _ _ hhA (by decide) hUpper x₀ hRoot
    push_cast at hUpperX
    let qp : ℝ := -(n:ℝ)+(w.j:ℝ)/20
    let qm : ℝ := -(n:ℝ)-(w.k:ℝ)/20
    let qt : ℝ := (w.l:ℝ)/20
    have hp₀ : cutValue a b c (-20*(n:ℤ)+(w.j:ℤ)) 20<0 := of_decide_eq_true hPlus
    have hm₀ : cutValue a b c (-20*(n:ℤ)-(w.k:ℤ)) 20<0 := of_decide_eq_true hMinus
    have ht₀ : 0<cutValue a b c (w.l:ℤ) 20 := of_decide_eq_true hPos
    have hpV := strict_value_of_neg _ _ _ _ _ (by decide) hp₀
    have hmV := strict_value_of_neg _ _ _ _ _ (by decide) hm₀
    have htV := strict_value_of_pos _ _ _ _ _ (by decide) ht₀
    push_cast at hpV hmV htV
    have ep : (-20*(n:ℝ)+(w.j:ℝ))/20=qp := by dsimp [qp]; ring
    have em : (-20*(n:ℝ)-(w.k:ℝ))/20=qm := by dsimp [qm]; ring
    have hpV' : P qp<0 := by simpa only [P,ep] using hpV
    have hmV' : P qm<0 := by simpa only [P,em] using hmV
    have htV' : 0<P qt := htV
    have hp := (inside_negative_pair P x₀ x₁ x₂ x₃ qp hF
      (by dsimp [qp]; linarith) (by dsimp [qp]; linarith) hOrd hpV').2
    have hm := (inside_negative_pair P x₀ x₁ x₂ x₃ qm hF
      (by dsimp [qm]; linarith) (by dsimp [qm]; linarith) hOrd hmV').1
    have ht := second_root_gt_positive P x₀ x₁ x₂ x₃ qt hF
      (by dsimp [qt]; linarith) (by dsimp [qt]; linarith) (by dsimp [qt]; linarith) htV'
    dsimp [qp,qm,qt] at hp hm ht
    have s0 := squared_mono_nonneg (2*(n:ℝ)-x₀) ((w.h:ℝ)/20)
      (by positivity) (by linarith)
    have s1 := squared_mono_nonneg x₁ ((w.l:ℝ)/20) (by positivity) ht.le
    have s2 := squared_mono_nonneg (x₂+(n:ℝ)) ((w.j:ℝ)/20) (by positivity) (by linarith)
    have s3 := squared_mono_nonneg (-(x₃+(n:ℝ))) ((w.k:ℝ)/20) (by positivity) (by linarith)
    nlinarith only [s0,s1,s2,s3,hNR,hScore]

#print axioms close_small_paw_quartet_is_Hn
end PawSmall


namespace PawUnbounded
open Matrix SpectralConjecture20 PawLargestFence Conj20CutCert
open scoped BigOperators Matrix

def oneSeedRows : Weights := #[1,1,1,1]
def oneSeedC : Cert := ⟨#[#[1,-1,1,1],#[1,1,1,-1],#[0,0,-1,-1],#[0,0,0,2]], #[2,-2,-2,2], #[#[-2,-2,-4,-2],#[2,-2,0,-2],#[0,0,4,2],#[0,0,0,-2]], -4⟩
def oneSeedX : Rows := #[#[1,1,2,1],#[1,-1,0,-1],#[0,0,2,1],#[0,0,0,1]]

def oneSeedW : Fin 4 → Nat := weightFn 4 oneSeedRows

theorem one_seed_count :
  Fintype.card {j // 0<(weightedQuotient_isHermitian seedPaw seedHerm oneSeedW).eigenvalues j}=2 := by
  have hw (j : Fin 4) : 0<oneSeedW j := by fin_cases j <;> decide
  have hd (j : Fin 4) : oneSeedW j ∣ 1 := by fin_cases j <;> decide
  have he := cached_cut_count_sound 4 seedRows oneSeedRows 1 1 1 0 oneSeedC oneSeedX
    (by decide +kernel) seedHerm hw (by decide) (by decide) hd
  have hh : countPos 4 oneSeedC.d=2 := by decide +kernel
  rw [hh] at he
  norm_num [oneSeedW] at he ⊢
  exact he

theorem singleton_second_pos (a b c : Nat) (ha : 0<a) (hb : 0<b) (hc : 0<c) :
    0 < singletonQEigen a b c 1 := by
  let w := singletonWeights a b c
  let hB := weightedQuotient_isHermitian seedPaw seedHerm w
  have hw (j : Fin 4) : oneSeedW j≤w j := by
    fin_cases j <;> first
    | exact ha
    | exact hb
    | exact hc
    | exact Nat.le_refl 1
  have hs (j : Fin 4) : 0<oneSeedW j := by fin_cases j <;> decide
  have hC := weighted_spectral_cut_mono seedPaw seedHerm oneSeedW w hs hw 1 0 (by norm_num)
  simp only [one_mul,one_seed_count] at hC
  rw [index_cut_eigenvalues₀ _ hB (fun x => 0<x)] at hC
  let j : Fin (Fintype.card (Fin 4)) := Fin.cast (Fintype.card_fin 4).symm 1
  change 0 < hB.eigenvalues₀ j
  apply (cut_count_rank_iff _ hB.eigenvalues₀_antitone _ j).mpr
  have hj : j.val=1 := by rfl
  omega

theorem singleton_factored_poly (a b c : Nat) (z : ℝ) :
    let x := singletonQEigen a b c
    poly (pawE a b c 1) (pawF a b c) (pawG a b c 1) z =
      (z-x 0)*(z-x 1)*(z-x 2)*(z-x 3) := by
  have h := singleton_factored_value a b c (-z)
  dsimp at h ⊢
  rw [neg_neg] at h
  rw [←h]
  ring
#print axioms singleton_second_pos
end PawUnbounded


namespace PawUnbounded
open Matrix SpectralConjecture20 Finset
open scoped BigOperators Matrix

theorem close_small_singleton_paw_is_Hn (n a b c z : Nat) (hn : 3≤n) (hNsmall : n≤23)
    (ha : 0<a) (hb : 0<b) (hc : 0<c)
    (hBC : b≤c) (hSum : a+b+c+1=3*n)
    (hF : (withIsolates seedPaw (singletonWeights a b c) z).IsHermitian)
    (hN : 4≤Fintype.card (Vertices (singletonWeights a b c) ⊕ Fin z))
    (y : Fin (Fintype.card (Vertices (singletonWeights a b c) ⊕ Fin z)) → ℝ)
    (hy0 : y ⟨0,by omega⟩=2*(n:ℝ)) (hy1 : y ⟨1,by omega⟩=0)
    (hy2 : y (Fin.rev ⟨1,by omega⟩)= -(n:ℝ))
    (hy3 : y (Fin.rev ⟨0,by omega⟩)= -(n:ℝ))
    (hClose : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(2/3:ℝ)) : a+1=n ∧ b=n ∧ c=n := by
  let N := Fintype.card (Vertices (singletonWeights a b c) ⊕ Fin z)
  let f : Fin N → ℝ := hF.eigenvalues₀
  let q := singletonQEigen a b c
  let i0 : Fin N := ⟨0,by dsimp [N]; omega⟩
  let i1 : Fin N := ⟨1,by dsimp [N]; omega⟩
  have hf : Antitone f := hF.eigenvalues₀_antitone
  have hq : Antitone q := by
    intro i j hij
    exact (weightedQuotient_isHermitian seedPaw seedHerm (singletonWeights a b c)).eigenvalues₀_antitone hij
  have hcPos (u : ℝ) (hu : 0≤u) :
      Fintype.card {i // u < f i} = Fintype.card {j // u < q j} := by
    simpa only [one_mul] using normalized_paw_sorted_cut a b c z (by omega) (by omega) (by omega) hF 1 u hu
  have hcNeg (u : ℝ) (hu : 0≤u) :
      Fintype.card {i : Fin N // u < -f i.rev} = Fintype.card {j : Fin 4 // u < -q j.rev} := by
    rw [←signed_reversed_cuts f,←signed_reversed_cuts q]
    simpa only [neg_one_mul] using normalized_paw_sorted_cut a b c z (by omega) (by omega) (by omega) hF (-1) u hu
  have hqP : 0<q 1 := singleton_second_pos a b c ha hb hc
  have hfP : 0<f i1 := by
    rw [cut_count_rank_iff _ hf, hcPos _ (by norm_num)]
    change 1 < _
    exact (cut_count_rank_iff _ hq _ 1).mp hqP
  have he1 : f i1=q 1 :=
    equal_coord_of_nonnegative_cut_counts _ _ hf hq _ _ rfl (by linarith) (by linarith) hcPos
  have he0 : f i0=q 0 :=
    equal_coord_of_nonnegative_cut_counts _ _ hf hq _ _ rfl
      ((by linarith : 0≤f i1).trans (hf (by change (0:Nat)≤1; exact Nat.zero_le _)))
      ((by linarith : 0≤q 1).trans (hq (by decide))) hcPos
  have hs (i : Fin N) : (f i-y i)^2<(2/3:ℝ) := by
    have h := Finset.single_le_sum (s := Finset.univ) (f := fun i => (f i-y i)^2)
      (fun j _ => sq_nonneg (f j-y j)) (Finset.mem_univ i)
    exact h.trans_lt hClose
  have hNegAt (i : Fin N) (hY : y i = -(n:ℝ)) : (2:ℝ)< -f i := by
    have hnR : (3:ℝ)≤n := by exact_mod_cast hn
    have h := hs i
    rw [hY] at h
    by_contra! hNo
    have ht := mul_nonneg (show 0≤f i+(n:ℝ)-1 by linarith) (show 0≤f i+(n:ℝ)+1 by linarith)
    nlinarith only [h,ht]
  have hnF₁ := hNegAt i1.rev hy2
  have hnF₀ := hNegAt i0.rev hy3
  have hfr := antitone_neg_rev f hf
  have hqr := antitone_neg_rev q hq
  have sortNegative (i : Fin N) (j : Fin 4) (hij : i.val=j.val) (hFNeg : (2:ℝ)< -f i.rev) :
      f i.rev=q j.rev := by
    have hqNeg : (2:ℝ)< -q j.rev := by
      apply (cut_count_rank_iff _ hqr 2 j).mpr
      rw [←hij,←hcNeg _ (by norm_num)]
      exact (cut_count_rank_iff _ hfr 2 i).mp hFNeg
    have he := equal_coord_of_nonnegative_cut_counts _ _ hfr hqr i j hij
      (by linarith) (by linarith) hcNeg
    linarith only [he]
  have he2 : f i1.rev=q 2 := sortNegative i1 1 rfl hnF₁
  have he3 : f i0.rev=q 3 := sortNegative i0 0 rfl hnF₀
  let eFun : Fin 4 → Fin N := ![i0,i1,i1.rev,i0.rev]
  have hInj : Function.Injective eFun := by
    intro i j he
    have hv := congrArg Fin.val he
    fin_cases i <;> fin_cases j <;>
      simp [eFun,i0,i1,Fin.val_rev] at hv ⊢ <;> omega
  let e : Fin 4 ↪ Fin N := ⟨eFun,hInj⟩
  have hsum := sum_of_four_coords_le (fun j => (f j-y j)^2)
    (fun j => sq_nonneg (f j-y j)) e
  change (f i0-y i0)^2+(f i1-y i1)^2+(f i1.rev-y i1.rev)^2+(f i0.rev-y i0.rev)^2≤_ at hsum
  change y i0=2*(n:ℝ) at hy0
  change y i1.rev= -(n:ℝ) at hy2
  change y i0.rev= -(n:ℝ) at hy3
  rw [he0,he1,he2,he3,hy0,hy1,hy2,hy3,sub_zero,sub_neg_eq_add,sub_neg_eq_add] at hsum
  exact PawSmall.close_small_paw_quartet_is_Hn n a b c hn hNsmall ha hb hBC hSum
    (q 0) (q 1) (q 2) (q 3) (hq (by decide)) (singleton_factored_poly a b c) (hsum.trans_lt hClose)

#print axioms close_small_singleton_paw_is_Hn
end PawUnbounded


namespace PawIsolate
open Matrix Finset PawLargestFence
open scoped BigOperators Matrix

theorem paw_quad_upper_mass (a b c : ℝ) (ha : 0≤a) (hb : 0≤b) (hc : 0≤c)
    (x : Fin 4 → ℝ) :
    x ⬝ᵥ ((pawQ a b c 1) *ᵥ x) ≤ (2/3:ℝ)*(a^2+b^2+c^2+1)*(∑ i,(x i)^2) := by
  let X := a* |x 0|
  let Y := b* |x 1|+|x 3|
  let Z := c* |x 2|
  have ax (i j : Fin 4) : x i*x j≤|x i| * |x j| := by
    rw [←abs_mul]
    exact le_abs_self _
  have hh₁ := mul_le_mul_of_nonneg_left (ax 0 1) (mul_nonneg ha hb)
  have hh₂ := mul_le_mul_of_nonneg_left (ax 0 2) (mul_nonneg ha hc)
  have hh₃ := mul_le_mul_of_nonneg_left (ax 0 3) ha
  have hh₄ := mul_le_mul_of_nonneg_left (ax 1 2) (mul_nonneg hb hc)
  have hExtra := mul_nonneg (mul_nonneg hc (abs_nonneg (x 2))) (abs_nonneg (x 3))
  have hQ : x ⬝ᵥ ((pawQ a b c 1) *ᵥ x) ≤ 2*(X*Y+X*Z+Y*Z) := by
    simp [dotProduct,Matrix.mulVec,Fin.sum_univ_four,pawQ,X,Y,Z]
    nlinarith only [hh₁,hh₂,hh₃,hh₄,hExtra]
  have hMid : 2*(X*Y+X*Z+Y*Z)≤(2/3:ℝ)*(X+Y+Z)^2 := by
    nlinarith only [sq_nonneg (X-Y),sq_nonneg (X-Z),sq_nonneg (Y-Z)]
  have hS := Finset.sum_mul_sq_le_sq_mul_sq (Finset.univ : Finset (Fin 4))
    (![a,b,c,1]:Fin 4→ℝ) (fun i => |x i|)
  simp [Fin.sum_univ_four,sq_abs] at hS
  have hS' : (X+Y+Z)^2≤(a^2+b^2+c^2+1)*(∑ i,(x i)^2) := by
    rw [Fin.sum_univ_four]
    dsimp [X,Y,Z]
    nlinarith only [hS]
  exact hQ.trans (hMid.trans (by nlinarith only [hS']))

theorem paw_spectral_cap (a b c : ℝ) (ha : 0≤a) (hb : 0≤b) (hc : 0≤c)
    (hB : (pawQ a b c 1).IsHermitian) (i : Fin 4) :
    hB.eigenvalues i ≤ (2/3:ℝ)*(a^2+b^2+c^2+1) := by
  let x : Fin 4 → ℝ := hB.eigenvectorBasis i
  have hNorm := PiLp.norm_sq_eq_of_L2 (fun _ : Fin 4 => ℝ) (hB.eigenvectorBasis i)
  rw [(hB.eigenvectorBasis).norm_eq_one,one_pow] at hNorm
  have hOne : ∑ j,(x j)^2=1 := by
    simpa only [x,Real.norm_eq_abs,sq_abs] using hNorm.symm
  have hMv : pawQ a b c 1 *ᵥ x = hB.eigenvalues i • x :=
    hB.mulVec_eigenvectorBasis i
  have hBnd := paw_quad_upper_mass a b c ha hb hc x
  rw [hMv,dotProduct_smul,hOne] at hBnd
  have hDot : x ⬝ᵥ x=1 := by simpa [dotProduct,pow_two] using hOne
  simpa [hDot] using hBnd

#print axioms paw_quad_upper_mass
#print axioms paw_spectral_cap
end PawIsolate


namespace PawUnbounded
open Matrix SpectralConjecture20 Finset
open scoped BigOperators Matrix

theorem singleton_ordered_quartet_score_le (n a b c z : Nat) (hn : 3≤n)
    (ha : 0<a) (hb : 0<b) (hc : 0<c)
    (hF : (withIsolates seedPaw (singletonWeights a b c) z).IsHermitian)
    (hN : 4≤Fintype.card (Vertices (singletonWeights a b c) ⊕ Fin z))
    (y : Fin (Fintype.card (Vertices (singletonWeights a b c) ⊕ Fin z)) → ℝ)
    (hy0 : y ⟨0,by omega⟩=2*(n:ℝ)) (hy1 : y ⟨1,by omega⟩=0)
    (hy2 : y (Fin.rev ⟨1,by omega⟩)= -(n:ℝ))
    (hy3 : y (Fin.rev ⟨0,by omega⟩)= -(n:ℝ))
    (hClose : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(2/3:ℝ)) :
    let x := singletonQEigen a b c
    (x 0-2*(n:ℝ))^2+(x 1)^2+(x 2+(n:ℝ))^2+(x 3+(n:ℝ))^2 ≤
      ∑ i,(hF.eigenvalues₀ i-y i)^2 := by
  let N := Fintype.card (Vertices (singletonWeights a b c) ⊕ Fin z)
  let f : Fin N → ℝ := hF.eigenvalues₀
  let q := singletonQEigen a b c
  let i0 : Fin N := ⟨0,by dsimp [N]; omega⟩
  let i1 : Fin N := ⟨1,by dsimp [N]; omega⟩
  have hf : Antitone f := hF.eigenvalues₀_antitone
  have hq : Antitone q := by
    intro i j hij
    exact (weightedQuotient_isHermitian seedPaw seedHerm (singletonWeights a b c)).eigenvalues₀_antitone hij
  have hcPos (u : ℝ) (hu : 0≤u) :
      Fintype.card {i // u < f i} = Fintype.card {j // u < q j} := by
    simpa only [one_mul] using normalized_paw_sorted_cut a b c z (by omega) (by omega) (by omega) hF 1 u hu
  have hcNeg (u : ℝ) (hu : 0≤u) :
      Fintype.card {i : Fin N // u < -f i.rev} = Fintype.card {j : Fin 4 // u < -q j.rev} := by
    rw [←signed_reversed_cuts f,←signed_reversed_cuts q]
    simpa only [neg_one_mul] using normalized_paw_sorted_cut a b c z (by omega) (by omega) (by omega) hF (-1) u hu
  have hqP : 0<q 1 := singleton_second_pos a b c ha hb hc
  have hfP : 0<f i1 := by
    rw [cut_count_rank_iff _ hf, hcPos _ (by norm_num)]
    change 1 < _
    exact (cut_count_rank_iff _ hq _ 1).mp hqP
  have he1 : f i1=q 1 :=
    equal_coord_of_nonnegative_cut_counts _ _ hf hq _ _ rfl (by linarith) (by linarith) hcPos
  have he0 : f i0=q 0 :=
    equal_coord_of_nonnegative_cut_counts _ _ hf hq _ _ rfl
      ((by linarith : 0≤f i1).trans (hf (by change (0:Nat)≤1; exact Nat.zero_le _)))
      ((by linarith : 0≤q 1).trans (hq (by decide))) hcPos
  have hs (i : Fin N) : (f i-y i)^2<(2/3:ℝ) := by
    have h := Finset.single_le_sum (s := Finset.univ) (f := fun i => (f i-y i)^2)
      (fun j _ => sq_nonneg (f j-y j)) (Finset.mem_univ i)
    exact h.trans_lt hClose
  have hNegAt (i : Fin N) (hY : y i = -(n:ℝ)) : (2:ℝ)< -f i := by
    have hnR : (3:ℝ)≤n := by exact_mod_cast hn
    have h := hs i
    rw [hY] at h
    by_contra! hNo
    have ht := mul_nonneg (show 0≤f i+(n:ℝ)-1 by linarith) (show 0≤f i+(n:ℝ)+1 by linarith)
    nlinarith only [h,ht]
  have hnF₁ := hNegAt i1.rev hy2
  have hnF₀ := hNegAt i0.rev hy3
  have hfr := antitone_neg_rev f hf
  have hqr := antitone_neg_rev q hq
  have sortNegative (i : Fin N) (j : Fin 4) (hij : i.val=j.val) (hFNeg : (2:ℝ)< -f i.rev) :
      f i.rev=q j.rev := by
    have hqNeg : (2:ℝ)< -q j.rev := by
      apply (cut_count_rank_iff _ hqr 2 j).mpr
      rw [←hij,←hcNeg _ (by norm_num)]
      exact (cut_count_rank_iff _ hfr 2 i).mp hFNeg
    have he := equal_coord_of_nonnegative_cut_counts _ _ hfr hqr i j hij
      (by linarith) (by linarith) hcNeg
    linarith only [he]
  have he2 : f i1.rev=q 2 := sortNegative i1 1 rfl hnF₁
  have he3 : f i0.rev=q 3 := sortNegative i0 0 rfl hnF₀
  let eFun : Fin 4 → Fin N := ![i0,i1,i1.rev,i0.rev]
  have hInj : Function.Injective eFun := by
    intro i j he
    have hv := congrArg Fin.val he
    fin_cases i <;> fin_cases j <;>
      simp [eFun,i0,i1,Fin.val_rev] at hv ⊢ <;> omega
  let e : Fin 4 ↪ Fin N := ⟨eFun,hInj⟩
  have hsum := sum_of_four_coords_le (fun j => (f j-y j)^2)
    (fun j => sq_nonneg (f j-y j)) e
  change (f i0-y i0)^2+(f i1-y i1)^2+(f i1.rev-y i1.rev)^2+(f i0.rev-y i0.rev)^2≤_ at hsum
  change y i0=2*(n:ℝ) at hy0
  change y i1.rev= -(n:ℝ) at hy2
  change y i0.rev= -(n:ℝ) at hy3
  rw [he0,he1,he2,he3,hy0,hy1,hy2,hy3,sub_zero,sub_neg_eq_add,sub_neg_eq_add] at hsum
  exact hsum

#print axioms singleton_ordered_quartet_score_le
end PawUnbounded


namespace PawIsolate
open Matrix Finset SpectralConjecture20 PawLargestFence PawUnbounded Conj20CutCert
open scoped BigOperators Matrix

theorem same_ordered_values {m : Type*} [Fintype m] [DecidableEq m] (A B : Matrix m m ℝ)
    (h : A=B) (hA : A.IsHermitian) (hB : B.IsHermitian) : hA.eigenvalues₀=hB.eigenvalues₀ := by
  subst B
  rfl

theorem singleton_paw_zero_trace (a b c : Nat) :
    let x := singletonQEigen a b c
    x 0+x 1+x 2+x 3=0 := by
  let w := singletonWeights a b c
  let Q := weightedQuotient seedPaw w
  let hQ := weightedQuotient_isHermitian seedPaw seedHerm w
  let e : Fin 4 ≃ Fin (Fintype.card (Fin 4)) := finCongr (Fintype.card_fin 4).symm
  have hSort : (∑ j : Fin 4, singletonQEigen a b c j) = ∑ i,hQ.eigenvalues₀ i :=
    Equiv.sum_comp e hQ.eigenvalues₀
  have hUnsort : (∑ j : Fin 4,hQ.eigenvalues j) = ∑ i,hQ.eigenvalues₀ i :=
    Equiv.sum_comp (Fintype.equivOfCardEq (Fintype.card_fin 4)).symm hQ.eigenvalues₀
  have hTr : Q.trace=0 := by
    dsimp [Q,w]
    rw [seed_paw_exact]
    change (weightedQuotient paw (pawWeights a b c 1)).trace=0
    rw [paw_quotient_explicit]
    simp [Matrix.trace,Matrix.diag_apply,Fin.sum_univ_four,pawQ]
  have hp := hQ.trace_eq_sum_eigenvalues
  change Q.trace=∑ j,hQ.eigenvalues j at hp
  rw [hUnsort,hTr] at hp
  rw [Fin.sum_univ_four] at hSort
  exact hSort.trans hp.symm

theorem singleton_paw_max_le_mass (a b c : Nat) :
    singletonQEigen a b c 0≤(2/3:ℝ)*((a:ℝ)+(b:ℝ)+(c:ℝ)+1) := by
  let w := singletonWeights a b c
  let P := pawQ (Real.sqrt a) (Real.sqrt b) (Real.sqrt c) 1
  let Q := weightedQuotient seedPaw w
  let hQ := weightedQuotient_isHermitian seedPaw seedHerm w
  have hEq : Q=P := by
    dsimp [Q,w]
    rw [seed_paw_exact]
    change weightedQuotient paw (pawWeights a b c 1)=_
    rw [paw_quotient_explicit]
    simp [P]
  let hP : P.IsHermitian := hEq ▸ hQ
  have hE : hQ.eigenvalues₀=hP.eigenvalues₀ := same_ordered_values Q P hEq hQ hP
  let i : Fin (Fintype.card (Fin 4)) := Fin.cast (Fintype.card_fin 4).symm 0
  change hQ.eigenvalues₀ i≤_
  rw [hE]
  let e : Fin (Fintype.card (Fin 4)) ≃ Fin 4 := Fintype.equivOfCardEq (Fintype.card_fin 4)
  have hI : hP.eigenvalues (e i)=hP.eigenvalues₀ i := by
    unfold Matrix.IsHermitian.eigenvalues
    change hP.eigenvalues₀ (e.symm (e i))=_
    rw [Equiv.symm_apply_apply]
  rw [←hI]
  have hp := paw_spectral_cap (Real.sqrt a) (Real.sqrt b) (Real.sqrt c)
    (Real.sqrt_nonneg _) (Real.sqrt_nonneg _) (Real.sqrt_nonneg _) hP (e i)
  simpa only [Real.sq_sqrt (Nat.cast_nonneg _)] using hp

theorem singleton_paw_isolate_gap (n a b c z : Nat) (hn : 3≤n)
    (ha : 0<a) (hb : 0<b) (hc : 0<c) (hz : 1≤z)
    (hSum : a+b+c+1+z=3*n)
    (hF : (withIsolates seedPaw (singletonWeights a b c) z).IsHermitian)
    (hN : 4≤Fintype.card (Vertices (singletonWeights a b c) ⊕ Fin z))
    (y : Fin (Fintype.card (Vertices (singletonWeights a b c) ⊕ Fin z)) → ℝ)
    (hy0 : y ⟨0,by omega⟩=2*(n:ℝ)) (hy1 : y ⟨1,by omega⟩=0)
    (hy2 : y (Fin.rev ⟨1,by omega⟩)= -(n:ℝ))
    (hy3 : y (Fin.rev ⟨0,by omega⟩)= -(n:ℝ)) :
    (16/27:ℝ)≤∑ i,(hF.eigenvalues₀ i-y i)^2 := by
  by_contra! hClose
  have hs := singleton_ordered_quartet_score_le n a b c z hn ha hb hc hF hN y hy0 hy1 hy2 hy3
    (hClose.trans (by norm_num))
  let x := singletonQEigen a b c
  let δ := 2*(n:ℝ)-x 0
  have hm := singleton_paw_max_le_mass a b c
  have hzR : (1:ℝ)≤z := by exact_mod_cast hz
  have hSumR : (a:ℝ)+(b:ℝ)+(c:ℝ)+1+(z:ℝ)=3*(n:ℝ) := by exact_mod_cast hSum
  have hδ : (2/3:ℝ)≤δ := by dsimp [δ,x]; linarith
  have hδ2 : (4/9:ℝ)≤δ^2 := by
    have hm := mul_nonneg (show 0≤δ-2/3 by linarith) (show 0≤δ+2/3 by linarith)
    nlinarith only [hm]
  have ht : x 0+x 1+x 2+x 3=0 := singleton_paw_zero_trace a b c
  let u := x 1
  let v := x 2+(n:ℝ)
  let w := x 3+(n:ℝ)
  have hD : u+v+w=δ := by dsimp [u,v,w,δ]; linarith only [ht]
  have hSq : δ^2≤3*(u^2+v^2+w^2) := by
    rw [←hD]
    nlinarith only [sq_nonneg (u-v),sq_nonneg (u-w),sq_nonneg (v-w)]
  have hs' : δ^2+u^2+v^2+w^2 ≤ ∑ i,(hF.eigenvalues₀ i-y i)^2 := by
    dsimp [δ,u,v,w,x]
    rw [←neg_sub (singletonQEigen a b c 0) (2*(n:ℝ)),neg_sq]
    exact hs
  nlinarith only [hs',hSq,hδ2,hClose]

#print axioms singleton_paw_max_le_mass
#print axioms singleton_paw_isolate_gap
end PawIsolate


namespace PawIsolate
open Matrix Finset PawLargestFence
open scoped BigOperators Matrix

theorem paw_quad_mass_all_weights (a b c t : ℝ) (ha : 0≤a) (hb : 0≤b) (hc : 0≤c) (ht : 0≤t)
    (x : Fin 4 → ℝ) :
    x ⬝ᵥ ((pawQ a b c t) *ᵥ x) ≤ (2/3:ℝ)*(a^2+b^2+c^2+t^2)*(∑ i,(x i)^2) := by
  let X := a* |x 0|
  let Y := b* |x 1|+t* |x 3|
  let Z := c* |x 2|
  have ax (i j : Fin 4) : x i*x j≤|x i| * |x j| := by
    rw [←abs_mul]
    exact le_abs_self _
  have hh₁ := mul_le_mul_of_nonneg_left (ax 0 1) (mul_nonneg ha hb)
  have hh₂ := mul_le_mul_of_nonneg_left (ax 0 2) (mul_nonneg ha hc)
  have hh₃ := mul_le_mul_of_nonneg_left (ax 0 3) (mul_nonneg ha ht)
  have hh₄ := mul_le_mul_of_nonneg_left (ax 1 2) (mul_nonneg hb hc)
  have hExtra := mul_nonneg (mul_nonneg hc ht) (mul_nonneg (abs_nonneg (x 2)) (abs_nonneg (x 3)))
  have hQ : x ⬝ᵥ ((pawQ a b c t) *ᵥ x) ≤ 2*(X*Y+X*Z+Y*Z) := by
    simp [dotProduct,Matrix.mulVec,Fin.sum_univ_four,pawQ,X,Y,Z]
    nlinarith only [hh₁,hh₂,hh₃,hh₄,hExtra]
  have hMid : 2*(X*Y+X*Z+Y*Z)≤(2/3:ℝ)*(X+Y+Z)^2 := by
    nlinarith only [sq_nonneg (X-Y),sq_nonneg (X-Z),sq_nonneg (Y-Z)]
  have hS := Finset.sum_mul_sq_le_sq_mul_sq (Finset.univ : Finset (Fin 4))
    (![a,b,c,t]:Fin 4→ℝ) (fun i => |x i|)
  simp [Fin.sum_univ_four,sq_abs] at hS
  have hS' : (X+Y+Z)^2≤(a^2+b^2+c^2+t^2)*(∑ i,(x i)^2) := by
    rw [Fin.sum_univ_four]
    dsimp [X,Y,Z]
    nlinarith only [hS]
  exact hQ.trans (hMid.trans (by nlinarith only [hS']))

theorem paw_spectral_cap_all_weights (a b c t : ℝ) (ha : 0≤a) (hb : 0≤b) (hc : 0≤c) (ht : 0≤t)
    (hB : (pawQ a b c t).IsHermitian) (i : Fin 4) :
    hB.eigenvalues i ≤ (2/3:ℝ)*(a^2+b^2+c^2+t^2) := by
  let x : Fin 4 → ℝ := hB.eigenvectorBasis i
  have hNorm := PiLp.norm_sq_eq_of_L2 (fun _ : Fin 4 => ℝ) (hB.eigenvectorBasis i)
  rw [(hB.eigenvectorBasis).norm_eq_one,one_pow] at hNorm
  have hOne : ∑ j,(x j)^2=1 := by
    simpa only [x,Real.norm_eq_abs,sq_abs] using hNorm.symm
  have hMv : pawQ a b c t *ᵥ x = hB.eigenvalues i • x :=
    hB.mulVec_eigenvectorBasis i
  have hBnd := paw_quad_mass_all_weights a b c t ha hb hc ht x
  rw [hMv,dotProduct_smul,hOne] at hBnd
  have hDot : x ⬝ᵥ x=1 := by simpa [dotProduct,pow_two] using hOne
  simpa [hDot] using hBnd

#print axioms paw_quad_mass_all_weights
#print axioms paw_spectral_cap_all_weights
end PawIsolate


namespace PawIsolate
open Matrix Finset SpectralConjecture20 PawLargestFence WeightedSeedPruning
open scoped BigOperators Matrix

theorem paw_full_spectral_cap (w : Fin 4 → Nat) (hw : ∀ i,0<w i)
    (z : Nat) (hF : (withIsolates paw w z).IsHermitian)
    (i : Fin (Fintype.card (Vertices w ⊕ Fin z))) :
    hF.eigenvalues₀ i≤(2/3:ℝ)*∑ j,(w j:ℝ) := by
  let P := pawQ (Real.sqrt (w 0)) (Real.sqrt (w 1)) (Real.sqrt (w 2)) (Real.sqrt (w 3))
  let q : ℝ := (2/3:ℝ)*∑ j,(w j:ℝ)
  have hwEq : w=pawWeights (w 0) (w 1) (w 2) (w 3) := by
    funext j
    fin_cases j <;> rfl
  have hEq : weightedQuotient paw w=P :=
    (congrArg (weightedQuotient paw) hwEq).trans (paw_quotient_explicit _ _ _ _)
  let hQ := weightedQuotient_isHermitian paw paw_herm w
  have hP : P.IsHermitian := hEq ▸ hQ
  have h0 (j : Fin 4) : hP.eigenvalues j≤q := by
    have hC := paw_spectral_cap_all_weights
      (Real.sqrt (w 0)) (Real.sqrt (w 1)) (Real.sqrt (w 2)) (Real.sqrt (w 3))
      (Real.sqrt_nonneg _) (Real.sqrt_nonneg _) (Real.sqrt_nonneg _) (Real.sqrt_nonneg _) hP j
    simpa only [q,Fin.sum_univ_four,Real.sq_sqrt (Nat.cast_nonneg _)] using hC
  have hc : Fintype.card {j // q < hP.eigenvalues j}=0 := by
    apply Fintype.card_eq_zero_iff.mpr
    exact ⟨fun j => (h0 j.val).not_gt j.property⟩
  have hq : 0≤q := by dsimp [q]; positivity
  have cc := (withIsolates_ordered_cut_count paw paw_herm w hw z hF 1 q hq).trans
    (cut_index_of_matrix_eq hEq hQ hP 1 q)
  simp only [one_mul,hc] at cc
  by_contra! hh
  exact (Fintype.card_eq_zero_iff.mp cc).false ⟨i,hh⟩

theorem paw_at_most_one_isolate_of_close (n : Nat) (w : Fin 4 → Nat) (hw : ∀ i,0<w i)
    (z : Nat) (hSum : (∑ j,w j)+z=3*n)
    (hF : (withIsolates paw w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hTop : ∃ i, 2*(n:ℝ)≤y i)
    (hClose : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(2/3:ℝ)) : z≤1 := by
  obtain ⟨i,hi⟩ := hTop
  have hCap := paw_full_spectral_cap w hw z hF i
  have he := (abs_lt.mp (coord_fence hF.eigenvalues₀ y hClose i)).1
  have hS : (∑ j,(w j:ℝ))+(z:ℝ)=3*(n:ℝ) := by exact_mod_cast hSum
  by_contra! h
  have hz : (2:ℝ)≤z := by exact_mod_cast (show 2≤z by omega)
  linarith only [hCap,he,hS,hz,hi]

#print axioms paw_full_spectral_cap
#print axioms paw_at_most_one_isolate_of_close
end PawIsolate


namespace PawIsolate
open Matrix Finset SpectralConjecture20 PawLargestFence PawUnbounded WeightedSeedPruning
open scoped BigOperators Matrix

theorem normalized_paw_below_isolate_gap (n : Nat) (hn : 3≤n) (w : Fin 4 → Nat)
    (hw : ∀ i,0<w i) (hOrder : w 1≤w 2) (z : Nat)
    (hTotal : (∑ i,w i)+z=3*n) (hF : (withIsolates paw w z).IsHermitian)
    (hN : 4≤Fintype.card (Vertices w ⊕ Fin z))
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hy0 : y ⟨0,by omega⟩=2*(n:ℝ)) (hy1 : y ⟨1,by omega⟩=0)
    (hy2 : y (Fin.rev ⟨1,by omega⟩)= -(n:ℝ))
    (hy3 : y (Fin.rev ⟨0,by omega⟩)= -(n:ℝ))
    (hyLow : ∀ i, -(n:ℝ)≤y i)
    (hPos : Fintype.card {i // 0<y i}=1)
    (hNeg : Fintype.card {i // y i= -(n:ℝ)}=2)
    (hClose : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(16/27:ℝ)) :
    z=0 ∧ w 3=1 ∧ w 0+1=n ∧ w 1=n ∧ w 2=n := by
  have hC₂ : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(2/3:ℝ) :=
    hClose.trans (by norm_num)
  have hTop : ∃ i, 2*(n:ℝ)≤y i := ⟨⟨0,by omega⟩,hy0.ge⟩
  have hz := paw_at_most_one_isolate_of_close n w hw z hTotal hF y hTop hC₂
  have hLeaf : w 3=1 := by
    by_contra! hne
    have hp := hw 3
    have hRaw : withIsolates paw w z=withIsolates PMat w z :=
      congrArg (fun M => withIsolates M w z) PawBullPrincipal.paw_raw_exact.symm
    have hR : (withIsolates PMat w z).IsHermitian := hRaw ▸ hF
    have hL := PawBullPrincipal.all_nonsingleton_paw_excluded n hn w hw (by omega)
      hOrder z hz hTotal hR y hPos hNeg hTop
    rw [←same_ordered_values _ _ hRaw hF hR] at hL
    exact hC₂.not_ge hL
  let a := w 0
  let b := w 1
  let c := w 2
  have hS : a+b+c+1+z=3*n := by
    rw [Fin.sum_univ_four,hLeaf] at hTotal
    exact hTotal
  have hW : w=singletonWeights a b c := by
    funext i
    fin_cases i
    · rfl
    · rfl
    · rfl
    · exact hLeaf
  have hGen (v : Fin 4 → Nat) (hv : v=singletonWeights a b c)
      (hG : (withIsolates paw v z).IsHermitian)
      (hSize : 4≤Fintype.card (Vertices v ⊕ Fin z))
      (Y : Fin (Fintype.card (Vertices v ⊕ Fin z)) → ℝ)
      (hy0 : Y ⟨0,by omega⟩=2*(n:ℝ)) (hy1 : Y ⟨1,by omega⟩=0)
      (hy2 : Y (Fin.rev ⟨1,by omega⟩)= -(n:ℝ))
      (hy3 : Y (Fin.rev ⟨0,by omega⟩)= -(n:ℝ))
      (hyLow : ∀ i, -(n:ℝ)≤Y i)
      (hSmall : (∑ i,(hG.eigenvalues₀ i-Y i)^2)<(16/27:ℝ)) :
      z=0 ∧ a+1=n ∧ b=n ∧ c=n := by
    subst v
    let v := singletonWeights a b c
    have hEq : withIsolates paw v z=withIsolates seedPaw v z :=
      congrArg (fun M => withIsolates M v z) seed_paw_exact.symm
    have hR : (withIsolates seedPaw v z).IsHermitian := hEq ▸ hG
    rw [same_ordered_values _ _ hEq hG hR] at hSmall
    have hZ : z=0 := by
      by_contra! hne
      have hGap := singleton_paw_isolate_gap n a b c z hn (hw 0) (hw 1) (hw 2)
        (by omega) hS hR hSize Y hy0 hy1 hy2 hy3
      exact hSmall.not_ge hGap
    refine ⟨hZ,?_⟩
    have hSum : a+b+c+1=3*n := by omega
    have hSmall₂ := hSmall.trans (by norm_num : (16/27:ℝ)<2/3)
    by_cases hI : 24≤n
    · exact close_large_singleton_paw_is_Hn n a b c z hI (hw 0) (hw 1) (hw 2)
        hOrder hSum hR hSize Y hy0 hy1 hy2 hy3 hyLow hSmall₂
    · exact close_small_singleton_paw_is_Hn n a b c z hn (by omega) (hw 0) (hw 1) (hw 2)
        hOrder hSum hR hSize Y hy0 hy1 hy2 hy3 hSmall₂
  obtain ⟨hZ,hW0,hW1,hW2⟩ := hGen w hW hF hN y hy0 hy1 hy2 hy3 hyLow hClose
  exact ⟨hZ,hLeaf,hW0,hW1,hW2⟩

#print axioms normalized_paw_below_isolate_gap
end PawIsolate


namespace UnitPruning
open Matrix
open scoped BigOperators Matrix

theorem ordered_eigenvalues_submatrix_equiv {n m : Type*} [Fintype n] [Fintype m]
    [DecidableEq n] [DecidableEq m] (A : Matrix m m ℝ) (hA : A.IsHermitian)
    (B : Matrix n n ℝ) (hB : B.IsHermitian) (e : n ≃ m) (h : B=A.submatrix e e)
    (i : Fin (Fintype.card n)) :
    hB.eigenvalues₀ i = hA.eigenvalues₀ (Fin.cast (Fintype.card_congr e) i) := by
  have hC : B.charpoly=A.charpoly := by
    rw [h]
    simpa [Matrix.reindex_apply] using Matrix.charpoly_reindex e.symm A
  have hL : List.ofFn hB.eigenvalues₀ = List.ofFn hA.eigenvalues₀ := by
    rw [←hB.sort_roots_charpoly_eq_eigenvalues₀,←hA.sort_roots_charpoly_eq_eigenvalues₀,hC]
  have hh := congrArg (fun z : List ℝ => z[i.val]?) hL
  have hm : i.val<Fintype.card m := by rw [←Fintype.card_congr e]; exact i.isLt
  change hB.eigenvalues₀ ⟨i.val,i.isLt⟩ = hA.eigenvalues₀ ⟨i.val,hm⟩
  simpa only [List.getElem?_ofFn,dite_eq_left i.isLt,dite_eq_left hm,Option.some.injEq] using hh

theorem squared_distance_submatrix_equiv {n m : Type*} [Fintype n] [Fintype m]
    [DecidableEq n] [DecidableEq m] (A : Matrix m m ℝ) (hA : A.IsHermitian)
    (B : Matrix n n ℝ) (hB : B.IsHermitian) (e : n ≃ m) (h : B=A.submatrix e e)
    (y : Fin (Fintype.card m) → ℝ) :
    (∑ j,(hB.eigenvalues₀ j-y (Fin.cast (Fintype.card_congr e) j))^2) =
      ∑ i,(hA.eigenvalues₀ i-y i)^2 := by
  have he := ordered_eigenvalues_submatrix_equiv A hA B hB e h
  simp_rw [he]
  exact Equiv.sum_comp (finCongr (Fintype.card_congr e)) (fun i => (hA.eigenvalues₀ i-y i)^2)

#print axioms squared_distance_submatrix_equiv
end UnitPruning


namespace UnitPruning
open Matrix SpectralConjecture20
open scoped BigOperators Matrix

def blowupEquiv {m n : Type*} (e : n ≃ m) (w : m → Nat) (z : Nat) :
    (Vertices (w ∘ e) ⊕ Fin z) ≃ (Vertices w ⊕ Fin z) :=
  Equiv.sumCongr (Equiv.sigmaCongr e (fun i => Equiv.refl (Fin (w (e i))))) (Equiv.refl _)

theorem withIsolates_reindex_template {m n : Type*} (B : Matrix m m ℝ)
    (C : Matrix n n ℝ) (e : n ≃ m) (h : C=B.submatrix e e) (w : m → Nat) (z : Nat) :
    withIsolates C (w ∘ e) z =
      (withIsolates B w z).submatrix (blowupEquiv e w z) (blowupEquiv e w z) := by
  subst C
  ext i j
  cases i <;> cases j <;> rfl

theorem template_reindex_preserves_squared_distance {m n : Type*}
    [Fintype m] [DecidableEq m] [Fintype n] [DecidableEq n]
    (B : Matrix m m ℝ) (C : Matrix n n ℝ) (e : n ≃ m) (h : C=B.submatrix e e)
    (w : m → Nat) (z : Nat) (hB : (withIsolates B w z).IsHermitian)
    (hC : (withIsolates C (w ∘ e) z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ) :
    (∑ j, (hC.eigenvalues₀ j -
      y (Fin.cast (Fintype.card_congr (blowupEquiv e w z)) j))^2) =
      ∑ i, (hB.eigenvalues₀ i-y i)^2 :=
  squared_distance_submatrix_equiv _ hB _ hC (blowupEquiv e w z)
    (withIsolates_reindex_template B C e h w z) y

#print axioms template_reindex_preserves_squared_distance
end UnitPruning


namespace PawIsolate
open Matrix Finset SpectralConjecture20 PawLargestFence UnitPruning
open scoped BigOperators Matrix

def swapCore : Fin 4 ≃ Fin 4 where
  toFun := ![0,2,1,3]
  invFun := ![0,2,1,3]
  left_inv := by intro i; fin_cases i <;> rfl
  right_inv := by intro i; fin_cases i <;> rfl

theorem paw_swap_core : paw=paw.submatrix swapCore swapCore := by
  ext i j
  change paw i j = paw (swapCore i) (swapCore j)
  fin_cases i <;> fin_cases j <;> norm_num [paw,swapCore]

theorem paw_below_isolate_gap (n : Nat) (hn : 3≤n) (w : Fin 4 → Nat)
    (hw : ∀ i,0<w i) (z : Nat)
    (hTotal : (∑ i,w i)+z=3*n) (hF : (withIsolates paw w z).IsHermitian)
    (hN : 4≤Fintype.card (Vertices w ⊕ Fin z))
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hy0 : y ⟨0,by omega⟩=2*(n:ℝ)) (hy1 : y ⟨1,by omega⟩=0)
    (hy2 : y (Fin.rev ⟨1,by omega⟩)= -(n:ℝ))
    (hy3 : y (Fin.rev ⟨0,by omega⟩)= -(n:ℝ))
    (hyLow : ∀ i, -(n:ℝ)≤y i)
    (hPos : Fintype.card {i // 0<y i}=1)
    (hNeg : Fintype.card {i // y i= -(n:ℝ)}=2)
    (hClose : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(16/27:ℝ)) :
    z=0 ∧ w 3=1 ∧ w 0+1=n ∧ w 1=n ∧ w 2=n := by
  by_cases h : w 1≤w 2
  · exact normalized_paw_below_isolate_gap n hn w hw h z hTotal hF hN y hy0 hy1 hy2 hy3 hyLow hPos hNeg hClose
  let v := w ∘ swapCore
  let e := blowupEquiv swapCore w z
  have hEq := withIsolates_reindex_template paw paw swapCore paw_swap_core w z
  let hG : (withIsolates paw v z).IsHermitian := hEq.symm ▸ hF.submatrix e
  have hc : Fintype.card (Vertices v ⊕ Fin z)=Fintype.card (Vertices w ⊕ Fin z) :=
    Fintype.card_congr e
  let k := finCongr hc
  let Y : Fin (Fintype.card (Vertices v ⊕ Fin z)) → ℝ := y ∘ k
  have hY0 : Y ⟨0,by omega⟩=2*(n:ℝ) := by simpa [Y,k] using hy0
  have hY1 : Y ⟨1,by omega⟩=0 := by simpa [Y,k] using hy1
  have hRev (i : Fin (Fintype.card (Vertices v ⊕ Fin z))) : k i.rev=(k i).rev := by
    apply Fin.ext
    simp [k,Fin.val_rev,hc]
  have hY2 : Y (Fin.rev ⟨1,by omega⟩)= -(n:ℝ) := by
    change y (k (Fin.rev ⟨1,by omega⟩))= _
    rw [hRev]
    simpa [k] using hy2
  have hY3 : Y (Fin.rev ⟨0,by omega⟩)= -(n:ℝ) := by
    change y (k (Fin.rev ⟨0,by omega⟩))= _
    rw [hRev]
    simpa [k] using hy3
  have hYL (i) : -(n:ℝ)≤Y i := hyLow (k i)
  have hYP : Fintype.card {i // 0<Y i}=1 := by
    exact (Fintype.card_congr (Equiv.subtypeEquiv k (fun _=>Iff.rfl))).trans hPos
  have hYN : Fintype.card {i // Y i= -(n:ℝ)}=2 := by
    exact (Fintype.card_congr (Equiv.subtypeEquiv k (fun _=>Iff.rfl))).trans hNeg
  have hScore := template_reindex_preserves_squared_distance paw paw swapCore paw_swap_core w z hF hG y
  change (∑ j,(hG.eigenvalues₀ j-Y j)^2) = _ at hScore
  have hTot : (∑ i, v i)+z=3*n := by
    have he := Equiv.sum_comp swapCore w
    change (∑ i,v i)=_ at he
    rw [he]
    exact hTotal
  have hSize : 4≤Fintype.card (Vertices v ⊕ Fin z) := by omega
  have hV : v 1≤v 2 := by change w 2≤w 1; omega
  obtain ⟨r0,r1,r2,r3,r4⟩ := normalized_paw_below_isolate_gap n hn v (fun i => hw _) hV
    z hTot hG hSize Y hY0 hY1 hY2 hY3 hYL hYP hYN (hScore.trans_lt hClose)
  exact ⟨r0,r1,r2,r4,r3⟩

#print axioms paw_below_isolate_gap
end PawIsolate


namespace PawIsolate
open Matrix Finset SpectralConjecture20 PawLargestFence PawUnbounded WeightedSeedPruning
open scoped BigOperators Matrix

theorem normalized_paw_below_two_thirds (n : Nat) (hn : 3≤n) (w : Fin 4 → Nat)
    (hw : ∀ i,0<w i) (hOrder : w 1≤w 2) (z : Nat)
    (hTotal : (∑ i,w i)+z=3*n) (hF : (withIsolates paw w z).IsHermitian)
    (hN : 4≤Fintype.card (Vertices w ⊕ Fin z))
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hy0 : y ⟨0,by omega⟩=2*(n:ℝ)) (hy1 : y ⟨1,by omega⟩=0)
    (hy2 : y (Fin.rev ⟨1,by omega⟩)= -(n:ℝ))
    (hy3 : y (Fin.rev ⟨0,by omega⟩)= -(n:ℝ))
    (hyLow : ∀ i, -(n:ℝ)≤y i)
    (hPos : Fintype.card {i // 0<y i}=1)
    (hNeg : Fintype.card {i // y i= -(n:ℝ)}=2)
    (hC₂ : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(2/3:ℝ)) :
    w 3=1 ∧ (z=0 → w 0+1=n ∧ w 1=n ∧ w 2=n) := by
  have hTop : ∃ i, 2*(n:ℝ)≤y i := ⟨⟨0,by omega⟩,hy0.ge⟩
  have hz := paw_at_most_one_isolate_of_close n w hw z hTotal hF y hTop hC₂
  have hLeaf : w 3=1 := by
    by_contra! hne
    have hp := hw 3
    have hRaw : withIsolates paw w z=withIsolates PMat w z :=
      congrArg (fun M => withIsolates M w z) PawBullPrincipal.paw_raw_exact.symm
    have hR : (withIsolates PMat w z).IsHermitian := hRaw ▸ hF
    have hL := PawBullPrincipal.all_nonsingleton_paw_excluded n hn w hw (by omega)
      hOrder z hz hTotal hR y hPos hNeg hTop
    rw [←same_ordered_values _ _ hRaw hF hR] at hL
    exact hC₂.not_ge hL
  let a := w 0
  let b := w 1
  let c := w 2
  have hS : a+b+c+1+z=3*n := by
    rw [Fin.sum_univ_four,hLeaf] at hTotal
    exact hTotal
  have hW : w=singletonWeights a b c := by
    funext i
    fin_cases i
    · rfl
    · rfl
    · rfl
    · exact hLeaf
  have hGen (v : Fin 4 → Nat) (hv : v=singletonWeights a b c)
      (hG : (withIsolates paw v z).IsHermitian)
      (hSize : 4≤Fintype.card (Vertices v ⊕ Fin z))
      (Y : Fin (Fintype.card (Vertices v ⊕ Fin z)) → ℝ)
      (hy0 : Y ⟨0,by omega⟩=2*(n:ℝ)) (hy1 : Y ⟨1,by omega⟩=0)
      (hy2 : Y (Fin.rev ⟨1,by omega⟩)= -(n:ℝ))
      (hy3 : Y (Fin.rev ⟨0,by omega⟩)= -(n:ℝ))
      (hyLow : ∀ i, -(n:ℝ)≤Y i)
      (hSmall₂ : (∑ i,(hG.eigenvalues₀ i-Y i)^2)<(2/3:ℝ)) (hZ : z=0) :
      a+1=n ∧ b=n ∧ c=n := by
    subst v
    let v := singletonWeights a b c
    have hEq : withIsolates paw v z=withIsolates seedPaw v z :=
      congrArg (fun M => withIsolates M v z) seed_paw_exact.symm
    have hR : (withIsolates seedPaw v z).IsHermitian := hEq ▸ hG
    rw [same_ordered_values _ _ hEq hG hR] at hSmall₂
    have hSum : a+b+c+1=3*n := by omega
    by_cases hI : 24≤n
    · exact close_large_singleton_paw_is_Hn n a b c z hI (hw 0) (hw 1) (hw 2)
        hOrder hSum hR hSize Y hy0 hy1 hy2 hy3 hyLow hSmall₂
    · exact close_small_singleton_paw_is_Hn n a b c z hn (by omega) (hw 0) (hw 1) (hw 2)
        hOrder hSum hR hSize Y hy0 hy1 hy2 hy3 hSmall₂
  exact ⟨hLeaf, hGen w hW hF hN y hy0 hy1 hy2 hy3 hyLow hC₂⟩

#print axioms normalized_paw_below_two_thirds
end PawIsolate


namespace PawIsolate
open Matrix Finset SpectralConjecture20 PawLargestFence UnitPruning
open scoped BigOperators Matrix

theorem paw_below_two_thirds (n : Nat) (hn : 3≤n) (w : Fin 4 → Nat)
    (hw : ∀ i,0<w i) (z : Nat)
    (hTotal : (∑ i,w i)+z=3*n) (hF : (withIsolates paw w z).IsHermitian)
    (hN : 4≤Fintype.card (Vertices w ⊕ Fin z))
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hy0 : y ⟨0,by omega⟩=2*(n:ℝ)) (hy1 : y ⟨1,by omega⟩=0)
    (hy2 : y (Fin.rev ⟨1,by omega⟩)= -(n:ℝ))
    (hy3 : y (Fin.rev ⟨0,by omega⟩)= -(n:ℝ))
    (hyLow : ∀ i, -(n:ℝ)≤y i)
    (hPos : Fintype.card {i // 0<y i}=1)
    (hNeg : Fintype.card {i // y i= -(n:ℝ)}=2)
    (hClose : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(2/3:ℝ)) :
    w 3=1 ∧ (z=0 → w 0+1=n ∧ w 1=n ∧ w 2=n) := by
  by_cases h : w 1≤w 2
  · exact normalized_paw_below_two_thirds n hn w hw h z hTotal hF hN y hy0 hy1 hy2 hy3 hyLow hPos hNeg hClose
  let v := w ∘ swapCore
  let e := blowupEquiv swapCore w z
  have hEq := withIsolates_reindex_template paw paw swapCore paw_swap_core w z
  let hG : (withIsolates paw v z).IsHermitian := hEq.symm ▸ hF.submatrix e
  have hc : Fintype.card (Vertices v ⊕ Fin z)=Fintype.card (Vertices w ⊕ Fin z) :=
    Fintype.card_congr e
  let k := finCongr hc
  let Y : Fin (Fintype.card (Vertices v ⊕ Fin z)) → ℝ := y ∘ k
  have hY0 : Y ⟨0,by omega⟩=2*(n:ℝ) := by simpa [Y,k] using hy0
  have hY1 : Y ⟨1,by omega⟩=0 := by simpa [Y,k] using hy1
  have hRev (i : Fin (Fintype.card (Vertices v ⊕ Fin z))) : k i.rev=(k i).rev := by
    apply Fin.ext
    simp [k,Fin.val_rev,hc]
  have hY2 : Y (Fin.rev ⟨1,by omega⟩)= -(n:ℝ) := by
    change y (k (Fin.rev ⟨1,by omega⟩))= _
    rw [hRev]
    simpa [k] using hy2
  have hY3 : Y (Fin.rev ⟨0,by omega⟩)= -(n:ℝ) := by
    change y (k (Fin.rev ⟨0,by omega⟩))= _
    rw [hRev]
    simpa [k] using hy3
  have hYL (i) : -(n:ℝ)≤Y i := hyLow (k i)
  have hYP : Fintype.card {i // 0<Y i}=1 := by
    exact (Fintype.card_congr (Equiv.subtypeEquiv k (fun _=>Iff.rfl))).trans hPos
  have hYN : Fintype.card {i // Y i= -(n:ℝ)}=2 := by
    exact (Fintype.card_congr (Equiv.subtypeEquiv k (fun _=>Iff.rfl))).trans hNeg
  have hScore := template_reindex_preserves_squared_distance paw paw swapCore paw_swap_core w z hF hG y
  change (∑ j,(hG.eigenvalues₀ j-Y j)^2) = _ at hScore
  have hTot : (∑ i, v i)+z=3*n := by
    have he := Equiv.sum_comp swapCore w
    change (∑ i,v i)=_ at he
    rw [he]
    exact hTotal
  have hSize : 4≤Fintype.card (Vertices v ⊕ Fin z) := by omega
  have hV : v 1≤v 2 := by change w 2≤w 1; omega
  obtain ⟨r1,r⟩ := normalized_paw_below_two_thirds n hn v (fun i => hw _) hV
    z hTot hG hSize Y hY0 hY1 hY2 hY3 hYL hYP hYN (hScore.trans_lt hClose)
  exact ⟨r1, fun hz => ⟨(r hz).1,(r hz).2.2,(r hz).2.1⟩⟩

#print axioms paw_below_two_thirds
end PawIsolate


namespace HouseLarge
open Matrix Finset SpectralConjecture20 WeightedSeedPruning Conj20CutCert
open scoped BigOperators Matrix

theorem close_house_weights (w : Fin 5 → Nat) (hw : ∀ i, 0<w i)
    (z : Nat) (hF : (withIsolates HMat w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hPos : Fintype.card {i // 0<y i}=1)
    (hClose : (∑ i,(hF.eigenvalues₀ i-y i)^2)<(2/3:ℝ)) :
    w 1=1 ∧ w 2=1 ∧ w 3≤2 := by
  constructor
  · by_contra! hh
    have hx : 2≤w 1 := by have := hw 1; omega
    apply h1_forbidden w hw z hF y hPos hClose
    intro i
    fin_cases i
    · exact Nat.succ_le_of_lt (hw 0)
    · exact hx
    · exact Nat.succ_le_of_lt (hw 2)
    · exact Nat.succ_le_of_lt (hw 3)
    · exact Nat.succ_le_of_lt (hw 4)
  constructor
  · by_contra! hh
    have hx : 2≤w 2 := by have := hw 2; omega
    apply h2_forbidden w hw z hF y hPos hClose
    intro i
    fin_cases i
    · exact Nat.succ_le_of_lt (hw 0)
    · exact Nat.succ_le_of_lt (hw 1)
    · exact hx
    · exact Nat.succ_le_of_lt (hw 3)
    · exact Nat.succ_le_of_lt (hw 4)
  · by_contra! hh
    have hx : 3≤w 3 := by omega
    apply h3_forbidden w hw z hF y hPos hClose
    intro i
    fin_cases i
    · exact Nat.succ_le_of_lt (hw 0)
    · exact Nat.succ_le_of_lt (hw 1)
    · exact Nat.succ_le_of_lt (hw 2)
    · exact hx
    · exact Nat.succ_le_of_lt (hw 4)

theorem house_raw_exact : HMat=HouseButterflyFence.house := by
  ext i j
  change (entry HRows i j : ℝ)=HouseButterflyFence.house i j
  fin_cases i <;> fin_cases j <;> norm_num [entry,HRows,HouseButterflyFence.house]


theorem all_weighted_house_excluded (n : Nat) (hn : 3≤n)
    (w : Fin 5 → Nat) (hw : ∀ i, 0<w i) (hTotal : (∑ i,w i)≤3*n)
    (z : Nat) (hF : (withIsolates HMat w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hPos : Fintype.card {i // 0<y i}=1)
    (hNeg : Fintype.card {i // y i= -(n:ℝ)}=2)
    (hTop : ∃ i, 2*(n:ℝ)≤y i) :
    (2/3:ℝ)≤∑ i,(hF.eigenvalues₀ i-y i)^2 := by
  by_contra! hClose
  obtain ⟨h1,h2,hD⟩ := close_house_weights w hw z hF y hPos hClose
  let a := w 0
  let d := w 3
  let e := w 4
  have ha : 0<a := hw 0
  have hd : 0<d := hw 3
  have he : 0<e := hw 4
  have hSum : a+d+e+2≤3*n := by
    simp [Fin.sum_univ_succ,h1,h2] at hTotal
    dsimp [a,d,e]
    omega
  have hW : w=houseW a d e := by
    funext i
    fin_cases i
    · rfl
    · exact h1
    · exact h2
    · rfl
    · rfl
  by_cases hN : 7≤n
  · have hGen (v : Fin 5 → Nat) (h : v=houseW a d e)
      (hH : (withIsolates HMat v z).IsHermitian) (Y : Fin (Fintype.card (Vertices v ⊕ Fin z))→ℝ)
      (hY : Fintype.card {i // Y i= -(n:ℝ)}=2) :
      (2/3:ℝ)≤∑ i,(hH.eigenvalues₀ i-Y i)^2 := by
      subst v
      exact house_large_excluded n a d e z hN ha hd hD he hSum hH Y hY
    exact hClose.not_ge (hGen w hW hF y hNeg)
  · have hGen (v : Fin 5 → Nat) (h : v=houseW a d e)
      (hH : (withIsolates HMat v z).IsHermitian) (Y : Fin (Fintype.card (Vertices v ⊕ Fin z))→ℝ)
      (hY : ∃ i, 2*(n:ℝ)≤Y i) : (2/3:ℝ)≤∑ i,(hH.eigenvalues₀ i-Y i)^2 := by
      subst v
      let v := houseW a d e
      have hK : withIsolates HMat v z = withIsolates HouseButterflyFence.house v z :=
        congrArg (fun M => withIsolates M v z) house_raw_exact
      have hH' : (withIsolates HouseButterflyFence.house v z).IsHermitian := hK ▸ hH
      obtain ⟨i,hY⟩ := hY
      have hx := HouseButterflyFence.weighted_house_bounded_fence n a d e z hn (by omega) ha hd hD he hSum hH' i
      rw [padded_eigenvalues_eq hK hH hH']
      exact PawLargestFence.squared_discrepancy_of_upper_fence hH'.eigenvalues₀ Y n i hx hY
    exact hClose.not_ge (hGen w hW hF y hTop)

#print axioms all_weighted_house_excluded
end HouseLarge


namespace PawUnbounded
open Matrix Finset SpectralConjecture20 PawLargestFence
open scoped BigOperators Matrix

theorem singleton_last_two_negative (a b c : Nat) (ha : 0<a) (hb : 0<b) (hc : 0<c) :
    let x := singletonQEigen a b c
    x 2<0 ∧ x 3<0 := by
  let x := singletonQEigen a b c
  have hAnti : Antitone x := by
    intro i j hij
    exact (weightedQuotient_isHermitian seedPaw seedHerm (singletonWeights a b c)).eigenvalues₀_antitone hij
  have h1 : 0<x 1 := singleton_second_pos a b c ha hb hc
  have h01 := hAnti (show (0:Fin 4) ≤ 1 by decide)
  have h23 := hAnti (show (2:Fin 4) ≤ 3 by decide)
  have h0 : 0<x 0 := h1.trans_le h01
  have hT : x 0+x 1+x 2+x 3=0 := PawIsolate.singleton_paw_zero_trace a b c
  have hE := singleton_factored_poly a b c 0
  have ha' : (0:ℝ)<a := by exact_mod_cast ha
  have hb' : (0:ℝ)<b := by exact_mod_cast hb
  have hc' : (0:ℝ)<c := by exact_mod_cast hc
  have hP : 0<(x 0*x 1)*(x 2*x 3) := by
    have hh : 0<(a:ℝ)*(b:ℝ)*(c:ℝ) := by positivity
    dsimp [poly,pawG] at hE
    nlinarith only [hE,hh]
  have h2 : x 2<0 := by
    by_contra! he
    have h3 : x 3<0 := by linarith
    have hQ := mul_nonpos_of_nonneg_of_nonpos he h3.le
    have hR := mul_nonpos_of_nonneg_of_nonpos (mul_nonneg h0.le h1.le) hQ
    linarith
  exact ⟨h2,h23.trans_lt h2⟩

theorem singleton_exact_card_signs (a b c : Nat) (ha : 0<a) (hb : 0<b) (hc : 0<c) :
    let x := singletonQEigen a b c
    Fintype.card {i // 0<x i}=2 ∧ Fintype.card {i // x i<0}=2 := by
  let x := singletonQEigen a b c
  have hAnti : Antitone x := by
    intro i j hij
    exact (weightedQuotient_isHermitian seedPaw seedHerm (singletonWeights a b c)).eigenvalues₀_antitone hij
  have h1 : 0<x 1 := singleton_second_pos a b c ha hb hc
  have h0 : 0<x 0 := h1.trans_le (hAnti (show (0:Fin 4) ≤ 1 by decide))
  obtain ⟨h2,h3⟩ := singleton_last_two_negative a b c ha hb hc
  change x 2 < 0 at h2
  change x 3 < 0 at h3
  change Fintype.card {i // 0<x i}=2 ∧ Fintype.card {i // x i<0}=2
  constructor
  · rw [Fintype.card_subtype,Finset.card_eq_sum_ones,Finset.sum_filter]
    change (∑ i : Fin 4, if 0<x i then (1:Nat) else 0)=2
    rw [Fin.sum_univ_four]
    simp [h0,h1,h2.not_gt,h3.not_gt]
  · rw [Fintype.card_subtype,Finset.card_eq_sum_ones,Finset.sum_filter]
    change (∑ i : Fin 4, if x i<0 then (1:Nat) else 0)=2
    rw [Fin.sum_univ_four]
    simp [h0.not_gt,h1.not_gt,h2,h3]

#print axioms singleton_exact_card_signs
end PawUnbounded


namespace PawUnbounded
open Matrix SpectralConjecture20 Finset
open scoped BigOperators Matrix

theorem singleton_ordered_quartet_score_eq (n a b c z : Nat)
    (ha : 0<a) (hb : 0<b) (hc : 0<c)
    (hF : (withIsolates seedPaw (singletonWeights a b c) z).IsHermitian)
    (hN : 4 ≤ Fintype.card (Vertices (singletonWeights a b c) ⊕ Fin z))
    (y : Fin (Fintype.card (Vertices (singletonWeights a b c) ⊕ Fin z)) → ℝ)
    (hy0 : y ⟨0,by omega⟩=2*(n:ℝ)) (hy1 : y ⟨1,by omega⟩=0)
    (hy2 : y (Fin.rev ⟨1,by omega⟩)= -(n:ℝ))
    (hy3 : y (Fin.rev ⟨0,by omega⟩)= -(n:ℝ))
    (hyRest : ∀ i : Fin (Fintype.card (Vertices (singletonWeights a b c) ⊕ Fin z)),
      2 ≤ i.val → 2 ≤ i.rev.val → y i=0)
    (cost : ℝ → ℝ) (hCost : cost 0=0) :
    let q := singletonQEigen a b c
    (∑ i,cost (hF.eigenvalues₀ i-y i)) =
      cost (q 0-2*(n:ℝ))+cost (q 1)+cost (q 2+(n:ℝ))+cost (q 3+(n:ℝ)) := by
  classical
  let N := Fintype.card (Vertices (singletonWeights a b c) ⊕ Fin z)
  let f : Fin N → ℝ := hF.eigenvalues₀
  let q := singletonQEigen a b c
  let i0 : Fin N := ⟨0,by dsimp [N]; omega⟩
  let i1 : Fin N := ⟨1,by dsimp [N]; omega⟩
  have hf : Antitone f := hF.eigenvalues₀_antitone
  have hq : Antitone q := by
    intro i j hij
    exact (weightedQuotient_isHermitian seedPaw seedHerm (singletonWeights a b c)).eigenvalues₀_antitone hij
  have hcPos (u : ℝ) (hu : 0 ≤ u) :
      Fintype.card {i // u < f i} = Fintype.card {j // u < q j} := by
    simpa only [one_mul] using normalized_paw_sorted_cut a b c z ha hb hc hF 1 u hu
  have hcNeg (u : ℝ) (hu : 0 ≤ u) :
      Fintype.card {i : Fin N // u < -f i.rev} = Fintype.card {j : Fin 4 // u < -q j.rev} := by
    rw [←signed_reversed_cuts f,←signed_reversed_cuts q]
    simpa only [neg_one_mul] using normalized_paw_sorted_cut a b c z ha hb hc hF (-1) u hu
  have hqP : 0<q 1 := singleton_second_pos a b c ha hb hc
  have hfP : 0<f i1 := by
    rw [cut_count_rank_iff _ hf, hcPos _ (by norm_num)]
    change 1 < _
    exact (cut_count_rank_iff _ hq _ 1).mp hqP
  have he1 : f i1=q 1 :=
    equal_coord_of_nonnegative_cut_counts _ _ hf hq _ _ rfl hfP.le hqP.le hcPos
  have he0 : f i0=q 0 :=
    equal_coord_of_nonnegative_cut_counts _ _ hf hq _ _ rfl
      (hfP.le.trans (hf (by change (0:Nat) ≤ 1; exact Nat.zero_le _)))
      (hqP.le.trans (hq (by decide))) hcPos
  obtain ⟨hQ2,hQ3⟩ := singleton_last_two_negative a b c ha hb hc
  have hfr := antitone_neg_rev f hf
  have hqr := antitone_neg_rev q hq
  have sortNegative (i : Fin N) (j : Fin 4) (hij : i.val=j.val) (hj : 0 < -q j.rev) :
      f i.rev=q j.rev := by
    have hFi : 0 < -f i.rev := by
      apply (cut_count_rank_iff _ hfr 0 i).mpr
      rw [hcNeg 0 (by norm_num),hij]
      exact (cut_count_rank_iff _ hqr 0 j).mp hj
    have he := equal_coord_of_nonnegative_cut_counts _ _ hfr hqr i j hij hFi.le hj.le hcNeg
    linarith only [he]
  have he2 : f i1.rev=q 2 := sortNegative i1 1 rfl (by change 0< -q 2; linarith)
  have he3 : f i0.rev=q 3 := sortNegative i0 0 rfl (by change 0< -q 3; linarith)
  have hCounts := singleton_exact_card_signs a b c ha hb hc
  have hPSize : Fintype.card {i // 0<f i}=2 := (hcPos 0 (by norm_num)).trans hCounts.1
  have hNSize : Fintype.card {i : Fin N // 0 < -f i.rev}=2 := by
    have hc := hcNeg 0 (by norm_num)
    rw [←signed_reversed_cuts q] at hc
    rw [hc]
    simpa only [neg_pos] using hCounts.2
  have hz (i : Fin N) (hi : 2 ≤ i.val) (hr : 2 ≤ i.rev.val) : f i=0 := by
    apply le_antisymm
    · by_contra! hh
      have hh' := (cut_count_rank_iff _ hf 0 i).mp hh
      omega
    · by_contra! hh
      have hh₀ : 0< -f (i.rev).rev := by simpa using (neg_pos.mpr hh)
      have hh' := (cut_count_rank_iff _ hfr 0 i.rev).mp hh₀
      omega
  let eFun : Fin 4 → Fin N := ![i0,i1,i1.rev,i0.rev]
  have hInj : Function.Injective eFun := by
    intro i j he
    have hv := congrArg Fin.val he
    fin_cases i <;> fin_cases j <;>
      simp [eFun,i0,i1,Fin.val_rev] at hv ⊢ <;> omega
  let e : Fin 4 ↪ Fin N := ⟨eFun,hInj⟩
  have mont (i : Fin N) (hmiss : i∉(Finset.univ : Finset (Fin 4)).map e) :
      2 ≤ i.val ∧ 2 ≤ i.rev.val := by
    have hn₀ : i.val≠0 := by
      intro he
      exact hmiss (Finset.mem_map.mpr ⟨0,Finset.mem_univ _,Fin.ext he.symm⟩)
    have hn₁ : i.val≠1 := by
      intro he
      exact hmiss (Finset.mem_map.mpr ⟨1,Finset.mem_univ _,Fin.ext he.symm⟩)
    have hn₂ : i.rev.val≠1 := by
      intro he
      have e1 : i1=i.rev := Fin.ext he.symm
      exact hmiss (Finset.mem_map.mpr ⟨2,Finset.mem_univ _,by
        change i1.rev=i; rw [e1,Fin.rev_rev]⟩)
    have hn₃ : i.rev.val≠0 := by
      intro he
      have e0 : i0=i.rev := Fin.ext he.symm
      exact hmiss (Finset.mem_map.mpr ⟨3,Finset.mem_univ _,by
        change i0.rev=i; rw [e0,Fin.rev_rev]⟩)
    omega
  let costF : Fin N → ℝ := fun i => cost (f i-y i)
  have he : (∑ i ∈ Finset.univ.map e,costF i)=∑ i,costF i := by
    apply Finset.sum_subset (Finset.subset_univ _)
    intro i _ hm
    obtain ⟨hi,hr⟩ := mont i hm
    dsimp [costF]
    rw [hz i hi hr,hyRest i hi hr,sub_self,hCost]
  rw [Finset.sum_map,Fin.sum_univ_four] at he
  change cost (f i0-y i0)+cost (f i1-y i1)+cost (f i1.rev-y i1.rev)+cost (f i0.rev-y i0.rev)=_ at he
  change y i0=2*(n:ℝ) at hy0
  change y i1=0 at hy1
  change y i1.rev= -(n:ℝ) at hy2
  change y i0.rev= -(n:ℝ) at hy3
  rw [he0,he1,he2,he3,hy0,hy1,hy2,hy3,sub_zero,sub_neg_eq_add,sub_neg_eq_add] at he
  exact he.symm

#print axioms singleton_ordered_quartet_score_eq
end PawUnbounded






set_option linter.unusedVariables false

namespace HubBenchmark

def cubic (n x : ℝ) : ℝ :=
  x^3 - n*x^2 + (-2*n^2+n+1)*x + n*(n-1)

lemma bracket (a b c l u : ℝ) (h : l ≤ u)
    (hs : ((l-a)*(l-b)*(l-c))*((u-a)*(u-b)*(u-c)) < 0) :
    (l<a ∧ a<u) ∨ (l<b ∧ b<u) ∨ (l<c ∧ c<u) := by
  by_contra! hn
  have aux (z : ℝ) (hz : z ≤ l ∨ u ≤ z) : 0 ≤ (l-z)*(u-z) := by
    rcases hz with hz|hz
    · exact mul_nonneg (sub_nonneg.mpr hz) (sub_nonneg.mpr (hz.trans h))
    · exact mul_nonneg_of_nonpos_of_nonpos (sub_nonpos.mpr (h.trans hz)) (sub_nonpos.mpr hz)
  have ha := aux a (or_iff_not_imp_left.mpr (fun hh => hn.1 (lt_of_not_ge hh)))
  have hb := aux b (or_iff_not_imp_left.mpr (fun hh => hn.2.1 (lt_of_not_ge hh)))
  have hc := aux c (or_iff_not_imp_left.mpr (fun hh => hn.2.2 (lt_of_not_ge hh)))
  have he : ((l-a)*(l-b)*(l-c))*((u-a)*(u-b)*(u-c)) =
      ((l-a)*(u-a))*((l-b)*(u-b))*((l-c)*(u-c)) := by ring
  rw [he] at hs
  exact (not_lt_of_ge (mul_nonneg (mul_nonneg ha hb) hc)) hs

lemma ordered_brackets (a b c l₁ u₁ l₂ u₂ l₃ u₃ : ℝ)
    (hab : b ≤ a) (hbc : c ≤ b) (h₁₂ : u₂ ≤ l₁) (h₂₃ : u₃ ≤ l₂)
    (h₁ : (l₁<a ∧ a<u₁) ∨ (l₁<b ∧ b<u₁) ∨ (l₁<c ∧ c<u₁))
    (h₂ : (l₂<a ∧ a<u₂) ∨ (l₂<b ∧ b<u₂) ∨ (l₂<c ∧ c<u₂))
    (h₃ : (l₃<a ∧ a<u₃) ∨ (l₃<b ∧ b<u₃) ∨ (l₃<c ∧ c<u₃)) :
    (l₁<a ∧ a<u₁) ∧ (l₂<b ∧ b<u₂) ∧ (l₃<c ∧ c<u₃) := by
  rcases h₁ with h₁|h₁|h₁ <;> rcases h₂ with h₂|h₂|h₂ <;>
    rcases h₃ with h₃|h₃|h₃ <;> first
      | exact ⟨h₁,h₂,h₃⟩
      | (exfalso; linarith only [hab,hbc,h₁₂,h₂₃,h₁.1,h₁.2,h₂.1,h₂.2,h₃.1,h₃.2])

lemma use_brackets (n a b c l₁ u₁ l₂ u₂ l₃ u₃ : ℝ)
    (hab : b ≤ a) (hbc : c ≤ b) (h₁₂ : u₂ ≤ l₁) (h₂₃ : u₃ ≤ l₂)
    (hf : ∀ x : ℝ, cubic n x = (x-a)*(x-b)*(x-c))
    (h₁ : l₁≤u₁) (h₂ : l₂≤u₂) (h₃ : l₃≤u₃)
    (hs₁ : cubic n l₁*cubic n u₁<0) (hs₂ : cubic n l₂*cubic n u₂<0)
    (hs₃ : cubic n l₃*cubic n u₃<0) :
    (l₁<a ∧ a<u₁) ∧ (l₂<b ∧ b<u₂) ∧ (l₃<c ∧ c<u₃) := by
  simp only [hf] at hs₁ hs₂ hs₃
  exact ordered_brackets _ _ _ _ _ _ _ _ _ hab hbc h₁₂ h₂₃
    (bracket _ _ _ _ _ h₁ hs₁) (bracket _ _ _ _ _ h₂ hs₂) (bracket _ _ _ _ _ h₃ hs₃)

def score (n a b c : ℝ) : ℝ := (a-2*n)^2 + b^2 + (c+n)^2

lemma score_small (n : ℕ) (a b c : ℝ) (hn : n=3 ∨ n=4)
    (hab : b ≤ a) (hbc : c ≤ b)
    (hf : ∀ x : ℝ, cubic n x = (x-a)*(x-b)*(x-c)) :
    score n a b c < 16/27 := by
  rcases hn with h|h <;> subst n <;> norm_num at hf ⊢
  · have hx := use_brackets 3 a b c (539/100) (54/10) (398/1000) (4/10)
          (-28/10) (-278/100) hab hbc (by norm_num) (by norm_num) hf
          (by norm_num) (by norm_num) (by norm_num)
          (by norm_num [cubic]) (by norm_num [cubic]) (by norm_num [cubic])
    rcases hx with ⟨⟨ha,ha'⟩,⟨hb,hb'⟩,⟨hc,hc'⟩⟩
    unfold score
    have hA : (a-2*3)^2 ≤ (61/100:ℝ)^2 := by
      nlinarith [mul_nonneg (show 0 ≤ a-539/100 by linarith) (show 0 ≤ 1261/100-a by linarith)]
    have hB : b^2 ≤ (4/10:ℝ)^2 := by
      nlinarith [mul_nonneg (show 0 ≤ 4/10-b by linarith) (show 0 ≤ 4/10+b by linarith)]
    have hC : (c+3)^2 ≤ (22/100:ℝ)^2 := by
      nlinarith [mul_nonneg (show 0 ≤ -278/100-c by linarith) (show 0 ≤ c+322/100 by linarith)]
    linarith
  · have hx := use_brackets 4 a b c (742/100) (743/100) (42/100) (43/100)
          (-385/100) (-384/100) hab hbc (by norm_num) (by norm_num) hf
          (by norm_num) (by norm_num) (by norm_num)
          (by norm_num [cubic]) (by norm_num [cubic]) (by norm_num [cubic])
    rcases hx with ⟨⟨ha,ha'⟩,⟨hb,hb'⟩,⟨hc,hc'⟩⟩
    unfold score
    have hA : (a-2*4)^2 ≤ (58/100:ℝ)^2 := by
      nlinarith [mul_nonneg (show 0 ≤ a-742/100 by linarith) (show 0 ≤ 858/100-a by linarith)]
    have hB : b^2 ≤ (43/100:ℝ)^2 := by
      nlinarith [mul_nonneg (show 0 ≤ 43/100-b by linarith) (show 0 ≤ 43/100+b by linarith)]
    have hC : (c+4)^2 ≤ (16/100:ℝ)^2 := by
      nlinarith [mul_nonneg (show 0 ≤ -384/100-c by linarith) (show 0 ≤ c+416/100 by linarith)]
    linarith


lemma brackets_large (n a b c : ℝ) (hn : 5 ≤ n)
    (hab : b ≤ a) (hbc : c ≤ b)
    (hf : ∀ x : ℝ, cubic n x = (x-a)*(x-b)*(x-c)) :
    (2*n-17/30<a ∧ a<2*n) ∧ (0<b ∧ b<1/2) ∧ (-n<c ∧ c< -n+2/15) := by
  let t := n-5
  have ht : 0 ≤ t := by dsimp [t]; linarith
  have ht2 := sq_nonneg t
  have hnt : n = t+5 := by dsimp [t]; ring
  have v1 : cubic n (2*n-17/30) = -2*t^2/5 - 353*t/180 - 14963/27000 := by
    rw [hnt]; unfold cubic; ring
  have v2 : cubic n (2*n) = 3*t^2 + 31*t + 80 := by
    rw [hnt]; unfold cubic; ring
  have v3 : cubic n 0 = t^2 + 9*t + 20 := by
    rw [hnt]; unfold cubic; ring
  have v4 : cubic n (1/2) = -3*t/4 - 25/8 := by
    rw [hnt]; unfold cubic; ring
  have v5 : cubic n (-n) = -2*t-10 := by
    rw [hnt]; unfold cubic; ring
  have v6 : cubic n (-n+2/15) = 2*t^2/5 + 464*t/225 + 1508/3375 := by
    rw [hnt]; unfold cubic; ring
  exact use_brackets n a b c (2*n-17/30) (2*n) 0 (1/2) (-n) (-n+2/15)
          hab hbc (by linarith) (by linarith) hf
          (by linarith) (by norm_num) (by linarith)
          (mul_neg_of_neg_of_pos (by rw [v1]; linarith) (by rw [v2]; linarith))
          (mul_neg_of_pos_of_neg (by rw [v3]; linarith) (by rw [v4]; linarith))
          (mul_neg_of_neg_of_pos (by rw [v5]; linarith) (by rw [v6]; linarith))

lemma score_large (n a b c : ℝ) (hn : 5 ≤ n)
    (hab : b ≤ a) (hbc : c ≤ b)
    (hf : ∀ x : ℝ, cubic n x = (x-a)*(x-b)*(x-c)) :
    score n a b c < 16/27 := by
  obtain ⟨⟨ha,ha'⟩,⟨hb,hb'⟩,⟨hc,hc'⟩⟩ := brackets_large n a b c hn hab hbc hf
  unfold score
  have hA : (a-2*n)^2 ≤ (17/30:ℝ)^2 := by
    nlinarith [mul_nonneg (show 0 ≤ a-2*n+17/30 by linarith)
      (show 0 ≤ 2*n+17/30-a by linarith)]
  have hB : b^2 ≤ (1/2:ℝ)^2 := by
    nlinarith [mul_nonneg (show 0 ≤ 1/2-b by linarith) (show 0 ≤ 1/2+b by linarith)]
  have hC : (c+n)^2 ≤ (2/15:ℝ)^2 := by
    nlinarith [mul_nonneg (show 0 ≤ 2/15-c-n by linarith) (show 0 ≤ 2/15+c+n by linarith)]
  linarith

theorem score_below_isolate_fence (n : ℕ) (a b c : ℝ) (hn : 3 ≤ n)
    (hab : b ≤ a) (hbc : c ≤ b)
    (hf : ∀ x : ℝ, cubic n x = (x-a)*(x-b)*(x-c)) :
    score n a b c < 16/27 := by
  by_cases hh : 5 ≤ n
  · exact score_large n a b c (by exact_mod_cast hh) hab hbc hf
  · exact score_small n a b c (by omega) hab hbc hf

#print axioms score_below_isolate_fence


lemma min_root (n a b c d : ℝ) (hn : 0 < n)
    (had : d ≤ a) (hbd : d ≤ b) (hcd : d ≤ c)
    (hf : ∀ x : ℝ, (x+n)*cubic n x = (x-a)*(x-b)*(x-c)*(x-d)) :
    d = -n := by
  have hu : d ≤ -n := by
    have h := hf (-n)
    have hz : ((-n-a)*(-n-b)*(-n-c)*(-n-d)) = 0 := by linarith only [h]
    rcases mul_eq_zero.mp hz with h|h
    · rcases mul_eq_zero.mp h with h|h
      · rcases mul_eq_zero.mp h with h|h <;> linarith
      · linarith
    · linarith
  by_contra hh
  have hd : d < -n := lt_of_le_of_ne hu hh
  let y := -n-d
  have hy : 0 < y := sub_pos.mpr hd
  have hi : cubic n d =
      -(3*n^2*y + 4*n*y^2 + n*y + 2*n + y^3 + y) := by
    dsimp [y,cubic]
    ring
  have hpos : 0 < 3*n^2*y + 4*n*y^2 + n*y + 2*n + y^3 + y := by positivity
  have hprod := hf d
  simp only [sub_self, mul_zero] at hprod
  rcases mul_eq_zero.mp hprod with h|h
  · linarith
  · linarith

lemma reduce_quartic (n a b c d : ℝ) (hn : 0 < n)
    (had : d ≤ a) (hbd : d ≤ b) (hcd : d ≤ c)
    (hf : ∀ x : ℝ, (x+n)*cubic n x = (x-a)*(x-b)*(x-c)*(x-d)) :
    d = -n ∧ ∀ x : ℝ, cubic n x = (x-a)*(x-b)*(x-c) := by
  have hd := min_root n a b c d hn had hbd hcd hf
  refine ⟨hd, ?_⟩
  have hc (x : ℝ) (hx : x+n ≠ 0) : cubic n x = (x-a)*(x-b)*(x-c) := by
    apply mul_left_cancel₀ hx
    simpa only [hd, sub_neg_eq_add, mul_comm (x+n)] using hf x
  intro x
  have k0 := hc 0 (by linarith)
  have k1 := hc 1 (by linarith)
  have k2 := hc 2 (by linarith)
  unfold cubic at *
  linear_combination ((x-1)*(x-2)/2)*k0 + (x*(2-x))*k1 + (x*(x-1)/2)*k2

theorem quartic_below_isolate_fence (n : ℕ) (a b c d : ℝ) (hn : 3 ≤ n)
    (hab : b ≤ a) (hbc : c ≤ b) (hcd : d ≤ c)
    (hf : ∀ x : ℝ, (x+n)*cubic n x = (x-a)*(x-b)*(x-c)*(x-d)) :
    score n a b c + (d+n)^2 < 16/27 := by
  have hnR : (0:ℝ)<n := by exact_mod_cast (show 0<n by omega)
  obtain ⟨hd, hc⟩ := reduce_quartic n a b c d hnR (hcd.trans (hbc.trans hab))
    (hcd.trans hbc) hcd hf
  have hh := score_below_isolate_fence n a b c hn hab hbc hc
  simpa [hd] using hh

#print axioms quartic_below_isolate_fence


lemma sum_roots (n a b c : ℝ) (hf : ∀ x : ℝ, cubic n x = (x-a)*(x-b)*(x-c)) :
    a+b+c=n := by
  have h0 := hf 0
  have h1 := hf 1
  have h2 := hf 2
  unfold cubic at *
  linear_combination (h2 - 2*h1 + h0)/2

theorem manhattan_large (n : ℕ) (a b c d : ℝ) (hn : 5 ≤ n)
    (hab : b ≤ a) (hbc : c ≤ b) (hcd : d ≤ c)
    (hf : ∀ x : ℝ, (x+n)*cubic n x = (x-a)*(x-b)*(x-c)*(x-d)) :
    |a-2*n| + |b| + |c+n| + |d+n| < (17/15:ℝ) := by
  have hnR : (5:ℝ)≤n := by exact_mod_cast hn
  obtain ⟨hd,hc⟩ := reduce_quartic n a b c d (by linarith) (hcd.trans (hbc.trans hab))
    (hcd.trans hbc) hcd hf
  obtain ⟨⟨ha,ha'⟩,⟨hb,_⟩,⟨hc',_⟩⟩ := brackets_large n a b c hnR hab hbc hc
  have ht := sum_roots n a b c hc
  rw [abs_of_neg (show a-2*n<0 by linarith),
      abs_of_pos hb, abs_of_pos (show c+n>0 by linarith),hd]
  simp only [neg_add_cancel,abs_zero,add_zero]
  linarith

#print axioms manhattan_large


theorem manhattan_small (n : ℕ) (a b c d : ℝ) (hn : n=3 ∨ n=4)
    (hab : b ≤ a) (hbc : c ≤ b) (hcd : d ≤ c)
    (hf : ∀ x : ℝ, (x+n)*cubic n x = (x-a)*(x-b)*(x-c)*(x-d)) :
    |a-2*n| + |b| + |c+n| + |d+n| <
      (if n=3 then (3047/2500:ℝ) else 1159/1000) := by
  have hnR : (0:ℝ)<n := by exact_mod_cast (show 0<n by omega)
  obtain ⟨hd,hc⟩ := reduce_quartic n a b c d hnR (hcd.trans (hbc.trans hab))
    (hcd.trans hbc) hcd hf
  have ht := sum_roots n a b c hc
  rcases hn with h|h <;> subst n <;> norm_num at hc hd ht ⊢
  · obtain ⟨⟨ha,ha'⟩,⟨hb,_⟩,⟨hc',_⟩⟩ := use_brackets 3 a b c
      (53906/10000) (54/10) (398/1000) (4/10) (-28/10) (-278/100)
      hab hbc (by norm_num) (by norm_num) hc
      (by norm_num) (by norm_num) (by norm_num)
      (by norm_num [cubic]) (by norm_num [cubic]) (by norm_num [cubic])
    rw [abs_of_neg (show a-6<0 by linarith),
      abs_of_pos (show b>0 by linarith), abs_of_pos (show c+3>0 by linarith), hd]
    norm_num
    linarith
  · obtain ⟨⟨ha,ha'⟩,⟨hb,_⟩,⟨hc',_⟩⟩ := use_brackets 4 a b c
      (74205/10000) (743/100) (42/100) (43/100) (-385/100) (-384/100)
      hab hbc (by norm_num) (by norm_num) hc
      (by norm_num) (by norm_num) (by norm_num)
      (by norm_num [cubic]) (by norm_num [cubic]) (by norm_num [cubic])
    rw [abs_of_neg (show a-8<0 by linarith),
      abs_of_pos (show b>0 by linarith), abs_of_pos (show c+4>0 by linarith), hd]
    norm_num
    linarith

#print axioms manhattan_small

end HubBenchmark


namespace PawUnbounded
open Matrix SpectralConjecture20 PawLargestFence
open scoped BigOperators Matrix

theorem benchmark_actual_quartic (n : Nat) (hn : 1≤n) (x : ℝ) :
    let q := singletonQEigen (n-1) n n
    (x+(n:ℝ))*HubBenchmark.cubic (n:ℝ) x=(x-q 0)*(x-q 1)*(x-q 2)*(x-q 3) := by
  dsimp
  rw [←singleton_factored_poly (n-1) n n x]
  unfold HubBenchmark.cubic poly pawE pawF pawG
  rw [Nat.cast_sub hn]
  push_cast
  ring

theorem benchmark_spectral_antitone (n : Nat) :
    Antitone (singletonQEigen (n-1) n n) := by
  intro i j hij
  exact (weightedQuotient_isHermitian seedPaw seedHerm (singletonWeights (n-1) n n)).eigenvalues₀_antitone hij

theorem actual_hub_benchmark_scores (n z : Nat) (hn : 3≤n)
    (hF : (withIsolates seedPaw (singletonWeights (n-1) n n) z).IsHermitian)
    (hN : 4≤Fintype.card (Vertices (singletonWeights (n-1) n n) ⊕ Fin z))
    (y : Fin (Fintype.card (Vertices (singletonWeights (n-1) n n) ⊕ Fin z)) → ℝ)
    (hy0 : y ⟨0,by omega⟩=2*(n:ℝ)) (hy1 : y ⟨1,by omega⟩=0)
    (hy2 : y (Fin.rev ⟨1,by omega⟩)= -(n:ℝ))
    (hy3 : y (Fin.rev ⟨0,by omega⟩)= -(n:ℝ))
    (hyRest : ∀ i : Fin (Fintype.card (Vertices (singletonWeights (n-1) n n) ⊕ Fin z)),
      2 ≤ i.val → 2 ≤ i.rev.val → y i=0) :
    ((∑ i,(hF.eigenvalues₀ i-y i)^2)<(16/27:ℝ)) ∧
    (5≤n → (∑ i,|hF.eigenvalues₀ i-y i|)<(17/15:ℝ)) ∧
    ((n=3 ∨ n=4) → (∑ i,|hF.eigenvalues₀ i-y i|)<(if n=3 then (3047/2500:ℝ) else 1159/1000)) := by
  let q := singletonQEigen (n-1) n n
  have hA := benchmark_spectral_antitone n
  have hab : q 1≤q 0 := hA (by decide)
  have hbc : q 2≤q 1 := hA (by decide)
  have hcd : q 3≤q 2 := hA (by decide)
  have hFct := benchmark_actual_quartic n (by omega)
  have eq (cost : ℝ → ℝ) (hCost : cost 0=0) :=
    singleton_ordered_quartet_score_eq n (n-1) n n z (by omega) (by omega) (by omega)
      hF hN y hy0 hy1 hy2 hy3 hyRest cost hCost
  constructor
  · have h := HubBenchmark.quartic_below_isolate_fence n (q 0) (q 1) (q 2) (q 3) hn hab hbc hcd hFct
    rw [eq (fun x => x^2) (by norm_num)]
    exact h
  · have hEq := eq (fun x => |x|) (by norm_num)
    constructor
    · intro hn₁
      rw [hEq]
      exact HubBenchmark.manhattan_large n (q 0) (q 1) (q 2) (q 3) hn₁ hab hbc hcd hFct
    · intro hn₂
      rw [hEq]
      exact HubBenchmark.manhattan_small n (q 0) (q 1) (q 2) (q 3) hn₂ hab hbc hcd hFct

#print axioms actual_hub_benchmark_scores
end PawUnbounded
