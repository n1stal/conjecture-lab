# The squared-distance nearest graph to the balanced complete tripartite graph

Jaime Nistal, with Codex assistance.

This formal proof establishes the p = 2 nearest-graph assertion and the limit of the squared cospectrality in Conjecture 20 of Irena M. Jovanović, Jelena Sedlar and Riste Škrekovski, [arXiv:2610.18636v2, §5](https://arxiv.org/html/2610.18636v2#S5). For each integer n ≥ 3, among simple undirected graphs on 3n vertices not isomorphic to the balanced complete tripartite graph Kₙ,ₙ,ₙ, a graph minimizes the sum of squared differences of ordered adjacency eigenvalues if and only if it is isomorphic to Hₙ. The authors already identified the n = 3 case; this result is uniform in n. It also proves that the true optimum tends to 1/2 as n grows. The Manhattan (p = 1) case is not asserted by this package; the work is not a historical priority claim or a claim of human referee acceptance.

## Identification of the formal objects

* The target is Kₙ,ₙ,ₙ: three independent sets of size n, all edges between distinct sets. Its checked eigenvalues are 2n, then 3n−3 zeros, then −n twice (C20Balance).
* The competitor Hₙ is (n−1)K₁ joined to K₁ ∪ Kₙ,ₙ. On four vertex classes with weights n−1, n, n, 1, its edges are precisely 01, 02, 03 and 12. C20Bench and C20HubRepEarly show it has a simple graph realization of the right size and a score strictly between 0 and 16/27.
* The key classification, close_graph_is_balanced_or_hub, proves that every simple graph on 3n vertices with score **strictly less than 16/27** is isomorphic to either Kₙ,ₙ,ₙ or Hₙ, without any connectedness assumption. It uses the previously verified rank-at-most-five theorem from Problem 21, plus the rank 2–5 catalogue, bounds for weighted templates and an explicit treatment of isolated vertices.
* Conjecture20Squared.squared_unique_nearest in C20Classify is unconditional. Its minimization domain excludes graphs isomorphic to the target, not all cospectral graphs. RelabelAs is exact matrix equality after a vertex bijection. Score is the sum of squares as written in §5 of the source.

## Reproduction

Use a checkout of [RokaSwK/conjecture-lab at 8673a57](https://github.com/RokaSwK/conjecture-lab/tree/8673a57d26ea1c8d2752635bd2dae5fe8665a171). Its lockfile pins Lean 4.35.0-rc2 (compiler commit 11acb17ec6b07a8f9e9173e6845197929540936b) and Mathlib 065356127b1dc0016f66b7283ce0ce2c4055aa55. Fetch those Lake dependencies (optionally use the Mathlib binary cache). With that toolchain on PATH, run:

    bash replay.sh /absolute/path/to/pinned/conjecture-lab

The script checks the source manifest, builds the published Problem 21 base, then checks all 16 research modules in dependency order with warnings promoted to errors. The final classification and minimization declarations use only propext, Classical.choice and Quot.sound. Exact strict build receipts from the verification run are included.


## Asymptotic provenance and check

The source authors’ Theorem 17(ii) already gives the sharper expansion σ²(Kₙ,ₙ,ₙ,Hₙ) = 1/2 − 1/(12n) + O(n⁻²) for their explicit candidate. The new use of that limit is for the optimum **over every graph**. The Lean follow-on does not take Theorem 17(ii) as an axiom or assert its sharper coefficient. Instead, it derives a deliberately loose sufficient bound directly from the source cubic.

For n ≥ 5 let a ≥ b ≥ c be the three cubic roots giving the other nonzero eigenvalues of Hₙ alongside −n. Evaluating the cubic at 1/2 and −n, and using previously checked root intervals, bounds n(1/2−b) by 1 and n(c+n) by 2, with both quantities nonnegative. The trace identity gives 2n−a=b+(c+n), and bounding the three squared deviations yields |n(σ²(K,Hₙ)−1/2)| ≤ 7. C20Limit defines cospectralitySquared as the infimum over the exact nonisomorphic graph competitors and proves that for n≥3 it equals the score of Hₙ. The theorem C20Rate.conjecture_20_squared_limit is the ordinary real limit of this infimum, not just an upper bound. Both this theorem and the independently imported objective identity and uniqueness restatement in IndependentSourceAudit have only the standard three Lean axioms.
