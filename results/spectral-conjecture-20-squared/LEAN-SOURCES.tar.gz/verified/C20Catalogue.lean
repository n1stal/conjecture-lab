import C20Structure
namespace RankFiveJoin
open Matrix Finset SpectralConjecture20 Conj20CutCert
open scoped BigOperators
def rowsJ : Rows := #[#[0,1,1,1,1],#[1,0,1,0,1],#[1,1,0,1,0],#[1,0,1,0,0],#[1,1,0,0,0]]
def J : Matrix (Fin 5) (Fin 5) ℝ := intMatrixToReal (ofRows 5 rowsJ)
theorem hJ : J.IsHermitian := by ext i j; fin_cases i <;> fin_cases j <;> rfl
def rowsP4 : Rows := #[#[0,1,0,1],#[1,0,1,0],#[0,1,0,0],#[1,0,0,0]]
def P4 : Matrix (Fin 4) (Fin 4) ℝ := intMatrixToReal (ofRows 4 rowsP4)
theorem hP4 : P4.IsHermitian := by ext i j; fin_cases i <;> fin_cases j <;> rfl
def seedRows (i : Fin 5) : Weights := Array.ofFn fun j : Fin 5 => if j=i then 2 else 1
def seedWeight (i : Fin 5) : Fin 5 → Nat := weightFn 5 (seedRows i)
def pThreshold (i : Fin 5) : Nat := if i=1 ∨ i=2 then 32 else 37
def nThreshold (i : Fin 5) : Nat := if i=1 ∨ i=2 then 25 else 24
def pathRows : Weights := #[1,1,1,1]
def pathWeight : Fin 4 → Nat := weightFn 4 pathRows
def p1Cert : Cert := ⟨#[#[1,-3,12,-3,3],#[0,-2,15,-18,-30],#[0,0,-7,-3,27],#[0,0,0,19,45],#[0,0,0,0,-40]],#[-64,448,-21280,-34048,1280],#[#[-10640,15960,15960,15960,15960],#[0,5320,11400,6840,11400],#[0,0,1520,240,1296],#[0,0,0,-560,-630],#[0,0,0,0,266]],-10640⟩
def p1Cache : Rows := #[#[-64,96,96,96,96],#[0,-224,-480,-288,-480],#[0,0,3040,480,2592],#[0,0,0,-1792,-2016],#[0,0,0,0,-32]]
theorem p1_check : validCached 5 rowsJ (seedRows 1) 2 48 (1) 32 p1Cert p1Cache=true := by decide +kernel

theorem p1_count :
    Fintype.card {j // ((pThreshold 1 : Nat):ℝ)/48 <
      (weightedQuotient_isHermitian J hJ (seedWeight 1)).eigenvalues j} =
      2 := by
  have hw (j : Fin 5) : 0<weightFn 5 (seedRows 1) j := by fin_cases j <;> decide
  have hd (j : Fin 5) : weightFn 5 (seedRows 1) j ∣ 2 := by fin_cases j <;> decide
  have eq := cached_cut_count_sound 5 rowsJ (seedRows 1) 2 48 (1) 32 p1Cert p1Cache
    p1_check hJ hw (by decide) (by decide) hd
  have ee : countPos 5 p1Cert.d = 2 := by decide +kernel
  rw [ee] at eq
  norm_num [seedWeight,pThreshold,nThreshold,pathWeight] at eq ⊢
  exact eq

def n1Cert : Cert := ⟨#[#[1,48,3408,-1200,4894800],#[0,-25,2208,9216,-8794464],#[0,0,-3983,-1200,-9504000],#[0,0,0,-7391,8849664],#[0,0,0,0,6899425]],#[-50,99575,1354164238,-4434230450,202818905615950],#[#[-5077692716175625,-9749170015057200,-9749170015057200,-9749170015057200,-9749170015057200],#[0,203107708647025,112593979586400,234978740006400,112593979586400],#[0,0,1274841254375,-206982750000,2021591520000],#[0,0,0,687010244375,-881205292800],#[0,0,0,0,-735958825]],-5077692716175625⟩
def n1Cache : Rows := #[#[-50,-96,-96,-96,-96],#[0,-3983,-2208,-4608,-2208],#[0,0,-339986,55200,-539136],#[0,0,0,599950,-769536],#[0,0,0,0,29396494]]
theorem n1_check : validCached 5 rowsJ (seedRows 1) 2 48 (-1) 25 n1Cert n1Cache=true := by decide +kernel

theorem n1_count :
    Fintype.card {j // ((nThreshold 1 : Nat):ℝ)/48 <
      -(weightedQuotient_isHermitian J hJ (seedWeight 1)).eigenvalues j} =
      3 := by
  have hw (j : Fin 5) : 0<weightFn 5 (seedRows 1) j := by fin_cases j <;> decide
  have hd (j : Fin 5) : weightFn 5 (seedRows 1) j ∣ 2 := by fin_cases j <;> decide
  have eq := cached_cut_count_sound 5 rowsJ (seedRows 1) 2 48 (-1) 25 n1Cert n1Cache
    n1_check hJ hw (by decide) (by decide) hd
  have ee : countPos 5 n1Cert.d = 3 := by decide +kernel
  rw [ee] at eq
  norm_num [seedWeight,pThreshold,nThreshold,pathWeight] at eq ⊢
  exact eq

def p2Cert : Cert := ⟨#[#[1,-3,3,-24,-24],#[0,-2,3,-81,-213],#[0,0,-1,-30,234],#[0,0,0,95,315],#[0,0,0,0,-352]],#[-64,320,-608,-1070080,78848],#[#[-66880,100320,100320,100320,100320],#[0,33440,100320,60192,100320],#[0,0,66880,21120,63360],#[0,0,0,-704,-630],#[0,0,0,0,190]],-66880⟩
def p2Cache : Rows := #[#[-64,96,96,96,96],#[0,-160,-480,-288,-480],#[0,0,608,192,576],#[0,0,0,-11264,-10080],#[0,0,0,0,-224]]
theorem p2_check : validCached 5 rowsJ (seedRows 2) 2 48 (1) 32 p2Cert p2Cache=true := by decide +kernel

theorem p2_count :
    Fintype.card {j // ((pThreshold 2 : Nat):ℝ)/48 <
      (weightedQuotient_isHermitian J hJ (seedWeight 2)).eigenvalues j} =
      2 := by
  have hw (j : Fin 5) : 0<weightFn 5 (seedRows 2) j := by fin_cases j <;> decide
  have hd (j : Fin 5) : weightFn 5 (seedRows 2) j ∣ 2 := by fin_cases j <;> decide
  have eq := cached_cut_count_sound 5 rowsJ (seedRows 2) 2 48 (1) 32 p2Cert p2Cache
    p2_check hJ hw (by decide) (by decide) hd
  have ee : countPos 5 p2Cert.d = 2 := by decide +kernel
  rw [ee] at eq
  norm_num [seedWeight,pThreshold,nThreshold,pathWeight] at eq ⊢
  exact eq

def n2Cert : Cert := ⟨#[#[1,48,48,-85200,6219600],#[0,-25,48,269568,-12249264],#[0,0,-73,-55200,-10828800],#[0,0,0,-169993,8849664],#[0,0,0,0,10989025]],#[-50,83950,539543,-3736114653650,323038807478350],#[#[-3409204621455625,-6545672873194800,-6545672873194800,-6545672873194800,-6545672873194800],#[0,136368184858225,89666751687600,187130612217600,89666751687600],#[0,0,46701433170625,-15164854500000,58233041280000],#[0,0,0,20054970625,-16150636800],#[0,0,0,0,-310237225]],-3409204621455625⟩
def n2Cache : Rows := #[#[-50,-96,-96,-96,-96],#[0,-3358,-2208,-4608,-2208],#[0,0,-7391,2400,-9216],#[0,0,0,21978050,-17699328],#[0,0,0,0,29396494]]
theorem n2_check : validCached 5 rowsJ (seedRows 2) 2 48 (-1) 25 n2Cert n2Cache=true := by decide +kernel

theorem n2_count :
    Fintype.card {j // ((nThreshold 2 : Nat):ℝ)/48 <
      -(weightedQuotient_isHermitian J hJ (seedWeight 2)).eigenvalues j} =
      3 := by
  have hw (j : Fin 5) : 0<weightFn 5 (seedRows 2) j := by fin_cases j <;> decide
  have hd (j : Fin 5) : weightFn 5 (seedRows 2) j ∣ 2 := by fin_cases j <;> decide
  have eq := cached_cut_count_sound 5 rowsJ (seedRows 2) 2 48 (-1) 25 n2Cert n2Cache
    n2_check hJ hw (by decide) (by decide) hd
  have ee : countPos 5 n2Cert.d = 3 := by decide +kernel
  rw [ee] at eq
  norm_num [seedWeight,pThreshold,nThreshold,pathWeight] at eq ⊢
  exact eq

def p3Cert : Cert := ⟨#[#[1,-48,48,-1776,-19536],#[0,-37,48,-4608,-240720],#[0,0,-11,-1776,170496],#[0,0,0,5015,391680],#[0,0,0,0,-336515]],#[-74,69190,-110330,-2640633205,27751045990],#[#[-686862449075,891064798800,891064798800,891064798800,891064798800],#[0,18563849975,81005890800,45744503040,81005890800],#[0,0,62442040825,22113073680,57374461440],#[0,0,0,-136961605,-159413760],#[0,0,0,0,2041105]],-686862449075⟩
def p3Cache : Rows := #[#[-74,96,96,96,96],#[0,-1870,-8160,-4608,-8160],#[0,0,10030,3552,9216],#[0,0,0,-526547,-612864],#[0,0,0,0,-82466]]
theorem p3_check : validCached 5 rowsJ (seedRows 3) 2 48 (1) 37 p3Cert p3Cache=true := by decide +kernel

theorem p3_count :
    Fintype.card {j // ((pThreshold 3 : Nat):ℝ)/48 <
      (weightedQuotient_isHermitian J hJ (seedWeight 3)).eigenvalues j} =
      2 := by
  have hw (j : Fin 5) : 0<weightFn 5 (seedRows 3) j := by fin_cases j <;> decide
  have hd (j : Fin 5) : weightFn 5 (seedRows 3) j ∣ 2 := by fin_cases j <;> decide
  have eq := cached_cut_count_sound 5 rowsJ (seedRows 3) 2 48 (1) 37 p3Cert p3Cache
    p3_check hJ hw (by decide) (by decide) hd
  have ee : countPos 5 p3Cert.d = 2 := by decide +kernel
  rw [ee] at eq
  norm_num [seedWeight,pThreshold,nThreshold,pathWeight] at eq ⊢
  exact eq

def n3Cert : Cert := ⟨#[#[1,2,2,-2,6],#[0,-1,2,8,-10],#[0,0,-3,-2,-8],#[0,0,0,-5,8],#[0,0,0,0,7]],#[-48,144,720,-2520,336],#[#[-105,-210,-210,-210,-210],#[0,105,70,140,70],#[0,0,35,-14,56],#[0,0,0,21,-24],#[0,0,0,0,-15]],-105⟩
def n3Cache : Rows := #[#[-48,-96,-96,-96,-96],#[0,-144,-96,-192,-96],#[0,0,-240,96,-384],#[0,0,0,504,-576],#[0,0,0,0,48]]
theorem n3_check : validCached 5 rowsJ (seedRows 3) 2 48 (-1) 24 n3Cert n3Cache=true := by decide +kernel

theorem n3_count :
    Fintype.card {j // ((nThreshold 3 : Nat):ℝ)/48 <
      -(weightedQuotient_isHermitian J hJ (seedWeight 3)).eigenvalues j} =
      3 := by
  have hw (j : Fin 5) : 0<weightFn 5 (seedRows 3) j := by fin_cases j <;> decide
  have hd (j : Fin 5) : weightFn 5 (seedRows 3) j ∣ 2 := by fin_cases j <;> decide
  have eq := cached_cut_count_sound 5 rowsJ (seedRows 3) 2 48 (-1) 24 n3Cert n3Cache
    n3_check hJ hw (by decide) (by decide) hd
  have ee : countPos 5 n3Cert.d = 3 := by decide +kernel
  rw [ee] at eq
  norm_num [seedWeight,pThreshold,nThreshold,pathWeight] at eq ⊢
  exact eq

def p4Cert : Cert := ⟨#[#[1,-48,48,-1776,1493616],#[0,-37,48,-4608,-13215120],#[0,0,-11,-1776,18584064],#[0,0,0,5015,26046720],#[0,0,0,0,-30264335]],#[-74,69190,-110330,-3571191530,165969280232315],#[#[-61772685490175,80137537933200,80137537933200,80137537933200,80137537933200],#[0,1669532040275,7285230721200,4114012642560,7285230721200],#[0,0,5615698680925,1988729981520,5159948060160],#[0,0,0,-12317584345,-10601015040],#[0,0,0,0,2041105]],-61772685490175⟩
def p4Cache : Rows := #[#[-74,96,96,96,96],#[0,-1870,-8160,-4608,-8160],#[0,0,10030,3552,9216],#[0,0,0,-712102,-612864],#[0,0,0,0,-5483989]]
theorem p4_check : validCached 5 rowsJ (seedRows 4) 2 48 (1) 37 p4Cert p4Cache=true := by decide +kernel

theorem p4_count :
    Fintype.card {j // ((pThreshold 4 : Nat):ℝ)/48 <
      (weightedQuotient_isHermitian J hJ (seedWeight 4)).eigenvalues j} =
      2 := by
  have hw (j : Fin 5) : 0<weightFn 5 (seedRows 4) j := by fin_cases j <;> decide
  have hd (j : Fin 5) : weightFn 5 (seedRows 4) j ∣ 2 := by fin_cases j <;> decide
  have eq := cached_cut_count_sound 5 rowsJ (seedRows 4) 2 48 (1) 37 p4Cert p4Cache
    p4_check hJ hw (by decide) (by decide) hd
  have ee : countPos 5 p4Cert.d = 2 := by decide +kernel
  rw [ee] at eq
  norm_num [seedWeight,pThreshold,nThreshold,pathWeight] at eq ⊢
  exact eq

def n4Cert : Cert := ⟨#[#[1,2,2,-2,10],#[0,-1,2,8,-14],#[0,0,-3,-2,-16],#[0,0,0,-5,12],#[0,0,0,0,13]],#[-48,144,720,-3120,936],#[#[-195,-390,-390,-390,-390],#[0,195,130,260,130],#[0,0,65,-26,104],#[0,0,0,39,-36],#[0,0,0,0,-15]],-195⟩
def n4Cache : Rows := #[#[-48,-96,-96,-96,-96],#[0,-144,-96,-192,-96],#[0,0,-240,96,-384],#[0,0,0,624,-576],#[0,0,0,0,72]]
theorem n4_check : validCached 5 rowsJ (seedRows 4) 2 48 (-1) 24 n4Cert n4Cache=true := by decide +kernel

theorem n4_count :
    Fintype.card {j // ((nThreshold 4 : Nat):ℝ)/48 <
      -(weightedQuotient_isHermitian J hJ (seedWeight 4)).eigenvalues j} =
      3 := by
  have hw (j : Fin 5) : 0<weightFn 5 (seedRows 4) j := by fin_cases j <;> decide
  have hd (j : Fin 5) : weightFn 5 (seedRows 4) j ∣ 2 := by fin_cases j <;> decide
  have eq := cached_cut_count_sound 5 rowsJ (seedRows 4) 2 48 (-1) 24 n4Cert n4Cache
    n4_check hJ hw (by decide) (by decide) hd
  have ee : countPos 5 n4Cert.d = 3 := by decide +kernel
  rw [ee] at eq
  norm_num [seedWeight,pThreshold,nThreshold,pathWeight] at eq ⊢
  exact eq

def rPathCert : Cert := ⟨#[#[1,1,1,3],#[0,-2,-2,-2],#[0,0,3,1],#[0,0,0,-4]],#[-2,-6,-12,-20],#[#[24,12,0,12],#[0,-12,-8,4],#[0,0,8,2],#[0,0,0,-6]],24⟩
def rPathCache : Rows := #[#[-2,-1,0,-1],#[0,3,2,-1],#[0,0,-4,-1],#[0,0,0,5]]

theorem path_check : validCached 4 rowsP4 pathRows 1 1 (-1) 2 rPathCert rPathCache=true := by decide +kernel
theorem path_count :
    Fintype.card {i // (2:ℝ) < -(weightedQuotient_isHermitian P4 hP4 pathWeight).eigenvalues i} = 0 := by
  have hw (j : Fin 4) : 0<weightFn 4 pathRows j := by fin_cases j <;> decide
  have hd (j : Fin 4) : weightFn 4 pathRows j ∣ 1 := by fin_cases j <;> decide
  have eq := cached_cut_count_sound 4 rowsP4 pathRows 1 1 (-1) 2 rPathCert rPathCache
    path_check hP4 hw (by decide) (by decide) hd
  have ee : countPos 4 rPathCert.d = 0 := by decide +kernel
  rw [ee] at eq
  norm_num [pathWeight] at eq ⊢
  exact eq
end RankFiveJoin



namespace RankFiveJoin
open Matrix Finset SpectralConjecture20 Conj20CutCert
open scoped BigOperators

theorem seedWeight_apply (i j : Fin 5) : seedWeight i j = if j=i then 2 else 1 := by
  fin_cases i <;> fin_cases j <;> rfl

theorem seed_pos_count (i : Fin 5) (hn : i≠0) :
    Fintype.card {j // ((pThreshold i : Nat):ℝ)/48 <
      (weightedQuotient_isHermitian J hJ (seedWeight i)).eigenvalues j}=2 := by
  fin_cases i
  · exact (hn rfl).elim
  · exact p1_count
  · exact p2_count
  · exact p3_count
  · exact p4_count

theorem seed_neg_count (i : Fin 5) (hn : i≠0) :
    Fintype.card {j // ((nThreshold i : Nat):ℝ)/48 <
      -(weightedQuotient_isHermitian J hJ (seedWeight i)).eigenvalues j}=3 := by
  fin_cases i
  · exact (hn rfl).elim
  · exact n1_count
  · exact n2_count
  · exact n3_count
  · exact n4_count

theorem pathWeight_apply (i : Fin 4) : pathWeight i=1 := by fin_cases i <;> rfl

theorem leaf_classes_singleton
    (w : Fin 5 → Nat) (hw : ∀ i, 0<w i) (z : Nat)
    (hFull : (withIsolates J w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hy : ∀ i, y i≠0 → 1≤|y i|)
    (hPos : Fintype.card {i // 0<y i}=1) (hNeg : Fintype.card {i // y i<0}=2)
    (hClose : (∑ i, (hFull.eigenvalues₀ i-y i)^2)<(2/3:ℝ)) :
    ∀ i, i≠0 → w i=1 := by
  intro i hi
  by_contra! hn
  have hLow : 2≤w i := by have hh:=hw i; omega
  have hwSeed (j : Fin 5) : 0<seedWeight i j := by rw [seedWeight_apply]; split <;> omega
  have hMono (j : Fin 5) : seedWeight i j≤w j := by
    have hj:=hw j
    rw [seedWeight_apply]
    split
    · rename_i he
      simpa [he] using hLow
    · omega
  have hGrid := weighted_template_grid_le_distance J hJ (seedWeight i) w hwSeed hMono z hFull y hy
    (hClose.trans (by norm_num)) 48 (by decide)
  rw [hPos,hNeg] at hGrid
  have hp := (seed_pos_count i hi).ge
  have hnN := (seed_neg_count i hi).ge
  have hMass : 2*48^2 ≤ 3*knownGridMass 48 1 2
      (prefixCount (pThreshold i) 2) (prefixCount (nThreshold i) 3) := by
    fin_cases i <;> decide +kernel
  exact ((not_le.mpr hClose)) (two_prefix_grid_rejects 48 (by decide) (pThreshold i) (nThreshold i)
    (weightedQuotient_isHermitian J hJ (seedWeight i)).eigenvalues hFull.eigenvalues₀ y hp hnN hMass hGrid)

theorem weightedQuotient_apply_explicit {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (w : m → Nat) (i j : m) :
    weightedQuotient B w i j = Real.sqrt (w i) * B i j * Real.sqrt (w j) := by
  simp [weightedQuotient,sqrtWeights]

theorem delete_universal_class
    (w : Fin 5 → Nat) (hw : ∀ i, i≠0 → w i=1) :
    (weightedQuotient J w).submatrix (Fin.succEmb 4) (Fin.succEmb 4) = weightedQuotient P4 pathWeight := by
  ext i j
  change weightedQuotient J w (i.succ) (j.succ) = _
  rw [weightedQuotient_apply_explicit,weightedQuotient_apply_explicit,
      hw i.succ (Fin.succ_ne_zero i), hw j.succ (Fin.succ_ne_zero j),
      pathWeight_apply, pathWeight_apply]
  have hJp : J i.succ j.succ=P4 i j := by
    fin_cases i <;> fin_cases j <;> rfl
  rw [hJp]

/-- End-to-end exclusion of every weighted blowup of the only rank-five unit
template surviving the preliminary signed-grid screen, even with isolates. -/
theorem no_close_blowup_of_join {w : Fin 5 → Nat} (hw : ∀ i, 0<w i) (z : Nat)
    (hFull : (withIsolates J w z).IsHermitian) (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hy : ∀ i, y i≠0 → 1≤|y i|)
    (hPos : Fintype.card {i // 0<y i}=1) (hNeg : Fintype.card {i // y i<0}=2)
    (hDeep : ∀ i, y i<0 → y i≤ -3) :
    (2/3:ℝ) ≤ ∑ i, (hFull.eigenvalues₀ i-y i)^2 := by
  by_contra! h
  have hW := leaf_classes_singleton w hw z hFull y hy hPos hNeg h
  let hQ := weightedQuotient_isHermitian J hJ w
  let e : Fin 4 ↪ Fin 5 := Fin.succEmb 4
  have hD := delete_universal_class w hW
  have inter := (shifted_principal_interlacing (weightedQuotient J w) hQ e (-1) 2).2
  change Fintype.card {i // (2:ℝ)<(-1)*(hQ.eigenvalues i)} + Fintype.card (Fin 4) ≤
     Fintype.card {i // (2:ℝ)<(-1)*((hQ.submatrix e).eigenvalues i)} + Fintype.card (Fin 5) at inter
  rw [cut_index_of_matrix_eq hD (hQ.submatrix e) (weightedQuotient_isHermitian P4 hP4 pathWeight) (-1) 2] at inter
  simp only [neg_one_mul, path_count, Fintype.card_fin, zero_add] at inter
  have hCount := withIsolates_ordered_cut_count J hJ w hw z hFull (-1) 2 (by norm_num)
  simp only [neg_one_mul] at hCount
  have hAtLeast := below_one_preserves_strict_negative_cut hFull.eigenvalues₀ y
    (h.trans (by norm_num)) hDeep
  rw [hNeg,hCount] at hAtLeast
  omega
#print axioms no_close_blowup_of_join
end RankFiveJoin

set_option maxRecDepth 10000
set_option maxHeartbeats 5000000

namespace UnitPruning
open Matrix SpectralConjecture20 Conj20CutCert
open scoped BigOperators

abbrev NatRows := Array (Array Nat)
def rawTemplate (A : NatRows) : Matrix (Fin A.size) (Fin A.size) ℝ :=
  fun i j => (((A[i.val]?.getD #[])[j.val]?).getD 0 : ℝ)

def Excluded {m : Type*} [Fintype m] [DecidableEq m] (B : Matrix m m ℝ) : Prop :=
  ∀ (w : m → Nat), (∀ i, 0<w i) → ∀ (z : Nat)
   (hFull : (withIsolates B w z).IsHermitian) (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ),
   (∀ i, y i≠0 → 1≤|y i|) → Fintype.card {i // 0<y i}=1 → Fintype.card {i // y i<0}=2 →
   (2/3:ℝ)≤∑ i,(hFull.eigenvalues₀ i-y i)^2

theorem excluded_of_unit_prefixes {m : Type*} [Fintype m] [DecidableEq m]
    (B : Matrix m m ℝ) (hB : B.IsHermitian)
    (a b cp cn : Nat)
    (hp : cp≤Fintype.card {j // (a:ℝ)/24 < (weightedQuotient_isHermitian B hB (fun _=>1)).eigenvalues j})
    (hn : cn≤Fintype.card {j // (b:ℝ)/24 < -(weightedQuotient_isHermitian B hB (fun _=>1)).eigenvalues j})
    (hMass : 2*24^2 ≤ 3*knownGridMass 24 1 2 (prefixCount a cp) (prefixCount b cn)) :
    Excluded B := by
  intro w hw z hFull y hy hPos hNeg
  by_contra! hc
  have hGrid := weighted_template_grid_le_distance B hB (fun _=>1) w
    (fun _ => by decide) (fun j => Nat.succ_le_of_lt (hw j)) z hFull y hy (hc.trans (by norm_num)) 24 (by decide)
  rw [hPos,hNeg] at hGrid
  have he := known_grid_rejects_close 24 1 2 (by decide) (prefixCount a cp) (prefixCount b cn)
    (weightedQuotient_isHermitian B hB (fun _=>1)).eigenvalues hFull.eigenvalues₀ y
    (fun j _ => prefix_count_sound _ 24 a cp (by decide) hp j)
    (fun j _ => prefix_count_sound _ 24 b cn (by decide) hn j) hMass hGrid
  exact hc.not_ge he

#print axioms excluded_of_unit_prefixes

def U3 : Array NatRows := #[#[#[0,1,1],#[1,0,1],#[1,1,0]]]
def U4 : Array NatRows := #[#[#[0,0,0,1],#[0,0,1,0],#[0,1,0,0],#[1,0,0,0]],#[#[0,1,0,1],#[1,0,1,0],#[0,1,0,0],#[1,0,0,0]],#[#[0,1,1,1],#[1,0,1,0],#[1,1,0,0],#[1,0,0,0]],#[#[0,1,1,1],#[1,0,1,1],#[1,1,0,1],#[1,1,1,0]],#[#[0,1,0,1,0],#[1,0,1,0,0],#[0,1,0,0,0],#[1,0,0,0,1],#[0,0,0,1,0]],#[#[0,1,1,1,0],#[1,0,1,0,0],#[1,1,0,0,1],#[1,0,0,0,1],#[0,0,1,1,0]],#[#[0,1,1,1,0],#[1,0,1,0,0],#[1,1,0,0,1],#[1,0,0,0,0],#[0,0,1,0,0]],#[#[0,1,1,1,0,0],#[1,0,1,0,1,0],#[1,1,0,0,0,1],#[1,0,0,0,1,1],#[0,1,0,1,0,1],#[0,0,1,1,1,0]],#[#[0,1,1,1,0,0],#[1,0,1,0,0,1],#[1,1,0,0,1,0],#[1,0,0,0,0,1],#[0,0,1,0,0,0],#[0,1,0,1,0,0]]]

def r4_0A : Rows := #[#[0,0,0,1],#[0,0,1,0],#[0,1,0,0],#[1,0,0,0]]
def r4_0B : Matrix (Fin 4) (Fin 4) ℝ := intMatrixToReal (ofRows 4 r4_0A)
theorem r4_0Herm : r4_0B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r4_0W : Weights := #[1,1,1,1]
theorem r4_0w : weightFn 4 r4_0W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r4_0pC : Cert := ⟨#[#[1,0,0,24],#[0,-1,24,0],#[0,0,23,0],#[0,0,0,23]], #[-23,-23,1081,1081], #[#[-529,0,0,552],#[0,529,-552,0],#[0,0,-23,0],#[0,0,0,-23]], -529⟩
def r4_0pX : Rows := #[#[-23,0,0,24],#[0,23,-24,0],#[0,0,47,0],#[0,0,0,47]]
theorem r4_0p_check : validCached 4 r4_0A r4_0W 1 24 (1) 23 r4_0pC r4_0pX=true := by decide +kernel
theorem r4_0p_count :
    2 ≤ Fintype.card {j // ((23:Nat):ℝ)/24 <
      (weightedQuotient_isHermitian r4_0B r4_0Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 4) : 0<weightFn 4 r4_0W j := by rw [r4_0w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 4) : weightFn 4 r4_0W j ∣ 1 := by rw [r4_0w]
  have eq := cached_cut_count_sound 4 r4_0A r4_0W 1 24 (1) 23 r4_0pC r4_0pX
    r4_0p_check r4_0Herm hw (by decide) (by decide) hd
  have ee : countPos 4 r4_0pC.d = 2 := by decide +kernel
  simp only [ee,r4_0w] at eq
  norm_num at eq ⊢
  exact (by decide : 2≤2).trans eq.ge


theorem r4_0_excluded : Excluded (rawTemplate U4[0]!) := by
  have hEx := excluded_of_unit_prefixes r4_0B r4_0Herm 23 0 2 0 r4_0p_count (Nat.zero_le _) (by decide +kernel)
  have he : rawTemplate U4[0]! = r4_0B := by
    ext j k
    change ((((#[#[0,0,0,1],#[0,0,1,0],#[0,1,0,0],#[1,0,0,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r4_0A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r4_3A : Rows := #[#[0,1,1,1],#[1,0,1,1],#[1,1,0,1],#[1,1,1,0]]
def r4_3B : Matrix (Fin 4) (Fin 4) ℝ := intMatrixToReal (ofRows 4 r4_3A)
theorem r4_3Herm : r4_3B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r4_3W : Weights := #[1,1,1,1]
theorem r4_3w : weightFn 4 r4_3W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r4_3nC : Cert := ⟨#[#[1,24,24,24],#[0,-23,24,24],#[0,0,-47,24],#[0,0,0,-71]], #[-23,1081,3337,6745], #[#[-76751,-80088,-80088,-80088],#[0,3337,1704,1704],#[0,0,1633,552],#[0,0,0,1081]], -76751⟩
def r4_3nX : Rows := #[#[-23,-24,-24,-24],#[0,-47,-24,-24],#[0,0,-71,-24],#[0,0,0,-95]]
theorem r4_3n_check : validCached 4 r4_3A r4_3W 1 24 (-1) 23 r4_3nC r4_3nX=true := by decide +kernel
theorem r4_3n_count :
    3 ≤ Fintype.card {j // ((23:Nat):ℝ)/24 <
      -(weightedQuotient_isHermitian r4_3B r4_3Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 4) : 0<weightFn 4 r4_3W j := by rw [r4_3w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 4) : weightFn 4 r4_3W j ∣ 1 := by rw [r4_3w]
  have eq := cached_cut_count_sound 4 r4_3A r4_3W 1 24 (-1) 23 r4_3nC r4_3nX
    r4_3n_check r4_3Herm hw (by decide) (by decide) hd
  have ee : countPos 4 r4_3nC.d = 3 := by decide +kernel
  simp only [ee,r4_3w] at eq
  norm_num at eq ⊢
  exact (by decide : 3≤3).trans eq.ge


theorem r4_3_excluded : Excluded (rawTemplate U4[3]!) := by
  have hEx := excluded_of_unit_prefixes r4_3B r4_3Herm 0 23 0 3 (Nat.zero_le _) r4_3n_count (by decide +kernel)
  have he : rawTemplate U4[3]! = r4_3B := by
    ext j k
    change ((((#[#[0,1,1,1],#[1,0,1,1],#[1,1,0,1],#[1,1,1,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r4_3A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r4_4A : Rows := #[#[0,1,0,1,0],#[1,0,1,0,0],#[0,1,0,0,0],#[1,0,0,0,1],#[0,0,0,1,0]]
def r4_4B : Matrix (Fin 5) (Fin 5) ℝ := intMatrixToReal (ofRows 5 r4_4A)
theorem r4_4Herm : r4_4B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r4_4W : Weights := #[1,1,1,1,1]
theorem r4_4w : weightFn 5 r4_4W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r4_4pC : Cert := ⟨#[#[1,-24,576,1128,-27072],#[0,-23,552,-13248,317952],#[0,0,-47,-13824,331776],#[0,0,0,14329,-343896],#[0,0,0,0,-302495]], #[-23,1081,-673463,-4334450855,392069516905], #[#[-4685541374255,4889260564440,0,4889260564440,0],#[0,203719190185,2392616871960,2496643692480,0],#[0,0,99692369665,96178890240,0],#[0,0,0,-326997095,371751576],#[0,0,0,0,15489649]], -4685541374255⟩
def r4_4pX : Rows := #[#[-23,24,0,24,0],#[0,-47,-552,-576,0],#[0,0,14329,13824,0],#[0,0,0,-302495,343896],#[0,0,0,0,-1296119]]
theorem r4_4p_check : validCached 5 r4_4A r4_4W 1 24 (1) 23 r4_4pC r4_4pX=true := by decide +kernel
theorem r4_4p_count :
    2 ≤ Fintype.card {j // ((23:Nat):ℝ)/24 <
      (weightedQuotient_isHermitian r4_4B r4_4Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 5) : 0<weightFn 5 r4_4W j := by rw [r4_4w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 5) : weightFn 5 r4_4W j ∣ 1 := by rw [r4_4w]
  have eq := cached_cut_count_sound 5 r4_4A r4_4W 1 24 (1) 23 r4_4pC r4_4pX
    r4_4p_check r4_4Herm hw (by decide) (by decide) hd
  have ee : countPos 5 r4_4pC.d = 2 := by decide +kernel
  simp only [ee,r4_4w] at eq
  norm_num at eq ⊢
  exact (by decide : 2≤2).trans eq.ge


theorem r4_4_excluded : Excluded (rawTemplate U4[4]!) := by
  have hEx := excluded_of_unit_prefixes r4_4B r4_4Herm 23 0 2 0 r4_4p_count (Nat.zero_le _) (by decide +kernel)
  have he : rawTemplate U4[4]! = r4_4B := by
    ext j k
    change ((((#[#[0,1,0,1,0],#[1,0,1,0,0],#[0,1,0,0,0],#[1,0,0,0,1],#[0,0,0,1,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r4_4A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r4_7A : Rows := #[#[0,1,1,1,0,0],#[1,0,1,0,1,0],#[1,1,0,0,0,1],#[1,0,0,0,1,1],#[0,1,0,1,0,1],#[0,0,1,1,1,0]]
def r4_7B : Matrix (Fin 6) (Fin 6) ℝ := intMatrixToReal (ofRows 6 r4_7A)
theorem r4_7Herm : r4_7B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r4_7W : Weights := #[1,1,1,1,1,1]
theorem r4_7w : weightFn 6 r4_7W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r4_7pC : Cert := ⟨#[#[1,-24,24,24,595584,-12672],#[0,-23,24,-576,305832,-12672],#[0,0,-1,-576,940608,-13848],#[0,0,0,1175,-675672,14376],#[0,0,0,0,-1243103,14376],#[0,0,0,0,0,12073]], #[-23,1081,-1175,-31077575,-24508035453527,966045241], #[#[-405590727575975,423225107035800,423225107035800,423225107035800,0,0],#[0,17634379459825,423225107035800,216114948273600,207110158762200,0],#[0,0,405590727575975,198825752411712,198825752411712,-8284406350488],#[0,0,0,-345183597937,187619925288,187619925288],#[0,0,0,0,326272825,-388511400],#[0,0,0,0,0,-33594858575]], -405590727575975⟩
def r4_7pX : Rows := #[#[-23,24,24,24,0,0],#[0,-47,-1128,-576,-552,0],#[0,0,1175,576,576,-24],#[0,0,0,-26449,14376,14376],#[0,0,0,0,19715209,-23476008],#[0,0,0,0,0,80017]]
theorem r4_7p_check : validCached 6 r4_7A r4_7W 1 24 (1) 23 r4_7pC r4_7pX=true := by decide +kernel
theorem r4_7p_count :
    2 ≤ Fintype.card {j // ((23:Nat):ℝ)/24 <
      (weightedQuotient_isHermitian r4_7B r4_7Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 6) : 0<weightFn 6 r4_7W j := by rw [r4_7w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 6) : weightFn 6 r4_7W j ∣ 1 := by rw [r4_7w]
  have eq := cached_cut_count_sound 6 r4_7A r4_7W 1 24 (1) 23 r4_7pC r4_7pX
    r4_7p_check r4_7Herm hw (by decide) (by decide) hd
  have ee : countPos 6 r4_7pC.d = 2 := by decide +kernel
  simp only [ee,r4_7w] at eq
  norm_num at eq ⊢
  exact (by decide : 2≤2).trans eq.ge


theorem r4_7_excluded : Excluded (rawTemplate U4[7]!) := by
  have hEx := excluded_of_unit_prefixes r4_7B r4_7Herm 23 0 2 0 r4_7p_count (Nat.zero_le _) (by decide +kernel)
  have he : rawTemplate U4[7]! = r4_7B := by
    ext j k
    change ((((#[#[0,1,1,1,0,0],#[1,0,1,0,1,0],#[1,1,0,0,0,1],#[1,0,0,0,1,1],#[0,1,0,1,0,1],#[0,0,1,1,1,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r4_7A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r4_8A : Rows := #[#[0,1,1,1,0,0],#[1,0,1,0,0,1],#[1,1,0,0,1,0],#[1,0,0,0,0,1],#[0,0,1,0,0,0],#[0,1,0,1,0,0]]
def r4_8B : Matrix (Fin 6) (Fin 6) ℝ := intMatrixToReal (ofRows 6 r4_8A)
theorem r4_8Herm : r4_8B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r4_8W : Weights := #[1,1,1,1,1,1]
theorem r4_8w : weightFn 6 r4_8W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r4_8pC : Cert := ⟨#[#[1,-24,24,24,622656,67968],#[0,-23,24,-576,290880,12120],#[0,0,-1,-576,-343896,-940608],#[0,0,0,1175,649728,993624],#[0,0,0,0,-1243103,-981504],#[0,0,0,0,0,884255]], #[-23,1081,-1175,-31077575,-25282060995095,3360161041705], #[#[-29706421669236625,30998005220073000,30998005220073000,30998005220073000,0,0],#[0,1291583550836375,30998005220073000,15828768623016000,0,15169236597057000],#[0,0,29706421669236625,14562467133174720,-606769463882280,14562467133174720],#[0,0,0,-25282060995095,-13214080350720,13741725920280],#[0,0,0,0,23896991375,26525145600],#[0,0,0,0,0,-33594858575]], -29706421669236625⟩
def r4_8pX : Rows := #[#[-23,24,24,24,0,0],#[0,-47,-1128,-576,0,-552],#[0,0,1175,576,-24,576],#[0,0,0,-26449,-13824,14376],#[0,0,0,0,20337865,22574592],#[0,0,0,0,0,3799991]]
theorem r4_8p_check : validCached 6 r4_8A r4_8W 1 24 (1) 23 r4_8pC r4_8pX=true := by decide +kernel
theorem r4_8p_count :
    2 ≤ Fintype.card {j // ((23:Nat):ℝ)/24 <
      (weightedQuotient_isHermitian r4_8B r4_8Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 6) : 0<weightFn 6 r4_8W j := by rw [r4_8w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 6) : weightFn 6 r4_8W j ∣ 1 := by rw [r4_8w]
  have eq := cached_cut_count_sound 6 r4_8A r4_8W 1 24 (1) 23 r4_8pC r4_8pX
    r4_8p_check r4_8Herm hw (by decide) (by decide) hd
  have ee : countPos 6 r4_8pC.d = 2 := by decide +kernel
  simp only [ee,r4_8w] at eq
  norm_num at eq ⊢
  exact (by decide : 2≤2).trans eq.ge


theorem r4_8_excluded : Excluded (rawTemplate U4[8]!) := by
  have hEx := excluded_of_unit_prefixes r4_8B r4_8Herm 23 0 2 0 r4_8p_count (Nat.zero_le _) (by decide +kernel)
  have he : rawTemplate U4[8]! = r4_8B := by
    ext j k
    change ((((#[#[0,1,1,1,0,0],#[1,0,1,0,0,1],#[1,1,0,0,1,0],#[1,0,0,0,0,1],#[0,0,1,0,0,0],#[0,1,0,1,0,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r4_8A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx

theorem exclude_rank4_outside_survivors (j : Fin 9) (h1 : j.val≠1) (h2 : j.val≠2) (h5 : j.val≠5) (h6 : j.val≠6) : Excluded (rawTemplate U4[j.val]!) := by
  fin_cases j
  · exact r4_0_excluded
  · exact (h1 rfl).elim
  · exact (h2 rfl).elim
  · exact r4_3_excluded
  · exact r4_4_excluded
  · exact (h5 rfl).elim
  · exact (h6 rfl).elim
  · exact r4_7_excluded
  · exact r4_8_excluded
#print axioms exclude_rank4_outside_survivors
def U5 : Array NatRows := #[#[#[0,0,0,1,1],#[0,0,1,0,1],#[0,1,0,1,0],#[1,0,1,0,0],#[1,1,0,0,0]],#[#[0,0,0,0,1],#[0,0,1,1,0],#[0,1,0,1,0],#[0,1,1,0,0],#[1,0,0,0,0]],#[#[0,1,1,0,1],#[1,0,1,1,0],#[1,1,0,1,0],#[0,1,1,0,0],#[1,0,0,0,0]],#[#[0,1,0,0,1],#[1,0,1,1,0],#[0,1,0,1,0],#[0,1,1,0,0],#[1,0,0,0,0]],#[#[0,1,1,1,1],#[1,0,0,0,1],#[1,0,0,1,0],#[1,0,1,0,0],#[1,1,0,0,0]],#[#[0,1,1,1,1],#[1,0,1,0,1],#[1,1,0,1,0],#[1,0,1,0,0],#[1,1,0,0,0]],#[#[0,1,1,1,1],#[1,0,1,1,0],#[1,1,0,1,0],#[1,1,1,0,0],#[1,0,0,0,0]],#[#[0,1,1,1,1],#[1,0,1,1,1],#[1,1,0,1,0],#[1,1,1,0,0],#[1,1,0,0,0]],#[#[0,1,1,1,1],#[1,0,1,1,1],#[1,1,0,1,1],#[1,1,1,0,1],#[1,1,1,1,0]],#[#[0,1,0,0,1,1],#[1,0,1,1,0,0],#[0,1,0,1,0,0],#[0,1,1,0,0,1],#[1,0,0,0,0,1],#[1,0,0,1,1,0]],#[#[0,1,1,0,1,0],#[1,0,1,1,0,0],#[1,1,0,1,0,0],#[0,1,1,0,0,0],#[1,0,0,0,0,1],#[0,0,0,0,1,0]],#[#[0,1,1,1,1,0],#[1,0,1,0,1,1],#[1,1,0,1,0,1],#[1,0,1,0,0,0],#[1,1,0,0,0,1],#[0,1,1,0,1,0]],#[#[0,1,1,1,1,0],#[1,0,1,1,0,0],#[1,1,0,1,0,0],#[1,1,1,0,0,1],#[1,0,0,0,0,1],#[0,0,0,1,1,0]],#[#[0,1,1,1,1,0],#[1,0,1,1,1,0],#[1,1,0,1,0,0],#[1,1,1,0,0,1],#[1,1,0,0,0,0],#[0,0,0,1,0,0]],#[#[0,1,1,1,1,0],#[1,0,1,0,1,0],#[1,1,0,1,0,0],#[1,0,1,0,0,0],#[1,1,0,0,0,1],#[0,0,0,0,1,0]],#[#[0,1,1,1,1,0],#[1,0,1,1,1,1],#[1,1,0,1,0,0],#[1,1,1,0,0,1],#[1,1,0,0,0,1],#[0,1,0,1,1,0]],#[#[0,1,1,1,1,0,0],#[1,0,1,0,1,0,1],#[1,1,0,1,0,0,1],#[1,0,1,0,0,0,0],#[1,1,0,0,0,1,1],#[0,0,0,0,1,0,1],#[0,1,1,0,1,1,0]],#[#[0,1,1,1,1,0,0],#[1,0,1,1,0,0,0],#[1,1,0,1,0,1,0],#[1,1,1,0,0,0,1],#[1,0,0,0,0,1,1],#[0,0,1,0,1,0,1],#[0,0,0,1,1,1,0]],#[#[0,1,1,1,1,0,0],#[1,0,1,0,1,1,0],#[1,1,0,1,0,1,0],#[1,0,1,0,0,1,0],#[1,1,0,0,0,0,1],#[0,1,1,1,0,0,0],#[0,0,0,0,1,0,0]],#[#[0,1,1,1,1,1,0],#[1,0,1,1,1,0,1],#[1,1,0,1,0,0,0],#[1,1,1,0,0,1,1],#[1,1,0,0,0,1,1],#[1,0,0,1,1,0,1],#[0,1,0,1,1,1,0]],#[#[0,1,1,1,1,0,0],#[1,0,1,1,1,0,0],#[1,1,0,1,0,1,0],#[1,1,1,0,0,0,1],#[1,1,0,0,0,0,0],#[0,0,1,0,0,0,1],#[0,0,0,1,0,1,0]],#[#[0,1,1,1,1,0,0],#[1,0,1,1,1,0,1],#[1,1,0,1,0,0,1],#[1,1,1,0,0,1,0],#[1,1,0,0,0,0,1],#[0,0,0,1,0,0,0],#[0,1,1,0,1,0,0]],#[#[0,1,1,1,1,0,0],#[1,0,1,1,1,1,1],#[1,1,0,1,0,1,0],#[1,1,1,0,0,0,1],#[1,1,0,0,0,1,1],#[0,1,1,0,1,0,1],#[0,1,0,1,1,1,0]],#[#[0,1,1,1,1,0,0,0],#[1,0,1,1,0,1,0,0],#[1,1,0,1,0,0,1,0],#[1,1,1,0,0,0,0,1],#[1,0,0,0,0,1,1,1],#[0,1,0,0,1,0,1,1],#[0,0,1,0,1,1,0,1],#[0,0,0,1,1,1,1,0]],#[#[0,1,1,1,1,0,1,0],#[1,0,1,1,1,0,0,1],#[1,1,0,1,0,0,1,1],#[1,1,1,0,0,1,0,0],#[1,1,0,0,0,0,1,1],#[0,0,0,1,0,0,0,0],#[1,0,1,0,1,0,0,1],#[0,1,1,0,1,0,1,0]]]

def r5_0A : Rows := #[#[0,0,0,1,1],#[0,0,1,0,1],#[0,1,0,1,0],#[1,0,1,0,0],#[1,1,0,0,0]]
def r5_0B : Matrix (Fin 5) (Fin 5) ℝ := intMatrixToReal (ofRows 5 r5_0A)
theorem r5_0Herm : r5_0B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r5_0W : Weights := #[1,1,1,1,1]
theorem r5_0w : weightFn 5 r5_0W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r5_0pC : Cert := ⟨#[#[1,0,0,1140,60],#[0,-1,12,-1008,60],#[0,0,7,-588,-144],#[0,0,0,665,-144],#[0,0,0,0,179]], #[-14,-14,1330,2618770,66946], #[#[-833245,0,0,1428420,1428420],#[0,833245,-1428420,0,-1428420],#[0,0,-119035,-105252,-180432],#[0,0,0,-1253,-1008],#[0,0,0,0,-4655]], -833245⟩
def r5_0pX : Rows := #[#[-14,0,0,24,24],#[0,14,-24,0,-24],#[0,0,190,168,288],#[0,0,0,3938,3168],#[0,0,0,0,374]]
theorem r5_0p_check : validCached 5 r5_0A r5_0W 1 24 (1) 14 r5_0pC r5_0pX=true := by decide +kernel
theorem r5_0p_count :
    3 ≤ Fintype.card {j // ((14:Nat):ℝ)/24 <
      (weightedQuotient_isHermitian r5_0B r5_0Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 5) : 0<weightFn 5 r5_0W j := by rw [r5_0w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 5) : weightFn 5 r5_0W j ∣ 1 := by rw [r5_0w]
  have eq := cached_cut_count_sound 5 r5_0A r5_0W 1 24 (1) 14 r5_0pC r5_0pX
    r5_0p_check r5_0Herm hw (by decide) (by decide) hd
  have ee : countPos 5 r5_0pC.d = 3 := by decide +kernel
  simp only [ee,r5_0w] at eq
  norm_num at eq ⊢
  exact (by decide : 3≤3).trans eq.ge


theorem r5_0_excluded : Excluded (rawTemplate U5[0]!) := by
  have hEx := excluded_of_unit_prefixes r5_0B r5_0Herm 14 0 3 0 r5_0p_count (Nat.zero_le _) (by decide +kernel)
  have he : rawTemplate U5[0]! = r5_0B := by
    ext j k
    change ((((#[#[0,0,0,1,1],#[0,0,1,0,1],#[0,1,0,1,0],#[1,0,1,0,0],#[1,1,0,0,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r5_0A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r5_1A : Rows := #[#[0,0,0,0,1],#[0,0,1,1,0],#[0,1,0,1,0],#[0,1,1,0,0],#[1,0,0,0,0]]
def r5_1B : Matrix (Fin 5) (Fin 5) ℝ := intMatrixToReal (ofRows 5 r5_1A)
theorem r5_1Herm : r5_1B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r5_1W : Weights := #[1,1,1,1,1]
theorem r5_1w : weightFn 5 r5_1W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r5_1nC : Cert := ⟨#[#[1,0,0,0,-24],#[0,-1,-24,-24,0],#[0,0,23,-24,0],#[0,0,0,47,0],#[0,0,0,0,23]], #[-23,-23,1081,3337,1081], #[#[-24863,0,0,0,-25944],#[0,24863,25944,25944,0],#[0,0,-1081,-552,0],#[0,0,0,-529,0],#[0,0,0,0,-1081]], -24863⟩
def r5_1nX : Rows := #[#[-23,0,0,0,-24],#[0,23,24,24,0],#[0,0,47,24,0],#[0,0,0,71,0],#[0,0,0,0,47]]
theorem r5_1n_check : validCached 5 r5_1A r5_1W 1 24 (-1) 23 r5_1nC r5_1nX=true := by decide +kernel
theorem r5_1n_count :
    3 ≤ Fintype.card {j // ((23:Nat):ℝ)/24 <
      -(weightedQuotient_isHermitian r5_1B r5_1Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 5) : 0<weightFn 5 r5_1W j := by rw [r5_1w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 5) : weightFn 5 r5_1W j ∣ 1 := by rw [r5_1w]
  have eq := cached_cut_count_sound 5 r5_1A r5_1W 1 24 (-1) 23 r5_1nC r5_1nX
    r5_1n_check r5_1Herm hw (by decide) (by decide) hd
  have ee : countPos 5 r5_1nC.d = 3 := by decide +kernel
  simp only [ee,r5_1w] at eq
  norm_num at eq ⊢
  exact (by decide : 3≤3).trans eq.ge


theorem r5_1_excluded : Excluded (rawTemplate U5[1]!) := by
  have hEx := excluded_of_unit_prefixes r5_1B r5_1Herm 0 23 0 3 (Nat.zero_le _) r5_1n_count (by decide +kernel)

  have he : rawTemplate U5[1]! = r5_1B := by
    ext j k
    change ((((#[#[0,0,0,0,1],#[0,0,1,1,0],#[0,1,0,1,0],#[0,1,1,0,0],#[1,0,0,0,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r5_1A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r5_2A : Rows := #[#[0,1,1,0,1],#[1,0,1,1,0],#[1,1,0,1,0],#[0,1,1,0,0],#[1,0,0,0,0]]
def r5_2B : Matrix (Fin 5) (Fin 5) ℝ := intMatrixToReal (ofRows 5 r5_2A)
theorem r5_2Herm : r5_2B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r5_2W : Weights := #[1,1,1,1,1]
theorem r5_2w : weightFn 5 r5_2W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r5_2pC : Cert := ⟨#[#[1,-24,24,-1152,-30504],#[0,-17,24,-408,9792],#[0,0,-7,-408,9792],#[0,0,0,1271,27648],#[0,0,0,0,-41191]], #[-17,4879,-8897,-52353761,1311892159], #[#[-6230097559,8795431848,8795431848,0,8795431848],#[0,366476327,1256490264,520983768,735506496],#[0,0,890013937,285700776,403342272],#[0,0,0,-4901729,-3290112],#[0,0,0,0,151249]], -6230097559⟩
def r5_2pX : Rows := #[#[-17,24,24,0,24],#[0,-287,-984,-408,-576],#[0,0,1271,408,576],#[0,0,0,-41191,-27648],#[0,0,0,0,-31849]]
theorem r5_2p_check : validCached 5 r5_2A r5_2W 1 24 (1) 17 r5_2pC r5_2pX=true := by decide +kernel
theorem r5_2p_count :
    2 ≤ Fintype.card {j // ((17:Nat):ℝ)/24 <
      (weightedQuotient_isHermitian r5_2B r5_2Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 5) : 0<weightFn 5 r5_2W j := by rw [r5_2w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 5) : weightFn 5 r5_2W j ∣ 1 := by rw [r5_2w]
  have eq := cached_cut_count_sound 5 r5_2A r5_2W 1 24 (1) 17 r5_2pC r5_2pX
    r5_2p_check r5_2Herm hw (by decide) (by decide) hd
  have ee : countPos 5 r5_2pC.d = 2 := by decide +kernel
  simp only [ee,r5_2w] at eq
  norm_num at eq ⊢
  exact (by decide : 2≤2).trans eq.ge


def r5_2nC : Cert := ⟨#[#[1,12,12,288,-1860],#[0,-7,12,-84,-1008],#[0,0,-19,-84,-1008],#[0,0,0,-155,3456],#[0,0,0,0,3101]], #[-14,1330,5890,-961310,3801826], #[#[-63927115,-109589340,-109589340,0,-109589340],#[0,9132445,5767860,-8075004,13842864],#[0,0,3364585,-1823388,3125808],#[0,0,0,412433,-459648],#[0,0,0,0,-20615]], -63927115⟩
def r5_2nX : Rows := #[#[-14,-24,-24,0,-24],#[0,-190,-120,168,-288],#[0,0,-310,168,-288],#[0,0,0,6202,-6912],#[0,0,0,0,1226]]
theorem r5_2n_check : validCached 5 r5_2A r5_2W 1 24 (-1) 14 r5_2nC r5_2nX=true := by decide +kernel
theorem r5_2n_count :
    3 ≤ Fintype.card {j // ((14:Nat):ℝ)/24 <
      -(weightedQuotient_isHermitian r5_2B r5_2Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 5) : 0<weightFn 5 r5_2W j := by rw [r5_2w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 5) : weightFn 5 r5_2W j ∣ 1 := by rw [r5_2w]
  have eq := cached_cut_count_sound 5 r5_2A r5_2W 1 24 (-1) 14 r5_2nC r5_2nX
    r5_2n_check r5_2Herm hw (by decide) (by decide) hd
  have ee : countPos 5 r5_2nC.d = 3 := by decide +kernel
  simp only [ee,r5_2w] at eq
  norm_num at eq ⊢
  exact (by decide : 3≤3).trans eq.ge


theorem r5_2_excluded : Excluded (rawTemplate U5[2]!) := by
  have hEx := excluded_of_unit_prefixes r5_2B r5_2Herm 17 14 2 3 r5_2p_count r5_2n_count (by decide +kernel)
  have he : rawTemplate U5[2]! = r5_2B := by
    ext j k
    change ((((#[#[0,1,1,0,1],#[1,0,1,1,0],#[1,1,0,1,0],#[0,1,1,0,0],#[1,0,0,0,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r5_2A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r5_3A : Rows := #[#[0,1,0,0,1],#[1,0,1,1,0],#[0,1,0,1,0],#[0,1,1,0,0],#[1,0,0,0,0]]
def r5_3B : Matrix (Fin 5) (Fin 5) ℝ := intMatrixToReal (ofRows 5 r5_3A)
theorem r5_3Herm : r5_3B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r5_3W : Weights := #[1,1,1,1,1]
theorem r5_3w : weightFn 5 r5_3W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r5_3pC : Cert := ⟨#[#[1,-24,576,-27072,-28200],#[0,-23,552,-25944,-576],#[0,0,-47,-12120,13824],#[0,0,0,14329,13824],#[0,0,0,0,-26449]], #[-23,1081,-673463,-17812422887,1811042377], #[#[-409685726401,427498149288,0,0,427498149288],#[0,17812422887,209201221992,209201221992,218296927296],#[0,0,8716717583,7372923240,8409512448],#[0,0,0,-28591369,-14943744],#[0,0,0,0,15489649]], -409685726401⟩
def r5_3pX : Rows := #[#[-23,24,0,0,24],#[0,-47,-552,-552,-576],#[0,0,14329,12120,13824],#[0,0,0,-1243103,-649728],#[0,0,0,0,-68473]]
theorem r5_3p_check : validCached 5 r5_3A r5_3W 1 24 (1) 23 r5_3pC r5_3pX=true := by decide +kernel
theorem r5_3p_count :
    2 ≤ Fintype.card {j // ((23:Nat):ℝ)/24 <
      (weightedQuotient_isHermitian r5_3B r5_3Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 5) : 0<weightFn 5 r5_3W j := by rw [r5_3w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 5) : weightFn 5 r5_3W j ∣ 1 := by rw [r5_3w]
  have eq := cached_cut_count_sound 5 r5_3A r5_3W 1 24 (1) 23 r5_3pC r5_3pX
    r5_3p_check r5_3Herm hw (by decide) (by decide) hd
  have ee : countPos 5 r5_3pC.d = 2 := by decide +kernel
  simp only [ee,r5_3w] at eq
  norm_num at eq ⊢
  exact (by decide : 2≤2).trans eq.ge


theorem r5_3_excluded : Excluded (rawTemplate U5[3]!) := by
  have hEx := excluded_of_unit_prefixes r5_3B r5_3Herm 23 0 2 0 r5_3p_count (Nat.zero_le _) (by decide +kernel)
  have he : rawTemplate U5[3]! = r5_3B := by
    ext j k
    change ((((#[#[0,1,0,0,1],#[1,0,1,1,0],#[0,1,0,1,0],#[0,1,1,0,0],#[1,0,0,0,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r5_3A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r5_4A : Rows := #[#[0,1,1,1,1],#[1,0,0,0,1],#[1,0,0,1,0],#[1,0,1,0,0],#[1,1,0,0,0]]
def r5_4B : Matrix (Fin 5) (Fin 5) ℝ := intMatrixToReal (ofRows 5 r5_4A)
theorem r5_4Herm : r5_4B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r5_4W : Weights := #[1,1,1,1,1]
theorem r5_4w : weightFn 5 r5_4W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r5_4nC : Cert := ⟨#[#[1,24,-552,-552,-1128],#[0,-23,576,576,-28776],#[0,0,-47,-14376,576],#[0,0,0,14329,576],#[0,0,0,0,28705]], #[-23,1081,-673463,411313945,1649992105], #[#[444630374545,463962129960,463962129960,463962129960,463962129960],#[0,-19331755415,-236916832320,-236916832320,-9871534680],#[0,0,-9460220735,-9491250840,380283840],#[0,0,0,31030105,-622656],#[0,0,0,0,15489649]], 444630374545⟩
def r5_4nX : Rows := #[#[-23,-24,-24,-24,-24],#[0,-47,-576,-576,-24],#[0,0,14329,14376,-576],#[0,0,0,28705,-576],#[0,0,0,0,57481]]
theorem r5_4n_check : validCached 5 r5_4A r5_4W 1 24 (-1) 23 r5_4nC r5_4nX=true := by decide +kernel
theorem r5_4n_count :
    3 ≤ Fintype.card {j // ((23:Nat):ℝ)/24 <
      -(weightedQuotient_isHermitian r5_4B r5_4Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 5) : 0<weightFn 5 r5_4W j := by rw [r5_4w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 5) : weightFn 5 r5_4W j ∣ 1 := by rw [r5_4w]
  have eq := cached_cut_count_sound 5 r5_4A r5_4W 1 24 (-1) 23 r5_4nC r5_4nX
    r5_4n_check r5_4Herm hw (by decide) (by decide) hd
  have ee : countPos 5 r5_4nC.d = 3 := by decide +kernel
  simp only [ee,r5_4w] at eq
  norm_num at eq ⊢
  exact (by decide : 3≤3).trans eq.ge


theorem r5_4_excluded : Excluded (rawTemplate U5[4]!) := by
  have hEx := excluded_of_unit_prefixes r5_4B r5_4Herm 0 23 0 3 (Nat.zero_le _) r5_4n_count (by decide +kernel)
  have he : rawTemplate U5[4]! = r5_4B := by
    ext j k
    change ((((#[#[0,1,1,1,1],#[1,0,0,0,1],#[1,0,0,1,0],#[1,0,1,0,0],#[1,1,0,0,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r5_4A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r5_6A : Rows := #[#[0,1,1,1,1],#[1,0,1,1,0],#[1,1,0,1,0],#[1,1,1,0,0],#[1,0,0,0,0]]
def r5_6B : Matrix (Fin 5) (Fin 5) ℝ := intMatrixToReal (ofRows 5 r5_6A)
theorem r5_6Herm : r5_6B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r5_6W : Weights := #[1,1,1,1,1]
theorem r5_6w : weightFn 5 r5_6W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r5_6nC : Cert := ⟨#[#[1,24,24,24,-1704],#[0,-23,24,24,576],#[0,0,-47,24,576],#[0,0,0,-71,576],#[0,0,0,0,-95]], #[-23,1081,3337,6745,-4092695], #[#[7291345,7608360,7608360,7608360,7608360],#[0,-317015,-161880,-161880,-3885120],#[0,0,-155135,-52440,-1258560],#[0,0,0,-102695,-622656],#[0,0,0,0,-76751]], 7291345⟩
def r5_6nX : Rows := #[#[-23,-24,-24,-24,-24],#[0,-47,-24,-24,-576],#[0,0,-71,-24,-576],#[0,0,0,-95,-576],#[0,0,0,0,43081]]
theorem r5_6n_check : validCached 5 r5_6A r5_6W 1 24 (-1) 23 r5_6nC r5_6nX=true := by decide +kernel
theorem r5_6n_count :
    3 ≤ Fintype.card {j // ((23:Nat):ℝ)/24 <
      -(weightedQuotient_isHermitian r5_6B r5_6Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 5) : 0<weightFn 5 r5_6W j := by rw [r5_6w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 5) : weightFn 5 r5_6W j ∣ 1 := by rw [r5_6w]
  have eq := cached_cut_count_sound 5 r5_6A r5_6W 1 24 (-1) 23 r5_6nC r5_6nX
    r5_6n_check r5_6Herm hw (by decide) (by decide) hd
  have ee : countPos 5 r5_6nC.d = 3 := by decide +kernel
  simp only [ee,r5_6w] at eq
  norm_num at eq ⊢
  exact (by decide : 3≤3).trans eq.ge


theorem r5_6_excluded : Excluded (rawTemplate U5[6]!) := by
  have hEx := excluded_of_unit_prefixes r5_6B r5_6Herm 0 23 0 3 (Nat.zero_le _) r5_6n_count (by decide +kernel)
  have he : rawTemplate U5[6]! = r5_6B := by
    ext j k
    change ((((#[#[0,1,1,1,1],#[1,0,1,1,0],#[1,1,0,1,0],#[1,1,1,0,0],#[1,0,0,0,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r5_6A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r5_7A : Rows := #[#[0,1,1,1,1],#[1,0,1,1,1],#[1,1,0,1,0],#[1,1,1,0,0],#[1,1,0,0,0]]
def r5_7B : Matrix (Fin 5) (Fin 5) ℝ := intMatrixToReal (ofRows 5 r5_7A)
theorem r5_7Herm : r5_7B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r5_7W : Weights := #[1,1,1,1,1]
theorem r5_7w : weightFn 5 r5_7W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r5_7nC : Cert := ⟨#[#[1,24,24,24,-1128],#[0,-23,24,24,-1128],#[0,0,-47,24,1152],#[0,0,0,-71,1152],#[0,0,0,0,-95]], #[-23,1081,3337,6745,-5351255], #[#[7291345,7608360,7608360,7608360,7608360],#[0,-317015,-161880,-161880,-161880],#[0,0,-155135,-52440,-2517120],#[0,0,0,-102695,-1245312],#[0,0,0,0,-76751]], 7291345⟩
def r5_7nX : Rows := #[#[-23,-24,-24,-24,-24],#[0,-47,-24,-24,-24],#[0,0,-71,-24,-1152],#[0,0,0,-95,-1152],#[0,0,0,0,56329]]
theorem r5_7n_check : validCached 5 r5_7A r5_7W 1 24 (-1) 23 r5_7nC r5_7nX=true := by decide +kernel
theorem r5_7n_count :
    3 ≤ Fintype.card {j // ((23:Nat):ℝ)/24 <
      -(weightedQuotient_isHermitian r5_7B r5_7Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 5) : 0<weightFn 5 r5_7W j := by rw [r5_7w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 5) : weightFn 5 r5_7W j ∣ 1 := by rw [r5_7w]
  have eq := cached_cut_count_sound 5 r5_7A r5_7W 1 24 (-1) 23 r5_7nC r5_7nX
    r5_7n_check r5_7Herm hw (by decide) (by decide) hd
  have ee : countPos 5 r5_7nC.d = 3 := by decide +kernel
  simp only [ee,r5_7w] at eq
  norm_num at eq ⊢
  exact (by decide : 3≤3).trans eq.ge


theorem r5_7_excluded : Excluded (rawTemplate U5[7]!) := by
  have hEx := excluded_of_unit_prefixes r5_7B r5_7Herm 0 23 0 3 (Nat.zero_le _) r5_7n_count (by decide +kernel)
  have he : rawTemplate U5[7]! = r5_7B := by
    ext j k
    change ((((#[#[0,1,1,1,1],#[1,0,1,1,1],#[1,1,0,1,0],#[1,1,1,0,0],#[1,1,0,0,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r5_7A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r5_8A : Rows := #[#[0,1,1,1,1],#[1,0,1,1,1],#[1,1,0,1,1],#[1,1,1,0,1],#[1,1,1,1,0]]
def r5_8B : Matrix (Fin 5) (Fin 5) ℝ := intMatrixToReal (ofRows 5 r5_8A)
theorem r5_8Herm : r5_8B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r5_8W : Weights := #[1,1,1,1,1]
theorem r5_8w : weightFn 5 r5_8W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r5_8nC : Cert := ⟨#[#[1,24,24,24,24],#[0,-23,24,24,24],#[0,0,-47,24,24],#[0,0,0,-71,24],#[0,0,0,0,-95]], #[-23,1081,3337,6745,11305], #[#[7291345,7608360,7608360,7608360,7608360],#[0,-317015,-161880,-161880,-161880],#[0,0,-155135,-52440,-52440],#[0,0,0,-102695,-25944],#[0,0,0,0,-76751]], 7291345⟩
def r5_8nX : Rows := #[#[-23,-24,-24,-24,-24],#[0,-47,-24,-24,-24],#[0,0,-71,-24,-24],#[0,0,0,-95,-24],#[0,0,0,0,-119]]
theorem r5_8n_check : validCached 5 r5_8A r5_8W 1 24 (-1) 23 r5_8nC r5_8nX=true := by decide +kernel
theorem r5_8n_count :
    3 ≤ Fintype.card {j // ((23:Nat):ℝ)/24 <
      -(weightedQuotient_isHermitian r5_8B r5_8Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 5) : 0<weightFn 5 r5_8W j := by rw [r5_8w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 5) : weightFn 5 r5_8W j ∣ 1 := by rw [r5_8w]
  have eq := cached_cut_count_sound 5 r5_8A r5_8W 1 24 (-1) 23 r5_8nC r5_8nX
    r5_8n_check r5_8Herm hw (by decide) (by decide) hd
  have ee : countPos 5 r5_8nC.d = 4 := by decide +kernel
  simp only [ee,r5_8w] at eq
  norm_num at eq ⊢
  exact (by decide : 3≤4).trans eq.ge


theorem r5_8_excluded : Excluded (rawTemplate U5[8]!) := by
  have hEx := excluded_of_unit_prefixes r5_8B r5_8Herm 0 23 0 3 (Nat.zero_le _) r5_8n_count (by decide +kernel)
  have he : rawTemplate U5[8]! = r5_8B := by
    ext j k
    change ((((#[#[0,1,1,1,1],#[1,0,1,1,1],#[1,1,0,1,1],#[1,1,1,0,1],#[1,1,1,1,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r5_8A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r5_9A : Rows := #[#[0,1,0,0,1,1],#[1,0,1,1,0,0],#[0,1,0,1,0,0],#[0,1,1,0,0,1],#[1,0,0,0,0,1],#[1,0,0,1,1,0]]
def r5_9B : Matrix (Fin 6) (Fin 6) ℝ := intMatrixToReal (ofRows 6 r5_9A)
theorem r5_9Herm : r5_9B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r5_9W : Weights := #[1,1,1,1,1,1]
theorem r5_9w : weightFn 6 r5_9W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r5_9pC : Cert := ⟨#[#[1,0,1,-2,-2,2],#[0,0,1,-2,2,-1],#[0,-1,1,-1,3,-2],#[0,0,0,1,1,-1],#[0,0,0,0,0,1],#[0,0,0,0,-4,2]], #[-24,-24,24,-96,-288,72], #[#[4,-4,0,0,-4,-4],#[0,4,-4,4,0,0],#[0,4,0,8,4,4],#[0,0,0,4,2,1],#[0,0,0,0,2,-1],#[0,0,0,0,4,0]], 4⟩
def r5_9pX : Rows := #[#[-24,24,0,0,24,24],#[0,-24,24,-24,0,0],#[0,24,0,48,24,24],#[0,0,0,-96,-48,-24],#[0,0,0,0,-144,72],#[0,0,0,0,72,0]]
theorem r5_9p_check : validCached 6 r5_9A r5_9W 1 24 (1) 24 r5_9pC r5_9pX=true := by decide +kernel
theorem r5_9p_count :
    2 ≤ Fintype.card {j // ((24:Nat):ℝ)/24 <
      (weightedQuotient_isHermitian r5_9B r5_9Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 6) : 0<weightFn 6 r5_9W j := by rw [r5_9w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 6) : weightFn 6 r5_9W j ∣ 1 := by rw [r5_9w]
  have eq := cached_cut_count_sound 6 r5_9A r5_9W 1 24 (1) 24 r5_9pC r5_9pX
    r5_9p_check r5_9Herm hw (by decide) (by decide) hd
  have ee : countPos 6 r5_9pC.d = 2 := by decide +kernel
  simp only [ee,r5_9w] at eq
  norm_num at eq ⊢
  exact (by decide : 2≤2).trans eq.ge


theorem r5_9_excluded : Excluded (rawTemplate U5[9]!) := by
  have hEx := excluded_of_unit_prefixes r5_9B r5_9Herm 24 0 2 0 r5_9p_count (Nat.zero_le _) (by decide +kernel)
  have he : rawTemplate U5[9]! = r5_9B := by
    ext j k
    change ((((#[#[0,1,0,0,1,1],#[1,0,1,1,0,0],#[0,1,0,1,0,0],#[0,1,1,0,0,1],#[1,0,0,0,0,1],#[1,0,0,1,1,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r5_9A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r5_10A : Rows := #[#[0,1,1,0,1,0],#[1,0,1,1,0,0],#[1,1,0,1,0,0],#[0,1,1,0,0,0],#[1,0,0,0,0,1],#[0,0,0,0,1,0]]
def r5_10B : Matrix (Fin 6) (Fin 6) ℝ := intMatrixToReal (ofRows 6 r5_10A)
theorem r5_10Herm : r5_10B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r5_10W : Weights := #[1,1,1,1,1,1]
theorem r5_10w : weightFn 6 r5_10W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r5_10nC : Cert := ⟨#[#[1,24,24,1152,-1704,-40896],#[0,-23,24,-552,-13248,-317952],#[0,0,-47,-552,-13248,-317952],#[0,0,0,-71,27648,663552],#[0,0,0,0,28129,675096],#[0,0,0,0,0,-606071]], #[-23,1081,3337,-1997159,-17048171159,1371339275641], #[#[1308464184624409,1365353931781992,1365353931781992,0,1365353931781992,0],#[0,-56889747157583,-29050083654936,668151924063528,-697202007718464,0],#[0,0,-27839663502647,216443581034664,-225854171514432,0],#[0,0,0,-18429073022879,18113939739648,0],#[0,0,0,0,46516555321,51814293096],#[0,0,0,0,0,-2158928879]], 1308464184624409⟩
def r5_10nX : Rows := #[#[-23,-24,-24,0,-24,0],#[0,-47,-24,552,-576,0],#[0,0,-71,552,-576,0],#[0,0,0,28129,-27648,0],#[0,0,0,0,-606071,-675096],#[0,0,0,0,0,-2262671]]
theorem r5_10n_check : validCached 6 r5_10A r5_10W 1 24 (-1) 23 r5_10nC r5_10nX=true := by decide +kernel
theorem r5_10n_count :
    3 ≤ Fintype.card {j // ((23:Nat):ℝ)/24 <
      -(weightedQuotient_isHermitian r5_10B r5_10Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 6) : 0<weightFn 6 r5_10W j := by rw [r5_10w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 6) : weightFn 6 r5_10W j ∣ 1 := by rw [r5_10w]
  have eq := cached_cut_count_sound 6 r5_10A r5_10W 1 24 (-1) 23 r5_10nC r5_10nX
    r5_10n_check r5_10Herm hw (by decide) (by decide) hd
  have ee : countPos 6 r5_10nC.d = 3 := by decide +kernel
  simp only [ee,r5_10w] at eq
  norm_num at eq ⊢
  exact (by decide : 3≤3).trans eq.ge


theorem r5_10_excluded : Excluded (rawTemplate U5[10]!) := by
  have hEx := excluded_of_unit_prefixes r5_10B r5_10Herm 0 23 0 3 (Nat.zero_le _) r5_10n_count (by decide +kernel)
  have he : rawTemplate U5[10]! = r5_10B := by
    ext j k
    change ((((#[#[0,1,1,0,1,0],#[1,0,1,1,0,0],#[1,1,0,1,0,0],#[0,1,1,0,0,0],#[1,0,0,0,0,1],#[0,0,0,0,1,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r5_10A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r5_11A : Rows := #[#[0,1,1,1,1,0],#[1,0,1,0,1,1],#[1,1,0,1,0,1],#[1,0,1,0,0,0],#[1,1,0,0,0,1],#[0,1,1,0,1,0]]
def r5_11B : Matrix (Fin 6) (Fin 6) ℝ := intMatrixToReal (ofRows 6 r5_11A)
theorem r5_11Herm : r5_11B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r5_11W : Weights := #[1,1,1,1,1,1]
theorem r5_11w : weightFn 6 r5_11W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r5_11pC : Cert := ⟨#[#[1,-8,8,-56,2296,-97088],#[0,-7,8,-128,-9480,101752],#[0,0,-1,-56,17024,-110280],#[0,0,0,135,22080,-236992],#[0,0,0,0,-27615,160568],#[0,0,0,0,0,135833]], #[-21,315,-405,-745605,-11253084885,108186502011], #[#[-3544721738775,4051110558600,4051110558600,4051110558600,4051110558600,0],#[0,506388819825,4051110558600,2160592297920,4051110558600,1890518260680],#[0,0,3544721738775,1470403091640,3360921352320,1470403091640],#[0,0,0,-26257198065,-20994348480,-20994348480],#[0,0,0,0,128362185,-151736760],#[0,0,0,0,0,-26096175]], -3544721738775⟩
def r5_11pX : Rows := #[#[-21,24,24,24,24,0],#[0,-45,-360,-192,-360,-168],#[0,0,405,168,384,168],#[0,0,0,-5523,-4416,-4416],#[0,0,0,0,407499,-481704],#[0,0,0,0,0,796467]]
theorem r5_11p_check : validCached 6 r5_11A r5_11W 1 24 (1) 21 r5_11pC r5_11pX=true := by decide +kernel
theorem r5_11p_count :
    2 ≤ Fintype.card {j // ((21:Nat):ℝ)/24 <
      (weightedQuotient_isHermitian r5_11B r5_11Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 6) : 0<weightFn 6 r5_11W j := by rw [r5_11w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 6) : weightFn 6 r5_11W j ∣ 1 := by rw [r5_11w]
  have eq := cached_cut_count_sound 6 r5_11A r5_11W 1 24 (1) 21 r5_11pC r5_11pX
    r5_11p_check r5_11Herm hw (by decide) (by decide) hd
  have ee : countPos 6 r5_11pC.d = 2 := by decide +kernel
  simp only [ee,r5_11w] at eq
  norm_num at eq ⊢
  exact (by decide : 2≤2).trans eq.ge


theorem r5_11_excluded : Excluded (rawTemplate U5[11]!) := by
  have hEx := excluded_of_unit_prefixes r5_11B r5_11Herm 21 0 2 0 r5_11p_count (Nat.zero_le _) (by decide +kernel)
  have he : rawTemplate U5[11]! = r5_11B := by
    ext j k
    change ((((#[#[0,1,1,1,1,0],#[1,0,1,0,1,1],#[1,1,0,1,0,1],#[1,0,1,0,0,0],#[1,1,0,0,0,1],#[0,1,1,0,1,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r5_11A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r5_12A : Rows := #[#[0,1,1,1,1,0],#[1,0,1,1,0,0],#[1,1,0,1,0,0],#[1,1,1,0,0,1],#[1,0,0,0,0,1],#[0,0,0,1,1,0]]
def r5_12B : Matrix (Fin 6) (Fin 6) ℝ := intMatrixToReal (ofRows 6 r5_12A)
theorem r5_12Herm : r5_12B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r5_12W : Weights := #[1,1,1,1,1,1]
theorem r5_12w : weightFn 6 r5_12W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r5_12nC : Cert := ⟨#[#[1,24,24,24,-1704,-54144],#[0,-23,24,24,576,-331200],#[0,0,-47,24,576,-331200],#[0,0,0,-71,576,702744],#[0,0,0,0,-95,11544],#[0,0,0,0,0,43081]], #[-23,1081,3337,6745,-4092695,-781221160775], #[#[314118433945,327775757160,327775757160,327775757160,327775757160,0],#[0,-13657323215,-6973952280,-6973952280,-167374854720,0],#[0,0,-6683370935,-2259167640,-54220023360,0],#[0,0,0,-4424203295,-26824643136,79356235944],#[0,0,0,0,-3306509831,886013544],#[0,0,0,0,0,7291345]], 314118433945⟩
def r5_12nX : Rows := #[#[-23,-24,-24,-24,-24,0],#[0,-47,-24,-24,-576,0],#[0,0,-71,-24,-576,0],#[0,0,0,-95,-576,1704],#[0,0,0,0,43081,-11544],#[0,0,0,0,0,-18133775]]
theorem r5_12n_check : validCached 6 r5_12A r5_12W 1 24 (-1) 23 r5_12nC r5_12nX=true := by decide +kernel
theorem r5_12n_count :
    3 ≤ Fintype.card {j // ((23:Nat):ℝ)/24 <
      -(weightedQuotient_isHermitian r5_12B r5_12Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 6) : 0<weightFn 6 r5_12W j := by rw [r5_12w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 6) : weightFn 6 r5_12W j ∣ 1 := by rw [r5_12w]
  have eq := cached_cut_count_sound 6 r5_12A r5_12W 1 24 (-1) 23 r5_12nC r5_12nX
    r5_12n_check r5_12Herm hw (by decide) (by decide) hd
  have ee : countPos 6 r5_12nC.d = 3 := by decide +kernel
  simp only [ee,r5_12w] at eq
  norm_num at eq ⊢
  exact (by decide : 3≤3).trans eq.ge


theorem r5_12_excluded : Excluded (rawTemplate U5[12]!) := by
  have hEx := excluded_of_unit_prefixes r5_12B r5_12Herm 0 23 0 3 (Nat.zero_le _) r5_12n_count (by decide +kernel)
  have he : rawTemplate U5[12]! = r5_12B := by
    ext j k
    change ((((#[#[0,1,1,1,1,0],#[1,0,1,1,0,0],#[1,1,0,1,0,0],#[1,1,1,0,0,1],#[1,0,0,0,0,1],#[0,0,0,1,1,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r5_12A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r5_13A : Rows := #[#[0,1,1,1,1,0],#[1,0,1,1,1,0],#[1,1,0,1,0,0],#[1,1,1,0,0,1],#[1,1,0,0,0,0],#[0,0,0,1,0,0]]
def r5_13B : Matrix (Fin 6) (Fin 6) ℝ := intMatrixToReal (ofRows 6 r5_13A)
theorem r5_13Herm : r5_13B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r5_13W : Weights := #[1,1,1,1,1,1]
theorem r5_13w : weightFn 6 r5_13W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r5_13nC : Cert := ⟨#[#[1,24,24,24,-1128,-13248],#[0,-23,24,24,-1128,-13248],#[0,0,-47,24,1152,-676800],#[0,0,0,-71,1152,675096],#[0,0,0,0,-95,27648],#[0,0,0,0,0,56329]], #[-23,1081,3337,6745,-5351255,-985637575559], #[#[410714172505,428571310440,428571310440,428571310440,428571310440,0],#[0,-17857137935,-9118538520,-9118538520,-9118538520,0],#[0,0,-8738599415,-2953892760,-141786852480,0],#[0,0,0,-5784706655,-70147179648,103759369896],#[0,0,0,0,-4323307079,2122011648],#[0,0,0,0,0,7291345]], 410714172505⟩
def r5_13nX : Rows := #[#[-23,-24,-24,-24,-24,0],#[0,-47,-24,-24,-24,0],#[0,0,-71,-24,-1152,0],#[0,0,0,-95,-1152,1704],#[0,0,0,0,56329,-27648],#[0,0,0,0,0,-17497871]]
theorem r5_13n_check : validCached 6 r5_13A r5_13W 1 24 (-1) 23 r5_13nC r5_13nX=true := by decide +kernel
theorem r5_13n_count :
    3 ≤ Fintype.card {j // ((23:Nat):ℝ)/24 <
      -(weightedQuotient_isHermitian r5_13B r5_13Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 6) : 0<weightFn 6 r5_13W j := by rw [r5_13w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 6) : weightFn 6 r5_13W j ∣ 1 := by rw [r5_13w]
  have eq := cached_cut_count_sound 6 r5_13A r5_13W 1 24 (-1) 23 r5_13nC r5_13nX
    r5_13n_check r5_13Herm hw (by decide) (by decide) hd
  have ee : countPos 6 r5_13nC.d = 3 := by decide +kernel
  simp only [ee,r5_13w] at eq
  norm_num at eq ⊢
  exact (by decide : 3≤3).trans eq.ge


theorem r5_13_excluded : Excluded (rawTemplate U5[13]!) := by
  have hEx := excluded_of_unit_prefixes r5_13B r5_13Herm 0 23 0 3 (Nat.zero_le _) r5_13n_count (by decide +kernel)
  have he : rawTemplate U5[13]! = r5_13B := by
    ext j k
    change ((((#[#[0,1,1,1,1,0],#[1,0,1,1,1,0],#[1,1,0,1,0,0],#[1,1,1,0,0,1],#[1,1,0,0,0,0],#[0,0,0,1,0,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r5_13A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r5_14A : Rows := #[#[0,1,1,1,1,0],#[1,0,1,0,1,0],#[1,1,0,1,0,0],#[1,0,1,0,0,0],#[1,1,0,0,0,1],#[0,0,0,0,1,0]]
def r5_14B : Matrix (Fin 6) (Fin 6) ℝ := intMatrixToReal (ofRows 6 r5_14A)
theorem r5_14Herm : r5_14B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r5_14W : Weights := #[1,1,1,1,1,1]
theorem r5_14w : weightFn 6 r5_14W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r5_14pC : Cert := ⟨#[#[1,0,1,-1,0,1],#[0,0,0,1,0,-1],#[0,0,0,0,-1,4],#[0,0,0,0,0,4],#[0,0,1,-2,1,-6],#[0,-1,1,-2,1,-6]], #[-24,-24,24,-96,-24,96], #[#[-4,4,4,4,4,0],#[0,0,0,0,-4,4],#[0,-8,-4,-4,-4,0],#[0,-4,0,-1,0,0],#[0,0,4,-4,0,0],#[0,0,0,-1,0,0]], -4⟩
def r5_14pX : Rows := #[#[-24,24,24,24,24,0],#[0,0,0,0,-24,24],#[0,48,24,24,24,0],#[0,-96,0,-24,0,0],#[0,0,24,-24,0,0],#[0,0,0,24,0,0]]
theorem r5_14p_check : validCached 6 r5_14A r5_14W 1 24 (1) 24 r5_14pC r5_14pX=true := by decide +kernel
theorem r5_14p_count :
    2 ≤ Fintype.card {j // ((24:Nat):ℝ)/24 <
      (weightedQuotient_isHermitian r5_14B r5_14Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 6) : 0<weightFn 6 r5_14W j := by rw [r5_14w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 6) : weightFn 6 r5_14W j ∣ 1 := by rw [r5_14w]
  have eq := cached_cut_count_sound 6 r5_14A r5_14W 1 24 (1) 24 r5_14pC r5_14pX
    r5_14p_check r5_14Herm hw (by decide) (by decide) hd
  have ee : countPos 6 r5_14pC.d = 2 := by decide +kernel
  simp only [ee,r5_14w] at eq
  norm_num at eq ⊢
  exact (by decide : 2≤2).trans eq.ge


theorem r5_14_excluded : Excluded (rawTemplate U5[14]!) := by
  have hEx := excluded_of_unit_prefixes r5_14B r5_14Herm 24 0 2 0 r5_14p_count (Nat.zero_le _) (by decide +kernel)
  have he : rawTemplate U5[14]! = r5_14B := by
    ext j k
    change ((((#[#[0,1,1,1,1,0],#[1,0,1,0,1,0],#[1,1,0,1,0,0],#[1,0,1,0,0,0],#[1,1,0,0,0,1],#[0,0,0,0,1,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r5_14A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r5_15A : Rows := #[#[0,1,1,1,1,0],#[1,0,1,1,1,1],#[1,1,0,1,0,0],#[1,1,1,0,0,1],#[1,1,0,0,0,1],#[0,1,0,1,1,0]]
def r5_15B : Matrix (Fin 6) (Fin 6) ℝ := intMatrixToReal (ofRows 6 r5_15A)
theorem r5_15Herm : r5_15B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r5_15W : Weights := #[1,1,1,1,1,1]
theorem r5_15w : weightFn 6 r5_15W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r5_15nC : Cert := ⟨#[#[1,24,24,24,-1128,-703296],#[0,-23,24,24,-1128,648600],#[0,0,-47,24,1152,-662400],#[0,0,0,-71,1152,689496],#[0,0,0,0,-95,-1704],#[0,0,0,0,0,56329]], #[-23,1081,3337,6745,-5351255,-1879640992775], #[#[410714172505,428571310440,428571310440,428571310440,428571310440,0],#[0,-17857137935,-9118538520,-9118538520,-9118538520,209726385960],#[0,0,-8738599415,-2953892760,-141786852480,-70893426240],#[0,0,0,-5784706655,-70147179648,68685780072],#[0,0,0,0,-4323307079,-130783704],#[0,0,0,0,0,7291345]], 410714172505⟩
def r5_15nX : Rows := #[#[-23,-24,-24,-24,-24,0],#[0,-47,-24,-24,-24,552],#[0,0,-71,-24,-1152,-576],#[0,0,0,-95,-1152,1128],#[0,0,0,0,56329,1704],#[0,0,0,0,0,-33368975]]
theorem r5_15n_check : validCached 6 r5_15A r5_15W 1 24 (-1) 23 r5_15nC r5_15nX=true := by decide +kernel
theorem r5_15n_count :
    3 ≤ Fintype.card {j // ((23:Nat):ℝ)/24 <
      -(weightedQuotient_isHermitian r5_15B r5_15Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 6) : 0<weightFn 6 r5_15W j := by rw [r5_15w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 6) : weightFn 6 r5_15W j ∣ 1 := by rw [r5_15w]
  have eq := cached_cut_count_sound 6 r5_15A r5_15W 1 24 (-1) 23 r5_15nC r5_15nX
    r5_15n_check r5_15Herm hw (by decide) (by decide) hd
  have ee : countPos 6 r5_15nC.d = 3 := by decide +kernel
  simp only [ee,r5_15w] at eq
  norm_num at eq ⊢
  exact (by decide : 3≤3).trans eq.ge


theorem r5_15_excluded : Excluded (rawTemplate U5[15]!) := by
  have hEx := excluded_of_unit_prefixes r5_15B r5_15Herm 0 23 0 3 (Nat.zero_le _) r5_15n_count (by decide +kernel)
  have he : rawTemplate U5[15]! = r5_15B := by
    ext j k
    change ((((#[#[0,1,1,1,1,0],#[1,0,1,1,1,1],#[1,1,0,1,0,0],#[1,1,1,0,0,1],#[1,1,0,0,0,1],#[0,1,0,1,1,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r5_15A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r5_16A : Rows := #[#[0,1,1,1,1,0,0],#[1,0,1,0,1,0,1],#[1,1,0,1,0,0,1],#[1,0,1,0,0,0,0],#[1,1,0,0,0,1,1],#[0,0,0,0,1,0,1],#[0,1,1,0,1,1,0]]
def r5_16B : Matrix (Fin 7) (Fin 7) ℝ := intMatrixToReal (ofRows 7 r5_16A)
theorem r5_16Herm : r5_16B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r5_16W : Weights := #[1,1,1,1,1,1,1]
theorem r5_16w : weightFn 7 r5_16W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r5_16nC : Cert := ⟨#[#[1,0,-1,0,0,1,-2],#[0,0,0,0,0,-1,2],#[0,0,0,1,1,1,-2],#[0,0,0,0,0,0,1],#[0,0,1,-1,-1,-1,1],#[0,-1,-1,1,2,2,-2],#[0,0,0,0,-1,-1,1]], #[-24,-24,24,-24,24,-24,72], #[#[-1,-1,-1,-1,-1,0,0],#[0,0,0,0,1,1,1],#[0,0,-1,-1,-1,0,0],#[0,0,-1,-1,0,0,-1],#[0,-1,0,1,0,0,1],#[0,1,0,-2,0,0,0],#[0,0,0,-1,0,0,0]], -1⟩
def r5_16nX : Rows := #[#[-24,-24,-24,-24,-24,0,0],#[0,0,0,0,24,24,24],#[0,0,24,24,24,0,0],#[0,0,-24,-24,0,0,-24],#[0,24,0,-24,0,0,-24],#[0,24,0,-48,0,0,0],#[0,0,0,72,0,0,0]]
theorem r5_16n_check : validCached 7 r5_16A r5_16W 1 24 (-1) 24 r5_16nC r5_16nX=true := by decide +kernel
theorem r5_16n_count :
    3 ≤ Fintype.card {j // ((24:Nat):ℝ)/24 <
      -(weightedQuotient_isHermitian r5_16B r5_16Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 7) : 0<weightFn 7 r5_16W j := by rw [r5_16w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 7) : weightFn 7 r5_16W j ∣ 1 := by rw [r5_16w]
  have eq := cached_cut_count_sound 7 r5_16A r5_16W 1 24 (-1) 24 r5_16nC r5_16nX
    r5_16n_check r5_16Herm hw (by decide) (by decide) hd
  have ee : countPos 7 r5_16nC.d = 3 := by decide +kernel
  simp only [ee,r5_16w] at eq
  norm_num at eq ⊢
  exact (by decide : 3≤3).trans eq.ge


theorem r5_16_excluded : Excluded (rawTemplate U5[16]!) := by
  have hEx := excluded_of_unit_prefixes r5_16B r5_16Herm 0 24 0 3 (Nat.zero_le _) r5_16n_count (by decide +kernel)
  have he : rawTemplate U5[16]! = r5_16B := by
    ext j k
    change ((((#[#[0,1,1,1,1,0,0],#[1,0,1,0,1,0,1],#[1,1,0,1,0,0,1],#[1,0,1,0,0,0,0],#[1,1,0,0,0,1,1],#[0,0,0,0,1,0,1],#[0,1,1,0,1,1,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r5_16A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r5_17A : Rows := #[#[0,1,1,1,1,0,0],#[1,0,1,1,0,0,0],#[1,1,0,1,0,1,0],#[1,1,1,0,0,0,1],#[1,0,0,0,0,1,1],#[0,0,1,0,1,0,1],#[0,0,0,1,1,1,0]]
def r5_17B : Matrix (Fin 7) (Fin 7) ℝ := intMatrixToReal (ofRows 7 r5_17A)
theorem r5_17Herm : r5_17B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r5_17W : Weights := #[1,1,1,1,1,1,1]
theorem r5_17w : weightFn 7 r5_17W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r5_17nC : Cert := ⟨#[#[1,0,-1,1,2,1,1],#[0,0,0,0,-3,-2,-3],#[0,0,1,-2,2,1,1],#[0,0,0,0,0,0,1],#[0,0,0,1,-1,0,0],#[0,-1,-1,1,-1,0,0],#[0,0,0,0,0,-1,-1]], #[-24,-24,24,-72,72,-24,24], #[#[-3,-3,-3,-3,-3,0,0],#[0,0,3,0,3,3,3],#[0,0,-3,0,-6,0,-3],#[0,1,0,1,-3,0,-2],#[0,1,0,1,0,0,-2],#[0,0,0,3,0,0,3],#[0,0,0,-3,0,0,0]], -3⟩
def r5_17nX : Rows := #[#[-24,-24,-24,-24,-24,0,0],#[0,0,24,0,24,24,24],#[0,0,24,0,48,0,24],#[0,24,0,24,-72,0,-48],#[0,-24,0,-24,0,0,48],#[0,0,0,24,0,0,24],#[0,0,0,24,0,0,0]]
theorem r5_17n_check : validCached 7 r5_17A r5_17W 1 24 (-1) 24 r5_17nC r5_17nX=true := by decide +kernel
theorem r5_17n_count :
    3 ≤ Fintype.card {j // ((24:Nat):ℝ)/24 <
      -(weightedQuotient_isHermitian r5_17B r5_17Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 7) : 0<weightFn 7 r5_17W j := by rw [r5_17w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 7) : weightFn 7 r5_17W j ∣ 1 := by rw [r5_17w]
  have eq := cached_cut_count_sound 7 r5_17A r5_17W 1 24 (-1) 24 r5_17nC r5_17nX
    r5_17n_check r5_17Herm hw (by decide) (by decide) hd
  have ee : countPos 7 r5_17nC.d = 3 := by decide +kernel
  simp only [ee,r5_17w] at eq
  norm_num at eq ⊢
  exact (by decide : 3≤3).trans eq.ge


theorem r5_17_excluded : Excluded (rawTemplate U5[17]!) := by
  have hEx := excluded_of_unit_prefixes r5_17B r5_17Herm 0 24 0 3 (Nat.zero_le _) r5_17n_count (by decide +kernel)
  have he : rawTemplate U5[17]! = r5_17B := by
    ext j k
    change ((((#[#[0,1,1,1,1,0,0],#[1,0,1,1,0,0,0],#[1,1,0,1,0,1,0],#[1,1,1,0,0,0,1],#[1,0,0,0,0,1,1],#[0,0,1,0,1,0,1],#[0,0,0,1,1,1,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r5_17A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r5_18A : Rows := #[#[0,1,1,1,1,0,0],#[1,0,1,0,1,1,0],#[1,1,0,1,0,1,0],#[1,0,1,0,0,1,0],#[1,1,0,0,0,0,1],#[0,1,1,1,0,0,0],#[0,0,0,0,1,0,0]]
def r5_18B : Matrix (Fin 7) (Fin 7) ℝ := intMatrixToReal (ofRows 7 r5_18A)
theorem r5_18Herm : r5_18B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r5_18W : Weights := #[1,1,1,1,1,1,1]
theorem r5_18w : weightFn 7 r5_18W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r5_18nC : Cert := ⟨#[#[1,24,24,-552,330648,7245504,40896],#[0,-23,24,1152,-14952,689496,40896],#[0,0,-47,-552,-344448,8597400,635904],#[0,0,0,-71,14400,-7950504,-345600],#[0,0,0,0,28129,-8280000,-370392],#[0,0,0,0,0,-8223671,-345600],#[0,0,0,0,0,0,273167]], #[-23,1081,3337,-1997159,-231323641559,-1291700433232775,712028087689], #[#[4849894553605303090103,5060759534196838007064,5060759534196838007064,5060759534196838007064,5060759534196838007064,0,0],#[0,-210864980591534916961,-107675734770145489512,-2584217634483491748288,-107675734770145489512,2476541899713346258776,0],#[0,0,-103189245821389427449,802260052019816393688,-1674281847693529865088,802260052019816393688,0],#[0,0,0,-68308373994440888593,34968914128477684800,30830925956607825432,0],#[0,0,0,0,172416173827910807,-173597158652760000,14153955002155032],#[0,0,0,0,0,-589748125089793,-746125820582400],#[0,0,0,0,0,0,17754320813294809]], 4849894553605303090103⟩
def r5_18nX : Rows := #[#[-23,-24,-24,-24,-24,0,0],#[0,-47,-24,-576,-24,552,0],#[0,0,-71,552,-1152,552,0],#[0,0,0,28129,-14400,-12696,0],#[0,0,0,0,-8223671,8280000,-675096],#[0,0,0,0,0,157071025,198720000],#[0,0,0,0,0,0,2606567]]
theorem r5_18n_check : validCached 7 r5_18A r5_18W 1 24 (-1) 23 r5_18nC r5_18nX=true := by decide +kernel
theorem r5_18n_count :
    3 ≤ Fintype.card {j // ((23:Nat):ℝ)/24 <
      -(weightedQuotient_isHermitian r5_18B r5_18Herm (fun _ => 1)).eigenvalues j} := by

  have hw (j : Fin 7) : 0<weightFn 7 r5_18W j := by rw [r5_18w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 7) : weightFn 7 r5_18W j ∣ 1 := by rw [r5_18w]
  have eq := cached_cut_count_sound 7 r5_18A r5_18W 1 24 (-1) 23 r5_18nC r5_18nX
    r5_18n_check r5_18Herm hw (by decide) (by decide) hd
  have ee : countPos 7 r5_18nC.d = 3 := by decide +kernel
  simp only [ee,r5_18w] at eq
  norm_num at eq ⊢
  exact (by decide : 3≤3).trans eq.ge


theorem r5_18_excluded : Excluded (rawTemplate U5[18]!) := by
  have hEx := excluded_of_unit_prefixes r5_18B r5_18Herm 0 23 0 3 (Nat.zero_le _) r5_18n_count (by decide +kernel)
  have he : rawTemplate U5[18]! = r5_18B := by
    ext j k
    change ((((#[#[0,1,1,1,1,0,0],#[1,0,1,0,1,1,0],#[1,1,0,1,0,1,0],#[1,0,1,0,0,1,0],#[1,1,0,0,0,0,1],#[0,1,1,1,0,0,0],#[0,0,0,0,1,0,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r5_18A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r5_19A : Rows := #[#[0,1,1,1,1,1,0],#[1,0,1,1,1,0,1],#[1,1,0,1,0,0,0],#[1,1,1,0,0,1,1],#[1,1,0,0,0,1,1],#[1,0,0,1,1,0,1],#[0,1,0,1,1,1,0]]
def r5_19B : Matrix (Fin 7) (Fin 7) ℝ := intMatrixToReal (ofRows 7 r5_19A)
theorem r5_19Herm : r5_19B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r5_19W : Weights := #[1,1,1,1,1,1,1]
theorem r5_19w : weightFn 7 r5_19W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r5_19pC : Cert := ⟨#[#[1,-24,24,-24,-24,39192,527616],#[0,-23,24,-24,-24,-1204416,637608],#[0,0,-1,-24,1152,-1881216,1881216],#[0,0,0,25,1152,-637608,637608],#[0,0,0,0,-2303,1325400,-1325400],#[0,0,0,0,0,2435399,-1325400],#[0,0,0,0,0,0,-1109999]], #[-23,1081,-1175,-57575,-119334551,-93924964092839,8307275805961], #[#[3579764802244009225,-3735406750167661800,-3735406750167661800,-3735406750167661800,-3735406750167661800,-3735406750167661800,0],#[0,-155641947923652575,-3735406750167661800,-3735406750167661800,-3735406750167661800,-1907441744766465600,-1827965005401196200],#[0,0,-3579764802244009225,-3436574210154248856,-3509692810370296704,-1754846405185148352,-1754846405185148352],#[0,0,0,143190592089760369,71626383885108096,-1492216330939752,-1492216330939752],#[0,0,0,0,-1554392011395575,845935787895000,845935787895000],#[0,0,0,0,0,1469888425775,-1755127815000],#[0,0,0,0,0,0,-3225016240775]], 3579764802244009225⟩
def r5_19pX : Rows := #[#[-23,24,24,24,24,24,0],#[0,-47,-1128,-1128,-1128,-576,-552],#[0,0,1175,1128,1152,576,576],#[0,0,0,-2303,-1152,24,24],#[0,0,0,0,51817,-28200,-28200],#[0,0,0,0,0,-38566561,46050600],#[0,0,0,0,0,0,-7484039]]
theorem r5_19p_check : validCached 7 r5_19A r5_19W 1 24 (1) 23 r5_19pC r5_19pX=true := by decide +kernel
theorem r5_19p_count :
    2 ≤ Fintype.card {j // ((23:Nat):ℝ)/24 <
      (weightedQuotient_isHermitian r5_19B r5_19Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 7) : 0<weightFn 7 r5_19W j := by rw [r5_19w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 7) : weightFn 7 r5_19W j ∣ 1 := by rw [r5_19w]
  have eq := cached_cut_count_sound 7 r5_19A r5_19W 1 24 (1) 23 r5_19pC r5_19pX
    r5_19p_check r5_19Herm hw (by decide) (by decide) hd
  have ee : countPos 7 r5_19pC.d = 2 := by decide +kernel
  simp only [ee,r5_19w] at eq
  norm_num at eq ⊢
  exact (by decide : 2≤2).trans eq.ge


theorem r5_19_excluded : Excluded (rawTemplate U5[19]!) := by
  have hEx := excluded_of_unit_prefixes r5_19B r5_19Herm 23 0 2 0 r5_19p_count (Nat.zero_le _) (by decide +kernel)
  have he : rawTemplate U5[19]! = r5_19B := by
    ext j k
    change ((((#[#[0,1,1,1,1,1,0],#[1,0,1,1,1,0,1],#[1,1,0,1,0,0,0],#[1,1,1,0,0,1,1],#[1,1,0,0,0,1,1],#[1,0,0,1,1,0,1],#[0,1,0,1,1,1,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r5_19A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r5_20A : Rows := #[#[0,1,1,1,1,0,0],#[1,0,1,1,1,0,0],#[1,1,0,1,0,1,0],#[1,1,1,0,0,0,1],#[1,1,0,0,0,0,0],#[0,0,1,0,0,0,1],#[0,0,0,1,0,1,0]]
def r5_20B : Matrix (Fin 7) (Fin 7) ℝ := intMatrixToReal (ofRows 7 r5_20A)
theorem r5_20Herm : r5_20B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r5_20W : Weights := #[1,1,1,1,1,1,1]
theorem r5_20w : weightFn 7 r5_20W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r5_20nC : Cert := ⟨#[#[1,24,24,24,-1128,-13248,331200],#[0,-23,24,24,-1128,-13248,331200],#[0,0,-47,24,1152,675096,1381248],#[0,0,0,-71,1152,-676800,-1338648],#[0,0,0,0,-95,27648,-691200],#[0,0,0,0,0,56329,-647448],#[0,0,0,0,0,0,-760777]], #[-23,1081,3337,6745,-5351255,-985637575559,-49575405563975], #[#[-312461896015836385,-326047195842611880,-326047195842611880,-326047195842611880,-326047195842611880,0,0],#[0,13585299826775495,6937174379630040,6937174379630040,6937174379630040,0,0],#[0,0,6648125447145455,2247253672274520,107868176269176960,-105620922596902440,0],#[0,0,0,4400871774870935,53366360891066496,26683180445533248,-78937742151369192],#[0,0,0,0,3289072589640383,-1614377655530496,-1614377655530496],#[0,0,0,0,0,-5547087575065,4720766737560],#[0,0,0,0,0,0,410714172505]], -312461896015836385⟩
def r5_20nX : Rows := #[#[-23,-24,-24,-24,-24,0,0],#[0,-47,-24,-24,-24,0,0],#[0,0,-71,-24,-1152,1128,0],#[0,0,0,-95,-1152,-576,1704],#[0,0,0,0,56329,-27648,-27648],#[0,0,0,0,0,-17497871,14891304],#[0,0,0,0,0,0,65164175]]
theorem r5_20n_check : validCached 7 r5_20A r5_20W 1 24 (-1) 23 r5_20nC r5_20nX=true := by decide +kernel
theorem r5_20n_count :
    3 ≤ Fintype.card {j // ((23:Nat):ℝ)/24 <
      -(weightedQuotient_isHermitian r5_20B r5_20Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 7) : 0<weightFn 7 r5_20W j := by rw [r5_20w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 7) : weightFn 7 r5_20W j ∣ 1 := by rw [r5_20w]
  have eq := cached_cut_count_sound 7 r5_20A r5_20W 1 24 (-1) 23 r5_20nC r5_20nX
    r5_20n_check r5_20Herm hw (by decide) (by decide) hd
  have ee : countPos 7 r5_20nC.d = 3 := by decide +kernel
  simp only [ee,r5_20w] at eq
  norm_num at eq ⊢
  exact (by decide : 3≤3).trans eq.ge


theorem r5_20_excluded : Excluded (rawTemplate U5[20]!) := by
  have hEx := excluded_of_unit_prefixes r5_20B r5_20Herm 0 23 0 3 (Nat.zero_le _) r5_20n_count (by decide +kernel)
  have he : rawTemplate U5[20]! = r5_20B := by
    ext j k
    change ((((#[#[0,1,1,1,1,0,0],#[1,0,1,1,1,0,0],#[1,1,0,1,0,1,0],#[1,1,1,0,0,0,1],#[1,1,0,0,0,0,0],#[0,0,1,0,0,0,1],#[0,0,0,1,0,1,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r5_20A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r5_21A : Rows := #[#[0,1,1,1,1,0,0],#[1,0,1,1,1,0,1],#[1,1,0,1,0,0,1],#[1,1,1,0,0,1,0],#[1,1,0,0,0,0,1],#[0,0,0,1,0,0,0],#[0,1,1,0,1,0,0]]
def r5_21B : Matrix (Fin 7) (Fin 7) ℝ := intMatrixToReal (ofRows 7 r5_21A)
theorem r5_21Herm : r5_21B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r5_21W : Weights := #[1,1,1,1,1,1,1]
theorem r5_21w : weightFn 7 r5_21W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r5_21nC : Cert := ⟨#[#[1,0,-1,0,1,2,-2],#[0,0,0,0,0,0,4],#[0,0,0,0,-1,-2,-2],#[0,0,1,-1,1,1,1],#[0,0,0,1,-1,-1,-1],#[0,-1,-1,1,-1,-1,-1],#[0,0,0,0,0,-1,-1]], #[-24,-24,24,-24,24,-96,96], #[#[-4,-4,-4,-4,-4,0,0],#[0,0,0,4,0,4,0],#[0,0,0,-4,-4,0,0],#[0,0,4,0,-4,0,-4],#[0,0,4,0,0,0,-8],#[0,1,0,0,0,0,4],#[0,-1,0,0,0,0,0]], -4⟩
def r5_21nX : Rows := #[#[-24,-24,-24,-24,-24,0,0],#[0,0,0,24,0,24,0],#[0,0,0,24,24,0,0],#[0,0,24,0,-24,0,-24],#[0,0,-24,0,0,0,48],#[0,24,0,0,0,0,96],#[0,24,0,0,0,0,0]]
theorem r5_21n_check : validCached 7 r5_21A r5_21W 1 24 (-1) 24 r5_21nC r5_21nX=true := by decide +kernel
theorem r5_21n_count :
    3 ≤ Fintype.card {j // ((24:Nat):ℝ)/24 <
      -(weightedQuotient_isHermitian r5_21B r5_21Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 7) : 0<weightFn 7 r5_21W j := by rw [r5_21w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 7) : weightFn 7 r5_21W j ∣ 1 := by rw [r5_21w]
  have eq := cached_cut_count_sound 7 r5_21A r5_21W 1 24 (-1) 24 r5_21nC r5_21nX
    r5_21n_check r5_21Herm hw (by decide) (by decide) hd
  have ee : countPos 7 r5_21nC.d = 3 := by decide +kernel
  simp only [ee,r5_21w] at eq
  norm_num at eq ⊢
  exact (by decide : 3≤3).trans eq.ge


theorem r5_21_excluded : Excluded (rawTemplate U5[21]!) := by
  have hEx := excluded_of_unit_prefixes r5_21B r5_21Herm 0 24 0 3 (Nat.zero_le _) r5_21n_count (by decide +kernel)
  have he : rawTemplate U5[21]! = r5_21B := by
    ext j k
    change ((((#[#[0,1,1,1,1,0,0],#[1,0,1,1,1,0,1],#[1,1,0,1,0,0,1],#[1,1,1,0,0,1,0],#[1,1,0,0,0,0,1],#[0,0,0,1,0,0,0],#[0,1,1,0,1,0,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r5_21A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r5_22A : Rows := #[#[0,1,1,1,1,0,0],#[1,0,1,1,1,1,1],#[1,1,0,1,0,1,0],#[1,1,1,0,0,0,1],#[1,1,0,0,0,1,1],#[0,1,1,0,1,0,1],#[0,1,0,1,1,1,0]]
def r5_22B : Matrix (Fin 7) (Fin 7) ℝ := intMatrixToReal (ofRows 7 r5_22A)
theorem r5_22Herm : r5_22B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r5_22W : Weights := #[1,1,1,1,1,1,1]
theorem r5_22w : weightFn 7 r5_22W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r5_22pC : Cert := ⟨#[#[1,-24,24,-24,-24,-1204416,1204416],#[0,-23,24,-24,-24,39192,-39192],#[0,0,-1,-24,1152,-637608,1204416],#[0,0,0,25,1152,-1881216,1314408],#[0,0,0,0,-2303,1325400,-1325400],#[0,0,0,0,0,2435399,-1325400],#[0,0,0,0,0,0,-1109999]], #[-23,1081,-1175,-57575,-119334551,-93924964092839,8307275805961], #[#[3579764802244009225,-3735406750167661800,-3735406750167661800,-3735406750167661800,-3735406750167661800,0,0],#[0,-155641947923652575,-3735406750167661800,-3735406750167661800,-3735406750167661800,-1827965005401196200,-1827965005401196200],#[0,0,-3579764802244009225,-3436574210154248856,-3509692810370296704,-1681727804969100504,-1754846405185148352],#[0,0,0,143190592089760369,71626383885108096,71626383885108096,-1492216330939752],#[0,0,0,0,-1554392011395575,845935787895000,845935787895000],#[0,0,0,0,0,1469888425775,-1755127815000],#[0,0,0,0,0,0,-3225016240775]], 3579764802244009225⟩
def r5_22pX : Rows := #[#[-23,24,24,24,24,0,0],#[0,-47,-1128,-1128,-1128,-552,-552],#[0,0,1175,1128,1152,552,576],#[0,0,0,-2303,-1152,-1152,24],#[0,0,0,0,51817,-28200,-28200],#[0,0,0,0,0,-38566561,46050600],#[0,0,0,0,0,0,-7484039]]
theorem r5_22p_check : validCached 7 r5_22A r5_22W 1 24 (1) 23 r5_22pC r5_22pX=true := by decide +kernel
theorem r5_22p_count :
    2 ≤ Fintype.card {j // ((23:Nat):ℝ)/24 <
      (weightedQuotient_isHermitian r5_22B r5_22Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 7) : 0<weightFn 7 r5_22W j := by rw [r5_22w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 7) : weightFn 7 r5_22W j ∣ 1 := by rw [r5_22w]
  have eq := cached_cut_count_sound 7 r5_22A r5_22W 1 24 (1) 23 r5_22pC r5_22pX
    r5_22p_check r5_22Herm hw (by decide) (by decide) hd
  have ee : countPos 7 r5_22pC.d = 2 := by decide +kernel
  simp only [ee,r5_22w] at eq
  norm_num at eq ⊢
  exact (by decide : 2≤2).trans eq.ge


theorem r5_22_excluded : Excluded (rawTemplate U5[22]!) := by
  have hEx := excluded_of_unit_prefixes r5_22B r5_22Herm 23 0 2 0 r5_22p_count (Nat.zero_le _) (by decide +kernel)
  have he : rawTemplate U5[22]! = r5_22B := by
    ext j k
    change ((((#[#[0,1,1,1,1,0,0],#[1,0,1,1,1,1,1],#[1,1,0,1,0,1,0],#[1,1,1,0,0,0,1],#[1,1,0,0,0,1,1],#[0,1,1,0,1,0,1],#[0,1,0,1,1,1,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r5_22A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r5_23A : Rows := #[#[0,1,1,1,1,0,0,0],#[1,0,1,1,0,1,0,0],#[1,1,0,1,0,0,1,0],#[1,1,1,0,0,0,0,1],#[1,0,0,0,0,1,1,1],#[0,1,0,0,1,0,1,1],#[0,0,1,0,1,1,0,1],#[0,0,0,1,1,1,1,0]]
def r5_23B : Matrix (Fin 8) (Fin 8) ℝ := intMatrixToReal (ofRows 8 r5_23A)
theorem r5_23Herm : r5_23B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r5_23W : Weights := #[1,1,1,1,1,1,1,1]
theorem r5_23w : weightFn 8 r5_23W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r5_23nC : Cert := ⟨#[#[1,0,-1,1,2,3,-3,-4],#[0,0,1,-2,2,3,-3,-4],#[0,0,0,0,-3,-5,-3,-4],#[0,0,0,0,0,0,8,11],#[0,0,0,1,-1,-1,1,1],#[0,-1,-1,1,-1,-1,1,1],#[0,0,0,0,0,-1,1,1],#[0,0,0,0,0,0,0,1]], #[-24,-24,24,-72,72,-192,192,-360], #[#[24,24,24,24,24,0,0,0],#[0,-24,0,0,-24,-24,-24,-24],#[0,24,0,0,48,0,24,24],#[0,0,-8,-8,24,0,16,16],#[0,0,-8,-8,0,0,40,16],#[0,0,0,3,0,0,-24,-9],#[0,0,0,3,0,0,0,-33],#[0,0,0,0,0,0,0,24]], 24⟩
def r5_23nX : Rows := #[#[-24,-24,-24,-24,-24,0,0,0],#[0,24,0,0,24,24,24,24],#[0,24,0,0,48,0,24,24],#[0,0,24,24,-72,0,-48,-48],#[0,0,-24,-24,0,0,120,48],#[0,0,0,-24,0,0,192,72],#[0,0,0,24,0,0,0,-264],#[0,0,0,0,0,0,0,-360]]
theorem r5_23n_check : validCached 8 r5_23A r5_23W 1 24 (-1) 24 r5_23nC r5_23nX=true := by decide +kernel
theorem r5_23n_count :
    3 ≤ Fintype.card {j // ((24:Nat):ℝ)/24 <
      -(weightedQuotient_isHermitian r5_23B r5_23Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 8) : 0<weightFn 8 r5_23W j := by rw [r5_23w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 8) : weightFn 8 r5_23W j ∣ 1 := by rw [r5_23w]
  have eq := cached_cut_count_sound 8 r5_23A r5_23W 1 24 (-1) 24 r5_23nC r5_23nX
    r5_23n_check r5_23Herm hw (by decide) (by decide) hd
  have ee : countPos 8 r5_23nC.d = 3 := by decide +kernel
  simp only [ee,r5_23w] at eq
  norm_num at eq ⊢
  exact (by decide : 3≤3).trans eq.ge


theorem r5_23_excluded : Excluded (rawTemplate U5[23]!) := by
  have hEx := excluded_of_unit_prefixes r5_23B r5_23Herm 0 24 0 3 (Nat.zero_le _) r5_23n_count (by decide +kernel)
  have he : rawTemplate U5[23]! = r5_23B := by
    ext j k
    change ((((#[#[0,1,1,1,1,0,0,0],#[1,0,1,1,0,1,0,0],#[1,1,0,1,0,0,1,0],#[1,1,1,0,0,0,0,1],#[1,0,0,0,0,1,1,1],#[0,1,0,0,1,0,1,1],#[0,0,1,0,1,1,0,1],#[0,0,0,1,1,1,1,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r5_23A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx


def r5_24A : Rows := #[#[0,1,1,1,1,0,1,0],#[1,0,1,1,1,0,0,1],#[1,1,0,1,0,0,1,1],#[1,1,1,0,0,1,0,0],#[1,1,0,0,0,0,1,1],#[0,0,0,1,0,0,0,0],#[1,0,1,0,1,0,0,1],#[0,1,1,0,1,0,1,0]]
def r5_24B : Matrix (Fin 8) (Fin 8) ℝ := intMatrixToReal (ofRows 8 r5_24A)
theorem r5_24Herm : r5_24B.IsHermitian := by
  ext j k
  fin_cases j <;> fin_cases k <;> rfl
def r5_24W : Weights := #[1,1,1,1,1,1,1,1]
theorem r5_24w : weightFn 8 r5_24W = fun _ => 1 := by
  funext j
  fin_cases j <;> rfl


def r5_24nC : Cert := ⟨#[#[1,0,-1,0,1,1,-2,-6],#[0,0,0,0,0,0,1,3],#[0,0,0,0,-1,-1,1,3],#[0,0,1,-1,1,1,-1,-2],#[0,0,0,1,-1,0,0,1],#[0,-1,-1,1,-1,-1,1,2],#[0,0,0,0,0,-1,1,1],#[0,0,0,0,0,0,0,1]], #[-24,-24,24,-24,24,-24,24,-216], #[#[-1,-1,-1,-1,-1,0,-1,0],#[0,0,0,1,0,1,0,0],#[0,0,0,-1,-1,0,-1,0],#[0,0,1,0,-1,0,-1,-1],#[0,0,1,0,0,0,-1,-2],#[0,-1,0,0,0,0,1,2],#[0,-1,0,0,0,0,0,3],#[0,0,0,0,0,0,0,-1]], -1⟩
def r5_24nX : Rows := #[#[-24,-24,-24,-24,-24,0,-24,0],#[0,0,0,24,0,24,0,0],#[0,0,0,24,24,0,24,0],#[0,0,24,0,-24,0,-24,-24],#[0,0,-24,0,0,0,24,48],#[0,-24,0,0,0,0,24,48],#[0,24,0,0,0,0,0,-72],#[0,0,0,0,0,0,0,-216]]
theorem r5_24n_check : validCached 8 r5_24A r5_24W 1 24 (-1) 24 r5_24nC r5_24nX=true := by decide +kernel
theorem r5_24n_count :
    3 ≤ Fintype.card {j // ((24:Nat):ℝ)/24 <
      -(weightedQuotient_isHermitian r5_24B r5_24Herm (fun _ => 1)).eigenvalues j} := by
  have hw (j : Fin 8) : 0<weightFn 8 r5_24W j := by rw [r5_24w]; exact Nat.zero_lt_succ 0
  have hd (j : Fin 8) : weightFn 8 r5_24W j ∣ 1 := by rw [r5_24w]
  have eq := cached_cut_count_sound 8 r5_24A r5_24W 1 24 (-1) 24 r5_24nC r5_24nX
    r5_24n_check r5_24Herm hw (by decide) (by decide) hd
  have ee : countPos 8 r5_24nC.d = 3 := by decide +kernel
  simp only [ee,r5_24w] at eq
  norm_num at eq ⊢
  exact (by decide : 3≤3).trans eq.ge


theorem r5_24_excluded : Excluded (rawTemplate U5[24]!) := by
  have hEx := excluded_of_unit_prefixes r5_24B r5_24Herm 0 24 0 3 (Nat.zero_le _) r5_24n_count (by decide +kernel)
  have he : rawTemplate U5[24]! = r5_24B := by
    ext j k
    change ((((#[#[0,1,1,1,1,0,1,0],#[1,0,1,1,1,0,0,1],#[1,1,0,1,0,0,1,1],#[1,1,1,0,0,1,0,0],#[1,1,0,0,0,0,1,1],#[0,0,0,1,0,0,0,0],#[1,0,1,0,1,0,0,1],#[0,1,1,0,1,0,1,0]] : NatRows)[j.val]?.getD #[])[k.val]?).getD 0 : ℝ) = (entry r5_24A j k : ℝ)
    fin_cases j <;> fin_cases k <;> rfl
  rw [he]
  exact hEx

theorem exclude_rank5_outside_survivors (j : Fin 25) (h5 : j.val≠5) : Excluded (rawTemplate U5[j.val]!) := by
  fin_cases j
  · exact r5_0_excluded
  · exact r5_1_excluded
  · exact r5_2_excluded
  · exact r5_3_excluded
  · exact r5_4_excluded
  · exact (h5 rfl).elim
  · exact r5_6_excluded
  · exact r5_7_excluded
  · exact r5_8_excluded
  · exact r5_9_excluded
  · exact r5_10_excluded
  · exact r5_11_excluded
  · exact r5_12_excluded
  · exact r5_13_excluded
  · exact r5_14_excluded
  · exact r5_15_excluded
  · exact r5_16_excluded
  · exact r5_17_excluded
  · exact r5_18_excluded
  · exact r5_19_excluded
  · exact r5_20_excluded
  · exact r5_21_excluded
  · exact r5_22_excluded
  · exact r5_23_excluded
  · exact r5_24_excluded
#print axioms exclude_rank5_outside_survivors
end UnitPruning


namespace UnitPruning
open Conj20StarCert

theorem agrees_T3 : U3 = T3 := by rfl
theorem agrees_T4 : U4 = T4 := by rfl
theorem agrees_T5 : U5 = T5 := by rfl

theorem catalogue_rank_four_excluded (j : Fin 9)
    (h1 : j.val≠1) (h2 : j.val≠2) (h5 : j.val≠5) (h6 : j.val≠6) :
    Excluded (catalogueMatrix T4[j.val]!) :=
  exclude_rank4_outside_survivors j h1 h2 h5 h6

theorem catalogue_rank_five_except_join_excluded (j : Fin 25) (h5 : j.val≠5) :
    Excluded (catalogueMatrix T5[j.val]!) :=
  exclude_rank5_outside_survivors j h5

#print axioms catalogue_rank_four_excluded
#print axioms catalogue_rank_five_except_join_excluded
end UnitPruning


namespace UnitPruning
open Conj20StarCert Matrix SpectralConjecture20 Conj20CutCert

theorem ordered_eigenvalues_congr {m : Type*} [Fintype m] [DecidableEq m]
    {A B : Matrix m m ℝ} (h : A=B) (hA : A.IsHermitian) (hB : B.IsHermitian) :
    hA.eigenvalues₀ = hB.eigenvalues₀ := by subst B; rfl

theorem rank_five_join_matrix : catalogueMatrix T5[5]! = RankFiveJoin.J := by
  ext i j
  change (tget T5[5]! i j : ℝ) = (entry RankFiveJoin.rowsJ i j : ℝ)
  fin_cases i <;> fin_cases j <;> rfl

theorem catalogue_all_rank_five_excluded (j : Fin 25)
    (w : Fin T5[j.val]!.size → Nat) (hw : ∀ i, 0<w i) (z : Nat)
    (hB : (withIsolates (catalogueMatrix T5[j.val]!) w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hy : ∀ i, y i≠0 → 1≤|y i|)
    (hPos : Fintype.card {i // 0<y i}=1) (hNeg : Fintype.card {i // y i<0}=2)
    (hDeep : ∀ i, y i<0 → y i≤ -3) :
    (2/3:ℝ) ≤ ∑ i,(hB.eigenvalues₀ i-y i)^2 := by
  by_cases he : j.val=5
  · have hj : j=(5:Fin 25) := Fin.ext he
    subst j
    have hD : withIsolates (catalogueMatrix T5[(5:Fin 25).val]!) w z =
        withIsolates RankFiveJoin.J w z := congrArg (fun M => withIsolates M w z) rank_five_join_matrix
    have hJ : (withIsolates RankFiveJoin.J w z).IsHermitian := hD ▸ hB
    rw [ordered_eigenvalues_congr hD hB hJ]
    exact RankFiveJoin.no_close_blowup_of_join hw z hJ y hy hPos hNeg hDeep
  · exact catalogue_rank_five_except_join_excluded j he w hw z hB y hy hPos hNeg

#print axioms catalogue_all_rank_five_excluded
end UnitPruning


namespace UnitPruning
open Matrix SpectralConjecture20 Conj20StarCert
open scoped BigOperators Matrix
theorem bipartite_catalogue_2_0_excluded
    (w : Fin T2[0]!.size → Nat) (hw : ∀ i, 0<w i) (z : Nat)
    (hFull : (withIsolates (catalogueMatrix T2[0]!) w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hNeg : Fintype.card {i // y i<0}=2) (hPos : Fintype.card {i // 0<y i}=1)
    (hDeep : ∀ i, y i<0 → y i≤ -3) :
    (2/3:ℝ)≤∑ i,(hFull.eigenvalues₀ i-y i)^2 := by
  let d : Fin 2 → ℝ := ![1,-1]
  have hB : (catalogueMatrix T2[0]!).IsHermitian := by
    ext i j
    fin_cases i <;> fin_cases j <;> rfl
  have hh (i : Fin 2) : d i*d i=1 := by
    fin_cases i <;> norm_num [d]
  have hf (i j : Fin 2) : d i*catalogueMatrix T2[0]! i j*d j =
      -catalogueMatrix T2[0]! i j := by
    fin_cases i <;> fin_cases j <;> norm_num [d,catalogueMatrix,tget,T2]
  exact no_close_sign_symmetric_spectrum _ hB w hw z hFull d hh
    (weighted_signflip_from_base _ w d hf) y hNeg hPos hDeep
#print axioms bipartite_catalogue_2_0_excluded

theorem bipartite_catalogue_4_1_excluded
    (w : Fin T4[1]!.size → Nat) (hw : ∀ i, 0<w i) (z : Nat)
    (hFull : (withIsolates (catalogueMatrix T4[1]!) w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hNeg : Fintype.card {i // y i<0}=2) (hPos : Fintype.card {i // 0<y i}=1)
    (hDeep : ∀ i, y i<0 → y i≤ -3) :
    (2/3:ℝ)≤∑ i,(hFull.eigenvalues₀ i-y i)^2 := by
  let d : Fin 4 → ℝ := ![1,-1,1,-1]
  have hB : (catalogueMatrix T4[1]!).IsHermitian := by
    ext i j
    fin_cases i <;> fin_cases j <;> rfl
  have hh (i : Fin 4) : d i*d i=1 := by
    fin_cases i <;> norm_num [d]
  have hf (i j : Fin 4) : d i*catalogueMatrix T4[1]! i j*d j =
      -catalogueMatrix T4[1]! i j := by
    fin_cases i <;> fin_cases j <;> norm_num [d,catalogueMatrix,tget,T4]
  exact no_close_sign_symmetric_spectrum _ hB w hw z hFull d hh
    (weighted_signflip_from_base _ w d hf) y hNeg hPos hDeep
#print axioms bipartite_catalogue_4_1_excluded
end UnitPruning


namespace UnitPruning
open Matrix Conj20StarCert
open scoped Matrix

def housePerm : Fin 5 ≃ Fin 5 where
  toFun := ![0,3,4,1,2]
  invFun := ![0,3,4,1,2]
  left_inv := by intro i; fin_cases i <;> rfl
  right_inv := by intro i; fin_cases i <;> rfl

def butterflyPerm : Fin 5 ≃ Fin 5 where
  toFun := ![0,2,4,3,1]
  invFun := ![0,4,1,3,2]
  left_inv := by intro i; fin_cases i <;> rfl
  right_inv := by intro i; fin_cases i <;> rfl

theorem catalogue_house_relabel :
    HouseButterflyFence.house = (catalogueMatrix T4[5]!).submatrix housePerm housePerm := by
  ext i j
  change HouseButterflyFence.house i j = catalogueMatrix T4[5]! (housePerm i) (housePerm j)
  fin_cases i <;> fin_cases j <;>
    norm_num [HouseButterflyFence.house,HouseButterflyFence.butterfly,PawLargestFence.paw,
      catalogueMatrix,tget,T4,housePerm,butterflyPerm]

theorem catalogue_butterfly_relabel :
    HouseButterflyFence.butterfly = (catalogueMatrix T4[6]!).submatrix butterflyPerm butterflyPerm := by
  ext i j
  change HouseButterflyFence.butterfly i j = catalogueMatrix T4[6]! (butterflyPerm i) (butterflyPerm j)
  fin_cases i <;> fin_cases j <;>
    norm_num [HouseButterflyFence.house,HouseButterflyFence.butterfly,PawLargestFence.paw,
      catalogueMatrix,tget,T4,housePerm,butterflyPerm]

theorem catalogue_paw_exact : PawLargestFence.paw = catalogueMatrix T4[2]! := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    norm_num [HouseButterflyFence.house,HouseButterflyFence.butterfly,PawLargestFence.paw,
      catalogueMatrix,tget,T4,housePerm,butterflyPerm]

#print axioms catalogue_house_relabel
#print axioms catalogue_butterfly_relabel
#print axioms catalogue_paw_exact
end UnitPruning


namespace UnitPruning
open Matrix SpectralConjecture20
open scoped BigOperators Matrix

def WeightedTargetExcluded {m : Type*} [Fintype m] [DecidableEq m] (B : Matrix m m ℝ) : Prop :=
  ∀ (n : Nat), 3≤n → ∀ (w : m → Nat), (∀ i,0<w i) → (∑ i,w i)≤3*n →
  ∀ (z : Nat) (hF : (withIsolates B w z).IsHermitian)
      (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ),
    Fintype.card {i // 0<y i}=1 → Fintype.card {i // y i= -(n:ℝ)}=2 →
    (∃ i, 2*(n:ℝ)≤y i) → (2/3:ℝ)≤∑ i,(hF.eigenvalues₀ i-y i)^2

theorem weighted_target_exclusion_under_relabel {m k : Type*}
    [Fintype m] [DecidableEq m] [Fintype k] [DecidableEq k]
    (B : Matrix m m ℝ) (C : Matrix k k ℝ) (e : k ≃ m) (h : C=B.submatrix e e)
    (hC : WeightedTargetExcluded C) : WeightedTargetExcluded B := by
  intro n hn w hw hTotal z hF y hPos hNeg hTop
  let v := w ∘ e
  let e' := blowupEquiv e w z
  let k' := finCongr (Fintype.card_congr e')
  let Y : Fin (Fintype.card (Vertices v ⊕ Fin z)) → ℝ := y ∘ k'
  have ht : (∑ i,v i)≤3*n := (Equiv.sum_comp e w).trans_le hTotal
  have hEq := withIsolates_reindex_template B C e h w z
  let hG : (withIsolates C v z).IsHermitian := hEq.symm ▸ hF.submatrix e'
  have hp : Fintype.card {i // 0<Y i}=1 :=
    (Fintype.card_congr (Equiv.subtypeEquiv k' (fun _=>Iff.rfl))).trans hPos
  have hnY : Fintype.card {i // Y i= -(n:ℝ)}=2 :=
    (Fintype.card_congr (Equiv.subtypeEquiv k' (fun _=>Iff.rfl))).trans hNeg
  have htop : ∃ i, 2*(n:ℝ)≤Y i := by
    obtain ⟨i,hi⟩ := hTop
    refine ⟨k'.symm i,?_⟩
    change 2*(n:ℝ)≤y (k' (k'.symm i))
    rw [Equiv.apply_symm_apply]
    exact hi
  have hs := template_reindex_preserves_squared_distance B C e h w z hF hG y
  change (∑ j,(hG.eigenvalues₀ j-Y j)^2) = _ at hs
  exact (hC n ‹3≤n› v (fun i=>hw (e i)) ht z hG Y hp hnY htop).trans_eq hs

#print axioms weighted_target_exclusion_under_relabel
end UnitPruning


namespace UnitPruning
open Matrix Conj20StarCert

theorem catalogue_house_excluded : WeightedTargetExcluded (catalogueMatrix T4[5]!) := by
  apply weighted_target_exclusion_under_relabel _ HouseButterflyFence.house housePerm catalogue_house_relabel
  rw [←HouseLarge.house_raw_exact]
  exact HouseLarge.all_weighted_house_excluded

theorem catalogue_bull_excluded : WeightedTargetExcluded (catalogueMatrix T4[6]!) := by
  apply weighted_target_exclusion_under_relabel _ HouseButterflyFence.butterfly butterflyPerm catalogue_butterfly_relabel
  rw [←PawBullPrincipal.bull_raw_exact]
  exact PawBullPrincipal.all_weighted_bull_excluded

#print axioms catalogue_house_excluded
#print axioms catalogue_bull_excluded
end UnitPruning
