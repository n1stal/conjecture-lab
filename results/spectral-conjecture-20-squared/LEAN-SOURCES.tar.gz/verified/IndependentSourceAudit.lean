import C20Classify

namespace IndependentSourceAudit
open Conjecture20Squared
open Matrix
open scoped BigOperators

/-- Explicitly restates the objective using sorted eigenvalues of the actual
balanced graph, not the handcrafted target vector. -/
theorem actual_spectral_score {V : Type*} [Fintype V] [DecidableEq V]
    (n : Nat) (hn : 3 ≤ n) (hc : Fintype.card V = 3*n)
    (G : Matrix V V ℝ) (hG : G.IsHermitian) (hK : (balanced n).IsHermitian) :
    score n _ hG =
      ∑ i, (hG.eigenvalues₀ i - hK.eigenvalues₀ (Fin.cast (hc.trans (balanced_card n).symm) i))^2 := by
  rw [balanced_matches_target n hn hK]
  rfl

/-- An independent import and exact typecheck: graph labels are unrestricted
Booleans satisfying symmetry and looplessness. There are no rank hypotheses. -/
theorem nearest (n : Nat) (hn : 3 ≤ n)
    (A : Fin (3*n) → Fin (3*n) → Bool) (hs : ∀ i j, A i j=A j i) (hd : ∀ i, A i i=false) :
    ((¬ RelabelAs (realAdj A) (balanced n)) ∧
      ∀ (B : Fin (3*n) → Fin (3*n) → Bool) (ht : ∀ i j, B i j = B j i),
      (∀ i, B i i=false) → (¬ RelabelAs (realAdj B) (balanced n)) →
        score n _ (realAdjHerm A hs) ≤ score n _ (realAdjHerm B ht)) ↔
    RelabelAs (realAdj A) (hub n) := squared_unique_nearest n hn A hs hd

#print axioms actual_spectral_score
#print axioms nearest
end IndependentSourceAudit
