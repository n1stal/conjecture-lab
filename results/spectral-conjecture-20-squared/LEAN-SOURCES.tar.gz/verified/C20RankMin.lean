import C20Minimizer
import SpectralRank.SpectralTop
namespace Conjecture20Squared
open Matrix Finset SpectralConjecture20 UnitPruning PawUnbounded
open scoped BigOperators Matrix
theorem rank_two_min_of_near (n : Nat) (hn : 3 ≤ n)
    (A : Fin (3*n) → Fin (3*n) → Bool) (hS : ∀ i j,A i j=A j i) (hD : ∀ i,A i i=false)
    (hF : (realAdj A).IsHermitian) (hClose : score n _ hF < (16/27:ℝ)) :
    2 ≤ (realAdj A).rank := by
  classical
  by_cases h0 : ∀ i j,A i j=false
  · have hb : realAdj A=0 := by ext i j; simp [realAdj,h0]
    have ee : hF.eigenvalues=0 := (hF.eigenvalues_eq_zero_iff).mpr hb
    let N := Fintype.card (Fin (3*n))
    let i : Fin N := ⟨0,by dsimp [N]; rw [Fintype.card_fin]; omega⟩
    let e : Fin N ≃ Fin (3*n) := Fintype.equivOfCardEq (Fintype.card_fin _)
    have eig : hF.eigenvalues₀ i=0 := by
      have hh := congrFun ee (e i)
      change hF.eigenvalues₀ (e.symm (e i))=0 at hh
      rwa [Equiv.symm_apply_apply] at hh
    have h := WeightedSeedPruning.coord_fence hF.eigenvalues₀ (target n N)
      (hClose.trans (by norm_num)) i
    have hnr : (3:ℝ) ≤ n := by exact_mod_cast hn
    have hT : target n N i=2*(n:ℝ) := by simp [target,i]
    rw [eig,hT,zero_sub,abs_neg,abs_of_nonneg (by positivity)] at h
    linarith
  · push Not at h0
    obtain ⟨i,j,hij⟩ := h0
    let f : Fin 2 → Fin (3*n) := ![i,j]
    have hNice : (realAdj A).submatrix f f = !![0,1;1,0] := by
      ext r t
      have hp : A i j=true := Bool.eq_true_of_ne_false hij
      have hq : A j i=true := (hS j i).trans hp
      fin_cases r <;> fin_cases t <;> simp [realAdj,Matrix.submatrix_apply,f,hD,hp,hq]
    have hInv : ((realAdj A).submatrix f f).det≠0 := by
      rw [hNice,Matrix.det_fin_two]; norm_num
    have hRank : ((realAdj A).submatrix f f).rank=2 := by
      rw [Matrix.rank_of_det_ne_zero hInv,Fintype.card_fin]
    have hLe := Matrix.rank_submatrix_le (realAdj A) f f
    rwa [hRank] at hLe


#print axioms rank_two_min_of_near
end Conjecture20Squared
