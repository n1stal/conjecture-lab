import Mathlib.Basic.Real.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
namespace C20NumericalCore
def cubic (n x : ℝ) : ℝ := x^3 - n*x^2 + (-2*n^2+n+1)*x + n*(n-1)
def score (n a b c : ℝ) : ℝ := (a-2*n)^2 + b^2 + (c+n)^2

/-- Scaled errors for the two smaller cubic roots, deduced by evaluating
the source cubic exactly at one half and at minus n. -/
theorem small_root_errors {n a b c : ℝ} (hn : 5 ≤ n) (br : (2*n-17/30<a ∧ a<2*n) ∧ (0<b ∧ b<1/2) ∧ (-n<c ∧ c< -n+2/15))
    (hf : ∀ x, cubic n x=(x-a)*(x-b)*(x-c)) :
    (0 ≤ n*(1/2-b) ∧ n*(1/2-b) ≤ 1) ∧
    (0 ≤ n*(c+n) ∧ n*(c+n) ≤ 2) ∧ a+b+c=n := by
  obtain ⟨⟨ha,ha'⟩,⟨hb,hb'⟩,⟨hc,hc'⟩⟩ := br
  have hn0 : 0<n := by linarith
  have hr : 0≤1/2-b := by linarith
  have ht : 0≤c+n := by linarith
  have p : (a-1/2)*(1/2-c)*(1/2-b) = 3*n/4-5/8 := by
    have h := hf (1/2)
    unfold cubic at h
    linarith only [h]
  have v : (a+n)*(b+n)*(c+n)=2*n := by
    have h := hf (-n)
    unfold cubic at h
    linarith only [h]
  have h1 : n*n ≤ (a-1/2)*(1/2-c) :=
    mul_le_mul (by linarith) (by linarith) hn0.le (by linarith)
  have h2 : n*n ≤ (a+n)*(b+n) :=
    mul_le_mul (by linarith) (by linarith) hn0.le (by linarith)
  have f1 := mul_le_mul_of_nonneg_right h1 hr
  have f2 := mul_le_mul_of_nonneg_right h2 ht
  have trace : a+b+c=n := by
    have x := hf (-1)
    have y := hf 1
    have z := hf 0
    unfold cubic at x y z
    linarith only [x,y,z]
  refine ⟨⟨mul_nonneg hn0.le hr,?_⟩,⟨mul_nonneg hn0.le ht,?_⟩,trace⟩
  · by_contra! h
    have hh := mul_lt_mul_of_pos_left h hn0
    linarith only [p,f1,hh,hn]
  · by_contra! h
    have hh := mul_lt_mul_of_pos_left h hn0
    linarith only [v,f2,hh]

/-- A deliberately loose, uniform rate, enough to prove convergence. -/
theorem scaled_score_rate {n a b c : ℝ} (hn : 5 ≤ n) (br : (2*n-17/30<a ∧ a<2*n) ∧ (0<b ∧ b<1/2) ∧ (-n<c ∧ c< -n+2/15))
    (hf : ∀ x, cubic n x=(x-a)*(x-b)*(x-c)) :
    |n*(score n a b c-1/2)| ≤ 7 := by
  obtain ⟨⟨hr0,hr1⟩,⟨ht0,ht2⟩,hs⟩ := small_root_errors hn br hf
  obtain ⟨⟨ha,ha'⟩,⟨hb,hb'⟩,⟨hc,hc'⟩⟩ := br
  let u := 2*n-a
  let t := c+n
  have uu : 0≤u := by dsimp [u]; linarith
  have uu1 : u≤1 := by dsimp [u]; linarith
  have ueq : u=b+t := by dsimp [u,t]; linarith
  have tr : 0≤n*t := ht0
  have tr2 : n*t≤2 := ht2
  have tn : 0≤t := by dsimp [t]; linarith
  have t1 : t≤1 := by dsimp [t]; linarith
  have ug : -1 ≤ n*(u-1/2) ∧ n*(u-1/2) ≤ 2 := by
    rw [ueq]; constructor <;> linarith only [hr0,hr1,tr,tr2]
  have s1 := mul_nonneg (sub_nonneg.mpr ug.1) (show 0≤u+1/2 by linarith)
  have s2 := mul_nonneg (sub_nonneg.mpr ug.2) (show 0≤u+1/2 by linarith)
  have s3 := mul_nonneg (sub_nonneg.mpr hr1) (show 0≤b+1/2 by linarith)
  have s4 := mul_nonneg hr0 (show 0≤b+1/2 by linarith)
  have s5 := mul_nonneg tr (sub_nonneg.mpr t1)
  have s6 := mul_nonneg tr tn
  change |n*((a-2*n)^2+b^2+t^2-1/2)| ≤ 7
  rw [show a-2*n= -u by dsimp [u]; ring,neg_sq]
  apply abs_le.mpr
  constructor <;> nlinarith only [s1,s2,s3,s4,s5,s6,uu,uu1,hb',tr2]
#print axioms small_root_errors
#print axioms scaled_score_rate
end C20NumericalCore
