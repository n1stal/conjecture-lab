import C20Bench

namespace Conjecture20Squared
def realAdj {V : Type*} (A : V → V → Bool) : Matrix V V ℝ := fun i j => if A i j then 1 else 0
open Matrix Finset SpectralConjecture20 UnitPruning PawUnbounded
theorem hub_has_bool_representative (n : Nat) (hn : 1 ≤ n) :
    ∃ A : Fin (3*n)→Fin (3*n)→Bool, (∀ i j,A i j=A j i) ∧ (∀ i,A i i=false) ∧
      RelabelAs (realAdj A) (hub n) := by
  classical
  let U := Vertices (singletonWeights (n-1) n n) ⊕ Fin 0
  let e : U ≃ Fin (3*n) := Fintype.equivOfCardEq ((hub_card n hn).trans (Fintype.card_fin _).symm)
  let A : Fin (3*n)→Fin (3*n)→Bool := fun i j => decide (hub n (e.symm i) (e.symm j)=1)
  have hBin (i j : U) : hub n i j=0 ∨ hub n i j=1 := by
    cases i with
    | inr i => exact (Fin.elim0 i)
    | inl i =>
      cases j with
      | inr j => exact (Fin.elim0 j)
      | inl j =>
        change (seedPaw i.1 j.1)=0 ∨ (seedPaw i.1 j.1)=1
        have h (a b : Fin 4) : seedPaw a b=0 ∨ seedPaw a b=1 := by
          rw [seed_paw_exact]; fin_cases a <;> fin_cases b <;> norm_num [PawLargestFence.paw]
        exact h i.1 j.1
  have hDiag (i : U) : hub n i i=0 := by
    cases i with
    | inr i => exact Fin.elim0 i
    | inl i =>
      change seedPaw i.1 i.1=0
      have h (i : Fin 4) : seedPaw i i=0 := by rw [seed_paw_exact]; fin_cases i <;> norm_num [PawLargestFence.paw]
      exact h i.1
  refine ⟨A,?_,?_,e,?_⟩
  · intro i j
    have he : hub n (e.symm i) (e.symm j)=hub n (e.symm j) (e.symm i) := by
      have h := Matrix.IsHermitian.ext_iff.mp (hub_herm n) (e.symm j) (e.symm i)
      simpa using h
    simp [A,he]
  · intro i; simp [A,hDiag]
  · ext i j
    rcases hBin i j with h|h <;> simp [realAdj,A,Matrix.submatrix_apply,h]


#print axioms hub_has_bool_representative
end Conjecture20Squared
