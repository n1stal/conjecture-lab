import ManhattanSign
import ManhattanTransport
import ManhattanFinite
import C20Bench

namespace ManhattanSmall
open Matrix SpectralConjecture20 Finset
open ManhattanTarget ManhattanFinite PawLargestFence
open scoped BigOperators

def shaped (a b c d t : ℝ) : ℝ :=
  t^4-(a*(b+c+d)+b*c)*t^2-2*a*b*c*t+a*b*c*d

theorem paw_product (a b c d z : Nat) (ha : 0<a) (hb : 0<b) (hc : 0<c) (hd : 0<d)
    (hA : (withIsolates paw (pawWeights a b c d) z).IsHermitian) (t : ℝ) :
    t^(Fintype.card (Vertices (pawWeights a b c d) ⊕ Fin z)-4)*shaped a b c d t =
      ∏ i, (t-hA.eigenvalues₀ i) := by
  have hw (i : Fin 4) : 0<pawWeights a b c d i := by
    fin_cases i <;> first | exact ha | exact hb | exact hc | exact hd
  rw [←PawUnbounded.eval_charpoly_by_ordered_roots _ hA,
    withIsolates_charpoly paw (pawWeights a b c d) hw,
    Polynomial.eval_mul,Polynomial.eval_pow,Polynomial.eval_X]
  have hcard : Fintype.card (Vertices (pawWeights a b c d))=a+b+c+d := by
    have h := PawUnbounded.card_blowup_vertices (pawWeights a b c d) 0
    simp only [Fintype.card_sum,Fintype.card_fin,Nat.add_zero] at h
    simpa [Fin.sum_univ_four,pawWeights] using h
  have hExp : Fintype.card (Vertices (pawWeights a b c d) ⊕ Fin z)-4 =
      Fintype.card (Vertices (pawWeights a b c d))-Fintype.card (Fin 4)+z := by
    rw [Fintype.card_sum,Fintype.card_fin,Fintype.card_fin,hcard]
    omega
  rw [hExp,paw_quotient_explicit,Matrix.eval_charpoly,det_paw]
  simp only [←pow_two,Real.sq_sqrt (Nat.cast_nonneg _)]
  unfold shaped poly pawE pawF pawG
  ring

theorem triangle_product (a b c z : Nat) (ha : 0<a) (hb : 0<b) (hc : 0<c)
    (hA : (withIsolates TriangleSpectralFence.triangleSeed (TriangleSpectralFence.triangleWeights a b c) z).IsHermitian)
    (hN : 4≤Fintype.card (Vertices (TriangleSpectralFence.triangleWeights a b c) ⊕ Fin z))
    (t : ℝ) :
    t^(Fintype.card (Vertices (TriangleSpectralFence.triangleWeights a b c) ⊕ Fin z)-4)*shaped a b c 0 t =
      ∏ i, (t-hA.eigenvalues₀ i) := by
  open TriangleSpectralFence in
  have hw (i : Fin 3) : 0<triangleWeights a b c i := by
    fin_cases i <;> first | exact ha | exact hb | exact hc
  rw [←PawUnbounded.eval_charpoly_by_ordered_roots _ hA,
    withIsolates_charpoly _ _ hw,Polynomial.eval_mul,Polynomial.eval_pow,Polynomial.eval_X]
  open TriangleSpectralFence in
  have hcard : Fintype.card (Vertices (triangleWeights a b c))=a+b+c := by
    have h := PawUnbounded.card_blowup_vertices (triangleWeights a b c) 0
    simp only [Fintype.card_sum,Fintype.card_fin,Nat.add_zero] at h
    simpa [Fin.sum_univ_three,triangleWeights] using h
  open TriangleSpectralFence in
  have hExp : Fintype.card (Vertices (triangleWeights a b c))-Fintype.card (Fin 3)+z =
      Fintype.card (Vertices (triangleWeights a b c) ⊕ Fin z)-4+1 := by
    have hc4 : 4≤a+b+c+z := by
      simpa only [Fintype.card_sum,Fintype.card_fin,hcard] using hN
    simp only [Fintype.card_sum,Fintype.card_fin,hcard]
    omega
  rw [hExp,pow_add,pow_one,mul_assoc,TriangleSpectralFence.triangleQ_quotient,
    Matrix.eval_charpoly,TriangleSpectralFence.det_triangle]
  simp only [Real.sq_sqrt (Nat.cast_nonneg _)]
  unfold shaped TriangleSpectralFence.generalTriPoly
  ring

theorem scaled_shape (a b c d : Nat) (t : ℤ) :
    ((value ⟨a,b,c,d⟩ t : ℤ) : ℝ) = 4096*shaped a b c d ((t:ℝ)/8) := by
  unfold value shaped
  dsimp
  push_cast
  ring

theorem necessary_grid {N : Nat} (n a b c d : Nat) (hn : 3≤n) (hN : 4≤N)
    (x : Fin N → ℝ) (hz : ∑ i, x i=0)
    (hClose : (∑ i, |x i-balancedSpectrum (n:ℝ) (by omega) i|)<(5/4:ℝ))
    (hf : ∀ t, t^(N-4)*shaped a b c d t = ∏ i, (t-x i)) :
    passes n ⟨a,b,c,d⟩ = true := by
  let y := balancedSpectrum (n:ℝ) (by omega : 3≤N)
  have hy : ∑ i, y i=0 := by
    dsimp only [y]
    rw [sum_profile _ _ (fun x => x) rfl]
    ring
  have hz' : ∑ i,(x i-y i)=0 := by rw [Finset.sum_sub_distrib,hz,hy,sub_zero]
  have hNear (i : Fin N) : |x i-y i| < (5/8:ℝ) := by
    have h := (ManhattanSpectral.twice_abs_of_zero_sum (fun j => x j-y j) hz' i).trans_lt hClose
    linarith
  have hnR : (3:ℝ)≤n := by exact_mod_cast hn
  obtain ⟨hT,hL,hU⟩ := ManhattanSign.exact_fence_signs hN x (shaped a b c d) (n:ℝ) hnR hNear hf
  unfold passes
  simp only [Bool.and_eq_true, decide_eq_true_eq]
  have h₁ : ((value ⟨a,b,c,d⟩ (16*(n:ℤ)-5) : ℤ) : ℝ) < 0 := by
    rw [scaled_shape]
    push_cast
    rw [show (16*(n:ℝ)-5)/8=2*n-5/8 by ring]
    exact mul_neg_of_pos_of_neg (by norm_num) hT
  have h₂ : 0 < ((value ⟨a,b,c,d⟩ (-8*(n:ℤ)-5) : ℤ) : ℝ) := by
    rw [scaled_shape]
    push_cast
    rw [show (-8*(n:ℝ)-5)/8=-(n:ℝ)-5/8 by ring]
    exact mul_pos (by norm_num) hL
  have h₃ : 0 < ((value ⟨a,b,c,d⟩ (-8*(n:ℤ)+5) : ℤ) : ℝ) := by
    rw [scaled_shape]
    push_cast
    rw [show (-8*(n:ℝ)+5)/8=-(n:ℝ)+5/8 by ring]
    exact mul_pos (by norm_num) hU
  exact ⟨⟨by exact_mod_cast h₁, by exact_mod_cast h₂⟩, by exact_mod_cast h₃⟩

theorem survivors (n a b c d : Nat) (hsmall : n=3 ∨ n=4)
    (ha : 0<a) (hb : 0<b) (hc : 0<c) (ht : a+b+c+d≤3*n)
    (h : passes n ⟨a,b,c,d⟩ = true) :
    (a=n ∧ b=n ∧ c=n ∧ d=0) ∨
    (a+1=n ∧ b=n ∧ c=n ∧ d=1) ∨
    (n=4 ∧ a=4 ∧ d=1 ∧ ((b=3 ∧ c=4) ∨ (b=4 ∧ c=3))) := by
  have hm : Shape.mk a b c d ∈ (allRows n).filter (passes n) :=
    List.mem_filter.mpr ⟨mem_allRows n a b c d ha hb hc ht,h⟩
  rcases hsmall with h3|h4
  · subst n
    rw [allSmall3] at hm
    simp only [List.mem_cons, List.not_mem_nil, or_false, Shape.mk.injEq] at hm
    rcases hm with ⟨rfl,rfl,rfl,rfl⟩|⟨rfl,rfl,rfl,rfl⟩ <;> decide
  · subst n
    rw [allSmall4] at hm
    simp only [List.mem_cons, List.not_mem_nil, or_false, Shape.mk.injEq] at hm
    rcases hm with ⟨rfl,rfl,rfl,rfl⟩|⟨rfl,rfl,rfl,rfl⟩|⟨rfl,rfl,rfl,rfl⟩|⟨rfl,rfl,rfl,rfl⟩ <;> decide

#print axioms survivors
#print axioms paw_product
#print axioms triangle_product
#print axioms necessary_grid
end ManhattanSmall
