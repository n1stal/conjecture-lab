import ManhattanLocal
import ManhattanSpectral

namespace ManhattanGraph
open ManhattanLocal
open scoped BigOperators

def matrixOf {V : Type*} (A : V → V → Bool) : Matrix V V ℝ :=
  fun x y => if A x y then 1 else 0

theorem pattern_cast (tag : Fin 3) :
    matrixOf (forbiddenBool (tag.val+1)) =
      ![ManhattanSpectral.path,ManhattanSpectral.matching,ManhattanSpectral.clique] tag := by
  ext i j
  fin_cases tag <;> fin_cases i <;> fin_cases j <;> rfl

theorem labelled_of_cut {V : Type*} [Fintype V] [DecidableEq V]
    (A : V → V → Bool) (hA : (matrixOf A).IsHermitian) (hdiag : ∀ i, A i i = false)
    (y : Fin (Fintype.card V) → ℝ) (hY : ∑ i, y i = 0)
    (hPos : Fintype.card {i // 0 < y i} ≤ 1)
    (hNeg : Fintype.card {i // y i < 0} ≤ 2)
    (hClose : (∑ i, |hA.eigenvalues₀ i-y i|) < (11/9:ℝ)) :
    ∀ (e : Fin 4 ↪ V) (t : Fin 3), ¬(∀ i j, A (e i) (e j) = forbiddenBool (t.val+1) i j) := by
  intro e t h
  have hE : (matrixOf A).submatrix e e = matrixOf (forbiddenBool (t.val+1)) := by
    ext i j
    change (if A (e i) (e j) then (1:ℝ) else 0) = if forbiddenBool (t.val+1) i j then 1 else 0
    rw [h]
  rw [pattern_cast t] at hE
  have hF := ManhattanSpectral.forbidden_ordered_principal_of_close (matrixOf A) hA
    (by intro i; simp [matrixOf,hdiag]) y hY hPos hNeg hClose e
  fin_cases t
  · exact hF.1 hE
  · exact hF.2.1 hE
  · exact hF.2.2 hE

theorem normalized_triangle_pair {V : Type*} (A : V → V → Bool)
    (hFree : ∀ (e : Fin 4 ↪ V) (t : Fin 3),
      ¬(∀ i j, A (e i) (e j) = forbiddenBool (t.val+1) i j))
    (f : Fin 5 ↪ V) (m n : Fin 8) (e : Bool)
    (hLocal : ∀ i j : Fin 5, A (f i) (f j) = adj 3 m n e i.val j.val) :
    law 3 m n e = true := by
  cases h : law 3 m n e
  · have hw := witness_sound m n e h
    let c := witnessCode3 m n e / 625
    have hc₁ : 1 ≤ c := hw.1
    have hc₂ : c ≤ 3 := hw.2.1
    let t : Fin 3 := ⟨c-1, by omega⟩
    let g : Fin 4 ↪ Fin 5 := ⟨witnessMap3 m n e,hw.2.2.1⟩
    exfalso
    apply hFree (g.trans f) t
    intro i j
    change A (f (g i)) (f (g j)) = forbiddenBool (t.val+1) i j
    rw [hLocal]
    have ht : t.val+1 = c := by dsimp [t]; omega
    rw [ht]
    exact hw.2.2.2 i j
  · rfl

/-- Encoding of all permitted neighborhood signatures of a vertex on the anchors. -/
def mask {V : Type*} (A : V → V → Bool) (a : Fin 3 ↪ V) (x : V) : Fin 8 :=
  ⟨(if A (a 0) x then 1 else 0) + (if A (a 1) x then 2 else 0) +
      (if A (a 2) x then 4 else 0), by
    split <;> split <;> split <;> decide⟩
def anchorMask (i : Fin 3) : Fin 8 := ![6,5,3] i

theorem mask_bit {V : Type*} (A : V → V → Bool) (a : Fin 3 ↪ V) (x : V) (i : Fin 3) :
    (mask A a x).val.testBit i.val = A (a i) x := by
  fin_cases i <;> cases h0 : A (a 0) x <;> cases h1 : A (a 1) x <;> cases h2 : A (a 2) x <;>
    simp [mask,h0,h1,h2] <;> rfl

theorem mask_anchor {V : Type*} (A : V → V → Bool) (a : Fin 3 ↪ V)
    (ha : ∀ i j, A (a i) (a j) = decide (i≠j)) (i : Fin 3) :
    mask A a (a i) = anchorMask i := by
  fin_cases i <;> apply Fin.ext <;> simp [mask,ha,anchorMask]

theorem anchor_right (m : Fin 8) (i : Fin 3) (hm : m.val ≠ 7) :
    law 3 m (anchorMask i) (m.val.testBit i.val) = true :=
  (by decide : ∀ (m : Fin 8) (i : Fin 3), m.val ≠ 7 →
    law 3 m (anchorMask i) (m.val.testBit i.val) = true) m i hm
theorem anchor_left (m : Fin 8) (i : Fin 3) (hm : m.val ≠ 7) :
    law 3 (anchorMask i) m (m.val.testBit i.val) = true :=
  (by decide : ∀ (m : Fin 8) (i : Fin 3), m.val ≠ 7 →
    law 3 (anchorMask i) m (m.val.testBit i.val) = true) m i hm
theorem self_mask (m : Fin 8) (hm : m.val ≠ 7) : law 3 m m false = true :=
  (by decide : ∀ (m : Fin 8), m.val ≠ 7 → law 3 m m false = true) m hm
theorem law_valid_left (m n : Fin 8) (e : Bool) (h : law 3 m n e = true) : m.val ≠ 7 :=
  (by decide : ∀ (m n : Fin 8) (e : Bool), law 3 m n e = true → m.val ≠ 7) m n e h

theorem triangle_pair {V : Type*} (A : V → V → Bool)
    (hsymm : ∀ x y, A x y = A y x) (hdiag : ∀ x, A x x = false)
    (hFree : ∀ (e : Fin 4 ↪ V) (t : Fin 3),
      ¬(∀ i j, A (e i) (e j) = forbiddenBool (t.val+1) i j))
    (a : Fin 3 ↪ V) (ha : ∀ i j, A (a i) (a j) = decide (i≠j))
    (x y : V) (hx : ∀ i, x ≠ a i) (hy : ∀ i, y ≠ a i) (hxy : x ≠ y) :
    law 3 (mask A a x) (mask A a y) (A x y) = true := by
  let f : Fin 5 → V := ![a 0,a 1,a 2,x,y]
  have hr (i j : Fin 3) (hij : i≠j) : a i ≠ a j := fun h => hij (a.injective h)
  have hf : Function.Injective f := by
    intro i j hij
    fin_cases i <;> fin_cases j <;>
      first | rfl
            | exact False.elim (hx _ hij)
            | exact False.elim (hx _ hij.symm)
            | exact False.elim (hy _ hij)
            | exact False.elim (hy _ hij.symm)
            | exact False.elim (hxy hij)
            | exact False.elim (hxy hij.symm)
            | exact False.elim (hr _ _ (by decide) hij)
  apply normalized_triangle_pair A hFree ⟨f,hf⟩
  intro i j
  change A (f i) (f j) = _
  fin_cases i <;> fin_cases j <;>
    simp [f,adj,ha,hdiag] <;>
    first
    | rfl
    | exact hsymm _ _
    | simpa using (mask_bit A a x 0).symm
    | simpa using (mask_bit A a x 1).symm
    | simpa using (mask_bit A a x 2).symm
    | simpa using (mask_bit A a y 0).symm
    | simpa using (mask_bit A a y 1).symm
    | simpa using (mask_bit A a y 2).symm
    | rw [hsymm x (a 0)]; simpa using (mask_bit A a x 0).symm
    | rw [hsymm x (a 1)]; simpa using (mask_bit A a x 1).symm
    | rw [hsymm x (a 2)]; simpa using (mask_bit A a x 2).symm
    | rw [hsymm y (a 0)]; simpa using (mask_bit A a y 0).symm
    | rw [hsymm y (a 1)]; simpa using (mask_bit A a y 1).symm
    | rw [hsymm y (a 2)]; simpa using (mask_bit A a y 2).symm

/-- Geometry of every forbidden-subgraph-free graph with a triangle. -/
theorem triangle_as_paw {V : Type*} (A : V → V → Bool)
    (hsymm : ∀ x y, A x y = A y x) (hdiag : ∀ x, A x x = false)
    (hFree : ∀ (e : Fin 4 ↪ V) (t : Fin 3),
      ¬(∀ i j, A (e i) (e j) = forbiddenBool (t.val+1) i j))
    (a : Fin 3 ↪ V) (ha : ∀ i j, A (a i) (a j) = decide (i≠j))
    :
    ∃ color : V → Fin 5,
      (∀ x y, A x y = pawColorAdj (color x) (color y)) ∧
      (∃ x, color x=0) ∧ (∃ x, color x=1) ∧ (∃ x, color x=2) := by
  classical
  have hValid (x : V) : (mask A a x).val ≠ 7 := by
    by_cases h : ∃ i, x=a i
    · obtain ⟨i,rfl⟩ := h
      rw [mask_anchor A a ha i]
      fin_cases i <;> decide
    · have hx : ∀ i, x ≠ a i := fun i hi => h ⟨i,hi⟩
      intro h7
      let f : Fin 4 → V := ![a 0,a 1,a 2,x]
      have hr (i j : Fin 3) (hij : i≠j) : a i ≠ a j := fun h => hij (a.injective h)
      have hf : Function.Injective f := by
        intro i j hij
        fin_cases i <;> fin_cases j <;>
          first | rfl
                | exact False.elim (hx _ hij)
                | exact False.elim (hx _ hij.symm)
                | exact False.elim (hr _ _ (by decide) hij)
      have hAx (i : Fin 3) : A (a i) x = true := by
        rw [←mask_bit A a x i, h7]
        fin_cases i <;> decide
      have hXa (i : Fin 3) : A x (a i) = true := (hsymm _ _).trans (hAx i)
      apply hFree ⟨f,hf⟩ 2
      intro i j
      change A (f i) (f j) = forbiddenBool (2+1) i j
      fin_cases i <;> fin_cases j <;> simp [f,ha,hdiag,hAx,hXa,forbiddenBool]
  have hp (x y : V) : law 3 (mask A a x) (mask A a y) (A x y) = true := by
    by_cases hx : ∃ i, x=a i
    · obtain ⟨i,rfl⟩ := hx
      rw [mask_anchor A a ha i, ←mask_bit A a y i]
      exact anchor_left _ _ (hValid y)
    by_cases hy : ∃ i, y=a i
    · obtain ⟨i,rfl⟩ := hy
      rw [mask_anchor A a ha i, hsymm x (a i), ←mask_bit A a x i]
      exact anchor_right _ _ (hValid x)
    by_cases hxy : x=y
    · subst y; rw [hdiag]; exact self_mask _ (hValid x)
    exact triangle_pair A hsymm hdiag hFree a ha x y (fun i hi => hx ⟨i,hi⟩)
      (fun i hi => hy ⟨i,hi⟩) hxy
  obtain ⟨hub,hh,hColor⟩ := triangle_global_color A (mask A a) hp
  refine ⟨fun x => triangleColor hub (mask A a x),hColor,?_⟩
  have hOne (c : Fin 5) (hc : triangleColor hub 6=c ∨ triangleColor hub 5=c ∨ triangleColor hub 3=c) :
      ∃ x, triangleColor hub (mask A a x) = c := by
    rcases hc with h|h|h
    · exact ⟨a 0, by rw [mask_anchor A a ha]; exact h⟩
    · exact ⟨a 1, by rw [mask_anchor A a ha]; exact h⟩
    · exact ⟨a 2, by rw [mask_anchor A a ha]; exact h⟩
  obtain ⟨h0,h1,h2⟩ := triangle_colors_nonempty hub hh
  exact ⟨hOne _ h0,hOne _ h1,hOne _ h2⟩

#print axioms triangle_as_paw
#print axioms labelled_of_cut
#print axioms normalized_triangle_pair
end ManhattanGraph
