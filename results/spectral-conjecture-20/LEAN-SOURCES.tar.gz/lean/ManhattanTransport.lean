import ManhattanTarget
import C20Triangle

namespace ManhattanTransport
open ManhattanLocal ManhattanGraph ManhattanTarget
open Matrix SpectralConjecture20
open scoped BigOperators

def colorSeed (k : Nat) (hk : k≤5) : Matrix (Fin k) (Fin k) ℝ :=
  matrixOf fun i j => pawColorAdj (Fin.castLE hk i) (Fin.castLE hk j)

theorem seed_four : colorSeed 4 (by decide) = PawLargestFence.paw := by
  ext i j
  fin_cases i <;> fin_cases j <;> rfl

theorem seed_three : colorSeed 3 (by decide) = TriangleSpectralFence.triangleSeed := by
  ext i j
  fin_cases i <;> fin_cases j <;> rfl

theorem isolate_color (i : Fin 5) :
    pawColorAdj i 4 = false ∧ pawColorAdj 4 i = false :=
  (by decide : ∀ i : Fin 5, pawColorAdj i 4 = false ∧ pawColorAdj 4 i = false) i

/-- Handle an empty leaf class without manufacturing positive weights. -/
theorem colored_to_weighted {V : Type*} [Fintype V]
    (A : V → V → Bool) (color : V → Fin 5)
    (hColor : ∀ x y, A x y = pawColorAdj (color x) (color y))
    (k : Nat) (hk : k≤5)
    (hInactive : ∀ x, ¬(color x).val<k → color x=4) :
    ∃ (w : Fin k → Nat) (z : Nat) (e : Vertices w ⊕ Fin z ≃ V),
      (∀ i, 0<w i ↔ ∃ x, color x = Fin.castLE hk i) ∧
      (matrixOf A).submatrix e e = withIsolates (colorSeed k hk) w z := by
  classical
  let live (x : V) := (color x).val < k
  let cls (x : {x // live x}) : Fin k := ⟨(color x.val).val,x.property⟩
  let w (i : Fin k) := Fintype.card {x : {x // live x} // cls x=i}
  let z := Fintype.card {x : V // ¬live x}
  let ph (i : Fin k) : Fin (w i) ≃ {x : {x // live x} // cls x=i} :=
    (Fintype.equivFin _).symm
  let g : Vertices w ≃ {x // live x} :=
    (Equiv.sigmaCongrRight ph).trans (Equiv.sigmaFiberEquiv cls)
  let e : Vertices w ⊕ Fin z ≃ V :=
    (Equiv.sumCongr g (Fintype.equivFin {x : V // ¬live x}).symm).trans (Equiv.sumCompl live)
  have hLeft (u : Vertices w) : e (Sum.inl u)=(g u).val := rfl
  have hCol (u : Vertices w) : color (g u).val = Fin.castLE hk u.1 := by
    apply Fin.ext
    exact congrArg (fun j : Fin k => j.val) (ph u.1 u.2).property
  have hIso (j : Fin z) : color (e (Sum.inr j))=4 :=
    hInactive _ ((Fintype.equivFin {x : V // ¬live x}).symm j).property
  refine ⟨w,z,e, ?_,?_⟩
  · intro i
    change 0 < Fintype.card {x : {x // live x} // cls x=i} ↔ _
    rw [Fintype.card_pos_iff]
    constructor
    · intro h
      obtain ⟨⟨x,hx⟩⟩ := h
      exact ⟨x.val,Fin.ext (congrArg (fun j : Fin k => j.val) hx)⟩
    · rintro ⟨x,hx⟩
      have hl : live x := by
        change (color x).val < k
        rw [hx]
        exact i.isLt
      exact ⟨⟨⟨x,hl⟩, Fin.ext (congrArg (fun j : Fin 5 => j.val) hx)⟩⟩
  ext (u|u) (v|v)
  · change (if A (e (Sum.inl u)) (e (Sum.inl v)) then (1:ℝ) else 0) =
      if pawColorAdj (Fin.castLE hk u.1) (Fin.castLE hk v.1) then 1 else 0
    rw [hColor,hLeft,hLeft,hCol,hCol]
  · change (if A (e (Sum.inl u)) (e (Sum.inr v)) then (1:ℝ) else 0)=0
    rw [hColor,hIso,(isolate_color _).1]
    rfl
  · change (if A (e (Sum.inr u)) (e (Sum.inl v)) then (1:ℝ) else 0)=0
    rw [hColor,hIso,(isolate_color _).2]
    rfl
  · change (if A (e (Sum.inr u)) (e (Sum.inr v)) then (1:ℝ) else 0)=0
    rw [hColor,hIso,(isolate_color _).2]
    rfl

theorem colors_to_paw_or_triangle {V : Type*} [Fintype V]
    (A : V → V → Bool) (color : V → Fin 5)
    (hColor : ∀ x y, A x y = pawColorAdj (color x) (color y))
    (h0 : ∃ x, color x=0) (h1 : ∃ x, color x=1) (h2 : ∃ x, color x=2) :
      (∃ (w : Fin 4 → Nat) (z : Nat) (e : Vertices w ⊕ Fin z ≃ V),
        (∀ i, 0<w i) ∧ (matrixOf A).submatrix e e = withIsolates PawLargestFence.paw w z) ∨
      (∃ (w : Fin 3 → Nat) (z : Nat) (e : Vertices w ⊕ Fin z ≃ V),
        (∀ i, 0<w i) ∧ (matrixOf A).submatrix e e = withIsolates TriangleSpectralFence.triangleSeed w z) := by
  classical
  by_cases h3 : ∃ x, color x=3
  · have hBad (x : V) (hx : ¬(color x).val<4) : color x=4 := by
      apply Fin.ext
      have hh := (color x).isLt
      omega
    obtain ⟨w,z,e,hw,he⟩ := colored_to_weighted A color hColor 4 (by decide) hBad
    rw [seed_four] at he
    exact Or.inl ⟨w,z,e, fun i => (hw i).mpr (by fin_cases i <;> first | exact h0 | exact h1 | exact h2 | exact h3),he⟩
  · have hBad (x : V) (hx : ¬(color x).val<3) : color x=4 := by
      have hneq : (color x).val ≠ 3 := fun h => h3 ⟨x, Fin.ext h⟩
      apply Fin.ext
      have hh := (color x).isLt
      omega
    -- Explicit inequality proof avoids leaving type information to elaboration.
    obtain ⟨w,z,e,hw,he⟩ := colored_to_weighted A color hColor 3 (by decide) hBad
    rw [seed_three] at he
    exact Or.inr ⟨w,z,e, fun i => (hw i).mpr (by fin_cases i <;> first | exact h0 | exact h1 | exact h2),he⟩

theorem near_weighted_paw_or_triangle {V : Type*} [Fintype V] [DecidableEq V]
    (n : Nat) (hn : 3≤n) (hcard : Fintype.card V=3*n)
    (A : V → V → Bool) (hA : (matrixOf A).IsHermitian)
    (hsymm : ∀ x y, A x y=A y x) (hdiag : ∀ i, A i i=false)
    (hClose : (∑ i, |hA.eigenvalues₀ i - balancedSpectrum (n:ℝ) (by omega) i|) < (11/9:ℝ)) :
      (∃ (w : Fin 4 → Nat) (z : Nat) (e : Vertices w ⊕ Fin z ≃ V),
        (∀ i, 0<w i) ∧ (matrixOf A).submatrix e e = withIsolates PawLargestFence.paw w z) ∨
      (∃ (w : Fin 3 → Nat) (z : Nat) (e : Vertices w ⊕ Fin z ≃ V),
        (∀ i, 0<w i) ∧ (matrixOf A).submatrix e e = withIsolates TriangleSpectralFence.triangleSeed w z) := by
  obtain ⟨c,hc,h0,h1,h2⟩ := spectral_paw_reduction n hn hcard A hA hsymm hdiag hClose
  exact colors_to_paw_or_triangle A c hc h0 h1 h2

#print axioms near_weighted_paw_or_triangle
end ManhattanTransport
