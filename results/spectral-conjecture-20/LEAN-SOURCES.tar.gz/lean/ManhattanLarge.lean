import ManhattanMass
import ManhattanPawIsolate
import ManhattanTransport
import C20Minimizer

namespace ManhattanLarge
open Matrix Finset SpectralConjecture20 PawUnbounded
open Conjecture20Squared ManhattanTarget
open scoped BigOperators

noncomputable def l1 {V : Type*} [Fintype V] [DecidableEq V] (n : Nat)
    (A : Matrix V V ℝ) (hA : A.IsHermitian) : ℝ :=
  ∑ i, |hA.eigenvalues₀ i - target n (Fintype.card V) i|

theorem profile_matches (n N : Nat) (hN : N=3*n) (h : 3≤N) (i : Fin N) :
    target n N i = balancedSpectrum (n:ℝ) h i := by
  have a : i.val=0 ↔ i=head h := by simp [head,Fin.ext_iff]
  have b₁ : (penult h).val=N-2 := by simp [penult,Fin.val_rev]
  have b₂ : (last h).val=N-1 := by simp [last,Fin.val_rev]
  have b : 3*n ≤ i.val+2 ↔ i=penult h ∨ i=last h := by
    constructor
    · intro hi
      have hi' := i.isLt
      by_cases he : i.val=N-2
      · exact Or.inl (Fin.ext (he.trans b₁.symm))
      · exact Or.inr (Fin.ext (by omega))
    · rintro (rfl|rfl) <;> omega
  unfold target balancedSpectrum
  simp only [a,b]

theorem target_sum (n N : Nat) (hN : N=3*n) (h : 3≤N) :
    ∑ i, target n N i=0 := by
  calc
    _ = ∑ i, balancedSpectrum (n:ℝ) h i :=
      Finset.sum_congr rfl fun i _ => profile_matches n N hN h i
    _ = 0 := by
      rw [sum_profile _ _ (fun t => t) rfl]
      ring

theorem l1_relabel {V W : Type*} [Fintype V] [Fintype W] [DecidableEq V] [DecidableEq W]
    (n : Nat) (A : Matrix V V ℝ) (hA : A.IsHermitian) (B : Matrix W W ℝ) (hB : B.IsHermitian)
    (e : W ≃ V) (he : B=A.submatrix e e) : l1 n B hB = l1 n A hA := by
  let hcard := Fintype.card_congr e
  unfold l1
  calc
    _ = ∑ j, |hA.eigenvalues₀ (Fin.cast hcard j) - target n (Fintype.card V) (Fin.cast hcard j)| := by
      apply Finset.sum_congr rfl
      intro j _
      simpa only [target,Fin.val_cast] using congrArg
        (fun t => |t - target n (Fintype.card W) j|)
        (UnitPruning.ordered_eigenvalues_submatrix_equiv A hA B hB e he j)
    _ = _ := Equiv.sum_comp (finCongr hcard) (fun i => |hA.eigenvalues₀ i-target n (Fintype.card V) i|)

theorem squared_of_low_l1 {V : Type*} [Fintype V] [DecidableEq V] (n : Nat)
    (hN : Fintype.card V=3*n) (hn : 3≤n)
    (A : Matrix V V ℝ) (hA : A.IsHermitian) (hD : ∀ i, A i i=0)
    (hNear : l1 n A hA < (17/15:ℝ)) : score n A hA < (2/3:ℝ) := by
  have hZero : ∑ i,(hA.eigenvalues₀ i-target n (Fintype.card V) i)=0 := by
    rw [Finset.sum_sub_distrib,ordered_eigenvalue_sum_zero_of_diag _ hA hD,
      target_sum n _ hN (by omega),sub_zero]
  have h := SpectralMass.sum_sq_le_half_abs_sq _ hZero
  have hs : 0≤l1 n A hA := Finset.sum_nonneg fun i _ => abs_nonneg _
  have hb : (l1 n A hA)^2 ≤ (17/15:ℝ)^2 :=
    pow_le_pow_left₀ hs hNear.le 2
  change score n A hA ≤ (l1 n A hA)^2/2 at h
  linarith only [h,hb]

private theorem paw_large (n : Nat) (hn : 5≤n) (w : Fin 4→Nat) (z : Nat)
    (hw : ∀ i,0<w i) (hN : Fintype.card (Vertices w ⊕ Fin z)=3*n)
    (hA : (withIsolates PawLargestFence.paw w z).IsHermitian)
    (hNear : l1 n _ hA < (17/15:ℝ)) :
    z=0 ∧ w=singletonWeights (n-1) n n := by
  let y := target n (Fintype.card (Vertices w ⊕ Fin z))
  have hsz : (∑ i,w i)+z=3*n := (card_blowup_vertices w z).symm.trans hN
  have hFour : 4≤Fintype.card (Vertices w ⊕ Fin z) := by omega
  obtain ⟨hy0,hy1,hy2,hy3,hyLow,_,hyPos,_,hyNeg,_,_⟩ := profile n _ (by omega) hN
  have hz := PawIsolate.paw_no_isolate_of_manhattan n w hw z hsz hA y (target_sum n _ hN (by omega))
    ⟨⟨0,by omega⟩,hy0.ge⟩ (hNear.trans (by norm_num))
  have hdiag (i : Fin 4) : PawLargestFence.paw i i=0 := by fin_cases i <;> rfl
  have hSq := squared_of_low_l1 n hN (by omega) _ hA
    (withIsolates_diagonal_zero _ hdiag w z) hNear
  obtain ⟨hd,hmain⟩ := PawIsolate.paw_below_two_thirds n (by omega) w hw z hsz hA hFour y
    hy0 hy1 hy2 hy3 hyLow hyPos hyNeg hSq
  obtain ⟨ha,hb,hc⟩ := hmain hz
  refine ⟨hz,?_⟩
  funext i
  fin_cases i
  · change w (0:Fin 4)=n-1; omega
  · exact hb
  · exact hc
  · exact hd

private theorem triangle_large (n : Nat) (hn : 5≤n) (w : Fin 3→Nat) (z : Nat)
    (hw : ∀ i,0<w i) (hN : Fintype.card (Vertices w ⊕ Fin z)=3*n)
    (hA : (withIsolates TriangleSpectralFence.triangleSeed w z).IsHermitian)
    (hNear : l1 n _ hA < (17/15:ℝ)) :
    z=0 ∧ w=TriangleSpectralFence.triangleWeights n n n := by
  let a := w 0
  let b := w 1
  let c := w 2
  have hW : w=TriangleSpectralFence.triangleWeights a b c := by
    funext i; fin_cases i <;> rfl
  have hdiag (i : Fin 3) : TriangleSpectralFence.triangleSeed i i=0 := by fin_cases i <;> rfl
  have hSq := squared_of_low_l1 n hN (by omega) _ hA
    (withIsolates_diagonal_zero _ hdiag w z) hNear
  have dep (v : Fin 3→Nat) (hv : v=TriangleSpectralFence.triangleWeights a b c)
      (hC : Fintype.card (Vertices v ⊕ Fin z)=3*n)
      (hG : (withIsolates TriangleSpectralFence.triangleSeed v z).IsHermitian)
      (hs : score n _ hG < (2/3:ℝ)) : a=n ∧ b=n ∧ c=n ∧ z=0 := by
    subst v
    obtain ⟨h0,_,h2,h3,_⟩ := profile n _ (by omega) hC
    exact TriangleSpectralFence.triangle_padded_close_is_balanced n a b c z (by omega)
      (hw 0) (hw 1) (hw 2) hG hC _ h0 h2 h3 hs
  obtain ⟨ha,hb,hc,hz⟩ := dep w hW hN hA hSq
  exact ⟨hz,hW.trans (by rw [ha,hb,hc])⟩

theorem classify_large (n : Nat) (hn : 5≤n) {V : Type*} [Fintype V] [DecidableEq V]
    (hcard : Fintype.card V=3*n) (A : V→V→Bool)
    (hs : ∀ i j, A i j=A j i) (hd : ∀ i, A i i=false)
    (hNear : l1 n _ (realAdjHerm A hs)<(17/15:ℝ)) :
    RelabelAs (realAdj A) (balanced n) ∨ RelabelAs (realAdj A) (hub n) := by
  have hm : (ManhattanGraph.matrixOf A).IsHermitian := realAdjHerm A hs
  have hCoarse : (∑ i, |hm.eigenvalues₀ i-balancedSpectrum (n:ℝ) (by omega) i|)<(11/9:ℝ) := by
    simp_rw [←profile_matches n _ hcard (by omega)]
    exact hNear.trans (by norm_num)
  rcases ManhattanTransport.near_weighted_paw_or_triangle n (by omega) hcard A hm hs hd hCoarse with
    ⟨w,z,e,hw,he⟩|⟨w,z,e,hw,he⟩
  · let hW := padded_herm PawLargestFence.paw PawLargestFence.paw_herm w z
    have hN := (Fintype.card_congr e).trans hcard
    have hWNear : l1 n _ hW < (17/15:ℝ) := (l1_relabel n _ hm _ hW e he.symm).trans_lt hNear
    obtain ⟨hz,hEq⟩ := paw_large n hn w z hw hN hW hWNear
    have pack (v : Fin 4→Nat) (t : Nat) (hv : v=singletonWeights (n-1) n n)
        (ht : t=0) (g : Vertices v ⊕ Fin t ≃ V)
        (hg : (realAdj A).submatrix g g=withIsolates PawLargestFence.paw v t) :
        RelabelAs (realAdj A) (hub n) := by
      subst v; subst t
      exact ⟨g,hg.trans (congrArg (fun B => withIsolates B _ 0) seed_paw_exact.symm)⟩
    exact Or.inr (pack w z hEq hz e he)
  · let hW := padded_herm TriangleSpectralFence.triangleSeed TriangleSpectralFence.triangleSeedHermitian w z
    have hN := (Fintype.card_congr e).trans hcard
    have hWNear : l1 n _ hW < (17/15:ℝ) := (l1_relabel n _ hm _ hW e he.symm).trans_lt hNear
    obtain ⟨hz,hEq⟩ := triangle_large n hn w z hw hN hW hWNear
    have pack (v : Fin 3→Nat) (t : Nat) (hv : v=TriangleSpectralFence.triangleWeights n n n)
        (ht : t=0) (g : Vertices v ⊕ Fin t ≃ V)
        (hg : (realAdj A).submatrix g g=withIsolates TriangleSpectralFence.triangleSeed v t) :
        RelabelAs (realAdj A) (balanced n) := by
      subst v; subst t
      exact ⟨g,hg⟩
    exact Or.inl (pack w z hEq hz e he)

#print axioms classify_large
end ManhattanLarge
