import Std
namespace ManhattanLocal
set_option maxRecDepth 100000
set_option maxHeartbeats 4000000

/-- k clique anchors numbered 0 through k-1; the external vertices k,k+1
have adjacency masks m,n on the clique, and are adjacent iff e. -/
def adj (k m n : Nat) (e : Bool) (i j : Nat) : Bool :=
  let u := min i j
  let v := max i j
  (u != v) && (if v < k then true else if u < k then
    (if v == k then m else n).testBit u else e)
def subsets : Nat → List Nat → List (List Nat)
  | 0, _ => [[]]
  | _+1, [] => []
  | s+1, h::t => ((subsets s t).map (h::·)) ++ subsets (s+1) t
def degrees (k m n : Nat) (e : Bool) (s : List Nat) : List Nat :=
  s.map fun i => (s.filter (adj k m n e i)).length
def allowed (k m n : Nat) (e : Bool) : Bool :=
  let vs := List.range (k+2)
  (k != 2 || (subsets 3 vs).all fun s => (degrees k m n e s).count 2 != 3) &&
  ((subsets 4 vs).all fun s => 
    let ds := degrees k m n e s
    !(ds.count 1 == 4 || (ds.count 1 == 2 && ds.count 2 == 2) || ds.count 3 == 4))
def law (k m n : Nat) (e : Bool) : Bool :=
  if m == 2^k-1 || n == 2^k-1 then false else
  if m == 0 || n == 0 then !e else
  if k == 2 then e == (m != n) else
  let single (x : Nat) := [1,2,4].contains x
  if single m && single n then (m == n) && !e else
  if !single m && !single n then e == (m != n) else
  e == (m &&& n == 0)
theorem edge_law (m n : Fin 4) (e : Bool) : allowed 2 m n e = law 2 m n e :=
  (by decide : ∀ (i j : Fin 4) (z : Bool), allowed 2 i j z = law 2 i j z) m n e
theorem triangle_law (m n : Fin 8) (e : Bool) : allowed 3 m n e = law 3 m n e :=
  (by decide : ∀ (i j : Fin 8) (z : Bool), allowed 3 i j z = law 3 i j z) m n e
#print axioms edge_law
#print axioms triangle_law
end ManhattanLocal

namespace ManhattanLocal
/-- The graph with a common hub class (0), two equally treated triangle classes (1,2),
singleton-neighborhood class (3), and isolate class (4). -/
def pawColorAdj (x y : Fin 5) : Bool :=
  let a := min x.val y.val
  let b := max x.val y.val
  (a != b) && (if a == 0 then b < 4 else a == 1 && b == 2)

def triangleColor (hub : Fin 8) (x : Fin 8) : Fin 5 :=
  if x.val == 0 then 4 else
  if [1,2,4].contains x.val then 3 else
  let remaining := 7-x.val
  if remaining == hub.val then 0 else
  if (hub.val == 1 && remaining == 2) || (hub.val != 1 && remaining == 1) then 1 else 2
def triangleOK (hub x : Fin 8) : Bool :=
  x.val != 7 && (![1,2,4].contains x.val || x == hub)
theorem triangleColor_law (hub x y : Fin 8) (e : Bool)
    (hh : [1,2,4].contains hub.val = true)
    (hx : triangleOK hub x = true) (hy : triangleOK hub y = true)
    (hl : law 3 x y e = true) : e = pawColorAdj (triangleColor hub x) (triangleColor hub y) :=
  (by decide : ∀ (h u v : Fin 8) (z : Bool), [1,2,4].contains h.val = true →
      triangleOK h u = true → triangleOK h v = true → law 3 u v z = true →
      z = pawColorAdj (triangleColor h u) (triangleColor h v)) hub x y e hh hx hy hl

/-- Source-graph vertices labelled by their triangle-neighborhood masks reduce to
    Paw with isolate padding, or Triangle with missing part 3. -/
theorem triangle_global_color {V : Type u} (A : V → V → Bool) (mask : V → Fin 8)
    (ha : ∀ x y, law 3 (mask x) (mask y) (A x y) = true) :
    ∃ hub : Fin 8, [1,2,4].contains hub.val = true ∧
      ∀ x y, A x y = pawColorAdj (triangleColor hub (mask x)) (triangleColor hub (mask y)) := by
  classical
  have prop : ∀ (m : Fin 8) (e : Bool), (law 3 m m e = true → m.val ≠ 7) :=
    (by decide : ∀ (m : Fin 8) (e : Bool), law 3 m m e = true → m.val ≠ 7)
  have ident : ∀ (m n : Fin 8) (e : Bool), [1,2,4].contains m.val = true →
      [1,2,4].contains n.val = true → law 3 m n e = true → m = n := by decide
  by_cases h : ∃ v : V, [1,2,4].contains (mask v).val = true
  · obtain ⟨v,hv⟩ := h
    refine ⟨mask v,hv, ?_⟩
    have hx (x : V) : triangleOK (mask v) (mask x) = true := by
      simp only [triangleOK, Bool.and_eq_true, bne_iff_ne, Bool.or_eq_true,
        Bool.not_eq_true', beq_iff_eq]
      refine ⟨prop _ _ (ha x x),?_⟩
      cases hx : [1,2,4].contains (mask x).val
      · exact Or.inl rfl
      · exact Or.inr (ident _ _ _ hx hv (ha x v))
    intro x y
    exact triangleColor_law _ _ _ _ hv (hx x) (hx y) (ha x y)
  · refine ⟨1, rfl, ?_⟩
    have hx (x : V) : triangleOK 1 (mask x) = true := by
      simp only [triangleOK, Bool.and_eq_true, bne_iff_ne, Bool.or_eq_true,
        Bool.not_eq_true', beq_iff_eq]
      refine ⟨prop _ _ (ha x x),Or.inl ?_⟩
      cases hx : [1,2,4].contains (mask x).val
      · rfl
      · exact False.elim (h ⟨x,hx⟩)
    intro x y
    exact triangleColor_law _ _ _ _ rfl (hx x) (hx y) (ha x y)

theorem triangle_colors_nonempty (hub : Fin 8) (hh : [1,2,4].contains hub.val = true) :
    (triangleColor hub 6 = 0 ∨ triangleColor hub 5 = 0 ∨ triangleColor hub 3 = 0) ∧
    (triangleColor hub 6 = 1 ∨ triangleColor hub 5 = 1 ∨ triangleColor hub 3 = 1) ∧
    (triangleColor hub 6 = 2 ∨ triangleColor hub 5 = 2 ∨ triangleColor hub 3 = 2) :=
  (by decide : ∀ h : Fin 8, [1,2,4].contains h.val = true →
    (triangleColor h 6 = 0 ∨ triangleColor h 5 = 0 ∨ triangleColor h 3 = 0) ∧
    (triangleColor h 6 = 1 ∨ triangleColor h 5 = 1 ∨ triangleColor h 3 = 1) ∧
    (triangleColor h 6 = 2 ∨ triangleColor h 5 = 2 ∨ triangleColor h 3 = 2)) hub hh

#print axioms triangle_global_color
#print axioms triangle_colors_nonempty
end ManhattanLocal


namespace ManhattanLocal
/-- Every forbidden local label configuration has an explicit four-anchor witness.
Tags 1, 2, 3 denote the P4, 2K2, K4 matrices in their canonical order. -/
def witness3 : List Nat := [0, 1830, 0, 1101, 0, 1105, 0, 1102, 0, 1110, 0, 1101, 0, 1105, 2430, 2430, 0, 1201, 0, 1836, 1153, 1202, 0, 1107, 1178, 1201, 0, 1111, 1153, 0, 2430, 2430, 0, 1205, 1133, 1102, 0, 1835, 0, 1102, 1183, 1205, 1133, 0, 0, 1110, 2430, 2430, 0, 1202, 0, 1207, 0, 1202, 0, 2455, 1178, 0, 1183, 0, 1178, 0, 2430, 2430, 0, 1210, 1138, 1101, 1163, 1105, 1138, 0, 0, 1830, 0, 1101, 0, 1105, 2430, 2430, 0, 1201, 0, 1211, 1153, 0, 1163, 0, 0, 1201, 0, 2460, 1153, 0, 2430, 2430, 0, 1205, 1133, 0, 0, 1210, 1138, 0, 0, 1205, 1133, 0, 0, 2461, 2430, 2430, 2305, 2305, 2305, 2305, 2305, 2305, 2305, 2305, 2305, 2305, 2305, 2305, 2305, 2305, 2305, 2305]
def witnessCode3 (m n : Fin 8) (e : Bool) : Nat :=
  witness3[(m.val*8+n.val)*2+(if e then 1 else 0)]!
def witnessMap3 (m n : Fin 8) (e : Bool) (i : Fin 4) : Fin 5 :=
  ⟨witnessCode3 m n e / 5^i.val % 5, Nat.mod_lt _ (by decide)⟩
def forbiddenBool (tag : Nat) (i j : Fin 4) : Bool :=
  let u := min i.val j.val
  let v := max i.val j.val
  match tag with
  | 1 => v == u+1
  | 2 => (u == 0 && v == 1) || (u == 2 && v == 3)
  | 3 => u != v
  | _ => false

theorem witness_sound (m n : Fin 8) (e : Bool) (h : law 3 m n e = false) :
    let code := witnessCode3 m n e
    let f := witnessMap3 m n e
    1 ≤ code/625 ∧ code/625 ≤ 3 ∧ (∀ (i j : Fin 4), f i = f j → i = j) ∧
      ∀ (i j : Fin 4), adj 3 m n e (f i).val (f j).val = forbiddenBool (code/625) i j :=
  (by decide : ∀ (m n : Fin 8) (e : Bool), law 3 m n e = false →
    let code := witnessCode3 m n e
    let f := witnessMap3 m n e
    1 ≤ code/625 ∧ code/625 ≤ 3 ∧ (∀ (i j : Fin 4), f i = f j → i = j) ∧
      ∀ (i j : Fin 4), adj 3 m n e (f i).val (f j).val = forbiddenBool (code/625) i j) m n e h

#print axioms witness_sound
end ManhattanLocal
