import C20Weighted

open Matrix Finset SpectralConjecture20
open scoped BigOperators
namespace ManhattanSpectral

def path : Matrix (Fin 4) (Fin 4) ℝ := !![0,1,0,0;1,0,1,0;0,1,0,1;0,0,1,0]
def matching : Matrix (Fin 4) (Fin 4) ℝ := !![0,1,0,0;1,0,0,0;0,0,0,1;0,0,1,0]
def clique : Matrix (Fin 4) (Fin 4) ℝ := !![0,1,1,1;1,0,1,1;1,1,0,1;1,1,1,0]

theorem cut_lower {m k : Type*} [Fintype m] [Fintype k] [DecidableEq m] [DecidableEq k]
    (A : Matrix m m ℝ) (hA : A.IsHermitian) (E : Matrix m k ℝ)
    (s t : ℝ) (d : k → ℝ) (hd : ∀ i, 0 < d i)
    (hg : Eᵀ * (s • A - t • (1 : Matrix m m ℝ)) * E = diagonal d) :
    Fintype.card k ≤ Fintype.card {i // t < s*hA.eigenvalues i} := by
  let B := s • A - t • (1 : Matrix m m ℝ)
  let hB := shifted_isHermitian A hA s t
  have hD : (diagonal d).IsHermitian := by
    rw [Matrix.IsHermitian.ext_iff]
    intro i j
    by_cases h : i=j
    · subst j; simp
    · simp [h, Ne.symm h]
  have hC : (Eᵀ*B*E).IsHermitian := hg.symm ▸ hD
  have hi : Function.Injective E.mulVecLin := by
    intro u v huv
    apply sub_eq_zero.mp
    have hz : E *ᵥ (u-v) = 0 := by
      change E *ᵥ u = E *ᵥ v at huv
      rw [Matrix.mulVec_sub,huv,sub_self]
    have hb : diagonal d *ᵥ (u-v) = 0 := by
      rw [←hg]
      change (Eᵀ*B*E) *ᵥ (u-v) = 0
      rw [←mulVec_mulVec,hz,mulVec_zero]
    ext i
    have hs := congrFun hb i
    rw [mulVec_diagonal] at hs
    exact (mul_eq_zero.mp hs).resolve_left (hd i).ne'
  have hM := positive_index_compression_mono B hB E hC hi
  rw [positive_index_of_matrix_eq hg hC hD, diagonal_index_congr d hD] at hM
  have hS := shifted_positive_index A hA s t
  change Fintype.card {i // 0 < hB.eigenvalues i} = _ at hS
  rw [hS] at hM
  simpa only [hd, Fintype.card_subtype_true] using hM

theorem path_cut (h : path.IsHermitian) :
    2 ≤ Fintype.card {i // (11/18:ℝ) < h.eigenvalues i} := by
  let E : Matrix (Fin 4) (Fin 2) ℝ := !![1,8;1,5;1,-5;1,-8]
  let d : Fin 2 → ℝ := ![32/9,11/9]
  have hd (i : Fin 2) : 0 < d i := by fin_cases i <;> norm_num [d]
  have hG : Eᵀ * ((1:ℝ) • path - (11/18:ℝ) • (1:Matrix (Fin 4) (Fin 4) ℝ)) * E = diagonal d := by
    ext i j
    fin_cases i <;> fin_cases j <;>
      norm_num [path, E, d, Matrix.mul_apply, Fin.sum_univ_four, Matrix.one_apply, diagonal_apply]
  simpa using cut_lower path h E 1 (11/18) d hd hG

theorem matching_cut (h : matching.IsHermitian) :
    2 ≤ Fintype.card {i // (11/18:ℝ) < h.eigenvalues i} := by
  let E : Matrix (Fin 4) (Fin 2) ℝ := !![1,0;1,0;0,1;0,1]
  let d : Fin 2 → ℝ := ![7/9,7/9]
  have hd (i : Fin 2) : 0 < d i := by fin_cases i <;> norm_num [d]
  have hG : Eᵀ * ((1:ℝ) • matching - (11/18:ℝ) • (1:Matrix (Fin 4) (Fin 4) ℝ)) * E = diagonal d := by
    ext i j
    fin_cases i <;> fin_cases j <;>
      norm_num [matching, E, d, Matrix.mul_apply, Fin.sum_univ_four, Matrix.one_apply, diagonal_apply]
  simpa using cut_lower matching h E 1 (11/18) d hd hG

theorem clique_cut (h : clique.IsHermitian) :
    3 ≤ Fintype.card {i // (11/18:ℝ) < -(h.eigenvalues i)} := by
  let E : Matrix (Fin 4) (Fin 3) ℝ := !![1,1,1;-1,1,1;0,-2,1;0,0,-3]
  let d : Fin 3 → ℝ := ![7/9,7/3,14/3]
  have hd (i : Fin 3) : 0 < d i := by fin_cases i <;> norm_num [d]
  have hG : Eᵀ * ((-1:ℝ) • clique - (11/18:ℝ) • (1:Matrix (Fin 4) (Fin 4) ℝ)) * E = diagonal d := by
    ext i j
    fin_cases i <;> fin_cases j <;>
      norm_num [clique, E, d, Matrix.mul_apply, Fin.sum_univ_four, Matrix.one_apply, diagonal_apply]
  simpa using cut_lower clique h E (-1) (11/18) d hd hG

theorem twice_abs_of_zero_sum {m : Type*} [Fintype m] (f : m → ℝ) (hf : ∑ i, f i = 0) (i : m) :
    2*|f i| ≤ ∑ j, |f j| := by
  classical
  have ht := Finset.sum_erase_add (Finset.univ : Finset m) f (Finset.mem_univ i)
  have hh : ∑ j ∈ (Finset.univ : Finset m).erase i, f j = -f i := by linarith
  have hl := Finset.abs_sum_le_sum_abs (f := f) ((Finset.univ : Finset m).erase i)
  rw [hh,abs_neg] at hl
  have hs := Finset.sum_erase_add (Finset.univ : Finset m) (fun j => |f j|) (Finset.mem_univ i)
  linarith

theorem spectrum_sum_zero {m : Type*} [Fintype m] [DecidableEq m]
    (A : Matrix m m ℝ) (hA : A.IsHermitian) (hdiag : ∀ i, A i i = 0) :
    ∑ i, hA.eigenvalues i = 0 := by
  have h' : A.trace = ∑ i, hA.eigenvalues i := by simpa using hA.trace_eq_sum_eigenvalues
  rw [←h']
  simp [Matrix.trace, Matrix.diag, hdiag]

theorem cut_congr {u : Type*} [Fintype u] [DecidableEq u] {X Y : Matrix u u ℝ}
    (hX : X.IsHermitian) (hY : Y.IsHermitian) (h : X=Y) (p : ℝ → Prop) [DecidablePred p] :
    Fintype.card {i // p (hX.eigenvalues i)} = Fintype.card {i // p (hY.eigenvalues i)} := by
  subst Y
  rfl

/-- Target profile is unordered but indexed in the same order as eigenvalues:
one strictly positive entry; two strictly negative entries; and zero total sum. -/
theorem forbidden_principal_of_close {m : Type*} [Fintype m] [DecidableEq m]
    (A : Matrix m m ℝ) (hA : A.IsHermitian) (hdiag : ∀ i, A i i = 0)
    (y : m → ℝ) (hY : ∑ i, y i = 0)
    (hPos : Fintype.card {i // 0 < y i} ≤ 1)
    (hNeg : Fintype.card {i // y i < 0} ≤ 2)
    (hClose : (∑ i, |hA.eigenvalues i-y i|) < (11/9:ℝ))
    (e : Fin 4 ↪ m) :
    A.submatrix e e ≠ path ∧ A.submatrix e e ≠ matching ∧ A.submatrix e e ≠ clique := by
  classical
  have hzero : ∑ i, (hA.eigenvalues i-y i) = 0 := by
    rw [Finset.sum_sub_distrib, spectrum_sum_zero A hA hdiag, hY, sub_zero]
  have hd (i : m) : |hA.eigenvalues i-y i| < (11/18:ℝ) := by
    have h := (twice_abs_of_zero_sum (fun i => hA.eigenvalues i-y i) hzero i).trans_lt hClose
    linarith
  have hUpper : Fintype.card {i // (11/18:ℝ) < hA.eigenvalues i} ≤ 1 := by
    apply le_trans _ hPos
    apply Fintype.card_subtype_mono
    intro i hi
    change (11/18:ℝ) < hA.eigenvalues i at hi
    have hu := le_abs_self (hA.eigenvalues i-y i)
    linarith [hd i]
  have hLower : Fintype.card {i // (11/18:ℝ) < -hA.eigenvalues i} ≤ 2 := by
    apply le_trans _ hNeg
    apply Fintype.card_subtype_mono
    intro i hi
    change (11/18:ℝ) < -hA.eigenvalues i at hi
    have hL := neg_le_abs (hA.eigenvalues i-y i)
    linarith [hd i]
  have hI := (shifted_principal_interlacing A hA e 1 (11/18)).1
  have hJ := (shifted_principal_interlacing A hA e (-1) (11/18)).1
  simp only [one_mul] at hI
  simp only [neg_one_mul] at hJ
  refine ⟨?_, ?_, ?_⟩
  · intro hp
    let hP : path.IsHermitian := hp ▸ hA.submatrix e
    have hs := path_cut hP
    rw [←cut_congr (hA.submatrix e) hP hp (fun t => (11/18:ℝ)<t)] at hs
    omega
  · intro hp
    let hP : matching.IsHermitian := hp ▸ hA.submatrix e
    have hs := matching_cut hP
    rw [←cut_congr (hA.submatrix e) hP hp (fun t => (11/18:ℝ)<t)] at hs
    omega
  · intro hp
    let hP : clique.IsHermitian := hp ▸ hA.submatrix e
    have hs := clique_cut hP
    rw [←cut_congr (hA.submatrix e) hP hp (fun t => (11/18:ℝ)< -t)] at hs
    omega

/-- Ordered-spectrum form, ready for the balanced tripartite profile. -/
theorem forbidden_ordered_principal_of_close {m : Type*} [Fintype m] [DecidableEq m]
    (A : Matrix m m ℝ) (hA : A.IsHermitian) (hdiag : ∀ i, A i i = 0)
    (y : Fin (Fintype.card m) → ℝ) (hY : ∑ i, y i = 0)
    (hPos : Fintype.card {i // 0 < y i} ≤ 1)
    (hNeg : Fintype.card {i // y i < 0} ≤ 2)
    (hClose : (∑ i, |hA.eigenvalues₀ i-y i|) < (11/9:ℝ))
    (e : Fin 4 ↪ m) :
    A.submatrix e e ≠ path ∧ A.submatrix e e ≠ matching ∧ A.submatrix e e ≠ clique := by
  classical
  let q : Fin (Fintype.card m) ≃ m := Fintype.equivOfCardEq (Fintype.card_fin _)
  let y' : m → ℝ := fun i => y (q.symm i)
  have eqSum : ∑ i, y' i = ∑ i, y i := Equiv.sum_comp q.symm y
  have cardP : Fintype.card {i // 0 < y' i} = Fintype.card {i // 0 < y i} :=
    Fintype.card_congr (Equiv.subtypeEquiv q.symm (fun _ => Iff.rfl))
  have cardN : Fintype.card {i // y' i < 0} = Fintype.card {i // y i < 0} :=
    Fintype.card_congr (Equiv.subtypeEquiv q.symm (fun _ => Iff.rfl))
  have eqClose : ∑ i, |hA.eigenvalues i-y' i| = ∑ i, |hA.eigenvalues₀ i-y i| :=
    Equiv.sum_comp q.symm (fun i => |hA.eigenvalues₀ i-y i|)
  exact forbidden_principal_of_close A hA hdiag y' (eqSum.trans hY)
    (cardP ▸ hPos) (cardN ▸ hNeg) (eqClose ▸ hClose) e

#print axioms forbidden_ordered_principal_of_close
#print axioms forbidden_principal_of_close
end ManhattanSpectral
