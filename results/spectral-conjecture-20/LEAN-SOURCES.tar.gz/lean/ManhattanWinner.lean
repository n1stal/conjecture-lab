import ManhattanLarge

namespace ManhattanLarge
open Matrix Finset SpectralConjecture20 PawUnbounded
open Conjecture20Squared
open scoped BigOperators

theorem hub_l1_bounds (n : Nat) (hn : 5≤n) :
    0 < l1 n _ (hub_herm n) ∧ l1 n _ (hub_herm n) < (17/15:ℝ) := by
  have hsz := hub_card n (by omega)
  have hN : 4≤Fintype.card (Vertices (singletonWeights (n-1) n n) ⊕ Fin 0) := by omega
  obtain ⟨hy0,hy1,hy2,hy3,_,_,_,_,_,_,hyRest⟩ := profile n _ (by omega) hsz
  refine ⟨?_,(actual_hub_benchmark_scores n 0 (by omega) (hub_herm n)
    hN (target n _) hy0 hy1 hy2 hy3 hyRest).2.1 hn⟩
  have hQuart := singleton_ordered_quartet_score_eq n (n-1) n n 0 (by omega) (by omega) (by omega)
    (hub_herm n) hN (target n _) hy0 hy1 hy2 hy3 hyRest abs abs_zero
  change l1 n _ (hub_herm n) = _ at hQuart
  rw [hQuart]
  have hpos := singleton_second_pos (n-1) n n (by omega) (by omega) (by omega)
  linarith only [abs_nonneg (singletonQEigen (n-1) n n 0 - 2*(n:ℝ)),
    (abs_pos.mpr hpos.ne'), abs_nonneg (singletonQEigen (n-1) n n 2+(n:ℝ)),
    abs_nonneg (singletonQEigen (n-1) n n 3+(n:ℝ))]

/-- For every n≥5, the unique nearest non-isomorphic graph in true Manhattan
distance is the source's H_n, up to relabeling of all vertices. -/
theorem manhattan_unique_minimizer_large (n : Nat) (hn : 5≤n)
    (A : Fin (3*n)→Fin (3*n)→Bool) (hS : ∀ i j,A i j=A j i) (hD : ∀ i,A i i=false) :
    ((¬ RelabelAs (realAdj A) (balanced n)) ∧
      (∀ (B : Fin (3*n) → Fin (3*n) → Bool) (hT : ∀ i j, B i j=B j i),
        (∀ i, B i i=false) → (¬ RelabelAs (realAdj B) (balanced n)) →
        l1 n _ (realAdjHerm A hS) ≤ l1 n _ (realAdjHerm B hT)))
    ↔ RelabelAs (realAdj A) (hub n) := by
  have hK : (balanced n).IsHermitian :=
    padded_herm TriangleSpectralFence.triangleSeed TriangleSpectralFence.triangleSeedHermitian
      (TriangleSpectralFence.triangleWeights n n n) 0
  have hKzero : l1 n _ hK=0 := by unfold l1; simp [balanced_matches_target n (by omega) hK]
  have hHub := hub_l1_bounds n hn
  have zeroOf {B : Fin (3*n) → Fin (3*n) → Bool} (hB : ∀ i j, B i j=B j i)
      (rel : RelabelAs (realAdj B) (balanced n)) : l1 n _ (realAdjHerm B hB)=0 := by
    obtain ⟨e,he⟩ := rel
    exact (l1_relabel n _ (realAdjHerm B hB) _ hK e he.symm).symm.trans hKzero
  have hubOf {B : Fin (3*n) → Fin (3*n) → Bool} (hB : ∀ i j, B i j=B j i)
      (rel : RelabelAs (realAdj B) (hub n)) : l1 n _ (realAdjHerm B hB)=l1 n _ (hub_herm n) := by
    obtain ⟨e,he⟩ := rel
    exact (l1_relabel n _ (realAdjHerm B hB) _ (hub_herm n) e he.symm).symm
  have excl {B : Fin (3*n) → Fin (3*n) → Bool} (hB : ∀ i j, B i j=B j i)
      (hr : RelabelAs (realAdj B) (hub n)) : ¬ RelabelAs (realAdj B) (balanced n) := by
    intro hb
    exact hHub.1.ne' ((hubOf hB hr).symm.trans (zeroOf hB hb))
  constructor
  · rintro ⟨hNot,hMin⟩
    obtain ⟨B,hBS,hBD,hr⟩ := hub_has_bool_representative n (by omega)
    have hc := (hMin B hBS hBD (excl hBS hr)).trans_lt ((hubOf hBS hr).trans_lt hHub.2)
    exact (classify_large n hn (Fintype.card_fin _) A hS hD hc).resolve_left hNot
  · intro hr
    refine ⟨excl hS hr,?_⟩
    intro B hT hDiag hNot
    by_contra! hc
    have hB := (classify_large n hn (Fintype.card_fin _) B hT hDiag
      (hc.trans ((hubOf hS hr).trans_lt hHub.2))).resolve_left hNot
    exact hc.ne ((hubOf hT hB).trans (hubOf hS hr).symm)

#print axioms manhattan_unique_minimizer_large
end ManhattanLarge
