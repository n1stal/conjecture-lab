import ManhattanTarget
import ManhattanMass

namespace ManhattanSmall
open Matrix SpectralConjecture20 Finset
open ManhattanTarget PawLargestFence
open scoped BigOperators

theorem residual_reject (x : Fin 12 → ℝ) (hxAnti : Antitone x) (hxSum : ∑ i, x i=0)
    (hf : ∀ t, t^8 * poly 44 96 48 t = ∏ i, (t-x i)) :
    (2:ℝ) < ∑ i, |x i-balancedSpectrum 4 (by decide) i| := by
  let i₀ : Fin 12 := head (by decide)
  let i₁ : Fin 12 := last (by decide)
  let y := balancedSpectrum (N:=12) 4 (by decide)
  have ht : x i₀ < 15/2 := by
    by_contra! h
    have hp : 0 < poly 44 96 48 (x i₀) := by
      rcases h.eq_or_lt with hEq|hLt
      · rw [←hEq]
        norm_num [poly]
      · exact eval_pos_of_shift_coeff_nonneg 44 96 48 (15/2) (x i₀) hLt (by norm_num)
          (by norm_num [poly]) (by norm_num) (by norm_num)
    have hz : ∏ i, (x i₀ - x i) = 0 :=
      Finset.prod_eq_zero (Finset.mem_univ i₀) (sub_self _)
    rw [←hf] at hz
    exact (mul_pos (pow_pos (by linarith) _) hp).ne' hz
  have hb : x i₁ < -9/2 := by
    by_contra! h
    have hEach (i : Fin 12) : 0 ≤ x i-(-9/2:ℝ) := by
      apply sub_nonneg.mpr
      exact h.trans (hxAnti (by change i.val ≤ i₁.val; simp [i₁,last]; omega))
    have hPr : 0 ≤ ∏ i, (x i-(-9/2:ℝ)) :=
      Finset.prod_nonneg (fun i _ => hEach i)
    have hFlip : (∏ i, (x i-(-9/2:ℝ))) = ∏ i, ((-9/2:ℝ)-x i) := by
      calc
        _ = ∏ i, (-1:ℝ)*((-9/2:ℝ)-x i) := by
          apply Finset.prod_congr rfl
          intro i _
          ring
        _ = _ := by
          rw [Finset.prod_mul_distrib]
          norm_num
    rw [hFlip,←hf] at hPr
    norm_num [poly] at hPr
  have hy : ∑ i, y i=0 := by
    dsimp only [y]
    rw [sum_profile _ _ (fun x => x) rfl]
    norm_num
  have hTr : ∑ i,(x i-y i)=0 := by rw [Finset.sum_sub_distrib,hxSum,hy,sub_zero]
  have dSum := SpectralMass.twice_selected_deficit_le_abs_sum {i₀,i₁}
    (fun i => x i-y i) hTr
  have hi : i₀≠i₁ := head_ne_last _
  have hyTop : y i₀=8 := by norm_num [y,i₀,balancedSpectrum]
  have hyLast : y i₁= -4 := by norm_num [y,i₁,balancedSpectrum,(head_ne_last (by decide : 3≤12)).symm]
  rw [Finset.sum_insert (by simpa using hi), Finset.sum_singleton] at dSum
  linarith

#print axioms residual_reject
end ManhattanSmall
