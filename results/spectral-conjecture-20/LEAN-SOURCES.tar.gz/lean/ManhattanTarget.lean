import ManhattanClose

namespace ManhattanTarget
open Matrix Finset ManhattanGraph ManhattanLocal
open scoped BigOperators

variable {N : Nat}

def head (h : 3 ≤ N) : Fin N := ⟨0,by omega⟩
def penult (h : 3 ≤ N) : Fin N := (⟨1,by omega⟩ : Fin N).rev
def last (h : 3 ≤ N) : Fin N := (⟨0,by omega⟩ : Fin N).rev

theorem head_ne_penult (h : 3≤N) : head h ≠ penult h := by
  intro he
  have hv := congrArg Fin.val he
  simp only [head,penult,Fin.val_rev] at hv
  omega
theorem head_ne_last (h : 3≤N) : head h ≠ last h := by
  intro he
  have hv := congrArg Fin.val he
  simp only [head,last,Fin.val_rev] at hv
  omega
theorem penult_ne_last (h : 3≤N) : penult h ≠ last h := by
  intro he
  have hv := congrArg Fin.val he
  simp only [penult,last,Fin.val_rev] at hv
  omega

noncomputable def balancedSpectrum (n : ℝ) (h : 3≤N) (i : Fin N) : ℝ :=
  if i=head h then 2*n else if i=penult h ∨ i=last h then -n else 0

theorem sum_profile (n : ℝ) (h : 3≤N) (f : ℝ → ℝ) (hz : f 0=0) :
    ∑ i, f (balancedSpectrum n h i) = f (2*n)+f (-n)+f (-n) := by
  have ht (i : Fin N) : f (balancedSpectrum n h i) =
      (if i=head h then f (2*n) else 0)+(if i=penult h then f (-n) else 0)+
        (if i=last h then f (-n) else 0) := by
    by_cases h0 : i=head h
    · subst i
      simp [balancedSpectrum,head_ne_penult,head_ne_last]
    by_cases h1 : i=penult h
    · subst i
      simp [balancedSpectrum,h0,penult_ne_last]
    by_cases h2 : i=last h
    · subst i
      simp [balancedSpectrum,h0,h1]
    · simp [balancedSpectrum,h0,h1,h2,hz]
  simp only [ht,Finset.sum_add_distrib,Finset.sum_ite_eq',Finset.mem_univ,ite_true]

theorem positive_profile (n : ℝ) (hn : 3≤n) (h : 3≤N) :
    Fintype.card {i // 0 < balancedSpectrum n h i} ≤ 1 := by
  let f : {i // 0 < balancedSpectrum n h i} → Fin 1 := fun _ => 0
  have hi (i : {i // 0 < balancedSpectrum n h i}) : i.val = head h := by
    have hp := i.property
    unfold balancedSpectrum at hp
    split at hp
    · assumption
    · split at hp <;> linarith
  have hf : Function.Injective f := by
    intro a b _
    exact Subtype.ext ((hi a).trans (hi b).symm)
  simpa using Fintype.card_le_of_injective f hf

theorem negative_profile (n : ℝ) (hn : 3≤n) (h : 3≤N) :
    Fintype.card {i // balancedSpectrum n h i < 0} ≤ 2 := by
  let f : {i // balancedSpectrum n h i < 0} → Fin 2 := fun i => if i.val=penult h then 0 else 1
  have hi (i : {i // balancedSpectrum n h i < 0}) : i.val = penult h ∨ i.val = last h := by
    have hp := i.property
    unfold balancedSpectrum at hp
    split at hp
    · linarith
    · split at hp
      · assumption
      · linarith
  have hf : Function.Injective f := by
    intro a b hab
    apply Subtype.ext
    rcases hi a with ha|ha <;> rcases hi b with hb|hb
    · exact ha.trans hb.symm
    · simp [f,ha,hb,(penult_ne_last h).symm] at hab
    · simp [f,ha,hb,(penult_ne_last h).symm] at hab
    · exact ha.trans hb.symm
  simpa using Fintype.card_le_of_injective f hf

theorem abs_profile (n : ℝ) (hn : 3≤n) (h : 3≤N) (i : Fin N) :
    |balancedSpectrum n h i| ≤ 2*n := by
  unfold balancedSpectrum
  split
  · rw [abs_of_nonneg (by linarith)]
  · split
    · rw [abs_neg,abs_of_nonneg (by linarith)]
      linarith
    · rw [abs_zero]
      linarith

/-- Manhattan distances use the decreasing adjacency spectrum of K_{n,n,n}:
one 2n, two terminal -n entries and zeros elsewhere. -/
theorem spectral_paw_reduction {V : Type*} [Fintype V] [DecidableEq V]
    (n : Nat) (hn : 3≤n) (hcard : Fintype.card V = 3*n)
    (A : V → V → Bool) (hA : (matrixOf A).IsHermitian)
    (hsymm : ∀ x y, A x y=A y x) (hdiag : ∀ i, A i i=false)
    (hClose : (∑ i, |hA.eigenvalues₀ i - balancedSpectrum (n:ℝ) (by omega) i|) < (11/9:ℝ)) :
    ∃ color : V → Fin 5,
      (∀ x y, A x y = pawColorAdj (color x) (color y)) ∧
      (∃ x, color x=0) ∧ (∃ x, color x=1) ∧ (∃ x, color x=2) := by
  let h : 3≤Fintype.card V := by omega
  have hnR : (3:ℝ) ≤ n := by exact_mod_cast hn
  have hTrace : ∑ i, balancedSpectrum (n:ℝ) h i = 0 := by
    rw [sum_profile (n:ℝ) h (fun z => z) rfl]
    ring
  have hCube : ∑ i, (balancedSpectrum (n:ℝ) h i)^3 = 6*(n:ℝ)^3 := by
    rw [sum_profile (n:ℝ) h (fun z => z^3) (by norm_num)]
    ring
  exact ManhattanClose.close_graph_as_paw A hA hsymm hdiag (n:ℝ) hnR _ hTrace
    (positive_profile _ hnR h) (negative_profile _ hnR h) (abs_profile _ hnR h) hCube hClose

#print axioms spectral_paw_reduction
end ManhattanTarget
