import ManhattanSmall
import ManhattanResidual
import C20Minimizer

namespace ManhattanSmallFinal
open Matrix Finset SpectralConjecture20 PawUnbounded
open Conjecture20Squared ManhattanTarget ManhattanSmall
open scoped BigOperators

noncomputable def l1 {V : Type*} [Fintype V] [DecidableEq V] (n : Nat)
    (A : Matrix V V ℝ) (hA : A.IsHermitian) : ℝ :=
  ∑ i, |hA.eigenvalues₀ i - target n (Fintype.card V) i|

theorem profile_matches (n N : Nat) (hN : N=3*n) (h : 3≤N) (i : Fin N) :
    target n N i = balancedSpectrum (n:ℝ) h i := by
  have a : i.val=0 ↔ i=head h := by simp [head,Fin.ext_iff]
  have b₁ : (penult h).val=N-2 := by simp [penult,Fin.val_rev]
  have b₂ : (last h).val=N-1 := by simp [last,Fin.val_rev]
  have b : 3*n ≤ i.val+2 ↔ i=penult h ∨ i=last h := by
    constructor
    · intro hi
      have hi' := i.isLt
      by_cases he : i.val=N-2
      · exact Or.inl (Fin.ext (he.trans b₁.symm))
      · exact Or.inr (Fin.ext (by omega))
    · rintro (rfl|rfl) <;> omega
  simp only [target,balancedSpectrum,a,b]

theorem l1_relabel {V W : Type*} [Fintype V] [Fintype W] [DecidableEq V] [DecidableEq W]
    (n : Nat) (A : Matrix V V ℝ) (hA : A.IsHermitian) (B : Matrix W W ℝ) (hB : B.IsHermitian)
    (e : W ≃ V) (he : B=A.submatrix e e) : l1 n B hB = l1 n A hA := by
  let hcard := Fintype.card_congr e
  unfold l1
  calc
    _ = ∑ j, |hA.eigenvalues₀ (Fin.cast hcard j) - target n (Fintype.card V) (Fin.cast hcard j)| := by
      apply Finset.sum_congr rfl
      intro j _
      simpa only [target,Fin.val_cast] using congrArg
        (fun t => |t - target n (Fintype.card W) j|)
        (UnitPruning.ordered_eigenvalues_submatrix_equiv A hA B hB e he j)
    _ = _ := Equiv.sum_comp (finCongr hcard) (fun i => |hA.eigenvalues₀ i-target n (Fintype.card V) i|)

private theorem rejectResidualCard {N : Nat} (hN : N=12)
    (x : Fin N → ℝ) (hxAnti : Antitone x) (hxSum : ∑ i, x i=0)
    (hf : ∀ t, t^(N-4)* PawLargestFence.poly 44 96 48 t = ∏ i, (t-x i)) :
    (2:ℝ) < ∑ i, |x i-balancedSpectrum 4 (by omega) i| := by
  subst N
  exact residual_reject x hxAnti hxSum hf

private theorem pawClose (n a b c d z : Nat) (hn : n=3 ∨ n=4)
    (ha : 0<a) (hb : 0<b) (hc : 0<c) (hd : 0<d)
    (hN : Fintype.card (Vertices (PawLargestFence.pawWeights a b c d) ⊕ Fin z)=3*n)
    (hA : (withIsolates PawLargestFence.paw (PawLargestFence.pawWeights a b c d) z).IsHermitian)
    (hClose : l1 n _ hA < (11/9:ℝ)) :
    z=0 ∧ a+1=n ∧ b=n ∧ c=n ∧ d=1 := by
  have hsz : a+b+c+d+z=3*n := by
    rw [←hN,card_blowup_vertices]
    simp [PawLargestFence.pawWeights,Fin.sum_univ_four]
  have hn3 : 3≤n := by omega
  have h3 : 3≤Fintype.card (Vertices (PawLargestFence.pawWeights a b c d) ⊕ Fin z) := by omega
  have h4 : 4≤Fintype.card (Vertices (PawLargestFence.pawWeights a b c d) ⊕ Fin z) := by omega
  have hPawDiag (i : Fin 4) : PawLargestFence.paw i i=0 := by fin_cases i <;> rfl
  have hTr := ordered_eigenvalue_sum_zero_of_diag _ hA
    (withIsolates_diagonal_zero _ hPawDiag _ _)
  have hScore : (∑ i, |hA.eigenvalues₀ i-balancedSpectrum (n:ℝ) h3 i|)<(11/9:ℝ) := by
    simp_rw [←profile_matches n _ hN h3]
    exact hClose
  have hfp := paw_product a b c d z ha hb hc hd hA
  have screen := necessary_grid n a b c d hn3 h4 hA.eigenvalues₀ hTr
    (hScore.trans (by norm_num)) hfp
  rcases survivors n a b c d hn ha hb hc (by omega) screen with hBal|hHub|hOther
  · exact False.elim (by omega)
  · exact ⟨by omega,hHub⟩
  · obtain ⟨rfl,rfl,rfl,hbc⟩ := hOther
    have hCard12 : Fintype.card (Vertices (PawLargestFence.pawWeights 4 b c 1) ⊕ Fin z)=12 := by omega
    have hg (t : ℝ) : shaped 4 b c 1 t = PawLargestFence.poly 44 96 48 t := by
      rcases hbc with ⟨rfl,rfl⟩|⟨rfl,rfl⟩ <;> norm_num [shaped,PawLargestFence.poly]
    have hf' (t : ℝ) :
        t^(Fintype.card (Vertices (PawLargestFence.pawWeights 4 b c 1) ⊕ Fin z)-4)*
          PawLargestFence.poly 44 96 48 t = ∏ i, (t-hA.eigenvalues₀ i) := by
      rw [← hg]
      norm_num only [Nat.cast_ofNat] at hfp
      exact hfp t
    have hbad := rejectResidualCard hCard12 hA.eigenvalues₀ hA.eigenvalues₀_antitone hTr hf'
    exact False.elim (by linarith)

private theorem triClose (n a b c z : Nat) (hn : n=3 ∨ n=4)
    (ha : 0<a) (hb : 0<b) (hc : 0<c)
    (hN : Fintype.card (Vertices (TriangleSpectralFence.triangleWeights a b c) ⊕ Fin z)=3*n)
    (hA : (withIsolates TriangleSpectralFence.triangleSeed (TriangleSpectralFence.triangleWeights a b c) z).IsHermitian)
    (hClose : l1 n _ hA < (11/9:ℝ)) :
    z=0 ∧ a=n ∧ b=n ∧ c=n := by
  have hsz : a+b+c+z=3*n := by
    rw [←hN,card_blowup_vertices]
    simp [TriangleSpectralFence.triangleWeights,Fin.sum_univ_three]
  have hn3 : 3≤n := by omega
  have h3 : 3≤Fintype.card (Vertices (TriangleSpectralFence.triangleWeights a b c) ⊕ Fin z) := by omega
  have h4 : 4≤Fintype.card (Vertices (TriangleSpectralFence.triangleWeights a b c) ⊕ Fin z) := by omega
  have hTriDiag (i : Fin 3) : TriangleSpectralFence.triangleSeed i i=0 := by fin_cases i <;> rfl
  have hTr := ordered_eigenvalue_sum_zero_of_diag _ hA
    (withIsolates_diagonal_zero _ hTriDiag _ _)
  have hScore : (∑ i, |hA.eigenvalues₀ i-balancedSpectrum (n:ℝ) h3 i|)<(11/9:ℝ) := by
    simp_rw [←profile_matches n _ hN h3]
    exact hClose
  have screen := necessary_grid n a b c 0 hn3 h4 hA.eigenvalues₀ hTr
    (hScore.trans (by norm_num)) (by simpa only [Nat.cast_zero] using triangle_product a b c z ha hb hc hA h4)
  rcases survivors n a b c 0 hn ha hb hc (by omega) screen with hBal|hHub|hOther
  · exact ⟨by omega,hBal.1,hBal.2.1,hBal.2.2.1⟩
  · exact False.elim (by omega)
  · exact False.elim (by omega)

theorem classify_small (n : Nat) (hn : n=3 ∨ n=4) {V : Type*} [Fintype V] [DecidableEq V]
    (hcard : Fintype.card V=3*n) (A : V→V→Bool)
    (hs : ∀ i j, A i j=A j i) (hd : ∀ i, A i i=false)
    (hNear : l1 n _ (realAdjHerm A hs)<(11/9:ℝ)) :
    RelabelAs (realAdj A) (balanced n) ∨ RelabelAs (realAdj A) (hub n) := by
  have hm : (ManhattanGraph.matrixOf A).IsHermitian := realAdjHerm A hs
  have hCoarse : (∑ i, |hm.eigenvalues₀ i-balancedSpectrum (n:ℝ) (by omega) i|)<(11/9:ℝ) := by
    simp_rw [←profile_matches n _ hcard (by omega)]
    exact hNear
  rcases ManhattanTransport.near_weighted_paw_or_triangle n (by omega) hcard A hm hs hd hCoarse with
    ⟨w,z,e,hw,he⟩|⟨w,z,e,hw,he⟩
  · let a := w 0
    let b := w 1
    let c := w 2
    let d := w 3
    have hW : w=PawLargestFence.pawWeights a b c d := by funext i; fin_cases i <;> rfl
    have pack (v : Fin 4→Nat) (hv : v=PawLargestFence.pawWeights a b c d) (e : Vertices v ⊕ Fin z ≃ V)
        (he : (realAdj A).submatrix e e=withIsolates PawLargestFence.paw v z) :
        RelabelAs (realAdj A) (hub n) := by
      subst v
      let hW := padded_herm PawLargestFence.paw PawLargestFence.paw_herm (PawLargestFence.pawWeights a b c d) z
      have hN := (Fintype.card_congr e).trans hcard
      have hWNear : l1 n _ hW < (11/9:ℝ) := (l1_relabel n _ hm _ hW e he.symm).trans_lt hNear
      obtain ⟨hz,ha,hb,hc,hd'⟩ := pawClose n a b c d z hn (hw 0) (hw 1) (hw 2) (hw 3) hN hW hWNear
      have hEq : PawLargestFence.pawWeights a b c d = singletonWeights (n-1) n n := by
        funext i
        fin_cases i
        · change a=n-1; omega
        · exact hb
        · exact hc
        · exact hd'
      have output (v : Fin 4 → Nat) (t : Nat)
          (hv : v=singletonWeights (n-1) n n) (ht : t=0)
          (g : Vertices v ⊕ Fin t ≃ V)
          (hg : (realAdj A).submatrix g g=withIsolates PawLargestFence.paw v t) :
          RelabelAs (realAdj A) (hub n) := by
        subst v; subst t
        exact ⟨g,hg.trans (congrArg (fun B => withIsolates B _ 0) seed_paw_exact.symm)⟩
      exact output _ z hEq hz e he
    exact Or.inr (pack w hW e he)
  · let a := w 0
    let b := w 1
    let c := w 2
    have hW : w=TriangleSpectralFence.triangleWeights a b c := by funext i; fin_cases i <;> rfl
    have pack (v : Fin 3→Nat) (hv : v=TriangleSpectralFence.triangleWeights a b c)
        (e : Vertices v ⊕ Fin z ≃ V)
        (he : (realAdj A).submatrix e e=withIsolates TriangleSpectralFence.triangleSeed v z) :
        RelabelAs (realAdj A) (balanced n) := by
      subst v
      let hW := padded_herm TriangleSpectralFence.triangleSeed TriangleSpectralFence.triangleSeedHermitian
        (TriangleSpectralFence.triangleWeights a b c) z
      have hN := (Fintype.card_congr e).trans hcard
      have hWNear : l1 n _ hW < (11/9:ℝ) := (l1_relabel n _ hm _ hW e he.symm).trans_lt hNear
      obtain ⟨hz,ha,hb,hc⟩ := triClose n a b c z hn (hw 0) (hw 1) (hw 2) hN hW hWNear
      have hEq : TriangleSpectralFence.triangleWeights a b c = TriangleSpectralFence.triangleWeights n n n := by
        rw [ha,hb,hc]
      have output (v : Fin 3 → Nat) (t : Nat)
          (hv : v=TriangleSpectralFence.triangleWeights n n n) (ht : t=0)
          (g : Vertices v ⊕ Fin t ≃ V)
          (hg : (realAdj A).submatrix g g=withIsolates TriangleSpectralFence.triangleSeed v t) :
          RelabelAs (realAdj A) (balanced n) := by
        subst v; subst t
        exact ⟨g,hg⟩
      exact output _ z hEq hz e he
    exact Or.inl (pack w hW e he)

#print axioms classify_small


theorem hub_l1_bounds_small (n : Nat) (hn : n=3 ∨ n=4) :
    0 < l1 n _ (hub_herm n) ∧ l1 n _ (hub_herm n) < (11/9:ℝ) := by
  have hn3 : 3≤n := by omega
  have hsz := hub_card n (by omega)
  have hN : 4≤Fintype.card (Vertices (singletonWeights (n-1) n n) ⊕ Fin 0) := by omega
  obtain ⟨hy0,hy1,hy2,hy3,_,_,_,_,_,_,hyRest⟩ := profile n _ hn3 hsz
  have hUB := (actual_hub_benchmark_scores n 0 hn3 (hub_herm n)
    hN (target n _) hy0 hy1 hy2 hy3 hyRest).2.2 hn
  change l1 n _ (hub_herm n) < (if n=3 then (3047/2500:ℝ) else 1159/1000) at hUB
  have hnum : (if n=3 then (3047/2500:ℝ) else 1159/1000) < (11/9:ℝ) := by
    rcases hn with hh|hh <;> norm_num [hh]
  refine ⟨?_,hUB.trans hnum⟩
  have hQuart := singleton_ordered_quartet_score_eq n (n-1) n n 0 (by omega) (by omega) (by omega)
    (hub_herm n) hN (target n _) hy0 hy1 hy2 hy3 hyRest abs abs_zero
  change l1 n _ (hub_herm n) = _ at hQuart
  rw [hQuart]
  have hpos := singleton_second_pos (n-1) n n (by omega) (by omega) (by omega)
  linarith only [abs_nonneg (singletonQEigen (n-1) n n 0 - 2*(n:ℝ)),
    (abs_pos.mpr hpos.ne'), abs_nonneg (singletonQEigen (n-1) n n 2+(n:ℝ)),
    abs_nonneg (singletonQEigen (n-1) n n 3+(n:ℝ))]

/-- Small cases of the Manhattan arm. The n=3 result is already credited in
    the source paper; n=4 is the remaining finite case for this construction. -/
theorem manhattan_unique_minimizer_small (n : Nat) (hn : n=3 ∨ n=4)
    (A : Fin (3*n)→Fin (3*n)→Bool) (hS : ∀ i j,A i j=A j i) (hD : ∀ i,A i i=false) :
    ((¬ RelabelAs (realAdj A) (balanced n)) ∧
      (∀ (B : Fin (3*n) → Fin (3*n) → Bool) (hT : ∀ i j, B i j=B j i),
        (∀ i, B i i=false) → (¬ RelabelAs (realAdj B) (balanced n)) →
        l1 n _ (realAdjHerm A hS) ≤ l1 n _ (realAdjHerm B hT)))
    ↔ RelabelAs (realAdj A) (hub n) := by
  have hK : (balanced n).IsHermitian :=
    padded_herm TriangleSpectralFence.triangleSeed TriangleSpectralFence.triangleSeedHermitian
      (TriangleSpectralFence.triangleWeights n n n) 0
  have hKzero : l1 n _ hK=0 := by unfold l1; simp [balanced_matches_target n (by omega) hK]
  have hHub := hub_l1_bounds_small n hn
  have zeroOf {B : Fin (3*n) → Fin (3*n) → Bool} (hB : ∀ i j, B i j=B j i)
      (rel : RelabelAs (realAdj B) (balanced n)) : l1 n _ (realAdjHerm B hB)=0 := by
    obtain ⟨e,he⟩ := rel
    exact (l1_relabel n _ (realAdjHerm B hB) _ hK e he.symm).symm.trans hKzero
  have hubOf {B : Fin (3*n) → Fin (3*n) → Bool} (hB : ∀ i j, B i j=B j i)
      (rel : RelabelAs (realAdj B) (hub n)) : l1 n _ (realAdjHerm B hB)=l1 n _ (hub_herm n) := by
    obtain ⟨e,he⟩ := rel
    exact (l1_relabel n _ (realAdjHerm B hB) _ (hub_herm n) e he.symm).symm
  have excl {B : Fin (3*n) → Fin (3*n) → Bool} (hB : ∀ i j, B i j=B j i)
      (hr : RelabelAs (realAdj B) (hub n)) : ¬ RelabelAs (realAdj B) (balanced n) := by
    intro hb
    exact hHub.1.ne' ((hubOf hB hr).symm.trans (zeroOf hB hb))
  constructor
  · rintro ⟨hNot,hMin⟩
    obtain ⟨B,hBS,hBD,hr⟩ := hub_has_bool_representative n (by omega)
    have hc := (hMin B hBS hBD (excl hBS hr)).trans_lt ((hubOf hBS hr).trans_lt hHub.2)
    exact (classify_small n hn (Fintype.card_fin _) A hS hD hc).resolve_left hNot
  · intro hr
    refine ⟨excl hS hr,?_⟩
    intro B hT hDiag hNot
    by_contra! hc
    have hB := (classify_small n hn (Fintype.card_fin _) B hT hDiag
      (hc.trans ((hubOf hS hr).trans_lt hHub.2))).resolve_left hNot
    exact hc.ne ((hubOf hT hB).trans (hubOf hS hr).symm)

#print axioms manhattan_unique_minimizer_small

end ManhattanSmallFinal
