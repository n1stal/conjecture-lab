import Std
namespace ManhattanFinite
set_option maxRecDepth 100000
set_option maxHeartbeats 4000000

structure Shape where
  a : Nat
  b : Nat
  c : Nat
  d : Nat
  deriving DecidableEq, Repr

/-- Any spare vertices are isolates. The first three parts are nonempty; in the
triangle case sort all three parts, otherwise sort the two symmetric parts. -/
def rows (n : Nat) : List Shape :=
  ((List.range (3*n)).map (·+1)).flatMap fun a =>
  ((List.range (3*n-a)).map (·+1)).flatMap fun b =>
  ((List.range (3*n-a-b-b+1)).map (b+·)).flatMap fun c =>
  (List.range (3*n-a-b-c+1)).flatMap fun d =>
  if (a+b+c+d > 3*n) || (d == 0 && a > b) then [] else [⟨a,b,c,d⟩]

theorem mem_rows (n a b c d : Nat) (ha : 0 < a) (hb : 0 < b) (hbc : b ≤ c)
    (ht : a+b+c+d ≤ 3*n) (hs : d=0 → a≤b) : Shape.mk a b c d ∈ rows n := by
  unfold rows
  apply List.mem_flatMap.mpr
  refine ⟨a, List.mem_map.mpr ⟨a-1,List.mem_range.mpr (by omega),by omega⟩, ?_⟩
  apply List.mem_flatMap.mpr
  refine ⟨b, List.mem_map.mpr ⟨b-1,List.mem_range.mpr (by omega),by omega⟩, ?_⟩
  apply List.mem_flatMap.mpr
  refine ⟨c, List.mem_map.mpr ⟨c-b,List.mem_range.mpr (by omega),by omega⟩, ?_⟩
  apply List.mem_flatMap.mpr
  refine ⟨d, List.mem_range.mpr (by omega), ?_⟩
  have h : ¬ (d = 0 ∧ a>b) := by omega
  simp [Nat.not_lt_of_ge ht, h]

/-- 8^4 times the quartic evaluated at t/8. -/
def value (s : Shape) (t : Int) : Int :=
  let a : Int := s.a
  let b : Int := s.b
  let c : Int := s.c
  let d : Int := s.d
  t^4 - 64*(a*(b+c+d)+b*c)*t^2 - 1024*a*b*c*t + 4096*a*b*c*d
def passes (n : Nat) (s : Shape) : Bool :=
  (value s (16*(n:Int)-5) < 0) && (0 < value s (-8*(n:Int)-5)) && (0 < value s (-8*(n:Int)+5))
theorem small3 : (rows 3).filter (passes 3) =
    [⟨2,3,3,1⟩,⟨3,3,3,0⟩] := by decide
theorem small4 : (rows 4).filter (passes 4) =
    [⟨3,4,4,1⟩,⟨4,3,4,1⟩,⟨4,4,4,0⟩] := by decide
#print axioms mem_rows
#print axioms small3
#print axioms small4
end ManhattanFinite

namespace ManhattanFinite
set_option maxHeartbeats 4000000
set_option maxRecDepth 100000
def allRows (n : Nat) : List Shape :=
  ((List.range (3*n)).map (·+1)).flatMap fun a =>
  ((List.range (3*n-a)).map (·+1)).flatMap fun b =>
  ((List.range (3*n-a-b)).map (·+1)).flatMap fun c =>
  (List.range (3*n-a-b-c+1)).map fun d => ⟨a,b,c,d⟩
theorem mem_allRows (n a b c d : Nat) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c)
    (ht : a+b+c+d ≤ 3*n) : Shape.mk a b c d ∈ allRows n := by
  unfold allRows
  apply List.mem_flatMap.mpr
  refine ⟨a, List.mem_map.mpr ⟨a-1,List.mem_range.mpr (by omega),by omega⟩, ?_⟩
  apply List.mem_flatMap.mpr
  refine ⟨b, List.mem_map.mpr ⟨b-1,List.mem_range.mpr (by omega),by omega⟩, ?_⟩
  apply List.mem_flatMap.mpr
  refine ⟨c, List.mem_map.mpr ⟨c-1,List.mem_range.mpr (by omega),by omega⟩, ?_⟩
  exact List.mem_map.mpr ⟨d, List.mem_range.mpr (by omega), rfl⟩
theorem allSmall3 : (allRows 3).filter (passes 3) =
    [⟨2,3,3,1⟩,⟨3,3,3,0⟩] := by decide
theorem allSmall4 : (allRows 4).filter (passes 4) =
    [⟨3,4,4,1⟩,⟨4,3,4,1⟩,⟨4,4,3,1⟩,⟨4,4,4,0⟩] := by decide
#print axioms allSmall3
#print axioms allSmall4
end ManhattanFinite
