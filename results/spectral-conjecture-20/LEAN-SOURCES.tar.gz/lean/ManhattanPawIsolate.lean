import C20Bench

namespace PawIsolate
open Matrix Finset SpectralConjecture20 PawLargestFence PawUnbounded
open scoped BigOperators Matrix

theorem twice_deficit_le_manhattan_of_equal_sum {m : Type*} [Fintype m]
    (x y : m → ℝ) (hSum : (∑ i,x i)=∑ i,y i) (i : m) :
    2*(y i-x i)≤∑ j,|x j-y j| := by
  classical
  let d : m → ℝ := fun j => x j-y j
  have hD : ∑ j,d j=0 := by dsimp [d]; rw [Finset.sum_sub_distrib,hSum,sub_self]
  have h0 (j : m) : 0≤|d j|-d j := sub_nonneg.mpr (le_abs_self _)
  have h1 := single_le_sum (s := Finset.univ) (f := fun j => |d j|-d j)
    (fun j _ => h0 j) (Finset.mem_univ i)
  rw [Finset.sum_sub_distrib,hD,sub_zero] at h1
  have h2 := neg_le_abs (d i)
  dsimp [d] at h1 h2
  linarith only [h1,h2]

theorem paw_no_isolate_of_manhattan (n : Nat) (w : Fin 4 → Nat) (hw : ∀ i,0<w i)
    (z : Nat) (hSum : (∑ j,w j)+z=3*n)
    (hF : (withIsolates paw w z).IsHermitian)
    (y : Fin (Fintype.card (Vertices w ⊕ Fin z)) → ℝ)
    (hy : (∑ i,y i)=0) (hTop : ∃ i, 2*(n:ℝ)≤y i)
    (hClose : (∑ i,|hF.eigenvalues₀ i-y i|)<(4/3:ℝ)) : z=0 := by
  obtain ⟨i,hI⟩ := hTop
  have hTopCap := paw_full_spectral_cap w hw z hF i
  have hd (j : Fin 4) : paw j j=0 := by fin_cases j <;> rfl
  have hx := ordered_eigenvalue_sum_zero_of_diag _ hF (withIsolates_diagonal_zero paw hd w z)
  have hAbs := twice_deficit_le_manhattan_of_equal_sum hF.eigenvalues₀ y (hx.trans hy.symm) i
  have hS : (∑ j,(w j:ℝ))+(z:ℝ)=3*(n:ℝ) := by exact_mod_cast hSum
  by_contra! hZ
  have hZr : (1:ℝ)≤z := by exact_mod_cast (show 1≤z by omega)
  linarith only [hS,hAbs,hTopCap,hClose,hZr,hI]

#print axioms paw_no_isolate_of_manhattan
end PawIsolate

