import ManhattanSpectral

open Matrix Finset
open scoped BigOperators
namespace ManhattanMoment

theorem cube_variation (x y R : ℝ) (hR : 0 ≤ R) (hx : |x| ≤ R) (hy : |y| ≤ R) :
  |x^3-y^3| ≤ 3*R^2*|x-y| := by
  have xx : |x*x| ≤ R^2 := by rw [abs_mul,pow_two]; exact mul_le_mul hx hx (abs_nonneg _) hR
  have xy : |x*y| ≤ R^2 := by rw [abs_mul,pow_two]; exact mul_le_mul hx hy (abs_nonneg _) hR
  have yy : |y*y| ≤ R^2 := by rw [abs_mul,pow_two]; exact mul_le_mul hy hy (abs_nonneg _) hR
  have hq : |x*x+x*y+y*y| ≤ 3*R^2 := by
    linarith [abs_add_le (x*x+x*y) (y*y),abs_add_le (x*x) (x*y)]
  rw [show x^3-y^3=(x*x+x*y+y*y)*(x-y) by ring,abs_mul]
  exact mul_le_mul_of_nonneg_right hq (abs_nonneg _)

theorem spectral_cubic_positive {m : Type*} [Fintype m] (x y : m → ℝ) (n : ℝ)
    (hn : 3 ≤ n) (hx : ∑ i,x i=0) (hy : ∑ i,y i=0)
    (hyR : ∀ i, |y i| ≤ 2*n) (hcube : ∑ i, (y i)^3=6*n^3)
    (hClose : (∑ i, |x i-y i|)<(11/9:ℝ)) :
    0 < ∑ i,(x i)^3 := by
  let R := 2*n+11/18
  have hR : 0≤R := by dsimp [R]; linarith
  have hzero : ∑ i,(x i-y i)=0 := by rw [Finset.sum_sub_distrib,hx,hy,sub_zero]
  have hxR (i : m) : |x i| ≤ R := by
    have h := (ManhattanSpectral.twice_abs_of_zero_sum (fun i => x i-y i) hzero i).trans_lt hClose
    have tr := abs_add_le (x i-y i) (y i)
    rw [sub_add_cancel] at tr
    dsimp [R]
    linarith [hyR i]
  have hc (i : m) : |(x i)^3-(y i)^3| ≤ 3*R^2*|x i-y i| :=
    cube_variation _ _ R hR (hxR i) ((hyR i).trans (by dsimp [R]; linarith))
  have hs : |(∑ i,(x i)^3) - ∑ i,(y i)^3| ≤ 3*R^2*(∑ i, |x i-y i|) := by
    rw [←Finset.sum_sub_distrib,Finset.mul_sum]
    exact (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum (fun i _ => hc i))
  have hpoly : (11/3:ℝ)*(2*n+11/18)^2 < 6*n^3 := by
    nlinarith [sq_nonneg (n-3), mul_nonneg (sub_nonneg.mpr hn) (sq_nonneg (n-3))]
  have hfit : 3*R^2*(∑ i, |x i-y i|) ≤ (11/3:ℝ)*(2*n+11/18)^2 := by
    simpa [R,show 3*(2*n+11/18)^2*(11/9:ℝ)=(11/3:ℝ)*(2*n+11/18)^2 by ring] using
      mul_le_mul_of_nonneg_left hClose.le (by positivity : 0≤3*R^2)
  rw [hcube] at hs
  linarith [neg_le_abs ((∑ i,(x i)^3)-6*n^3), hs.trans (hfit.trans_lt hpoly).le,
    (hs.trans hfit).trans_lt hpoly]

theorem trace_cube_spectrum {m : Type*} [Fintype m] [DecidableEq m]
    (A : Matrix m m ℝ) (h : A.IsHermitian) :
    Matrix.trace (A*A*A) = ∑ i, (h.eigenvalues i)^3 := by
  let U : Matrix m m ℝ := h.eigenvectorUnitary
  have hs : star U = Uᵀ := by rw [star_eq_conjTranspose,conjTranspose_eq_transpose_of_trivial]
  have hU : Uᵀ*U=1 := by
    rw [←hs]
    exact Unitary.coe_star_mul_self h.eigenvectorUnitary
  let d := h.eigenvalues
  let D := diagonal d
  have eq : A=U*D*Uᵀ := by
    have hh := h.spectral_theorem
    rw [Unitary.conjStarAlgAut_apply, ← Unitary.coe_star] at hh
    change A = U * diagonal (RCLike.ofReal ∘ h.eigenvalues) * star U at hh
    rw [hs] at hh
    simpa using hh
  have prod : A*A*A=U*(D*D*D)*Uᵀ := by
    nth_rewrite 1 2 3 [eq]
    suffices h₁ : U*D*Uᵀ*(U*D*Uᵀ)=U*(D*D)*Uᵀ by
      rw [h₁]
      calc
        _ = U * (D*D) * (Uᵀ*U) * D * Uᵀ := by simp only [Matrix.mul_assoc]
        _ = _ := by simp only [hU,Matrix.mul_one,Matrix.mul_assoc]
    calc
      _ = U * D * (Uᵀ*U) * D * Uᵀ := by simp only [Matrix.mul_assoc]
      _ = _ := by simp only [hU,Matrix.mul_one,Matrix.mul_assoc]
  rw [prod, Matrix.trace_mul_cycle, hU, Matrix.one_mul]
  simp [D, diagonal_mul_diagonal, Matrix.trace_diagonal, pow_succ, d]

#print axioms spectral_cubic_positive
#print axioms trace_cube_spectrum
end ManhattanMoment
