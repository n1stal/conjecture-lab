import ManhattanTarget

namespace ManhattanSign
open ManhattanTarget
open Finset
open scoped BigOperators

private theorem product_one_negative {ι : Type*} [Fintype ι] [DecidableEq ι]
    (f : ι → ℝ) (i : ι) (hi : f i<0) (h : ∀ j, j≠i → 0<f j) :
    (∏ j, f j)<0 := by
  rw [←Finset.prod_erase_mul _ _ (Finset.mem_univ i)]
  exact mul_neg_of_pos_of_neg (Finset.prod_pos (fun j hj => h j (Finset.mem_erase.mp hj).1)) hi

private theorem product_two_negative {ι : Type*} [Fintype ι] [DecidableEq ι]
    (f : ι → ℝ) (i j : ι) (hij : i≠j) (hi : f i<0) (hj : f j<0)
    (h : ∀ k, k≠i → k≠j → 0<f k) : 0<(∏ k, f k) := by
  rw [← Finset.prod_erase_mul _ _ (Finset.mem_univ i)]
  have hj' : j∈Finset.univ.erase i := Finset.mem_erase.mpr ⟨hij.symm,Finset.mem_univ _⟩
  rw [← Finset.prod_erase_mul _ _ hj']
  rw [mul_assoc]
  apply mul_pos _ (mul_pos_of_neg_of_neg hj hi)
  apply Finset.prod_pos
  intro k hk
  exact h k (Finset.mem_erase.mp (Finset.mem_erase.mp hk).2).1 (Finset.mem_erase.mp hk).1

/-- The rational cuts on the four effective roots are unaffected by zero padding.
This statement does not assume a particular graph template or root inertia. -/
theorem exact_fence_signs {N : Nat} (hN : 4≤N) (f : Fin N → ℝ) (p : ℝ → ℝ)
    (n : ℝ) (hn : 3≤n)
    (hNear : ∀ i, |f i-balancedSpectrum n (by omega) i| < (5/8:ℝ))
    (hp : ∀ t, t^(N-4)*p t=∏ i, (t-f i)) :
    p (2*n-5/8) < 0 ∧ 0 < p (-n-5/8) ∧ 0 < p (-n+5/8) := by
  let h3 : 3≤N := by omega
  let i0 : Fin N := head h3
  let i1 : Fin N := penult h3
  let i2 : Fin N := last h3
  let y := balancedSpectrum n h3
  have h0 : y i0 = 2*n := by simp [y,i0,balancedSpectrum]
  have h1 : y i1 = -n := by simp [y,i1,balancedSpectrum, (head_ne_penult h3).symm]
  have h2 : y i2 = -n := by simp [y,i2,balancedSpectrum, (head_ne_last h3).symm]
  have hR (i : Fin N) (ha : i≠i0) (hb : i≠i1) (hc : i≠i2) : y i=0 := by
    simp [y,balancedSpectrum,show i≠head h3 from ha,show i≠penult h3 from hb,show i≠last h3 from hc]
  have hBox (i : Fin N) : -(5/8:ℝ) < f i-y i ∧ f i-y i < 5/8 :=
    abs_lt.mp (hNear i)
  have hp' (t : ℝ) : (-t)^(N-4)*p t=∏ i, (f i-t) := by
    have hpar : (-1:ℝ)^N = (-1)^(N-4) := by
      nth_rewrite 1 [show N=(N-4)+4 by omega]
      norm_num [pow_add]
    calc
      _ = (-1:ℝ)^N * (t^(N-4)*p t) := by
        rw [hpar,show -t=(-1:ℝ)*t by ring,mul_pow,mul_assoc]
      _ = (-1:ℝ)^N * (∏ i, (t-f i)) := by rw [hp]
      _ = ∏ i, ((-1:ℝ)*(t-f i)) := by
        rw [Finset.prod_mul_distrib]
        simp
      _ = ∏ i, (f i-t) := by
        apply Finset.prod_congr rfl
        intro j _
        ring
  constructor
  · have hx : (∏ i, (2*n-5/8-f i))<0 := by
      apply product_one_negative _ i0 (by linarith [h0,(hBox i0).1])
      intro i hi
      by_cases b : i=i1
      · subst i; linarith [h1,(hBox i1).2]
      by_cases c : i=i2
      · subst i; linarith [h2,(hBox i2).2]
      linarith [hR i hi b c,(hBox i).2]
    rw [← hp] at hx
    exact neg_of_mul_neg_right hx (pow_nonneg (by linarith) _)
  constructor
  · have hx : 0 < ∏ i, (f i-(-n-5/8)) := by
      apply Finset.prod_pos
      intro i _
      by_cases a : i=i0
      · subst i; linarith [h0,(hBox i0).1]
      by_cases b : i=i1
      · subst i; linarith [h1,(hBox i1).1]
      by_cases c : i=i2
      · subst i; linarith [h2,(hBox i2).1]
      linarith [hR i a b c,(hBox i).1]
    rw [←hp'] at hx
    exact pos_of_mul_pos_right hx (pow_nonneg (by linarith) _)
  · have hx : 0 < ∏ i, (f i-(-n+5/8)) := by
      apply product_two_negative _ i1 i2 (penult_ne_last h3)
        (by linarith [h1,(hBox i1).2]) (by linarith [h2,(hBox i2).2])
      intro i b c
      by_cases a : i=i0
      · subst i; linarith [h0,(hBox i0).1]
      linarith [hR i a b c,(hBox i).1]
    rw [← hp'] at hx
    exact pos_of_mul_pos_right hx (pow_nonneg (by linarith) _)

#print axioms exact_fence_signs
end ManhattanSign
