import ManhattanGraph
import ManhattanMoment

namespace ManhattanClose
open ManhattanGraph ManhattanSpectral ManhattanLocal Matrix Finset
open scoped BigOperators

theorem triangle_of_trace_cube {V : Type*} [Fintype V] [DecidableEq V]
    (A : V → V → Bool) (hsymm : ∀ x y, A x y = A y x) (hdiag : ∀ i, A i i = false)
    (hTrace : 0 < ((matrixOf A)*(matrixOf A)*(matrixOf A)).trace) :
    ∃ a : Fin 3 ↪ V, ∀ i j, A (a i) (a j) = decide (i≠j) := by
  by_contra! h
  have hz (i j k : V) : matrixOf A i j * matrixOf A j k * matrixOf A k i = 0 := by
    cases hij : A i j <;> cases hjk : A j k <;> cases hki : A k i <;>
      simp [matrixOf,hij,hjk,hki]
    have hNEij : i ≠ j := by intro r; subst j; simp [hdiag] at hij
    have hNEjk : j ≠ k := by intro r; subst k; simp [hdiag] at hjk
    have hNEki : k ≠ i := by intro r; subst k; simp [hdiag] at hki
    let f : Fin 3 → V := ![i,j,k]
    have hf : Function.Injective f := by
      intro x y hh
      fin_cases x <;> fin_cases y <;>
        first | rfl | exact False.elim (hNEij hh) | exact False.elim (hNEij hh.symm)
              | exact False.elim (hNEjk hh) | exact False.elim (hNEjk hh.symm)
              | exact False.elim (hNEki hh) | exact False.elim (hNEki hh.symm)
    exfalso
    obtain ⟨u,v,hn⟩ := h ⟨f,hf⟩
    apply hn
    change A (f u) (f v) = _
    have hji := (hsymm j i).trans hij
    have hkj := (hsymm k j).trans hjk
    have hik := (hsymm i k).trans hki
    fin_cases u <;> fin_cases v <;> simp [f,hdiag,hij,hjk,hki,hji,hkj,hik]
  have hZ : ((matrixOf A)*(matrixOf A)*(matrixOf A)).trace = 0 := by
    simp only [Matrix.trace,Matrix.diag,Matrix.mul_apply,Finset.sum_mul,hz,Finset.sum_const_zero]
  linarith

/-- A close loopless undirected graph is a weighted Paw with isolated vertices,
including the complete tripartite degeneration, with no extra graph hypotheses. -/
theorem close_graph_as_paw {V : Type*} [Fintype V] [DecidableEq V]
    (A : V → V → Bool) (hA : (matrixOf A).IsHermitian)
    (hsymm : ∀ x y, A x y = A y x) (hdiag : ∀ i, A i i = false)
    (n : ℝ) (hn : 3 ≤ n)
    (y : Fin (Fintype.card V) → ℝ) (hY : ∑ i, y i = 0)
    (hPos : Fintype.card {i // 0 < y i} ≤ 1)
    (hNeg : Fintype.card {i // y i < 0} ≤ 2)
    (hyR : ∀ i, |y i| ≤ 2*n) (hcube : ∑ i, (y i)^3=6*n^3)
    (hClose : (∑ i, |hA.eigenvalues₀ i-y i|) < (11/9:ℝ)) :
    ∃ color : V → Fin 5,
      (∀ x y, A x y = pawColorAdj (color x) (color y)) ∧
      (∃ x, color x=0) ∧ (∃ x, color x=1) ∧ (∃ x, color x=2) := by
  let q : Fin (Fintype.card V) ≃ V := Fintype.equivOfCardEq (Fintype.card_fin _)
  let y' : V → ℝ := fun i => y (q.symm i)
  have eqSum : ∑ i, y' i = ∑ i, y i := Equiv.sum_comp q.symm y
  have eqCube : ∑ i, (y' i)^3 = ∑ i, (y i)^3 := Equiv.sum_comp q.symm (fun i => (y i)^3)
  have eqClose : ∑ i, |hA.eigenvalues i-y' i| = ∑ i, |hA.eigenvalues₀ i-y i| :=
    Equiv.sum_comp q.symm (fun i => |hA.eigenvalues₀ i-y i|)
  have hZero := spectrum_sum_zero (matrixOf A) hA (by intro i; simp [matrixOf,hdiag])
  have hp := ManhattanMoment.spectral_cubic_positive hA.eigenvalues y' n hn hZero (eqSum.trans hY)
    (fun i => hyR (q.symm i)) (eqCube.trans hcube) (eqClose ▸ hClose)
  rw [←ManhattanMoment.trace_cube_spectrum _ hA] at hp
  obtain ⟨a,ha⟩ := triangle_of_trace_cube A hsymm hdiag hp
  exact triangle_as_paw A hsymm hdiag (labelled_of_cut A hA hdiag y hY hPos hNeg hClose) a ha

#print axioms close_graph_as_paw
end ManhattanClose
