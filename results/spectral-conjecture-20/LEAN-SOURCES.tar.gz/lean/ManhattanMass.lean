import Mathlib.Analysis.Matrix.Spectrum
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

open scoped BigOperators

namespace SpectralMass

private lemma sq_mass_le {ι : Type*} (s : Finset ι) (f : ι → ℝ)
    (hf : ∀ i, 0 ≤ f i) :
    (∑ i ∈ s, (f i)^2) ≤ (∑ i ∈ s, f i)^2 := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | insert a s ha ih =>
    simp only [Finset.sum_insert ha]
    have hs : 0 ≤ ∑ i ∈ s, f i := Finset.sum_nonneg fun i _ => hf i
    nlinarith only [ih, mul_nonneg (hf a) hs]

/-- An equal-sum difference list splits its absolute mass evenly between signs. -/
theorem sum_sq_le_half_abs_sq {ι : Type*} [Fintype ι] (f : ι → ℝ)
    (hf : ∑ i, f i = 0) :
    (∑ i, (f i)^2) ≤ (∑ i, |f i|)^2 / 2 := by
  let u i := max (f i) 0
  let v i := max (-f i) 0
  have hu (i : ι) : 0 ≤ u i := le_max_right _ _
  have hv (i : ι) : 0 ≤ v i := le_max_right _ _
  have hs (i : ι) :
      f i = u i - v i ∧ |f i| = u i + v i ∧ (f i)^2 = (u i)^2 + (v i)^2 := by
    by_cases h : 0 ≤ f i
    · simp [u,v,max_eq_left h,max_eq_right (neg_nonpos.mpr h),abs_of_nonneg h]
    · have h' : f i ≤ 0 := le_of_not_ge h
      simp [u,v,max_eq_right h',max_eq_left (neg_nonneg.mpr h'),abs_of_nonpos h']
  have hdiff : (∑ i, u i) - (∑ i, v i) = 0 := by
    rw [← Finset.sum_sub_distrib]
    exact (Finset.sum_congr rfl fun i _ => (hs i).1.symm).trans hf
  have habs : (∑ i, |f i|) = (∑ i, u i) + (∑ i, v i) := by
    rw [← Finset.sum_add_distrib]
    exact Finset.sum_congr rfl fun i _ => (hs i).2.1
  have hsq : (∑ i, (f i)^2) = (∑ i, (u i)^2) + (∑ i, (v i)^2) := by
    rw [← Finset.sum_add_distrib]
    exact Finset.sum_congr rfl fun i _ => (hs i).2.2
  have hEq : (∑ i, u i) = (∑ i, v i) := sub_eq_zero.mp hdiff
  rw [habs, hsq]
  have h1 := sq_mass_le Finset.univ u hu
  have h2 := sq_mass_le Finset.univ v hv
  rw [hEq] at h1 ⊢
  nlinarith only [h1,h2]

/-- For equal-trace spectral differences, any selected deficits are paid for
twice in the full absolute mass, whether or not the selected set is proper. -/
theorem twice_selected_deficit_le_abs_sum {ι : Type*} [Fintype ι] (s : Finset ι)
    (f : ι → ℝ) (hf : ∑ i, f i = 0) :
    -2 * (∑ i ∈ s, f i) ≤ ∑ i, |f i| := by
  let v (i : ι) := max (-f i) 0
  have hpoint (i : ι) : -f i ≤ v i := le_max_left _ _
  have hv (i : ι) : 0 ≤ v i := le_max_right _ _
  have hsum : -(∑ i ∈ s, f i) ≤ ∑ i ∈ s, v i := by
    rw [← Finset.sum_neg_distrib]
    exact Finset.sum_le_sum (fun i _ => hpoint i)
  have hle : (∑ i ∈ s, v i) ≤ ∑ i, v i :=
    Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _) (fun i _ _ => hv i)
  have heq (i : ι) : 2 * v i = |f i| - f i := by
    by_cases h : 0 ≤ f i
    · simp [v, max_eq_right (neg_nonpos.mpr h), abs_of_nonneg h]
    · have h' : f i ≤ 0 := le_of_not_ge h
      rw [abs_of_nonpos h']
      simp [v, max_eq_left (neg_nonneg.mpr h')]
      ring
  have hh : 2 * (∑ i, v i) = ∑ i, |f i| := by
    rw [Finset.mul_sum]
    simp_rw [heq]
    rw [Finset.sum_sub_distrib, hf, sub_zero]
  linarith only [hsum, hle, hh]

#print axioms twice_selected_deficit_le_abs_sum
#print axioms sum_sq_le_half_abs_sq
end SpectralMass

